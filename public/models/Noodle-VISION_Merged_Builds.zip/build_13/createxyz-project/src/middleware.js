import { NextResponse } from "next/server";

export const config = {
  matcher: "/integrations/:path*",
};

export function middleware(request) {
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-createxyz-project-id", "b6c0c80c-6cb7-46c8-af5b-5adc61a5bc0d");
  requestHeaders.set("x-createxyz-project-group-id", "ad21e40b-a703-4a8b-b757-003a3c39681f");


  request.nextUrl.href = `https://www.create.xyz/${request.nextUrl.pathname}`;

  return NextResponse.rewrite(request.nextUrl, {
    request: {
      headers: requestHeaders,
    },
  });
}