"use client";
import React from "react";

function MainComponent() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="bg-[#010101] text-white py-20 px-4 md:px-8 flex flex-col items-center justify-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">
          Welcome to Our AR/VR Platform For All Your Audio/Video Audio-Visual
        </h1>
        <p className="text-lg md:text-xl mb-8">
          Explore the "Now" of immersive experiences.
        </p>
        <button className="bg-[#121212] text-white px-6 py-3 rounded-md hover:bg-[#333] transition-colors duration-300">
          Sign Up Now
        </button>
      </div>

      {/* Subscription Tiers */}
      <div className="py-16 px-4 md:px-8">
        <h2 className="text-3xl font-bold mb-8">Choose Your Subscription</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-[#f5f5f5] p-8 rounded-md shadow-md">
            <h3 className="text-2xl font-bold mb-4">Basic</h3>
            <p className="text-4xl font-bold mb-4">$9/mo</p>
            <ul className="mb-8">
              <li className="flex items-center mb-2">
                <i className="fas fa-check-circle text-green-500 mr-2"></i>
                Feature 1
              </li>
              <li className="flex items-center mb-2">
                <i className="fas fa-check-circle text-green-500 mr-2"></i>
                Feature 2
              </li>
              <li className="flex items-center mb-2">
                <i className="fas fa-times-circle text-red-500 mr-2"></i>
                Feature 3
              </li>
            </ul>
            <button className="bg-[#121212] text-white px-6 py-3 rounded-md hover:bg-[#333] transition-colors duration-300">
              Subscribe
            </button>
          </div>
          {/* Repeat the above structure for the other subscription tiers */}
        </div>
      </div>

      {/* Testimonials */}
      <div className="bg-[#f5f5f5] py-16 px-4 md:px-8">
        <h2 className="text-3xl font-bold mb-8">What Our Users Say</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-md shadow-md">
            <p className="mb-4">
              "This platform has completely transformed my business. Highly
              recommended!"
            </p>
            <div className="flex items-center">
              <img
                src="user-avatar.jpg"
                alt="User Avatar"
                className="w-12 h-12 rounded-full mr-4"
              />
              <div>
                <h4 className="font-bold">John Doe</h4>
                <p className="text-gray-500">CEO, Acme Corp</p>
              </div>
            </div>
          </div>
          {/* Repeat the above structure for the other testimonials */}
        </div>
      </div>

      {/* Blog/Resource Center */}
      <div className="py-16 px-4 md:px-8">
        <h2 className="text-3xl font-bold mb-8">From Our Blog</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-[#f5f5f5] p-8 rounded-md shadow-md">
            <img
              src="blog-image-1.jpg"
              alt="Blog Post 1"
              className="w-full h-48 object-cover mb-4"
            />
            <h3 className="text-xl font-bold mb-2">
              Unlocking the Potential of AR/VR
            </h3>
            <p className="mb-4">
              Discover how our platform can help you harness the power of
              immersive technology.
            </p>
            <a href="#" className="text-[#121212] font-bold hover:underline">
              Read More
              <i className="fas fa-arrow-right ml-2"></i>
            </a>
          </div>
          {/* Repeat the above structure for the other blog posts */}
        </div>
      </div>

      <style jsx global>
        {`
          @keyframes fadeIn {
            0% {
              opacity: 0;
            }
            100% {
              opacity: 1;
            }
          }

          .animate-fade-in {
            animation: fadeIn 0.5s ease-in-out;
          }
        `}
      </style>
    </div>
  );
}

export default MainComponent;