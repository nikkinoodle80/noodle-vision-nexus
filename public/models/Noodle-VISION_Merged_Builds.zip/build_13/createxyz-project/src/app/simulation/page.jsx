"use client";
import React from "react";

function MainComponent() {
  const [scene, setScene] = React.useState([]);
  const [selectedEquipment, setSelectedEquipment] = React.useState(null);
  const [mode, setMode] = React.useState("AR");
  const [savedSetups, setSavedSetups] = React.useState([]);

  // 1. 3D rendering of the user's virtual environment
  const renderScene = () => {
    return (
      <div className="w-full h-[600px] bg-[#010101] relative">
        <></>
      </div>
    );
  };

  // 2. Sidebar for searching and adding equipment
  const renderEquipmentPanel = () => {
    return (
      <div className="bg-[#f5f5f5] p-4 rounded-md shadow-md">
        <h3 className="text-xl font-bold mb-4">Add Equipment</h3>
        <input
          type="text"
          placeholder="Search for equipment"
          className="w-full px-4 py-2 mb-4 rounded-md"
        />
        <div className="grid grid-cols-3 gap-4">
          {/* Render equipment options from web scraping/product search */}
        </div>
      </div>
    );
  };

  // 3. Tools for simulating connections and interactions
  const renderConnectionTools = () => {
    return (
      <div className="bg-[#f5f5f5] p-4 rounded-md shadow-md">
        <h3 className="text-xl font-bold mb-4">Connection Tools</h3>
        {/* Render tools for simulating connections and interactions */}
      </div>
    );
  };

  // 4. AR/VR mode switching
  const renderModeSwitch = () => {
    return (
      <div className="flex justify-end mb-4">
        <button
          className={`px-4 py-2 rounded-md transition-colors duration-300 ${
            mode === "AR"
              ? "bg-[#121212] text-white hover:bg-[#333]"
              : "bg-[#f5f5f5] text-[#121212] hover:bg-[#ddd]"
          }`}
          onClick={() => setMode("AR")}
        >
          AR Mode
        </button>
        <button
          className={`ml-4 px-4 py-2 rounded-md transition-colors duration-300 ${
            mode === "VR"
              ? "bg-[#121212] text-white hover:bg-[#333]"
              : "bg-[#f5f5f5] text-[#121212] hover:bg-[#ddd]"
          }`}
          onClick={() => setMode("VR")}
        >
          VR Mode
        </button>
      </div>
    );
  };

  // 5. Saving, loading, and sharing setups
  const renderSetupManagement = () => {
    return (
      <div className="bg-[#f5f5f5] p-4 rounded-md shadow-md">
        <h3 className="text-xl font-bold mb-4">Manage Setups</h3>
        <button className="bg-[#121212] text-white px-4 py-2 rounded-md mb-4 hover:bg-[#333] transition-colors duration-300">
          Save Current Setup
        </button>
        <div className="grid grid-cols-3 gap-4">
          {savedSetups.map((setup, index) => (
            <div
              key={index}
              className="bg-white p-4 rounded-md shadow-md cursor-pointer hover:bg-[#f5f5f5] transition-colors duration-300"
            >
              <img
                src={setup.previewImage}
                alt={`Setup ${index + 1}`}
                className="w-full h-32 object-cover mb-2"
              />
              <h4 className="text-lg font-bold">{setup.name}</h4>
              <p className="text-gray-500">{setup.description}</p>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // 6. Tutorials and guides
  const renderTutorials = () => {
    return (
      <div className="bg-[#f5f5f5] p-4 rounded-md shadow-md">
        <h3 className="text-xl font-bold mb-4">Tutorials</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded-md shadow-md">
            <h4 className="text-lg font-bold mb-2">Getting Started</h4>
            <p className="text-gray-500 mb-4">
              Learn how to use the AR/VR Simulation tools.
            </p>
            <a href="#" className="text-[#121212] font-bold hover:underline">
              Watch Tutorial
              <i className="fas fa-arrow-right ml-2"></i>
            </a>
          </div>
          {/* Add more tutorial cards as needed */}
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white py-8 px-4 md:px-8">
      {renderModeSwitch()}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="col-span-2">{renderScene()}</div>
        <div className="space-y-8">
          {renderEquipmentPanel()}
          {renderConnectionTools()}
          {renderSetupManagement()}
          {renderTutorials()}
        </div>
      </div>

      <style jsx global>
        {`
          @keyframes fadeIn {
            0% {
              opacity: 0;
            }
            100% {
              opacity: 1;
            }
          }

          .animate-fade-in {
            animation: fadeIn 0.5s ease-in-out;
          }
        `}
      </style>
    </div>
  );
}

export default MainComponent;