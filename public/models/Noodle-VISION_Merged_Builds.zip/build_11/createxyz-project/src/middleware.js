import { NextResponse } from "next/server";

export const config = {
  matcher: "/integrations/:path*",
};

export function middleware(request) {
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-createxyz-project-id", "95f73cf4-4196-4a2a-be21-59efcad77aef");
  requestHeaders.set("x-createxyz-project-group-id", "83ba07bb-7d22-4126-9002-82ecf1e941c5");


  request.nextUrl.href = `https://www.create.xyz/${request.nextUrl.pathname}`;

  return NextResponse.rewrite(request.nextUrl, {
    request: {
      headers: requestHeaders,
    },
  });
}