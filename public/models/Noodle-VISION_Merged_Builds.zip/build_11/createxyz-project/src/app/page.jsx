"use client";
import React from "react";

function MainComponent() {
  const [uploadedImage, setUploadedImage] = React.useState(null);
  const [devices, setDevices] = React.useState([
    {
      brand: "Denon",
      model: "AVR-3313CI",
      image: "https://manualsimg/manualsdenon/avr3313ci-rear.jpg",
      ports: [
        { label: "HDMI IN 1", type: "hdmi-in" },
        { label: "HDMI OUT", type: "hdmi-out" },
        { label: "COMPONENT IN", type: "component-in" },
        { label: "VGA IN", type: "vga-in" },
        { label: "AUDIO IN", type: "audio-in" },
        { label: "AUDIO OUT", type: "audio-out" },
      ],
    },
    {
      brand: "Sony",
      model: "KDL",
      image: "https://manualsimg/manualssony/kdl-rear.jpg",
      ports: [
        { label: "HDMI 1", type: "hdmi-in" },
        { label: "VGA", type: "vga-in" },
        { label: "AUDIO IN", type: "audio-in" },
      ],
    },
  ]);
  const [adapters, setAdapters] = React.useState([
    {
      name: "C-HDMI Adapter",
      input: "usb-c",
      output: "hdmi",
    },
    {
      name: "HDMI-VGA Adapter",
      input: "hdmi",
      output: "vga",
    },
  ]);
  const [addDeviceForm, setAddDeviceForm] = React.useState({
    Brand: "",
    Model: "",
    "Image URL": "",
    Ports: [{ Label: "", Type: "" }],
  });
  const [workspaceNodes, setWorkspaceNodes] = React.useState([]);
  const [workspaceCables, setWorkspaceCables] = React.useState([]);
  const [patchStatus, setPatchStatus] = React.useState(null);
  const [error, setError] = React.useState(null);

  function handleImageUpload(e) {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = function (ev) {
        setUploadedImage(ev.target.result);
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  }

  function handleAddDeviceFormChange(e, idx, portField) {
    const { name, value } = e.target;
    if (name === "Brand" || name === "Model" || name === "Image URL") {
      setAddDeviceForm({ ...addDeviceForm, [name]: value });
    } else if (name === "Label" || name === "Type") {
      const newPorts = addDeviceForm.Ports.map((port, i) =>
        i === idx ? { ...port, [name]: value } : port
      );
      setAddDeviceForm({ ...addDeviceForm, Ports: newPorts });
    }
  }

  function handleAddPort() {
    setAddDeviceForm({
      ...addDeviceForm,
      Ports: [...addDeviceForm.Ports, { Label: "", Type: "" }],
    });
  }

  function handleRemovePort(idx) {
    const newPorts = addDeviceForm.Ports.filter((_, i) => i !== idx);
    setAddDeviceForm({ ...addDeviceForm, Ports: newPorts });
  }

  function handleAddDevice(e) {
    e.preventDefault();
    if (
      !addDeviceForm.Brand ||
      !addDeviceForm.Model ||
      !addDeviceForm["Image URL"] ||
      addDeviceForm.Ports.some((p) => !p.Label || !p.Type)
    ) {
      setError("Please fill out all device fields.");
      return;
    }
    setDevices([
      ...devices,
      {
        brand: addDeviceForm.Brand,
        model: addDeviceForm.Model,
        image: addDeviceForm["Image URL"],
        ports: addDeviceForm.Ports.map((p) => ({
          label: p.Label,
          type: p.Type,
        })),
      },
    ]);
    setAddDeviceForm({
      Brand: "",
      Model: "",
      "Image URL": "",
      Ports: [{ Label: "", Type: "" }],
    });
    setError(null);
  }

  function handleAddNodeToWorkspace(deviceIdx) {
    const device = devices[deviceIdx];
    setWorkspaceNodes([
      ...workspaceNodes,
      {
        ...device,
        id: `${device.brand}-${device.model}-${workspaceNodes.length}`,
      },
    ]);
  }

  function handleCableConnect(fromNodeIdx, fromPortIdx, toNodeIdx, toPortIdx) {
    const fromNode = workspaceNodes[fromNodeIdx];
    const toNode = workspaceNodes[toNodeIdx];
    const fromPort = fromNode.ports[fromPortIdx];
    const toPort = toNode.ports[toPortIdx];
    let compatible = false;
    let warning = false;
    if (fromPort.type.split("-")[1] === toPort.type.split("-")[1]) {
      compatible = true;
    } else {
      const adapter = adapters.find(
        (a) =>
          (a.input === fromPort.type.replace("-in", "").replace("-out", "") &&
            a.output === toPort.type.replace("-in", "").replace("-out", "")) ||
          (a.output === fromPort.type.replace("-in", "").replace("-out", "") &&
            a.input === toPort.type.replace("-in", "").replace("-out", ""))
      );
      if (adapter) {
        compatible = true;
        warning = true;
      }
    }
    setWorkspaceCables([
      ...workspaceCables,
      {
        from: { node: fromNodeIdx, port: fromPortIdx },
        to: { node: toNodeIdx, port: toPortIdx },
      },
    ]);
    if (compatible && !warning) {
      setPatchStatus("success");
    } else if (compatible && warning) {
      setPatchStatus("warning");
    } else {
      setPatchStatus("error");
    }
  }

  function handleCloseFeedback() {
    setPatchStatus(null);
  }

  const feedbackMessages = [
    {
      status: "success",
      text: "Patch successful! Signal is flowing.",
    },
    {
      status: "warning",
      text: "Patch is unconventional, check adapter compatibility.",
    },
    {
      status: "error",
      text: "Patch failed. Ports or adapters are incompatible.",
    },
  ];

  let feedbackMessage = null;
  if (patchStatus) {
    feedbackMessage = feedbackMessages.find((m) => m.status === patchStatus);
  }

  return (
    <div className="min-h-screen bg-[#530808] font-roboto flex flex-col items-center py-4 px-2 md:px-8">
      <div className="w-full max-w-5xl">
        <h1 className="text-3xl md:text-4xl font-bold text-[#121212] mb-4 font-roboto flex items-center gap-2">
          <span className="text-[#1e90ff]">
            <i className="fas fa-heart"></i>
          </span>
          Noodle VISION Patch Bay
        </h1>
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <label className="block text-lg font-semibold mb-2 font-roboto">
            Rack/Device Panel Image
          </label>
          <input
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="block mb-2"
            name="panelImage"
          />
          {uploadedImage && (
            <div className="w-full flex justify-center">
              <img
                src={uploadedImage}
                alt="Uploaded rack or device panel"
                className="max-h-[300px] rounded shadow"
              />
            </div>
          )}
        </div>
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <h2 className="text-xl font-semibold mb-2 font-roboto">
            Add Device or Adapter
          </h2>
          <form onSubmit={handleAddDevice} className="space-y-2">
            <div className="flex flex-col md:flex-row gap-2">
              <input
                type="text"
                name="Brand"
                placeholder="Brand"
                value={addDeviceForm.Brand}
                onChange={handleAddDeviceFormChange}
                className="border rounded px-2 py-1 font-roboto"
              />
              <input
                type="text"
                name="Model"
                placeholder="Model"
                value={addDeviceForm.Model}
                onChange={handleAddDeviceFormChange}
                className="border rounded px-2 py-1 font-roboto"
              />
              <input
                type="text"
                name="Image URL"
                placeholder="Image URL"
                value={addDeviceForm["Image URL"]}
                onChange={handleAddDeviceFormChange}
                className="border rounded px-2 py-1 font-roboto"
              />
            </div>
            <div>
              <label className="block font-semibold font-roboto">Ports</label>
              {addDeviceForm.Ports.map((port, idx) => (
                <div key={idx} className="flex gap-2 mb-1">
                  <input
                    type="text"
                    name="Label"
                    placeholder="Label"
                    value={port.Label}
                    onChange={(e) => handleAddDeviceFormChange(e, idx)}
                    className="border rounded px-2 py-1 font-roboto"
                  />
                  <select
                    name="Type"
                    value={port.Type}
                    onChange={(e) => handleAddDeviceFormChange(e, idx)}
                    className="border rounded px-2 py-1 font-roboto"
                  >
                    <option value="">Type</option>
                    <option value="hdmi-in">HDMI In</option>
                    <option value="hdmi-out">HDMI Out</option>
                    <option value="vga-in">VGA In</option>
                    <option value="vga-out">VGA Out</option>
                    <option value="usb-c">USB-C</option>
                    <option value="audio-in">Audio In</option>
                    <option value="audio-out">Audio Out</option>
                    <option value="midi-in">MIDI In</option>
                    <option value="midi-out">MIDI Out</option>
                    <option value="bt-in">Bluetooth In</option>
                    <option value="bt-out">Bluetooth Out</option>
                    <option value="component-in">Component In</option>
                    <option value="component-out">Component Out</option>
                  </select>
                  {addDeviceForm.Ports.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemovePort(idx)}
                      className="text-red-500 font-bold"
                    >
                      <i className="fas fa-minus-circle"></i>
                    </button>
                  )}
                </div>
              ))}
              <button
                type="button"
                onClick={handleAddPort}
                className="text-green-600 font-bold mt-1"
              >
                <i className="fas fa-plus-circle"></i> Add Port
              </button>
            </div>
            {error && <div className="text-red-600 font-roboto">{error}</div>}
            <button
              type="submit"
              className="bg-[#1e90ff] text-white px-4 py-2 rounded font-roboto mt-2"
            >
              Add Device
            </button>
          </form>
          <div className="mt-4">
            <h3 className="font-semibold font-roboto mb-1">Existing Devices</h3>
            <div className="flex flex-wrap gap-4">
              {devices.map((device, idx) => (
                <div
                  key={idx}
                  className="border rounded p-2 w-[180px] flex flex-col items-center"
                >
                  <img
                    src={device.image}
                    alt={`Device ${device.brand} ${device.model} rear panel`}
                    className="w-[120px] h-[60px] object-cover rounded mb-1"
                  />
                  <div className="font-bold font-roboto text-sm">
                    {device.brand} {device.model}
                  </div>
                  <div className="text-xs font-roboto mb-1">
                    {device.ports.map((p, i) => (
                      <span key={i} className="inline-block mr-1">
                        {p.label}
                      </span>
                    ))}
                  </div>
                  <button
                    className="bg-[#1e90ff] text-white px-2 py-1 rounded text-xs font-roboto"
                    onClick={() => handleAddNodeToWorkspace(idx)}
                  >
                    Add to Workspace
                  </button>
                </div>
              ))}
            </div>
          </div>
          <div className="mt-4">
            <h3 className="font-semibold font-roboto mb-1">
              Existing Adapters
            </h3>
            <ul className="list-disc pl-5 font-roboto text-sm">
              {adapters.map((adapter, idx) => (
                <li key={idx}>
                  {adapter.name}: {adapter.input} → {adapter.output}
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <h2 className="text-xl font-semibold mb-2 font-roboto">
            Patch Bay Workspace
          </h2>
          <div className="relative w-full min-h-[200px] md:min-h-[300px] bg-[#e5e7eb] rounded flex flex-wrap gap-4 p-2">
            {uploadedImage && (
              <img
                src={uploadedImage}
                alt="Patch bay workspace background"
                className="absolute inset-0 w-full h-full object-contain opacity-20 pointer-events-none"
                style={{ zIndex: 0 }}
              />
            )}
            <div className="relative z-10 flex flex-wrap gap-4 w-full">
              {workspaceNodes.map((node, nodeIdx) => (
                <div
                  key={node.id}
                  className="bg-[#f1f5f9] border rounded p-2 w-[180px] flex flex-col items-center"
                >
                  <img
                    src={node.image}
                    alt={`Workspace device ${node.brand} ${node.model} rear panel`}
                    className="w-[120px] h-[60px] object-cover rounded mb-1"
                  />
                  <div className="font-bold font-roboto text-sm">
                    {node.brand} {node.model}
                  </div>
                  <div className="flex flex-col gap-1 mt-1">
                    {node.ports.map((port, portIdx) => (
                      <div key={portIdx} className="flex items-center gap-1">
                        <span className="text-xs font-roboto">
                          {port.label}
                        </span>
                        <button
                          className="text-[#1e90ff] text-xs"
                          onClick={() => {
                            if (workspaceNodes.length < 2) return;
                            const toNodeIdx =
                              (nodeIdx + 1) % workspaceNodes.length;
                            const toPortIdx = 0;
                            handleCableConnect(
                              nodeIdx,
                              portIdx,
                              toNodeIdx,
                              toPortIdx
                            );
                          }}
                          name="connectPort"
                        >
                          <i className="fas fa-plug"></i>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
              {workspaceCables.map((cable, idx) => {
                const fromNode = workspaceNodes[cable.from.node];
                const toNode = workspaceNodes[cable.to.node];
                if (!fromNode || !toNode) return null;
                const x1 = 100 + cable.from.node * 200;
                const y1 = 80 + cable.from.port * 20;
                const x2 = 100 + cable.to.node * 200;
                const y2 = 80 + cable.to.port * 20;
                return (
                  <line
                    key={idx}
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke="green"
                    strokeWidth="4"
                    strokeDasharray="8,4"
                  />
                );
              })}
            </svg>
          </div>
        </div>
        {patchStatus && feedbackMessage && (
          <div className="fixed bottom-4 left-1/2 -translate-x-1/2 bg-white border shadow-lg rounded-lg px-6 py-4 flex items-center gap-3 z-50 font-roboto">
            <span>
              {patchStatus === "success" && (
                <i className="fas fa-check-circle text-green-500"></i>
              )}
              {patchStatus === "warning" && (
                <i className="fas fa-exclamation-triangle text-yellow-500"></i>
              )}
              {patchStatus === "error" && (
                <i className="fas fa-times-circle text-red-500"></i>
              )}
            </span>
            <span>{feedbackMessage.text}</span>
            <button
              className="ml-4 text-[#1e90ff] font-bold"
              onClick={handleCloseFeedback}
              name="closeFeedback"
            >
              Close
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;