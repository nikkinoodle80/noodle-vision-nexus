"use client";
import React from "react";



export default function Index() {
  return (function MainComponent() {
  const [cables, setCables] = React.useState([]);
  const [draggingCable, setDraggingCable] = React.useState(null);
  const connectionPoints = [
    { x: 50, y: 50 },
    { x: 150, y: 50 },
    { x: 250, y: 50 },
  ];

  const handleCableDragStart = (index) => {
    setDraggingCable(index);
  };

  const handleCableDragEnd = (index) => {
    setDraggingCable(null);
    // Snap to nearest connection point
    const nearestPoint = connectionPoints.reduce((prev, curr) => {
      const prevDistance = Math.hypot(
        prev.x - cables[index].end.x,
        prev.y - cables[index].end.y,
      );
      const currDistance = Math.hypot(
        curr.x - cables[index].end.x,
        curr.y - cables[index].end.y,
      );
      return currDistance < prevDistance ? curr : prev;
    });
    setCables((prevCables) =>
      prevCables.map((cable, i) =>
        i === index ? { ...cable, end: nearestPoint } : cable,
      ),
    );
  };

  const handleCableDrag = (e, index) => {
    if (draggingCable === index) {
      setCables((prevCables) =>
        prevCables.map((cable, i) =>
          i === index
            ? {
                ...cable,
                end: { x: e.clientX, y: e.clientY },
              }
            : cable,
        ),
      );
    }
  };

  const addCable = () => {
    setCables((prevCables) => [
      ...prevCables,
      { start: { x: 0, y: 0 }, end: { x: 0, y: 0 } },
    ]);
  };

  return (
    <div style={{ position: "relative", width: "100%", height: "100vh" }}>
      {connectionPoints.map((point, index) => (
        <div
          key={index}
          style={{
            position: "absolute",
            left: point.x,
            top: point.y,
            width: "10px",
            height: "10px",
            backgroundColor: "red",
            borderRadius: "50%",
          }}
        />
      ))}
      {cables.map((cable, index) => (
        <svg
          key={index}
          style={{ position: "absolute", pointerEvents: "none" }}
          onMouseMove={(e) => handleCableDrag(e, index)}
          onMouseUp={() => handleCableDragEnd(index)}
        >
          <line
            x1={cable.start.x}
            y1={cable.start.y}
            x2={cable.end.x}
            y2={cable.end.y}
            stroke="black"
            strokeWidth="2"
          />
        </svg>
      ))}
      <button
        onClick={addCable}
        style={{ position: "absolute", top: "10px", right: "10px" }}
      >
        Add Cable
      </button>
    </div>
  );
}

function StoryComponent() {
  return (
    <div>
      <MainComponent />
    </div>
  );
});
}