"use client";
import React from "react";

function MainComponent() {
  const [position, setPosition] = React.useState({ x: 0, y: 0 });
  const [scale, setScale] = React.useState(1);
  const [cables, setCables] = React.useState([]);
  const [imageUrl, setImageUrl] = React.useState(null);
  const [prompt, setPrompt] = React.useState("");
  const [loading, setLoading] = React.useState(false);

  const [isCanvasDragging, setIsCanvasDragging] = React.useState(false);
  const [draggingCable, setDraggingCable] = React.useState(null);
  const dragStartRef = React.useRef({ x: 0, y: 0 });
  const canvasRef = React.useRef(null);

  const initialPosition = { x: 0, y: 0 };
  const initialCables = [];
  const connectionPoints = [
    { id: "p1", x: 100, y: 100 },
    { id: "p2", x: 250, y: 100 },
    { id: "p3", x: 400, y: 100 },
    { id: "p4", x: 100, y: 400 },
    { id: "p5", x: 250, y: 400 },
    { id: "p6", x: 400, y: 400 },
  ];

  const getMousePosition = (e) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return { x: 0, y: 0 };
    return {
      x: (e.clientX - rect.left - position.x) / scale,
      y: (e.clientY - rect.top - position.y) / scale,
    };
  };
}

export default MainComponent;