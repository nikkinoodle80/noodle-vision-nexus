"use client";
import React from "react";

function MainComponent() {
  const [backgroundImage, setBackgroundImage] = React.useState("");
  const [loadingImage, setLoadingImage] = React.useState(true);
  const [errorImage, setErrorImage] = React.useState(null);
  const [userDeviceInput, setUserDeviceInput] = React.useState("");
  const [configResult, setConfigResult] = React.useState("");
  const [loadingConfig, setLoadingConfig] = React.useState(false);
  const [errorConfig, setErrorConfig] = React.useState(null);

  React.useEffect(() => {
    const fetchImage = async () => {
      try {
        setLoadingImage(true);
        const response = await fetch(
          "/integrations/stable-diffusion-v-3/?prompt=futuristic+glowing+network+of+interconnected+audio+visual+equipment+holographic+interface+cyberpunk+aesthetic+vibrant+colors"
        );
        if (!response.ok) {
          throw new Error(
            `Failed to fetch image: ${response.status} ${response.statusText}`
          );
        }
        const data = await response.json();
        if (data.data && data.data.length > 0) {
          setBackgroundImage(data.data[0]);
        } else {
          throw new Error("No image returned from API");
        }
      } catch (err) {
        console.error("Error fetching background image:", err);
        setErrorImage("Could not load background image. Using fallback.");
        setBackgroundImage(
          "https://via.placeholder.com/1920x1080/000022?text=Futuristic+A/V+Connections"
        );
      } finally {
        setLoadingImage(false);
      }
    };
    fetchImage();
  }, []);

  const handleDeviceConfigSearch = React.useCallback(async () => {
    if (!userDeviceInput.trim()) {
      setErrorConfig("Please enter your A/V devices.");
      return;
    }
    setLoadingConfig(true);
    setErrorConfig(null);
    setConfigResult("");
    try {
      const response = await fetch("/integrations/chat-gpt/conversationgpt4", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [
            {
              role: "system",
              content:
                "You are an A/V equipment setup expert. Provide a simple, brief wiring configuration step or a fun fact based on the user's devices. Keep it very short and conceptual for this demo.",
            },
            {
              role: "user",
              content: `Suggest a wiring configuration for: ${userDeviceInput}`,
            },
          ],
        }),
      });
      if (!response.ok) {
        throw new Error(
          `Configuration API error: ${response.status} ${response.statusText}`
        );
      }
      const data = await response.json();
      if (data.choices && data.choices.length > 0 && data.choices[0].message) {
        setConfigResult(data.choices[0].message.content);
      } else {
        throw new Error("Unexpected response format from configuration API.");
      }
    } catch (err) {
      console.error("Error fetching configuration:", err);
      setErrorConfig("Could not fetch configuration. Please try again.");
      setConfigResult(
        "Example: Connect HDMI Out from Source to HDMI In on Display."
      );
    } finally {
      setLoadingConfig(false);
    }
  }, [userDeviceInput]);

  const heroStyle = {
    backgroundImage: `url(${backgroundImage})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    minHeight: "400px",
  };

  const navLinkStyle =
    "text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium transition-colors duration-300";
  const sectionStyle = "py-12 md:py-16 bg-opacity-90 backdrop-blur-sm";
  const titleStyle =
    "text-3xl sm:text-4xl lg:text-5xl font-bold mb-6 text-center";
  const cardStyle =
    "bg-[#1a202c] bg-opacity-75 p-6 rounded-lg shadow-xl hover:shadow-2xl transition-shadow duration-300 backdrop-blur-md";
  const inputStyle =
    "w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-[#63b3ed] focus:border-transparent outline-none";
  const buttonStyle =
    "px-6 py-3 bg-gradient-to-r from-[#63b3ed] to-[#4299e1] text-white font-semibold rounded-lg shadow-md hover:shadow-lg hover:from-[#4299e1] hover:to-[#3182ce] transition-all duration-300 transform hover:scale-105 disabled:opacity-50";

  return (
    <div className="min-h-screen bg-[#0a0f18] text-gray-200 font-roboto">
      <nav className="bg-[#111827] bg-opacity-80 shadow-lg sticky top-0 z-50 backdrop-filter backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <span className="font-bold text-xl text-white">
                AVConnect Pro
              </span>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <a href="#" className={navLinkStyle}>
                  Home
                </a>
                <a href="#simulators" className={navLinkStyle}>
                  Simulators
                </a>
                <a href="#diagrams" className={navLinkStyle}>
                  Diagrams
                </a>
                <a href="#community" className={navLinkStyle}>
                  Community
                </a>
                <a href="#blog" className={navLinkStyle}>
                  Blog
                </a>
                <a href="#subscriptions" className={navLinkStyle}>
                  Subscriptions
                </a>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {loadingImage && (
        <div className="flex justify-center items-center min-h-[400px] bg-[#0a0f18]">
          <div className="text-xl">Loading awesome background...</div>
        </div>
      )}
      {errorImage && !loadingImage && (
        <div className="flex justify-center items-center min-h-[400px] bg-red-900 text-white p-4">
          <p>{errorImage}</p>
        </div>
      )}
      {!loadingImage && backgroundImage && (
        <header
          style={heroStyle}
          className="flex items-center justify-center text-center text-white relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-black opacity-60"></div>
          <div className="relative z-10 p-8">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-4 animate-pulse">
              Connect Your A/V World
            </h1>
            <p className="text-lg sm:text-xl md:text-2xl mb-8">
              Interactive guides, simulators, and community support for all your
              audio-visual setup needs.
            </p>
            <a href="#simulators" className={`${buttonStyle} text-lg`}>
              Get Started
            </a>
          </div>
        </header>
      )}

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <section className={sectionStyle}>
          <div className="text-center mb-12">
            <h2 className={titleStyle}>Master Your A/V Connections</h2>
            <p className="mt-4 text-lg text-gray-400 max-w-3xl mx-auto">
              From basic setups to complex integrations, AVConnect Pro provides
              the tools and knowledge you need. Explore interactive simulations,
              detailed diagrams, and a vibrant community.
            </p>
          </div>
        </section>

        <section id="simulators" className={sectionStyle}>
          <h2 className={titleStyle}>Interactive Wiring Simulators</h2>
          <div className={cardStyle}>
            <p className="text-gray-400 mb-4 text-center">
              Input your devices (e.g., "Sony TV, Yamaha Receiver, PS5") and
              instantly see a clear, step-by-step wiring configuration tailored
              to your specific gear. Experiment with different setups before you
              touch a cable!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 items-center">
              <input
                type="text"
                name="userDeviceInput"
                value={userDeviceInput}
                onChange={(e) => setUserDeviceInput(e.target.value)}
                placeholder="Enter your devices here"
                className={`${inputStyle} flex-grow`}
              />
              <button
                onClick={handleDeviceConfigSearch}
                className={buttonStyle}
                disabled={loadingConfig}
              >
                {loadingConfig ? "Generating..." : "Show Configuration"}
              </button>
            </div>
            {errorConfig && (
              <p className="text-red-400 mt-4 text-center">{errorConfig}</p>
            )}
            {configResult && !loadingConfig && (
              <div className="mt-6 p-4 bg-gray-800 rounded-lg">
                <h4 className="font-semibold text-lg mb-2 text-white">
                  Suggested Setup:
                </h4>
                <p className="text-gray-300 whitespace-pre-wrap">
                  {configResult}
                </p>
              </div>
            )}
          </div>
        </section>

        <section id="diagrams" className={sectionStyle}>
          <h2 className={titleStyle}>Extensive Diagram Library</h2>
          <div className={cardStyle}>
            <p className="text-gray-400 text-center">
              Explore our comprehensive library of detailed wiring diagrams.
              Search by device type, brand, or specific connection challenge to
              find high-resolution, easy-to-follow visual guides. New diagrams
              are added regularly based on community requests and new tech
              releases.
            </p>
            <div className="mt-4 text-center">
              <i className="fas fa-project-diagram fa-3x text-[#63b3ed]"></i>
            </div>
          </div>
        </section>

        <section id="inventory" className={sectionStyle}>
          <h2 className={titleStyle}>Manage Your Gear</h2>
          <div className={cardStyle}>
            <p className="text-gray-400 text-center">
              Keep track of your A/V equipment in your personal inventory. Get
              personalized setup advice, discover compatible accessories, find
              alternative wiring solutions for your specific gear, and receive
              reports on potential upgrades or if any of your equipment is
              outdated. Sign up to start building your virtual A/V closet!
            </p>
            <div className="mt-4 text-center">
              <i className="fas fa-cogs fa-3x text-[#63b3ed]"></i>
            </div>
          </div>
        </section>

        <section id="community" className={sectionStyle}>
          <h2 className={titleStyle}>Join Our Community</h2>
          <div className={cardStyle}>
            <p className="text-gray-400 text-center">
              Dive into the AVConnect Pro community! Share your unique setups in
              our forums, ask tricky questions and get help from fellow
              enthusiasts and experts, and stay updated with our insightful
              expert blog covering the latest A/V trends and troubleshooting
              tips.
            </p>
            <div className="mt-4 text-center">
              <i className="fas fa-users fa-3x text-[#63b3ed]"></i>
            </div>
          </div>
        </section>

        <section id="future-tech" className={sectionStyle}>
          <h2 className={titleStyle}>The Future of A/V</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className={cardStyle}>
              <h3 className="text-2xl font-semibold mb-3 text-white">
                VR/AR Experiences
              </h3>
              <p className="text-gray-400">
                Imagine virtually assembling your dream A/V system! Our upcoming
                VR/AR features will allow you to interactively learn, experiment
                with complex setups, and visualize connections in immersive 3D
                environments, making even the most daunting installations
                intuitive.
              </p>
              <div className="mt-4 text-center">
                <i className="fas fa-vr-cardboard fa-3x text-[#63b3ed]"></i>
              </div>
            </div>
            <div className={cardStyle}>
              <h3 className="text-2xl font-semibold mb-3 text-white">
                AI-Powered Updates
              </h3>
              <p className="text-gray-400">
                Stay ahead of the curve! Our AI engine continuously scans the
                A/V landscape for new technologies, emerging standards, user
                reviews, and compatibility information. This means our guides,
                simulators, and recommendations are always current, ensuring you
                get the best possible advice.
              </p>
              <div className="mt-4 text-center">
                <i className="fas fa-robot fa-3x text-[#63b3ed]"></i>
              </div>
            </div>
          </div>
        </section>

        <section id="subscriptions" className={sectionStyle}>
          <h2 className={titleStyle}>Unlock Premium Features</h2>
          <div className={cardStyle}>
            <p className="text-gray-400 text-center">
              Elevate your A/V expertise with a Pro subscription! Gain access to
              our most advanced simulation tools with expanded device libraries,
              exclusive in-depth guides for complex scenarios, an ad-free
              browsing experience, priority support, and be the first to try
              groundbreaking features like custom adapter chain builders and our
              interactive VR/AR learning modules.
            </p>
            <div className="mt-4 text-center">
              <button
                className={`${buttonStyle} opacity-70 cursor-not-allowed`}
              >
                View Plans
              </button>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-[#111827] bg-opacity-80 mt-16 py-8 text-center text-gray-400 backdrop-filter backdrop-blur-lg">
        <p>
          &copy; {new Date().getFullYear()} AVConnect Pro. All rights reserved.
        </p>
        <p className="text-sm">
          Revolutionizing A/V connections, one cable at a time.
        </p>
        <div className="mt-4">
          <a href="#" className="text-gray-400 hover:text-white mx-2">
            <i className="fab fa-facebook fa-lg"></i>
          </a>
          <a href="#" className="text-gray-400 hover:text-white mx-2">
            <i className="fab fa-twitter fa-lg"></i>
          </a>
          <a href="#" className="text-gray-400 hover:text-white mx-2">
            <i className="fab fa-youtube fa-lg"></i>
          </a>
        </div>
      </footer>

      <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
      />

      <style jsx global>{`
        @keyframes pulse {
          0%, 100% {
            opacity: 1;
            transform: scale(1);
          }
          50% {
            opacity: 0.8;
            transform: scale(1.02);
          }
        }
        .animate-pulse {
          animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        body {
          scroll-behavior: smooth;
        }
      `}</style>
    </div>
  );
}

export default MainComponent;