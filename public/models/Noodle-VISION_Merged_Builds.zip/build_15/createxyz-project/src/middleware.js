import { NextResponse } from "next/server";

export const config = {
  matcher: "/integrations/:path*",
};

export function middleware(request) {
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-createxyz-project-id", "8e3b2824-26c6-479f-be0d-cd0cac3058a9");
  requestHeaders.set("x-createxyz-project-group-id", "d7c34214-fa16-4034-8cac-295dfaf90252");


  request.nextUrl.href = `https://www.create.xyz/${request.nextUrl.pathname}`;

  return NextResponse.rewrite(request.nextUrl, {
    request: {
      headers: requestHeaders,
    },
  });
}