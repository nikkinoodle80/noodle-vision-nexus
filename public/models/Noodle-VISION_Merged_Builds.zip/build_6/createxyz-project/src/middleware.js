import { NextResponse } from "next/server";

export const config = {
  matcher: "/integrations/:path*",
};

export function middleware(request) {
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-createxyz-project-id", "e12bf3bd-13a0-4404-8b2c-3052f934b23d");
  requestHeaders.set("x-createxyz-project-group-id", "92a37ff2-2e37-401f-b3c8-882a75d67d5a");


  request.nextUrl.href = `https://www.create.xyz/${request.nextUrl.pathname}`;

  return NextResponse.rewrite(request.nextUrl, {
    request: {
      headers: requestHeaders,
    },
  });
}