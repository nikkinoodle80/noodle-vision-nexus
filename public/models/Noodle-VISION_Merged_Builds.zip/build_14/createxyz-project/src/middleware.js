import { NextResponse } from "next/server";

export const config = {
  matcher: "/integrations/:path*",
};

export function middleware(request) {
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-createxyz-project-id", "fe7fab9e-5451-4d69-824f-5d0b23f7577b");
  requestHeaders.set("x-createxyz-project-group-id", "c09a05b2-f92c-4fa3-a345-051ee42bf8d7");


  request.nextUrl.href = `https://www.create.xyz/${request.nextUrl.pathname}`;

  return NextResponse.rewrite(request.nextUrl, {
    request: {
      headers: requestHeaders,
    },
  });
}