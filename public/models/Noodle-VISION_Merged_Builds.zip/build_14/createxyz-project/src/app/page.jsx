"use client";
import React from "react";

function MainComponent() {
  // REMOVED: useEffect for Stable Diffusion backgroundImage (and its state)
  // REMOVED: useEffect for Google Search (and its state for stats)

  const { data: user } = useUser();

  // Using a static background color now
  return (
    <div className="flex flex-col min-h-screen bg-gray-800 text-white font-roboto">
      <nav className="w-full bg-black bg-opacity-50 p-4 shadow-lg">
        <div className="container mx-auto flex justify-between items-center">
          <a
            href="/"
            className="text-2xl font-bold text-[#00B2FF] hover:text-white transition-colors"
          >
            A/V Connect
          </a>
          <div className="space-x-4">
            <a
              href="/devices"
              className="hover:text-[#00B2FF] transition-colors"
            >
              Browse Devices
            </a>
            <a href="/blog" className="hover:text-[#00B2FF] transition-colors">
              Blog
            </a>
            <a
              href="/community"
              className="hover:text-[#00B2FF] transition-colors"
            >
              Community
            </a>
            {user ? (
              <>
                <a
                  href="/my-gear"
                  className="hover:text-[#00B2FF] transition-colors"
                >
                  My Gear
                </a>
                <a
                  href="/subscription"
                  className="hover:text-[#00B2FF] transition-colors"
                >
                  Subscription
                </a>
                <a
                  href="/account/logout"
                  className="hover:text-[#00B2FF] transition-colors"
                >
                  Sign Out
                </a>
              </>
            ) : (
              <>
                <a
                  href="/account/signin"
                  className="hover:text-[#00B2FF] transition-colors"
                >
                  Sign In
                </a>
                <a
                  href="/account/signup"
                  className="bg-[#0072C6] text-white px-4 py-2 rounded-md hover:bg-[#0052A6] transition-colors"
                >
                  Sign Up
                </a>
              </>
            )}
          </div>
        </div>
      </nav>

      <main className="flex-grow flex flex-col items-center justify-center text-center p-8 bg-black bg-opacity-30">
        <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
          Master Your A/V Universe
        </h1>
        <p className="text-xl md:text-2xl text-gray-300 mb-10 max-w-2xl">
          From tangled wires to perfect setups. Input your devices, get custom
          wiring diagrams, explore upgrade paths, and connect with a vibrant
          community.
        </p>
        <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-6">
          <a
            href="/devices"
            className="bg-[#0072C6] text-white font-bold py-3 px-8 rounded-lg text-lg hover:bg-[#0052A6] transition-colors duration-300 shadow-xl"
          >
            Explore Devices
          </a>
          <a
            href="/community"
            className="bg-transparent text-white font-bold py-3 px-8 rounded-lg text-lg border-2 border-white hover:bg-white hover:text-[#0072C6] transition-colors duration-300 shadow-xl"
          >
            Join Community
          </a>
        </div>
      </main>

      <footer className="w-full bg-black bg-opacity-70 p-4 text-center">
        <p className="text-sm text-gray-400">
          &copy; 2025 A/V Connect. All rights reserved.
        </p>
        <p className="text-xs text-gray-500">
          High-tech connections, simplified.
        </p>
      </footer>
    </div>
  );
}

export default MainComponent;