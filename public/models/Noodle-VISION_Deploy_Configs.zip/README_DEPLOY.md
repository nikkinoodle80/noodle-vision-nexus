# Noodle‑VISION Deploy Guide (GitHub: noodle-vision/nvg1, branch: main)

## Quick Start
```bash
git clone https://github.com/noodle-vision/nvg1.git
cd nvg1
unzip ../Noodle-VISION_Merged_Builds.zip -d ./
npm install
npm run build
npm start
```

## Replit
- The included `.replit` lets you run `npm run dev`.

## Render
- Use `render.yaml` with Node build & start commands.
- Store secrets in Render dashboard, not in repo.

## Branching
- `main` → production
- `dev` → agent auto-uploads
- `assets` → large scenes & media

## Required ENV
See `.env.example` for placeholders you must fill in:
- NOTION_TOKEN
- GOOGLE_OAUTH_TOKEN
- STRIPE_SECRET_KEY
- SUPABASE_URL
- SUPABASE_ANON_KEY
- NEXT_PUBLIC_* as needed
