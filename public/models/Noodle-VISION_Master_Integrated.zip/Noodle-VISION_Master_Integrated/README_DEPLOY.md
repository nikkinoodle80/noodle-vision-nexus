# Deployment Guide for Noodle-VISION Master Build

Congratulations on reaching the final Noodle‑VISION Master build! This package bundles your Create.xyz builds (#1–16) into a single, unified project with everything needed for deployment.

## Repository Structure

```
createxyz-project/      → Next.js + Tailwind app with full simulator and API logic
README_DEPLOY.md       → This deployment guide
.env.example           → Example environment file with placeholders
```

The main app is under `createxyz-project`. You can run and develop locally with `npm run dev` and deploy to production with `npm run build` followed by `npm start`.

## Environment Configuration

Create a `.env` file in the project root (alongside `README_DEPLOY.md`), or define these variables directly in your hosting service (e.g. Render, Netlify). Use the placeholders below as a guide and replace the 🔹 prompts with your actual keys.

```
# ===== SUPABASE =====
NEXT_PUBLIC_SUPABASE_URL="https://lektchshcgubtxouwdmq.supabase.co"
NEXT_PUBLIC_SUPABASE_ANON_KEY="🔹 Copy from Supabase → Project Settings → API → anon public key"
SUPABASE_SERVICE_KEY="🔹 Copy from Supabase → Project Settings → API → service_role key"
SUPABASE_OAUTH_CALLBACK_URL="https://lektchshcgubtxouwdmq.supabase.co/auth/v1/callback"

# ===== BASEROW =====
BASEROW_URL="🔹 Copy from Baserow → API Docs → Table endpoint URL (ends with /api/database/rows/table/<TABLE_ID>)"
BASEROW_TOKEN="🔹 Copy from Baserow → Account → API token"

# ===== NOTION =====
NOTION_TOKEN="🔹 Copy from Notion → My Integrations → Internal Integration Token"

# ===== MCP-LINK =====
MCP_API_KEY="🔹 Paste your MCP key (Bearer mcp-xxxxxxxxx)"

# ===== RENDER =====
RENDER_API_KEY="🔹 Paste your Render key"

# ===== OPTIONAL STRIPE =====
STRIPE_SECRET_KEY="🔹 Copy from Stripe Dashboard → API keys → Secret key"
```

## Deployment Steps

1. **Unzip this package** into your GitHub repository (e.g. `noodle-vision/nvg1`).
2. Commit and push your changes:

```bash
git add .
git commit -m "Deploy Noodle-VISION Master build"
git push origin main
```

3. **Set environment variables** in your hosting provider using the `.env.example` as a reference.
4. **Trigger a deployment** on your hosting provider (e.g. Render). Build and start commands for Render:
   - Build command: `npm install && npm run build`
   - Start command: `npm start`

## Additional Notes

- This build includes a `createxyz-project` folder with a fully functional Next.js simulator. It may not include the custom VR rig and HUD logic you developed separately; those can be added on top of this structure.
- Keep all secrets and API keys private. Do not commit actual keys into the repository.

