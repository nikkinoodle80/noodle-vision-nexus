async function handler({ userId }) {
  const session = getSession();

  if (!session) {
    return { error: "User not authenticated" };
  }

  try {
    const configurations = await sql(
      "SELECT id, name, jsonb_array_length(devices) AS devices_count, created_at FROM user_saved_setups WHERE user_id = $1",
      [userId]
    );

    return { configurations };
  } catch (error) {
    return { error: "Failed to fetch configurations" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}