async function handler({ action, webhookUrl, event, deliveryId, status }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  switch (action) {
    case "subscribe":
      if (!webhookUrl) {
        return { error: "Webhook URL is required" };
      }

      const existingWebhook = await sql`
        SELECT id FROM stored_urls 
        WHERE url = ${webhookUrl} 
        AND description = 'webhook'
      `;

      if (existingWebhook.length > 0) {
        return { error: "Webhook URL already registered" };
      }

      const newWebhook = await sql`
        INSERT INTO stored_urls (url, description)
        VALUES (${webhookUrl}, 'webhook')
        RETURNING id, url
      `;

      return { success: true, webhook: newWebhook[0] };

    case "unsubscribe":
      if (!webhookUrl) {
        return { error: "Webhook URL is required" };
      }

      await sql`
        DELETE FROM stored_urls 
        WHERE url = ${webhookUrl} 
        AND description = 'webhook'
      `;

      return { success: true };

    case "list":
      const webhooks = await sql`
        SELECT id, url, created_at 
        FROM stored_urls 
        WHERE description = 'webhook'
      `;

      return { webhooks };

    case "log-delivery":
      if (!deliveryId || !status || !webhookUrl) {
        return { error: "Delivery ID, status and webhook URL are required" };
      }

      await sql`
        INSERT INTO security_audit_logs (
          user_id,
          action,
          details
        ) VALUES (
          ${session.user.id},
          'webhook_delivery',
          ${JSON.stringify({
            deliveryId,
            status,
            webhookUrl,
            timestamp: new Date().toISOString(),
          })}
        )
      `;

      return { success: true };

    case "get-delivery-status":
      if (!deliveryId) {
        return { error: "Delivery ID is required" };
      }

      const deliveryLogs = await sql`
        SELECT details
        FROM security_audit_logs
        WHERE action = 'webhook_delivery'
        AND details->>'deliveryId' = ${deliveryId}
        ORDER BY created_at DESC
        LIMIT 1
      `;

      return deliveryLogs.length > 0
        ? { status: deliveryLogs[0].details.status }
        : { error: "Delivery not found" };

    default:
      return { error: "Invalid action" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}