async function handler({ url }) {
  if (!url) {
    return { error: "URL is required" };
  }

  try {
    // Fetch device info from URL
    const response = await fetch("/integrations/web-scraping/post", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        url,
        getText: true,
      }),
    });

    const text = await response.text();

    // Basic info extraction
    const deviceInfo = {
      name: text.match(/(?:model|name)[:]\s*([^\n]+)/i)?.[1]?.trim(),
      brand: text.match(/(?:brand|manufacturer)[:]\s*([^\n]+)/i)?.[1]?.trim(),
      type: text.match(/(?:type|category)[:]\s*([^\n]+)/i)?.[1]?.trim(),
      ports: {
        inputs: [],
        outputs: [],
      },
    };

    // Extract ports
    const portMatches = text.matchAll(
      /(?:port|connector|input|output)[:]\s*([^\n]+)/gi
    );
    for (const match of portMatches) {
      const port = match[1].trim().toLowerCase();
      if (port.includes("input")) {
        deviceInfo.ports.inputs.push(port);
      } else if (port.includes("output")) {
        deviceInfo.ports.outputs.push(port);
      }
    }

    // Store in database
    const result = await sql`
      INSERT INTO devices (
        name,
        type,
        brand,
        ports,
        created_at
      ) VALUES (
        ${deviceInfo.name || "Unknown"},
        ${deviceInfo.type || "Unknown"},
        ${deviceInfo.brand || "Unknown"},
        ${JSON.stringify(deviceInfo.ports)},
        NOW()
      )
      RETURNING id, name, type, brand, ports
    `;

    return {
      success: true,
      device: result[0],
    };
  } catch (error) {
    return {
      error: "Failed to fetch or process device information",
      details: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}