async function handler({ userId, name, email, image }) {
  if (!userId) {
    return { error: "User ID is required" };
  }

  const fields = [];
  const values = [];
  let paramCount = 1;

  if (name) {
    fields.push(`name = $${paramCount++}`);
    values.push(name);
  }
  if (email) {
    fields.push(`email = $${paramCount++}`);
    values.push(email);
  }
  if (image) {
    fields.push(`image = $${paramCount++}`);
    values.push(image);
  }

  if (fields.length === 0) {
    return { error: "No fields to update" };
  }

  values.push(userId);

  const query = `UPDATE auth_users SET ${fields.join(
    ", "
  )} WHERE id = $${paramCount} RETURNING *`;
  const [updatedUser] = await sql(query, values);

  return updatedUser || { error: "User not found or not updated" };
}
export async function POST(request) {
  return handler(await request.json());
}