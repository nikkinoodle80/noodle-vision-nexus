async function handler({ mode = "test", keyType = "all" }) {
  try {
    const session = getSession();
    if (!session?.user) {
      return { success: false, error: "Authentication required" };
    }

    // Get the current configuration
    const config = await sql`
      SELECT * FROM stripe_configuration 
      WHERE user_id = ${session.user.id}
    `;

    if (!config || config.length === 0) {
      return { success: false, error: "No Stripe configuration found" };
    }

    const stripeConfig = config[0];
    const results = {
      success: true,
      apiConnection: false,
      webhookStatus: null,
      errors: [],
    };

    // Test API connection
    if (keyType === "all" || keyType === "secret") {
      const secretKey =
        mode === "test"
          ? stripeConfig.test_secret_key
          : stripeConfig.live_secret_key;
      if (!secretKey) {
        results.errors.push(`No ${mode} secret key configured`);
      } else {
        try {
          // Make a request to Stripe API to validate the key
          const response = await fetch("https://api.stripe.com/v1/account", {
            method: "GET",
            headers: {
              Authorization: `Bearer ${secretKey}`,
              "Content-Type": "application/x-www-form-urlencoded",
            },
          });

          if (response.ok) {
            results.apiConnection = true;
          } else {
            const errorData = await response.json();
            results.errors.push(
              `API connection failed: ${
                errorData.error?.message || "Unknown error"
              }`
            );
          }
        } catch (error) {
          results.errors.push(`API connection failed: ${error.message}`);
        }
      }
    }

    // Test webhook if requested
    if (keyType === "all" || keyType === "webhook") {
      const webhookSecret =
        mode === "test"
          ? stripeConfig.test_webhook_secret
          : stripeConfig.live_webhook_secret;
      const webhookUrl =
        mode === "test"
          ? stripeConfig.test_webhook_url
          : stripeConfig.live_webhook_url;

      if (!webhookSecret || !webhookUrl) {
        results.webhookStatus = {
          configured: false,
          message: `No ${mode} webhook configuration found`,
        };
      } else {
        results.webhookStatus = {
          configured: true,
          message: "Webhook configuration found",
        };
        // We can't fully test the webhook without sending a test event
      }
    }

    // Log the test results
    await sql`
      INSERT INTO stripe_test_logs 
      (user_id, test_mode, success, api_connection, webhook_status, errors)
      VALUES (
        ${session.user.id},
        ${mode === "test"},
        ${results.success && results.errors.length === 0},
        ${results.apiConnection},
        ${JSON.stringify(results.webhookStatus || {})},
        ${JSON.stringify(results.errors)}
      )
    `;

    return results;
  } catch (error) {
    console.error("Error testing API keys:", error);
    return { success: false, error: error.message };
  }
}
export async function POST(request) {
  return handler(await request.json());
}