function handler({ name, description, primaryRoomId, setupType }) {
  const session = getSession();
  if (!session || !session.user) {
    return { error: "Authentication required" };
  }

  const userId = session.user.id;

  if (!name || !setupType) {
    return { error: "Name and setup type are required" };
  }

  try {
    const result = sql`
      INSERT INTO home_setups (user_id, name, description, primary_room_id, setup_type)
      VALUES (${userId}, ${name}, ${description}, ${primaryRoomId}, ${setupType})
      RETURNING *
    `;

    return { setup: result[0], success: true };
  } catch (error) {
    console.error("Error creating home setup:", error);
    return { error: "Failed to create setup" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}