async function handler() {
  const session = getSession();
  if (!session || !session.user) {
    return { error: "Authentication required" };
  }

  const userId = session.user.id;

  try {
    const rows = await sql`
      SELECT hs.*, hr.name as room_name
      FROM home_setups hs
      LEFT JOIN home_rooms hr ON hs.primary_room_id = hr.id
      WHERE hs.user_id = ${userId}
      ORDER BY hs.name ASC
    `;

    return { setups: rows };
  } catch (error) {
    console.error("Error fetching home setups:", error);
    return { error: "Failed to fetch setups" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}