async function handler() {
  const adapterTypes = await sql`SELECT * FROM adapter_types`;
  return adapterTypes;
}
export async function POST(request) {
  return handler(await request.json());
}