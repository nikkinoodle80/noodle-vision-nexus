async function handler({ category, roomType }) {
  try {
    const queryParts = ["SELECT * FROM devices WHERE 1=1"];
    const values = [];
    let paramCount = 1;

    if (category) {
      queryParts.push(`AND category = $${paramCount}`);
      values.push(category);
      paramCount++;
    }

    if (roomType) {
      queryParts.push(`AND room_type = $${paramCount}`);
      values.push(roomType);
      paramCount++;
    }

    queryParts.push("ORDER BY name ASC");

    const queryString = queryParts.join(" ");
    const devices = await sql(queryString, values);

    return { devices };
  } catch (error) {
    console.error("Error fetching home devices:", error);
    return { error: "Failed to fetch devices" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}