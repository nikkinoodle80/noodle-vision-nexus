async function handler({
  sourceDeviceType,
  targetDeviceType,
  sourceModel,
  targetModel,
  featureRequired,
}) {
  try {
    // Validate required parameters
    if (!sourceDeviceType || !targetDeviceType) {
      return {
        success: false,
        message: "Source and target device types are required",
      };
    }

    // Build the query
    let query = `
      SELECT 
        cc.*,
        json_agg(a.*) as adapters,
        json_agg(df.*) FILTER (WHERE df.id IS NOT NULL) as features
      FROM 
        public.connection_chains cc
      LEFT JOIN LATERAL unnest(cc.adapter_sequence) as adapter_id ON true
      LEFT JOIN public.adapters a ON a.id = adapter_id
      LEFT JOIN LATERAL unnest(cc.features_enabled) as feature_name ON true
      LEFT JOIN public.device_features df ON df.name = feature_name
      WHERE 
        cc.source_device_type = $1 
        AND cc.target_device_type = $2
    `;

    const queryParams = [sourceDeviceType, targetDeviceType];
    let paramCount = 3;

    // Add feature filter if provided
    if (featureRequired) {
      query += ` AND $${paramCount} = ANY(cc.features_enabled)`;
      queryParams.push(featureRequired);
      paramCount++;
    }

    // Add source model compatibility check if provided
    if (sourceModel) {
      query += `
        AND EXISTS (
          SELECT 1 FROM public.device_models dm
          WHERE dm.model_name = $${paramCount}
          AND dm.device_type = cc.source_device_type
        )
      `;
      queryParams.push(sourceModel);
      paramCount++;
    }

    // Add target model compatibility check if provided
    if (targetModel) {
      query += `
        AND EXISTS (
          SELECT 1 FROM public.device_models dm
          WHERE dm.model_name = $${paramCount}
          AND dm.device_type = cc.target_device_type
        )
      `;
      queryParams.push(targetModel);
      paramCount++;
    }

    // Group by to aggregate the adapter and feature information
    query += `
      GROUP BY cc.id
      ORDER BY cc.user_rating DESC NULLS LAST, cc.name
    `;

    // Execute the query
    const rows = await sql(query, queryParams);

    return {
      success: true,
      chains: rows,
    };
  } catch (error) {
    console.error("Error fetching adapter chains:", error);
    return {
      success: false,
      message: "Failed to retrieve adapter chains",
      error: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}