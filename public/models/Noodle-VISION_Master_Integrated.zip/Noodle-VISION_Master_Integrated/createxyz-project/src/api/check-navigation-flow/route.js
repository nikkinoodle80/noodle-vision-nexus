async function handler() {
  return {
    navigationFlows: [
      {
        from: "Home",
        action: "Go to Setup",
        expectedDestination: "Setup Page",
      },
      {
        from: "Home",
        action: "Add Room",
        expectedDestination: "Add Room Page",
      },
      {
        from: "Home",
        action: "New Setup",
        expectedDestination: "New Setup Page",
      },
      {
        from: "Home",
        action: "Account",
        expectedDestination: "Account Page",
      },
      {
        from: "Home",
        action: "Dashboard",
        expectedDestination: "Dashboard Page",
      },
      {
        from: "Home",
        action: "Device Library",
        expectedDestination: "Device Library Page",
      },
      {
        from: "Home",
        action: "Adapter Library",
        expectedDestination: "Adapter Library Page",
      },
      {
        from: "Home",
        action: "Connection Designer",
        expectedDestination: "Connection Designer Page",
      },
    ],
    status:
      "Checklist generated. Manual or automated UI testing required to verify actual navigation.",
  };
}
export async function POST(request) {
  return handler(await request.json());
}