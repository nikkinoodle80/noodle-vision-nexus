async function handler({ action, data }) {
  const session = getSession();
  if (!session || !session.user) {
    return {
      success: false,
      message: "Unauthorized",
    };
  }

  try {
    if (!action) {
      return {
        success: false,
        message: "Missing action parameter",
      };
    }

    let result;

    switch (action) {
      case "createCustomer":
        result = fetch("https://api.stripe.com/v1/customers", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            email: session.user.email,
            name: session.user.name || "",
            metadata: JSON.stringify({
              userId: session.user.id,
            }),
            ...data,
          }),
        }).then((res) => res.json());
        break;

      case "createPaymentIntent":
        if (!data.amount || !data.currency) {
          return {
            success: false,
            message: "Missing required fields: amount, currency",
          };
        }

        result = fetch("https://api.stripe.com/v1/payment_intents", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            amount: data.amount,
            currency: data.currency,
            customer: data.customerId,
            payment_method_types: JSON.stringify(
              data.paymentMethodTypes || ["card"]
            ),
            metadata: JSON.stringify({
              userId: session.user.id,
              ...data.metadata,
            }),
          }),
        }).then((res) => res.json());
        break;

      case "createSubscription":
        if (!data.customerId || !data.priceId) {
          return {
            success: false,
            message: "Missing required fields: customerId, priceId",
          };
        }

        result = fetch("https://api.stripe.com/v1/subscriptions", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            customer: data.customerId,
            items: JSON.stringify([{ price: data.priceId }]),
            metadata: JSON.stringify({
              userId: session.user.id,
              ...data.metadata,
            }),
          }),
        }).then((res) => res.json());
        break;

      case "getCustomer":
        if (!data.customerId) {
          return {
            success: false,
            message: "Missing required field: customerId",
          };
        }

        result = fetch(
          `https://api.stripe.com/v1/customers/${data.customerId}`,
          {
            method: "GET",
            headers: {
              Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
            },
          }
        ).then((res) => res.json());
        break;

      case "getSubscriptions":
        if (!data.customerId) {
          return {
            success: false,
            message: "Missing required field: customerId",
          };
        }

        result = fetch(
          `https://api.stripe.com/v1/subscriptions?customer=${
            data.customerId
          }&limit=${data.limit || 10}`,
          {
            method: "GET",
            headers: {
              Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
            },
          }
        ).then((res) => res.json());
        break;

      case "cancelSubscription":
        if (!data.subscriptionId) {
          return {
            success: false,
            message: "Missing required field: subscriptionId",
          };
        }

        result = fetch(
          `https://api.stripe.com/v1/subscriptions/${data.subscriptionId}`,
          {
            method: "DELETE",
            headers: {
              Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
            },
          }
        ).then((res) => res.json());
        break;

      case "createCheckoutSession":
        if (!data.priceId) {
          return {
            success: false,
            message: "Missing required field: priceId",
          };
        }

        result = fetch("https://api.stripe.com/v1/checkout/sessions", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            payment_method_types: JSON.stringify(["card"]),
            line_items: JSON.stringify([
              {
                price: data.priceId,
                quantity: data.quantity || 1,
              },
            ]),
            mode: data.mode || "subscription",
            success_url:
              data.successUrl ||
              `${process.env.NEXTAUTH_URL}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
            cancel_url:
              data.cancelUrl || `${process.env.NEXTAUTH_URL}/payment-cancelled`,
            customer_email: session.user.email,
            metadata: JSON.stringify({
              userId: session.user.id,
              ...data.metadata,
            }),
          }),
        }).then((res) => res.json());
        break;

      case "testConnection":
        const accountPromise = fetch("https://api.stripe.com/v1/account", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
          },
        }).then((res) => res.json());

        const balancePromise = fetch("https://api.stripe.com/v1/balance", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
          },
        }).then((res) => res.json());

        const [account, balance] = await Promise.all([
          accountPromise,
          balancePromise,
        ]);

        result = {
          connected: true,
          message: "Successfully connected to Stripe API",
          details: {
            account: {
              id: account.id,
              business_type: account.business_type,
              country: account.country,
              email: account.email,
            },
            mode: process.env.STRIPE_SECRET_KEY.startsWith("sk_test_")
              ? "test"
              : "live",
            capabilities: Object.keys(account.capabilities || {}).filter(
              (key) => account.capabilities[key] === "active"
            ),
            available: balance.available,
            pending: balance.pending,
          },
        };
        break;

      default:
        return {
          success: false,
          message: `Unsupported action: ${action}`,
        };
    }

    return {
      success: true,
      data: await result,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error("Stripe API error:", error);

    return {
      success: false,
      message: "Stripe API error",
      error: error.message,
      timestamp: new Date().toISOString(),
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}