function handler({ userId }) {
  if (!userId) {
    return {
      success: true,
      tier: "basic", // Default to basic for non-logged in users
      features: {
        unconventionalConnections: false,
        inventoryManagement: false,
        roomLayoutPlanning: false,
        maxDevices: 5,
        maxSavedConfigurations: 2,
      },
    };
  }

  try {
    // Get user session
    const session = getSession();
    const user = session?.user;

    if (!user) {
      return {
        success: true,
        tier: "basic",
        features: {
          unconventionalConnections: false,
          inventoryManagement: false,
          roomLayoutPlanning: false,
          maxDevices: 5,
          maxSavedConfigurations: 2,
        },
      };
    }

    // Query the database for subscription info using the global sql tag
    return sql`
      SELECT * FROM user_subscriptions 
      WHERE user_id = ${user.id} AND status = 'active'
      LIMIT 1
    `.then((subscriptions) => {
      let tier = "basic";
      let features = {
        unconventionalConnections: false,
        inventoryManagement: false,
        roomLayoutPlanning: false,
        maxDevices: 5,
        maxSavedConfigurations: 2,
      };

      if (subscriptions && subscriptions.length > 0) {
        const subscription = subscriptions[0];
        tier = subscription.plan_type;

        if (tier === "pro") {
          features = {
            unconventionalConnections: true,
            inventoryManagement: true,
            roomLayoutPlanning: false,
            maxDevices: 20,
            maxSavedConfigurations: 10,
          };
        } else if (tier === "enterprise") {
          features = {
            unconventionalConnections: true,
            inventoryManagement: true,
            roomLayoutPlanning: true,
            maxDevices: 100,
            maxSavedConfigurations: 50,
          };
        }
      }

      return {
        success: true,
        tier,
        features,
      };
    });
  } catch (error) {
    console.error("Error checking subscription tier:", error);
    return {
      success: false,
      error: "Failed to check subscription tier",
      tier: "basic", // Default to basic on error
      features: {
        unconventionalConnections: false,
        inventoryManagement: false,
        roomLayoutPlanning: false,
        maxDevices: 5,
        maxSavedConfigurations: 2,
      },
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}