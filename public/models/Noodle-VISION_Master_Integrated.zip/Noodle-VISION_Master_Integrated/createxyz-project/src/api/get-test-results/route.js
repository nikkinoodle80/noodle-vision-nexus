function handler({
  id,
  testSuite,
  environment,
  limit = 10,
  offset = 0,
  sortBy = "created_at",
  sortDirection = "desc",
}) {
  try {
    // If an ID is provided, return that specific test result
    if (id) {
      const result = sql`SELECT * FROM test_results WHERE id = ${id}`;

      if (result.length === 0) {
        return {
          success: false,
          error: `No test result found with ID: ${id}`,
        };
      }

      return {
        success: true,
        result: result[0],
      };
    }

    // Build the query with filters
    let queryConditions = [];
    let queryParams = [];
    let paramCounter = 1;

    let queryStr = "SELECT * FROM test_results WHERE 1=1";

    if (testSuite && testSuite !== "all") {
      queryStr += ` AND test_suite = $${paramCounter}`;
      queryParams.push(testSuite);
      paramCounter++;
    }

    if (environment) {
      queryStr += ` AND environment = $${paramCounter}`;
      queryParams.push(environment);
      paramCounter++;
    }

    // Validate sort parameters
    const validSortFields = [
      "created_at",
      "test_suite",
      "environment",
      "success",
      "total_tests",
      "passed_tests",
      "failed_tests",
    ];
    const validSortDirections = ["asc", "desc"];

    const actualSortBy = validSortFields.includes(sortBy)
      ? sortBy
      : "created_at";
    const actualSortDirection = validSortDirections.includes(
      sortDirection.toLowerCase()
    )
      ? sortDirection.toLowerCase()
      : "desc";

    // Add sorting
    queryStr += ` ORDER BY ${actualSortBy} ${actualSortDirection}`;

    // Add pagination
    queryStr += ` LIMIT $${paramCounter} OFFSET $${paramCounter + 1}`;
    queryParams.push(limit, offset);

    // Execute the query
    const results = sql(queryStr, queryParams);

    // Build count query
    let countQueryStr = "SELECT COUNT(*) as total FROM test_results WHERE 1=1";
    let countParams = [];
    let countParamCounter = 1;

    if (testSuite && testSuite !== "all") {
      countQueryStr += ` AND test_suite = $${countParamCounter}`;
      countParams.push(testSuite);
      countParamCounter++;
    }

    if (environment) {
      countQueryStr += ` AND environment = $${countParamCounter}`;
      countParams.push(environment);
      countParamCounter++;
    }

    // Execute count query
    const countResult = sql(countQueryStr, countParams);

    return {
      success: true,
      results,
      pagination: {
        total: parseInt(countResult[0].total),
        limit,
        offset,
        hasMore: parseInt(countResult[0].total) > offset + limit,
      },
    };
  } catch (error) {
    console.error("Error getting test results:", error);
    return {
      success: false,
      error: `Failed to get test results: ${error.message}`,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}