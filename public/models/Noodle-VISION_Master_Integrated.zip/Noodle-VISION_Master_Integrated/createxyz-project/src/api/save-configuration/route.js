async function handler({ name, devices, connections, layout }) {
  try {
    // Get current user session
    const session = getSession();
    if (!session || !session.user) {
      return { error: "Authentication required" };
    }

    // Validate input data
    if (!name || typeof name !== "string" || name.trim() === "") {
      return { error: "Configuration name is required" };
    }

    if (!devices || !Array.isArray(devices) || devices.length === 0) {
      return { error: "At least one device is required" };
    }

    if (!connections || !Array.isArray(connections)) {
      return { error: "Connections must be an array" };
    }

    // Save configuration to database
    const userId = session.user.id;
    const now = new Date().toISOString();

    const [savedSetup] = await sql`
      INSERT INTO user_saved_setups (
        user_id, 
        name, 
        devices, 
        connections, 
        layout, 
        created_at, 
        updated_at
      ) 
      VALUES (
        ${userId}, 
        ${name}, 
        ${JSON.stringify(devices)}, 
        ${JSON.stringify(connections)}, 
        ${layout ? JSON.stringify(layout) : null}, 
        ${now}, 
        ${now}
      )
      RETURNING *
    `;

    return {
      success: true,
      configuration: savedSetup,
    };
  } catch (error) {
    console.error("Error saving configuration:", error);
    return {
      error: "Failed to save configuration",
      details: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}