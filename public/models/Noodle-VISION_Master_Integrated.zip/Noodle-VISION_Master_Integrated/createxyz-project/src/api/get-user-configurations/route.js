async function handler({ userId }) {
  try {
    const session = getSession();

    // Check if user is authenticated
    if (!session || !session.user) {
      return {
        success: false,
        error: "Authentication required",
      };
    }

    // Use the provided userId or default to the authenticated user's id
    const targetUserId = userId || session.user.id;

    // Query the database for user's saved configurations
    const configurations = await sql`
      SELECT 
        id, 
        name, 
        jsonb_array_length(devices) as device_count,
        created_at
      FROM user_saved_setups
      WHERE user_id = ${targetUserId}
      ORDER BY updated_at DESC
    `;

    return {
      success: true,
      configurations: configurations.map((config) => ({
        id: config.id,
        name: config.name,
        deviceCount: config.device_count,
        createdAt: config.created_at,
      })),
    };
  } catch (error) {
    console.error("Error fetching user configurations:", error);
    return {
      success: false,
      error: "Failed to retrieve configurations",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}