async function handler({ filter = {}, page = 1, pageSize = 10 }) {
  const offset = (page - 1) * pageSize;
  const conditions = [];
  const values = [];

  if (filter.name) {
    conditions.push(`name ILIKE $${conditions.length + 1}`);
    values.push(`%${filter.name}%`);
  }

  if (filter.source_type) {
    conditions.push(`source_type = $${conditions.length + 1}`);
    values.push(filter.source_type);
  }

  if (filter.target_type) {
    conditions.push(`target_type = $${conditions.length + 1}`);
    values.push(filter.target_type);
  }

  const whereClause = conditions.length
    ? `WHERE ${conditions.join(" AND ")}`
    : "";
  const query = `
    SELECT * FROM adapters
    ${whereClause}
    ORDER BY id
    LIMIT $${conditions.length + 1} OFFSET $${conditions.length + 2}
  `;

  values.push(pageSize, offset);

  const adapters = await sql(query, values);
  return { adapters };
}
export async function POST(request) {
  return handler(await request.json());
}