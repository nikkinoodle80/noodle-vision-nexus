async function handler() {
  try {
    // Check if all required checklist items are completed
    const requiredItemsResult = await sql`
      SELECT COUNT(*) as total_items, 
      SUM(CASE WHEN is_completed THEN 1 ELSE 0 END) as completed_items
      FROM deployment_checklist
    `;

    const { total_items, completed_items } = requiredItemsResult[0];

    // Check if Stripe is properly configured
    const stripeConfigResult = await sql`
      SELECT COUNT(*) as count
      FROM stripe_configuration
      WHERE (test_secret_key IS NOT NULL OR live_secret_key IS NOT NULL)
    `;

    const stripeConfigured = stripeConfigResult[0].count > 0;

    // Check if environment variables are set up
    const envVarsResult = await sql`
      SELECT COUNT(*) as count
      FROM deployment_environments
      WHERE is_active = TRUE AND (SELECT COUNT(*) FROM jsonb_object_keys(variables)) > 0
    `;

    const envVarsConfigured = envVarsResult[0].count > 0;

    // Calculate overall readiness
    const completionPercentage =
      total_items > 0 ? (completed_items / total_items) * 100 : 0;
    const isReady =
      completionPercentage === 100 && stripeConfigured && envVarsConfigured;

    // Get issues that need to be addressed
    const issuesResult = await sql`
      SELECT category, item_name
      FROM deployment_checklist
      WHERE is_completed = FALSE
    `;

    return {
      success: true,
      isReady,
      completionPercentage,
      totalItems: parseInt(total_items),
      completedItems: parseInt(completed_items),
      stripeConfigured,
      envVarsConfigured,
      pendingIssues: issuesResult,
    };
  } catch (error) {
    console.error("Error checking deployment readiness:", error);
    return {
      success: false,
      error: "Failed to check deployment readiness",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}