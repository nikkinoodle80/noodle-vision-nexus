async function handler({ id, newUrl, newDescription }) {
  if (!id || !newUrl) {
    return { error: "ID and new URL are required" };
  }

  const query =
    "UPDATE stored_urls SET url = $1, description = $2 WHERE id = $3 RETURNING *";
  const values = [newUrl, newDescription, id];

  const result = await sql(query, values);

  return result.length > 0 ? result[0] : { error: "Failed to update URL" };
}
export async function POST(request) {
  return handler(await request.json());
}