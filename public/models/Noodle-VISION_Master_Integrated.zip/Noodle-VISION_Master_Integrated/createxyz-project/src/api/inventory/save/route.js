function handler({ items }) {
  const session = getSession();
  const userId = session?.user?.id;

  if (!userId) {
    return {
      success: false,
      error: "You must be logged in to save inventory",
    };
  }

  if (!items || !Array.isArray(items) || items.length === 0) {
    return {
      success: false,
      error: "No inventory items provided",
    };
  }

  try {
    return sql.transaction(async (txn) => {
      // Clear existing inventory
      await txn`
        DELETE FROM user_inventory
        WHERE user_id = ${userId}
      `;

      // Insert new inventory items
      for (const item of items) {
        if (item.deviceId) {
          await txn`
            INSERT INTO user_inventory
            (user_id, device_id, quantity, notes)
            VALUES (${userId}, ${item.deviceId}, ${item.quantity || 1}, ${
            item.notes || null
          })
          `;
        } else if (item.adapterTypeId) {
          await txn`
            INSERT INTO user_inventory
            (user_id, adapter_type_id, quantity, notes)
            VALUES (${userId}, ${item.adapterTypeId}, ${item.quantity || 1}, ${
            item.notes || null
          })
          `;
        }
      }

      return {
        success: true,
        message: "Inventory saved successfully",
      };
    });
  } catch (error) {
    console.error("Error saving inventory:", error);
    return {
      success: false,
      error: "Failed to save inventory",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}