async function handler({ userId, items }) {
  try {
    if (!userId) {
      return { error: "User ID is required" };
    }

    if (!items || !Array.isArray(items) || items.length === 0) {
      return { error: "Items array is required and must not be empty" };
    }

    const session = getSession();

    if (!session || session.user?.id != userId) {
      return { error: "Unauthorized: You can only modify your own inventory" };
    }

    const results = await sql.transaction(async (txn) => {
      const itemResults = [];

      for (const item of items) {
        const { item_type, item_id, quantity = 1, notes } = item;

        if (!item_type || !item_id) {
          throw new Error("Each item must have item_type and item_id");
        }

        if (!["device", "adapter"].includes(item_type)) {
          throw new Error(
            `Invalid item_type: ${item_type}. Must be 'device' or 'adapter'`
          );
        }

        let checkResult;
        if (item_type === "device") {
          checkResult = await txn(
            "SELECT id FROM public.devices WHERE id = $1",
            [item_id]
          );
        } else {
          checkResult = await txn(
            "SELECT id FROM public.adapter_types WHERE id = $1",
            [item_id]
          );
        }

        if (checkResult.length === 0) {
          throw new Error(`${item_type} with ID ${item_id} not found`);
        }

        const existingQuery =
          "SELECT id, quantity FROM public.user_inventory_simplified WHERE user_id = $1 AND item_type = $2 AND item_id = $3";
        const existingResult = await txn(existingQuery, [
          userId,
          item_type,
          item_id,
        ]);

        let result;

        if (existingResult.length > 0) {
          const newQuantity = existingResult[0].quantity + quantity;

          const updateQuery = `
            UPDATE public.user_inventory_simplified 
            SET quantity = $1, notes = $2, last_updated_at = CURRENT_TIMESTAMP
            WHERE id = $3
            RETURNING *
          `;

          result = await txn(updateQuery, [
            newQuantity,
            notes || existingResult[0].notes,
            existingResult[0].id,
          ]);
        } else {
          const insertQuery = `
            INSERT INTO public.user_inventory_simplified 
            (user_id, item_type, item_id, quantity, notes, created_at, last_updated_at)
            VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            RETURNING *
          `;

          result = await txn(insertQuery, [
            userId,
            item_type,
            item_id,
            quantity,
            notes,
          ]);
        }

        itemResults.push(result[0]);
      }

      return itemResults;
    });

    return {
      items: results,
      message: `Successfully added ${results.length} items to inventory`,
    };
  } catch (error) {
    console.error("Error in BatchCreateUserInventory:", error);
    return { error: `Failed to update inventory: ${error.message}` };
  }
}
export async function POST(request) {
  return handler(await request.json());
}