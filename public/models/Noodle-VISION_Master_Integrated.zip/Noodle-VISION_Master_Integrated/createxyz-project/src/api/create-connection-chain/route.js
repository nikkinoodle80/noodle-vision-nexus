function handler({
  name,
  description,
  source_device_type,
  target_device_type,
  adapter_sequence,
  features_enabled,
  compatibility_notes,
}) {
  try {
    // Validate required fields
    if (
      !name ||
      !source_device_type ||
      !target_device_type ||
      !adapter_sequence ||
      !Array.isArray(adapter_sequence)
    ) {
      return {
        success: false,
        message:
          "Name, source_device_type, target_device_type, and adapter_sequence array are required",
      };
    }

    // Verify all adapters exist
    const adapterCheckQuery =
      "SELECT COUNT(*) FROM public.adapters WHERE id = ANY($1::int[])";

    const adapterCheckResult = sql(adapterCheckQuery, [adapter_sequence]);

    if (parseInt(adapterCheckResult[0].count) !== adapter_sequence.length) {
      return {
        success: false,
        message: "One or more adapter IDs in the sequence do not exist",
      };
    }

    // Insert the connection chain
    const query =
      "INSERT INTO public.connection_chains (name, description, source_device_type, target_device_type, adapter_sequence, features_enabled, compatibility_notes) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *";

    const values = [
      name,
      description,
      source_device_type,
      target_device_type,
      adapter_sequence,
      features_enabled,
      compatibility_notes,
    ];

    const result = sql(query, values);

    return {
      success: true,
      connectionChain: result[0],
    };
  } catch (error) {
    console.error("Error creating connection chain:", error);
    return {
      success: false,
      message: "Failed to create connection chain",
      error: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}