async function handler({ filter = "", page = 1, pageSize = 10 }) {
  const offset = (page - 1) * pageSize;
  const filterCondition = filter
    ? `WHERE LOWER(name) LIKE LOWER($1) OR LOWER(email) LIKE LOWER($1)`
    : "";
  const values = filter
    ? [`%${filter}%`, offset, pageSize]
    : [offset, pageSize];

  const query = `
    SELECT * FROM auth_users
    ${filterCondition}
    ORDER BY id
    LIMIT $2 OFFSET $3
  `;

  const users = await sql(query, values);
  return { users };
}
export async function POST(request) {
  return handler(await request.json());
}