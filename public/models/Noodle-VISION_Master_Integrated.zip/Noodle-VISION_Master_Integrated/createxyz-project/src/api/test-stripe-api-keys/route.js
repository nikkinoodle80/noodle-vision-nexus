function handler() {
  const session = getSession();

  if (!session || !session.user) {
    return {
      success: false,
      error: "Authentication required to test Stripe API keys",
      timestamp: new Date().toISOString(),
    };
  }

  try {
    // Get the Stripe configuration from the database
    return fetch("/api/get-stripe-configuration", {
      method: "POST",
    })
      .then((response) => response.json())
      .then(async (configData) => {
        if (!configData.exists || !configData.config) {
          return {
            success: false,
            error:
              "No Stripe configuration found. Please save your API keys first.",
            timestamp: new Date().toISOString(),
          };
        }

        const config = configData.config;
        const testApiKey = config.testSecretKey;
        const liveApiKey = config.liveSecretKey;

        const results = {
          testMode: {
            keyConfigured: !!testApiKey,
            apiConnection: false,
            error: null,
          },
          liveMode: {
            keyConfigured: !!liveApiKey,
            apiConnection: false,
            error: null,
          },
          timestamp: new Date().toISOString(),
        };

        // Test connections in parallel
        return Promise.all([
          testApiKey
            ? testStripeConnection(testApiKey, true)
            : Promise.resolve(null),
          liveApiKey
            ? testStripeConnection(liveApiKey, false)
            : Promise.resolve(null),
        ]).then(async ([testResult, liveResult]) => {
          if (testResult) {
            results.testMode.apiConnection = testResult.success;
            results.testMode.error = testResult.error;
            results.testMode.details = testResult.success
              ? testResult.balance
              : null;
          }

          if (liveResult) {
            results.liveMode.apiConnection = liveResult.success;
            results.liveMode.error = liveResult.error;
            results.liveMode.details = liveResult.success
              ? liveResult.balance
              : null;
          }

          // Log the test results
          await logTestResults(results);

          return {
            success: true,
            results,
            message: "API key test completed",
          };
        });
      });
  } catch (error) {
    console.error("Error testing Stripe API keys:", error);
    return {
      success: false,
      error: `Failed to test Stripe API keys: ${error.message}`,
      timestamp: new Date().toISOString(),
    };
  }

  async function testStripeConnection(apiKey, isTestMode) {
    try {
      const response = await fetch("https://api.stripe.com/v1/balance", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
      });

      const data = await response.json();

      if (response.ok) {
        return {
          success: true,
          balance: data.available,
          accountType: isTestMode ? "test" : "live",
        };
      } else {
        return {
          success: false,
          error: data.error?.message || "Unknown API error",
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error.message,
      };
    }
  }

  async function logTestResults(results) {
    try {
      // Log test mode results
      if (results.testMode.keyConfigured) {
        await sql`
          INSERT INTO stripe_test_logs (
            user_id, 
            test_mode, 
            success, 
            api_connection, 
            webhook_status, 
            buy_button_status, 
            errors, 
            created_at
          )
          VALUES (
            ${session.user.id},
            ${true},
            ${results.testMode.apiConnection},
            ${results.testMode.apiConnection},
            ${null},
            ${null},
            ${
              results.testMode.error
                ? JSON.stringify([results.testMode.error])
                : "[]"
            },
            CURRENT_TIMESTAMP
          )
        `;
      }

      // Log live mode results
      if (results.liveMode.keyConfigured) {
        await sql`
          INSERT INTO stripe_test_logs (
            user_id, 
            test_mode, 
            success, 
            api_connection, 
            webhook_status, 
            buy_button_status, 
            errors, 
            created_at
          )
          VALUES (
            ${session.user.id},
            ${false},
            ${results.liveMode.apiConnection},
            ${results.liveMode.apiConnection},
            ${null},
            ${null},
            ${
              results.liveMode.error
                ? JSON.stringify([results.liveMode.error])
                : "[]"
            },
            CURRENT_TIMESTAMP
          )
        `;
      }
    } catch (error) {
      console.error("Failed to log Stripe API key test results:", error);
    }
  }
}
export async function POST(request) {
  return handler(await request.json());
}