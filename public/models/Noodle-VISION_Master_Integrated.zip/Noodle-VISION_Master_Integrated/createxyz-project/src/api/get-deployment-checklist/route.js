async function handler({ category }) {
  try {
    let queryText = "SELECT * FROM deployment_checklist WHERE 1=1";
    const queryParams = [];

    if (category) {
      queryParams.push(category);
      queryText += ` AND category = $1`;
    }

    queryText += " ORDER BY category, id";

    const result = await sql(queryText, queryParams);

    return {
      success: true,
      items: result,
    };
  } catch (error) {
    console.error("Error fetching deployment checklist:", error);
    return {
      success: false,
      error: "Failed to fetch deployment checklist",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}