async function handler({ name, description, connections }) {
  if (!name || !connections || !Array.isArray(connections)) {
    return {
      success: false,
      message: "Name and connections array are required",
    };
  }

  try {
    // Create the setup and get the ID
    const setups = await sql`
      INSERT INTO device_setups (name, description)
      VALUES (${name}, ${description})
      RETURNING id
    `;

    const setupId = setups[0].id;

    // Use transaction to insert all connections
    const connectionQueries = connections.map((conn) => {
      return sql`
        INSERT INTO setup_connections (
          setup_id, 
          source_device_id, 
          target_device_id, 
          adapter_id, 
          source_port_type, 
          target_port_type, 
          position_data
        )
        VALUES (
          ${setupId},
          ${conn.sourceDeviceId},
          ${conn.targetDeviceId},
          ${conn.adapterId},
          ${conn.sourcePortType},
          ${conn.targetPortType},
          ${JSON.stringify(conn.positionData || {})}
        )
      `;
    });

    await sql.transaction(connectionQueries);

    return {
      success: true,
      setupId,
      message: "Setup saved successfully",
    };
  } catch (error) {
    return {
      success: false,
      message: "Failed to save setup: " + error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}