async function handler({ id, fieldsToUpdate }) {
  if (!id || !fieldsToUpdate || Object.keys(fieldsToUpdate).length === 0) {
    return { error: "Invalid input" };
  }

  const setClauses = [];
  const values = [];
  let paramCount = 1;

  for (const [key, value] of Object.entries(fieldsToUpdate)) {
    setClauses.push(`${key} = $${paramCount}`);
    values.push(value);
    paramCount++;
  }

  const query = `
    UPDATE auth_accounts
    SET ${setClauses.join(", ")}
    WHERE id = $${paramCount}
    RETURNING *;
  `;
  values.push(id);

  const [updatedAccount] = await sql(query, values);

  return updatedAccount ? { updatedAccount } : { error: "Update failed" };
}
export async function POST(request) {
  return handler(await request.json());
}