async function handler({ filter = {}, page = 1, pageSize = 10 }) {
  const { type, provider } = filter;
  const offset = (page - 1) * pageSize;
  const values = [];
  let query = "SELECT * FROM auth_accounts WHERE 1=1";

  if (type) {
    query += " AND type = $1";
    values.push(type);
  }

  if (provider) {
    query += " AND provider = $2";
    values.push(provider);
  }

  query += " LIMIT $3 OFFSET $4";
  values.push(pageSize, offset);

  const authAccounts = await sql(query, values);
  return { authAccounts };
}
export async function POST(request) {
  return handler(await request.json());
}