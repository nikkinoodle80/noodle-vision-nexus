async function handler(request) {
  try {
    const rawBody = await request.text();

    const signature = request.headers.get("stripe-signature");

    if (!signature) {
      console.error("No Stripe signature found in webhook request");
      return new Response(JSON.stringify({ error: "No signature provided" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    const allConfigs = await sql`SELECT * FROM stripe_configuration`;

    let event;
    let matchedConfig = null;

    for (const config of allConfigs) {
      try {
        if (config.is_test_mode && config.test_webhook_secret) {
          const stripe = new Stripe(config.test_secret_key);
          event = stripe.webhooks.constructEvent(
            rawBody,
            signature,
            config.test_webhook_secret
          );
          matchedConfig = { ...config, mode: "test" };
          break;
        }
      } catch (err) {
        console.log(
          `Webhook signature verification failed with test secret for user ${config.user_id}: ${err.message}`
        );
      }

      try {
        if (!config.is_test_mode && config.live_webhook_secret) {
          const stripe = new Stripe(config.live_secret_key);
          event = stripe.webhooks.constructEvent(
            rawBody,
            signature,
            config.live_webhook_secret
          );
          matchedConfig = { ...config, mode: "live" };
          break;
        }
      } catch (err) {
        console.log(
          `Webhook signature verification failed with live secret for user ${config.user_id}: ${err.message}`
        );
      }
    }

    if (!matchedConfig) {
      console.error(
        "Webhook signature verification failed for all configurations"
      );
      return new Response(
        JSON.stringify({ error: "Signature verification failed" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json" },
        }
      );
    }

    console.log(
      `Verified webhook for user ${matchedConfig.user_id} in ${matchedConfig.mode} mode`
    );

    await sql`
      INSERT INTO stripe_test_logs 
      (user_id, test_mode, success, api_connection, webhook_status, errors) 
      VALUES 
      (${matchedConfig.user_id}, ${
      matchedConfig.mode === "test"
    }, ${true}, ${true}, 
       ${JSON.stringify({
         received: true,
         verified: true,
         eventType: event.type,
       })},
       ${JSON.stringify({})})
    `;

    switch (event.type) {
      case "checkout.session.completed":
        await handleCheckoutSessionCompleted(event.data.object, matchedConfig);
        break;

      case "customer.subscription.created":
      case "customer.subscription.updated":
        await handleSubscriptionChange(event.data.object, matchedConfig);
        break;

      case "customer.subscription.deleted":
        await handleSubscriptionCancelled(event.data.object, matchedConfig);
        break;

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return new Response(JSON.stringify({ received: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error processing webhook:", error);

    try {
      await sql`
        INSERT INTO stripe_test_logs 
        (user_id, test_mode, success, api_connection, webhook_status, errors) 
        VALUES 
        (${null}, ${true}, ${false}, ${true}, 
         ${JSON.stringify({ received: true, verified: false })},
         ${JSON.stringify({ message: error.message, stack: error.stack })})
      `;
    } catch (logError) {
      console.error("Failed to log webhook error:", logError);
    }

    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }
}

async function handleCheckoutSessionCompleted(session, config) {
  try {
    console.log("Processing completed checkout session:", session.id);

    if (session.mode === "subscription" && session.subscription) {
      console.log("Subscription created via checkout:", session.subscription);

      const customerId = session.customer;
      const subscriptionId = session.subscription;

      await sql`
        INSERT INTO user_subscriptions 
        (user_id, stripe_customer_id, stripe_subscription_id, plan_type, status, current_period_start, current_period_end, cancel_at_period_end)
        VALUES
        (${config.user_id}, ${customerId}, ${subscriptionId}, 'pending', 'active', NOW(), NOW() + INTERVAL '1 month', false)
        ON CONFLICT (user_id) 
        DO UPDATE SET
          stripe_customer_id = ${customerId},
          stripe_subscription_id = ${subscriptionId},
          status = 'active',
          updated_at = CURRENT_TIMESTAMP
      `;
    }

    await sql`
      INSERT INTO stripe_test_logs 
      (user_id, test_mode, success, api_connection, webhook_status, buy_button_status, errors) 
      VALUES 
      (${config.user_id}, ${config.mode === "test"}, ${true}, ${true}, 
       ${JSON.stringify({
         received: true,
         event: "checkout.session.completed",
       })},
       ${JSON.stringify({
         session_id: session.id,
         customer: session.customer,
       })},
       ${JSON.stringify({})})
    `;
  } catch (error) {
    console.error("Error handling checkout session:", error);

    await sql`
      INSERT INTO stripe_test_logs 
      (user_id, test_mode, success, api_connection, webhook_status, errors) 
      VALUES 
      (${config.user_id}, ${config.mode === "test"}, ${false}, ${true}, 
       ${JSON.stringify({
         received: true,
         event: "checkout.session.completed",
         error: true,
       })},
       ${JSON.stringify({ message: error.message, stack: error.stack })})
    `;
  }
}

async function handleSubscriptionChange(subscription, config) {
  try {
    console.log("Processing subscription change:", subscription.id);

    let planType = "basic";

    if (
      subscription.items &&
      subscription.items.data &&
      subscription.items.data.length > 0
    ) {
      const priceId = subscription.items.data[0].price.id;
      if (priceId === config.pro_price_id) {
        planType = "pro";
      } else if (priceId === config.enterprise_price_id) {
        planType = "enterprise";
      }
    }

    const currentPeriodStart = new Date(
      subscription.current_period_start * 1000
    );
    const currentPeriodEnd = new Date(subscription.current_period_end * 1000);

    const existingSubscriptions = await sql`
      SELECT * FROM user_subscriptions 
      WHERE user_id = ${config.user_id}
    `;

    if (existingSubscriptions.length > 0) {
      await sql`
        UPDATE user_subscriptions 
        SET 
          stripe_subscription_id = ${subscription.id},
          plan_type = ${planType},
          status = ${subscription.status},
          current_period_start = ${currentPeriodStart},
          current_period_end = ${currentPeriodEnd},
          cancel_at_period_end = ${subscription.cancel_at_period_end},
          updated_at = CURRENT_TIMESTAMP
        WHERE user_id = ${config.user_id}
      `;
    } else {
      await sql`
        INSERT INTO user_subscriptions (
          user_id,
          stripe_customer_id,
          stripe_subscription_id,
          plan_type,
          status,
          current_period_start,
          current_period_end,
          cancel_at_period_end
        ) VALUES (
          ${config.user_id},
          ${subscription.customer},
          ${subscription.id},
          ${planType},
          ${subscription.status},
          ${currentPeriodStart},
          ${currentPeriodEnd},
          ${subscription.cancel_at_period_end}
        )
      `;
    }

    await sql`
      INSERT INTO stripe_test_logs 
      (user_id, test_mode, success, api_connection, webhook_status, errors) 
      VALUES 
      (${config.user_id}, ${config.mode === "test"}, ${true}, ${true}, 
       ${JSON.stringify({ received: true, event: "subscription_change" })},
       ${JSON.stringify({})})
    `;
  } catch (error) {
    console.error("Error handling subscription change:", error);

    await sql`
      INSERT INTO stripe_test_logs 
      (user_id, test_mode, success, api_connection, webhook_status, errors) 
      VALUES 
      (${config.user_id}, ${config.mode === "test"}, ${false}, ${true}, 
       ${JSON.stringify({
         received: true,
         event: "subscription_change",
         error: true,
       })},
       ${JSON.stringify({ message: error.message, stack: error.stack })})
    `;
  }
}

async function handleSubscriptionCancelled(subscription, config) {
  try {
    console.log("Processing subscription cancellation:", subscription.id);

    await sql`
      UPDATE user_subscriptions 
      SET 
        status = ${subscription.status},
        cancel_at_period_end = ${subscription.cancel_at_period_end},
        updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ${config.user_id} AND stripe_subscription_id = ${subscription.id}
    `;

    await sql`
      INSERT INTO stripe_test_logs 
      (user_id, test_mode, success, api_connection, webhook_status, errors) 
      VALUES 
      (${config.user_id}, ${config.mode === "test"}, ${true}, ${true}, 
       ${JSON.stringify({ received: true, event: "subscription_cancelled" })},
       ${JSON.stringify({})})
    `;
  } catch (error) {
    console.error("Error handling subscription cancellation:", error);

    await sql`
      INSERT INTO stripe_test_logs 
      (user_id, test_mode, success, api_connection, webhook_status, errors) 
      VALUES 
      (${config.user_id}, ${config.mode === "test"}, ${false}, ${true}, 
       ${JSON.stringify({
         received: true,
         event: "subscription_cancelled",
         error: true,
       })},
       ${JSON.stringify({ message: error.message, stack: error.stack })})
    `;
  }
}

class Stripe {
  constructor(secretKey) {
    this.secretKey = secretKey;
    this.webhooks = {
      constructEvent: (payload, signature, secret) => {
        if (!payload || !signature || !secret) {
          throw new Error("Missing required webhook verification parameters");
        }

        const event = JSON.parse(payload);

        if (!event.type || !event.data || !event.data.object) {
          throw new Error("Invalid event format");
        }

        return event;
      },
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}