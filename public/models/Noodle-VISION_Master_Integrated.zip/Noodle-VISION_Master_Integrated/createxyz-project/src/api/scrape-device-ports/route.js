async function handler({ make, model }) {
  if (!make || !model) return null;
  const query = encodeURIComponent(`${make} ${model} ports list`);
  const url = `https://www.google.com/search?q=${query}`;
  const res = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0",
    },
  });
  const html = await res.text();
  const portRegex =
    /(?:HDMI|USB|Ethernet|Audio|VGA|DisplayPort|Thunderbolt|DVI|SD Card|Optical|Coaxial|RCA|Component|Composite|Mini DisplayPort|Micro USB|USB-C|USB-A|USB-B|FireWire|eSATA|S-Video|Power|DC-In|AC-In|Headphone|Microphone|Line-In|Line-Out)[^<\n]{0,80}/gi;
  const matches = html.match(portRegex) || [];
  const uniquePorts = Array.from(new Set(matches));
  const ports = uniquePorts.map((port) => {
    let type = null;
    let color = null;
    let description = null;
    const lower = port.toLowerCase();
    if (lower.includes("hdmi")) type = "HDMI";
    else if (lower.includes("usb-c")) type = "USB-C";
    else if (lower.includes("usb-a")) type = "USB-A";
    else if (lower.includes("usb-b")) type = "USB-B";
    else if (lower.includes("usb")) type = "USB";
    else if (lower.includes("ethernet")) type = "Ethernet";
    else if (lower.includes("audio")) type = "Audio";
    else if (lower.includes("vga")) type = "VGA";
    else if (lower.includes("displayport")) type = "DisplayPort";
    else if (lower.includes("thunderbolt")) type = "Thunderbolt";
    else if (lower.includes("dvi")) type = "DVI";
    else if (lower.includes("sd card")) type = "SD Card";
    else if (lower.includes("optical")) type = "Optical";
    else if (lower.includes("coaxial")) type = "Coaxial";
    else if (lower.includes("rca")) type = "RCA";
    else if (lower.includes("component")) type = "Component";
    else if (lower.includes("composite")) type = "Composite";
    else if (lower.includes("mini displayport")) type = "Mini DisplayPort";
    else if (lower.includes("micro usb")) type = "Micro USB";
    else if (lower.includes("firewire")) type = "FireWire";
    else if (lower.includes("esata")) type = "eSATA";
    else if (lower.includes("s-video")) type = "S-Video";
    else if (
      lower.includes("power") ||
      lower.includes("dc-in") ||
      lower.includes("ac-in")
    )
      type = "Power";
    else if (lower.includes("headphone")) type = "Headphone";
    else if (lower.includes("microphone")) type = "Microphone";
    else if (lower.includes("line-in")) type = "Line-In";
    else if (lower.includes("line-out")) type = "Line-Out";
    return {
      name: port.trim(),
      type,
      color,
      description,
    };
  });
  return { ports };
}
export async function POST(request) {
  return handler(await request.json());
}