async function handler({ planId }) {
  if (!planId) {
    return { error: "Plan ID is required" };
  }

  const [pricingPlan] = await sql("SELECT * FROM pricing_plans WHERE id = $1", [
    planId,
  ]);

  if (!pricingPlan) {
    return { error: "Pricing plan not found" };
  }

  return pricingPlan;
}
export async function POST(request) {
  return handler(await request.json());
}