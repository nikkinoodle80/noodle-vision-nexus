async function handler() {
  try {
    const subscriptions = await sql`SELECT * FROM subscriptions`;
    return { subscriptions };
  } catch (error) {
    return { error: "An error occurred while fetching the subscriptions" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}