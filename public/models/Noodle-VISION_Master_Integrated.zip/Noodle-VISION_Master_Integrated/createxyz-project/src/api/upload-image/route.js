async function handler({ base64 }) {
  const { url, error } = await upload({ base64 });

  if (error) {
    return { error };
  }

  return { url };
}
export async function POST(request) {
  return handler(await request.json());
}