async function handler() {
  const healthStatus = {
    timestamp: new Date().toISOString(),
    status: "checking",
    database: { status: "unknown" },
    api: { status: "unknown", endpoints: {} },
    auth: { status: "unknown" },
    externalServices: {
      stripe: { status: "unknown" },
    },
    environment: { status: "unknown" },
  };

  try {
    // Check authentication
    const session = getSession();
    if (!session || !session.user) {
      healthStatus.auth = {
        status: "error",
        message: "User not authenticated",
      };
    } else {
      healthStatus.auth = {
        status: "healthy",
        message: "User authenticated",
        details: { userId: session.user.id },
      };
    }

    // Check database connection
    try {
      const dbResult = await sql`SELECT NOW()`;
      healthStatus.database = {
        status: "healthy",
        message: "Database connection successful",
      };

      // Check critical tables
      const tables = [
        "adapter_types",
        "devices",
        "auth_users",
        "user_configurations",
        "stripe_configuration",
      ];

      healthStatus.database.tables = {};
      let allTablesHealthy = true;

      for (const table of tables) {
        try {
          const query = `SELECT COUNT(*) FROM ${table}`;
          const result = await sql.unsafe(query);
          healthStatus.database.tables[table] = {
            status: "healthy",
            count: parseInt(result[0].count, 10),
          };
        } catch (tableError) {
          healthStatus.database.tables[table] = {
            status: "error",
            error: tableError.message,
          };
          allTablesHealthy = false;
        }
      }

      if (!allTablesHealthy) {
        healthStatus.database.status = "degraded";
        healthStatus.database.message = "Some tables have issues";
      }
    } catch (dbError) {
      healthStatus.database = {
        status: "error",
        message: "Database connection failed",
        error: dbError.message,
      };
    }

    // Check API endpoints
    const criticalEndpoints = [
      { name: "GetAdapterTypes", path: "/api/get-adapter-types" },
      { name: "GetDevices", path: "/api/get-devices" },
      { name: "GetUserConfigurations", path: "/api/get-user-configurations" },
    ];

    healthStatus.api.endpoints = {};
    let allEndpointsAvailable = true;

    for (const endpoint of criticalEndpoints) {
      try {
        const functionExists = typeof global[endpoint.name] === "function";
        healthStatus.api.endpoints[endpoint.name] = {
          status: functionExists ? "available" : "unavailable",
          path: endpoint.path,
        };

        if (!functionExists) {
          allEndpointsAvailable = false;
        }
      } catch (apiError) {
        healthStatus.api.endpoints[endpoint.name] = {
          status: "error",
          path: endpoint.path,
          error: apiError.message,
        };
        allEndpointsAvailable = false;
      }
    }

    healthStatus.api.status = allEndpointsAvailable ? "healthy" : "degraded";

    // Check Stripe configuration
    try {
      if (session && session.user) {
        const configs =
          await sql`SELECT * FROM stripe_configuration WHERE user_id = ${session.user.id}`;
        const config = configs[0];

        if (!config) {
          healthStatus.externalServices.stripe = {
            status: "not_configured",
            message: "Stripe configuration not found for user",
          };
        } else {
          const secretKey = config.is_test_mode
            ? config.test_secret_key
            : config.live_secret_key;
          const webhookSecret = config.is_test_mode
            ? config.test_webhook_secret
            : config.live_webhook_secret;
          const webhookUrl = config.is_test_mode
            ? config.test_webhook_url
            : config.live_webhook_url;
          const priceIdsConfigured = Boolean(
            config.basic_price_id &&
              config.pro_price_id &&
              config.enterprise_price_id
          );

          const stripeDetails = {
            mode: config.is_test_mode ? "test" : "live",
            apiKeyConfigured: Boolean(secretKey),
            webhookConfigured: Boolean(webhookSecret && webhookUrl),
            priceIdsConfigured,
          };

          if (
            stripeDetails.apiKeyConfigured &&
            stripeDetails.webhookConfigured &&
            stripeDetails.priceIdsConfigured
          ) {
            healthStatus.externalServices.stripe = {
              status: "healthy",
              message: "Stripe fully configured",
              details: stripeDetails,
            };
          } else {
            healthStatus.externalServices.stripe = {
              status: "degraded",
              message: "Stripe partially configured",
              details: stripeDetails,
            };
          }
        }
      } else {
        healthStatus.externalServices.stripe = {
          status: "unknown",
          message: "Cannot check Stripe configuration without authentication",
        };
      }
    } catch (stripeError) {
      healthStatus.externalServices.stripe = {
        status: "error",
        message: "Failed to check Stripe configuration",
        error: stripeError.message,
      };
    }

    // Check environment variables
    const requiredEnvVars = [
      "STRIPE_SECRET_KEY",
      "NEXTAUTH_SECRET",
      "NEXTAUTH_URL",
    ];

    const missingEnvVars = requiredEnvVars.filter(
      (varName) => !process.env[varName]
    );

    healthStatus.environment = {
      status: missingEnvVars.length === 0 ? "healthy" : "missing_variables",
      missingVariables: missingEnvVars.length > 0 ? missingEnvVars : undefined,
    };

    // Overall status
    const allStatuses = [
      healthStatus.database.status,
      healthStatus.api.status,
      healthStatus.auth.status,
      healthStatus.externalServices.stripe.status,
      healthStatus.environment.status,
    ];

    if (allStatuses.some((status) => status === "error")) {
      healthStatus.status = "critical";
    } else if (
      allStatuses.some((status) =>
        ["degraded", "missing_variables", "not_configured"].includes(status)
      )
    ) {
      healthStatus.status = "degraded";
    } else {
      healthStatus.status = "healthy";
    }

    // Add test Stripe connection functionality
    if (
      session &&
      session.user &&
      healthStatus.externalServices.stripe.status !== "error" &&
      healthStatus.externalServices.stripe.status !== "not_configured"
    ) {
      try {
        const stripeTestResponse = await fetch("/api/test-stripe-connection", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
        });

        if (stripeTestResponse.ok) {
          const stripeTestResult = await stripeTestResponse.json();
          healthStatus.externalServices.stripe.connectionTest = {
            status: stripeTestResult.success ? "success" : "failed",
            details: stripeTestResult,
          };
        } else {
          healthStatus.externalServices.stripe.connectionTest = {
            status: "error",
            message: "Failed to test Stripe connection",
            statusCode: stripeTestResponse.status,
          };
        }
      } catch (testError) {
        healthStatus.externalServices.stripe.connectionTest = {
          status: "error",
          message: "Error testing Stripe connection",
          error: testError.message,
        };
      }
    }

    return healthStatus;
  } catch (error) {
    healthStatus.status = "error";
    healthStatus.error = error.message;
    return healthStatus;
  }
}
export async function POST(request) {
  return handler(await request.json());
}