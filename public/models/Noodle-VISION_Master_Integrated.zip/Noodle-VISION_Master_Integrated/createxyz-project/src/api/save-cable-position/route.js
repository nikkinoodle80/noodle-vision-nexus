async function handler({ x, y }) {
  const session = getSession();

  if (!session || !session.user) {
    return { error: "Unauthorized" };
  }

  const userId = session.user.id;

  try {
    const result = await sql(
      "INSERT INTO cables (user_id, x, y, created_at) VALUES ($1, $2, $3, NOW()) RETURNING id",
      [userId, x, y]
    );

    return { success: true, cableId: result[0].id };
  } catch (error) {
    return { error: "Failed to save cable position" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}