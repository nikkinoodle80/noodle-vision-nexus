async function handler() {
  try {
    // Query all subscription plans from the database and sort by price
    const plans = await sql`
      SELECT id, name, description, price, interval, features, api_calls_limit, stripe_price_id
      FROM subscription_plans
      ORDER BY price ASC
    `;

    // Return the sorted list of plans
    return {
      success: true,
      plans: plans,
    };
  } catch (error) {
    console.error("Error fetching subscription plans:", error);

    // Return error response
    return {
      success: false,
      error: "Failed to retrieve subscription plans",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}