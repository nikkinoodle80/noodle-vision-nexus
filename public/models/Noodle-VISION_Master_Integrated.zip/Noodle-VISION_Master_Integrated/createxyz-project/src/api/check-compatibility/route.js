async function handler({ deviceA, deviceB }) {
  try {
    // Validate input parameters
    if (!deviceA || !deviceB) {
      return {
        success: false,
        error: "Both devices must be provided",
      };
    }

    // Fetch device details if IDs are provided
    let deviceAData = typeof deviceA === "object" ? deviceA : null;
    let deviceBData = typeof deviceB === "object" ? deviceB : null;

    if (!deviceAData && typeof deviceA === "number") {
      const result = await sql`SELECT * FROM devices WHERE id = ${deviceA}`;
      if (result.length === 0) {
        return { success: false, error: `Device with ID ${deviceA} not found` };
      }
      deviceAData = result[0];
    }

    if (!deviceBData && typeof deviceB === "number") {
      const result = await sql`SELECT * FROM devices WHERE id = ${deviceB}`;
      if (result.length === 0) {
        return { success: false, error: `Device with ID ${deviceB} not found` };
      }
      deviceBData = result[0];
    }

    if (!deviceAData || !deviceBData) {
      return { success: false, error: "Invalid device data provided" };
    }

    // Get input/output ports
    const deviceAOutputs = deviceAData.output_ports || [];
    const deviceBInputs = deviceBData.input_ports || [];

    // Check direct compatibility
    const directConnections = [];
    const incompatibleConnections = [];

    deviceAOutputs.forEach((outputPort) => {
      const compatibleInputs = deviceBInputs.filter(
        (inputPort) => inputPort.type === outputPort.type
      );

      if (compatibleInputs.length > 0) {
        directConnections.push({
          from: { device: deviceAData.name, port: outputPort },
          to: { device: deviceBData.name, port: compatibleInputs[0] },
        });
      } else {
        incompatibleConnections.push({
          outputPort: outputPort,
          device: deviceAData.name,
        });
      }
    });

    // If there are incompatible connections, find adapters
    let adapterRecommendations = [];

    if (incompatibleConnections.length > 0) {
      for (const connection of incompatibleConnections) {
        const adapters = await sql`
          SELECT * FROM adapters 
          WHERE input_type = ${connection.outputPort.type}
        `;

        for (const adapter of adapters) {
          const compatibleInputs = deviceBInputs.filter(
            (inputPort) => inputPort.type === adapter.output_type
          );

          if (compatibleInputs.length > 0) {
            adapterRecommendations.push({
              adapter: adapter,
              from: { device: connection.device, port: connection.outputPort },
              to: { device: deviceBData.name, port: compatibleInputs[0] },
            });
          }
        }
      }
    }

    // Determine overall compatibility status
    const isDirectlyCompatible = directConnections.length > 0;
    const isCompatibleWithAdapter = adapterRecommendations.length > 0;

    return {
      success: true,
      devices: {
        deviceA: deviceAData,
        deviceB: deviceBData,
      },
      compatibility: {
        isDirectlyCompatible,
        isCompatibleWithAdapter,
        isCompatible: isDirectlyCompatible || isCompatibleWithAdapter,
      },
      connections: {
        direct: directConnections,
        withAdapters: adapterRecommendations,
      },
      recommendations:
        !isDirectlyCompatible && !isCompatibleWithAdapter
          ? "These devices are not compatible, even with available adapters."
          : null,
    };
  } catch (error) {
    console.error("Error checking compatibility:", error);
    return {
      success: false,
      error: "Failed to check device compatibility",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}