function handler({ description }) {
  if (!description) {
    throw new Error("Patch description is required");
  }

  try {
    let generatedPatch = {
      name: "AI Generated Patch",
      description: description,
      modules: [],
      connections: [],
    };

    if (description.toLowerCase().includes("bass")) {
      generatedPatch = {
        name: "AI Bass Patch",
        description: "Generated bass sound based on your description",
        modules: [
          {
            id: "vco-1",
            type: "vco",
            position: { x: 100, y: 100 },
            settings: { waveform: "saw", octave: -1 },
          },
          {
            id: "vcf-1",
            type: "vcf",
            position: { x: 300, y: 100 },
            settings: { cutoff: 0.3, resonance: 0.7 },
          },
          {
            id: "adsr-1",
            type: "adsr",
            position: { x: 100, y: 300 },
            settings: { attack: 0.01, decay: 0.3, sustain: 0.7, release: 0.5 },
          },
          {
            id: "vca-1",
            type: "vca",
            position: { x: 500, y: 100 },
            settings: { gain: 0.8 },
          },
        ],
        connections: [
          {
            from: { module: "vco-1", port: "output" },
            to: { module: "vcf-1", port: "input" },
          },
          {
            from: { module: "vcf-1", port: "output" },
            to: { module: "vca-1", port: "input" },
          },
          {
            from: { module: "adsr-1", port: "output" },
            to: { module: "vca-1", port: "cv" },
          },
        ],
      };
    } else if (
      description.toLowerCase().includes("ambient") ||
      description.toLowerCase().includes("pad")
    ) {
      generatedPatch = {
        name: "AI Ambient Patch",
        description: "Generated ambient sound based on your description",
        modules: [
          {
            id: "vco-1",
            type: "vco",
            position: { x: 100, y: 100 },
            settings: { waveform: "sine", octave: 0 },
          },
          {
            id: "vco-2",
            type: "vco",
            position: { x: 100, y: 250 },
            settings: { waveform: "triangle", octave: 1, detune: 0.05 },
          },
          {
            id: "mixer-1",
            type: "mixer",
            position: { x: 300, y: 175 },
            settings: { levels: [0.6, 0.4] },
          },
          {
            id: "vcf-1",
            type: "vcf",
            position: { x: 500, y: 175 },
            settings: { cutoff: 0.7, resonance: 0.2 },
          },
          {
            id: "adsr-1",
            type: "adsr",
            position: { x: 300, y: 350 },
            settings: { attack: 2.0, decay: 1.0, sustain: 0.8, release: 3.0 },
          },
          {
            id: "reverb-1",
            type: "reverb",
            position: { x: 700, y: 175 },
            settings: { size: 0.9, damping: 0.2, wet: 0.7 },
          },
          {
            id: "vca-1",
            type: "vca",
            position: { x: 900, y: 175 },
            settings: { gain: 0.6 },
          },
        ],
        connections: [
          {
            from: { module: "vco-1", port: "output" },
            to: { module: "mixer-1", port: "input1" },
          },
          {
            from: { module: "vco-2", port: "output" },
            to: { module: "mixer-1", port: "input2" },
          },
          {
            from: { module: "mixer-1", port: "output" },
            to: { module: "vcf-1", port: "input" },
          },
          {
            from: { module: "vcf-1", port: "output" },
            to: { module: "reverb-1", port: "input" },
          },
          {
            from: { module: "reverb-1", port: "output" },
            to: { module: "vca-1", port: "input" },
          },
          {
            from: { module: "adsr-1", port: "output" },
            to: { module: "vca-1", port: "cv" },
          },
        ],
      };
    } else if (description.toLowerCase().includes("lead")) {
      generatedPatch = {
        name: "AI Lead Patch",
        description: "Generated lead sound based on your description",
        modules: [
          {
            id: "vco-1",
            type: "vco",
            position: { x: 100, y: 100 },
            settings: { waveform: "pulse", pulseWidth: 0.3, octave: 0 },
          },
          {
            id: "lfo-1",
            type: "lfo",
            position: { x: 100, y: 300 },
            settings: { rate: 5, amount: 0.1, waveform: "sine" },
          },
          {
            id: "vcf-1",
            type: "vcf",
            position: { x: 300, y: 100 },
            settings: { cutoff: 0.8, resonance: 0.6 },
          },
          {
            id: "adsr-1",
            type: "adsr",
            position: { x: 300, y: 300 },
            settings: { attack: 0.05, decay: 0.2, sustain: 0.6, release: 0.3 },
          },
          {
            id: "delay-1",
            type: "delay",
            position: { x: 500, y: 100 },
            settings: { time: 0.25, feedback: 0.3, mix: 0.2 },
          },
          {
            id: "vca-1",
            type: "vca",
            position: { x: 700, y: 100 },
            settings: { gain: 0.7 },
          },
        ],
        connections: [
          {
            from: { module: "lfo-1", port: "output" },
            to: { module: "vco-1", port: "fm" },
          },
          {
            from: { module: "vco-1", port: "output" },
            to: { module: "vcf-1", port: "input" },
          },
          {
            from: { module: "vcf-1", port: "output" },
            to: { module: "delay-1", port: "input" },
          },
          {
            from: { module: "delay-1", port: "output" },
            to: { module: "vca-1", port: "input" },
          },
          {
            from: { module: "adsr-1", port: "output" },
            to: { module: "vca-1", port: "cv" },
          },
        ],
      };
    } else {
      generatedPatch = {
        name: "AI Simple Patch",
        description: "Generated sound based on your description",
        modules: [
          {
            id: "vco-1",
            type: "vco",
            position: { x: 100, y: 100 },
            settings: { waveform: "sine", octave: 0 },
          },
          {
            id: "vcf-1",
            type: "vcf",
            position: { x: 300, y: 100 },
            settings: { cutoff: 0.5, resonance: 0.3 },
          },
          {
            id: "adsr-1",
            type: "adsr",
            position: { x: 100, y: 300 },
            settings: { attack: 0.1, decay: 0.2, sustain: 0.5, release: 0.5 },
          },
          {
            id: "vca-1",
            type: "vca",
            position: { x: 500, y: 100 },
            settings: { gain: 0.7 },
          },
        ],
        connections: [
          {
            from: { module: "vco-1", port: "output" },
            to: { module: "vcf-1", port: "input" },
          },
          {
            from: { module: "vcf-1", port: "output" },
            to: { module: "vca-1", port: "input" },
          },
          {
            from: { module: "adsr-1", port: "output" },
            to: { module: "vca-1", port: "cv" },
          },
        ],
      };
    }

    return {
      success: true,
      patch: generatedPatch,
    };
  } catch (error) {
    console.error("Error generating patch with AI:", error);
    throw new Error(`Failed to generate patch: ${error.message}`);
  }
}
export async function POST(request) {
  return handler(await request.json());
}