async function handler({ id, x, y }) {
  if (!id || x === undefined || y === undefined) {
    return { error: "Invalid input" };
  }

  const session = getSession();
  if (!session) {
    return { error: "Unauthorized" };
  }

  try {
    const result = await sql(
      "UPDATE cables SET x = $1, y = $2 WHERE id = $3 RETURNING *",
      [x, y, id]
    );

    if (result.length === 0) {
      return { error: "Cable not found" };
    }

    return { success: true, cable: result[0] };
  } catch (error) {
    console.error("Error updating cable position:", error);
    return { error: "Failed to update cable position" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}