function handler() {
  try {
    const session = getSession();

    if (!session || !session.user) {
      return {
        success: false,
        error: "You must be signed in to view saved configurations",
      };
    }

    const configurations = sql`
      SELECT id, name, devices, connections, layout, created_at
      FROM user_saved_setups
      WHERE user_id = ${session.user.id}
      ORDER BY created_at DESC
    `;

    return {
      success: true,
      configurations,
    };
  } catch (error) {
    console.error("Error retrieving configurations:", error);
    return {
      success: false,
      error: "Failed to retrieve configurations",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}