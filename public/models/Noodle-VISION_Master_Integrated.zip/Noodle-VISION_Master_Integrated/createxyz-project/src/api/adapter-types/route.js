async function handler() {
  try {
    const adapterTypes = await sql`
      SELECT * FROM adapter_types
      ORDER BY name ASC
    `;

    return {
      success: true,
      adapterTypes: adapterTypes,
    };
  } catch (error) {
    console.error("Error fetching adapter types:", error);
    return {
      success: false,
      error: "Failed to fetch adapter types",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}