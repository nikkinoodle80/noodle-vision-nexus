async function handler({ name, location, contactInfo, inventory = [] }) {
  if (!name || typeof name !== "string" || name.trim().length === 0) {
    return { error: "Store name is required and must be a non-empty string" };
  }

  if (
    !location ||
    typeof location !== "string" ||
    location.trim().length === 0
  ) {
    return {
      error: "Store location is required and must be a non-empty string",
    };
  }

  if (
    !contactInfo ||
    typeof contactInfo !== "string" ||
    contactInfo.trim().length === 0
  ) {
    return {
      error: "Contact information is required and must be a non-empty string",
    };
  }

  if (inventory && !Array.isArray(inventory)) {
    return { error: "Inventory must be an array of product IDs" };
  }

  try {
    const timestamp = new Date().toISOString();
    const session = getSession();
    const userId = session?.user?.id || "anonymous";

    const result = await sql.transaction(async (txn) => {
      const storeResult = await txn(
        "INSERT INTO stores (name, location, contact_info) VALUES ($1, $2, $3) RETURNING id",
        [name, location, contactInfo]
      );

      const storeId = storeResult[0]?.id;

      if (!storeId) {
        throw new Error("Failed to create store");
      }

      if (inventory.length > 0) {
        const inventoryValues = inventory
          .map((productId, index) => {
            return `($1, $${index + 2}, 10)`;
          })
          .join(", ");

        const inventoryParams = [storeId, ...inventory];

        await txn(`
          CREATE TABLE IF NOT EXISTS store_inventory (
            id SERIAL PRIMARY KEY,
            store_id INTEGER REFERENCES stores(id),
            product_id INTEGER REFERENCES products(id),
            quantity INTEGER NOT NULL DEFAULT 0
          )
        `);

        if (inventory.length > 0) {
          const placeholders = inventory
            .map((_, i) => `($1, $${i + 2}, 10)`)
            .join(", ");

          await txn(
            `
            INSERT INTO store_inventory (store_id, product_id, quantity)
            VALUES ${placeholders}
          `,
            [storeId, ...inventory]
          );
        }
      }

      await txn(`
        CREATE TABLE IF NOT EXISTS audit_logs (
          id SERIAL PRIMARY KEY,
          action VARCHAR(255) NOT NULL,
          entity_type VARCHAR(255) NOT NULL,
          entity_id INTEGER,
          user_id VARCHAR(255),
          timestamp TIMESTAMP NOT NULL,
          details JSONB
        )
      `);

      await txn(
        "INSERT INTO audit_logs (action, entity_type, entity_id, user_id, timestamp, details) VALUES ($1, $2, $3, $4, $5, $6)",
        [
          "create",
          "store",
          storeId,
          userId,
          timestamp,
          JSON.stringify({ name, location, contactInfo, inventory }),
        ]
      );

      return { storeId };
    });

    return {
      success: true,
      message: "Store added successfully",
      storeId: result.storeId,
    };
  } catch (error) {
    console.error("Error creating store:", error);

    if (error.message.includes("duplicate key")) {
      return { error: "A store with this name already exists" };
    } else if (error.message.includes("foreign key constraint")) {
      return { error: "One or more product IDs in the inventory are invalid" };
    } else {
      return { error: `Failed to create store: ${error.message}` };
    }
  }
}
export async function POST(request) {
  return handler(await request.json());
}