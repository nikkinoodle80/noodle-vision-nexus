async function handler({ body }) {
  const { imageData, userId } = body;

  if (!imageData) {
    return {
      success: false,
      error: "No image data provided",
    };
  }

  try {
    await new Promise((resolve) => setTimeout(resolve, 1500));

    const extractedInventory = {
      adapters: [
        { type: "HDMI to VGA", quantity: 2, condition: "good" },
        { type: "VGA to HDMI", quantity: 1, condition: "good" },
        { type: "USB-C to HDMI", quantity: 1, condition: "excellent" },
        { type: "USB-C to Bluetooth", quantity: 1, condition: "excellent" },
        { type: "DisplayPort to HDMI", quantity: 1, condition: "fair" },
      ],
      devices: [
        {
          type: "Smartphone",
          brand: "Samsung",
          model: "Galaxy S21",
          ports: ["USB-C"],
        },
        {
          type: "Monitor",
          brand: "Dell",
          model: "U2719D",
          ports: ["HDMI", "DisplayPort", "VGA"],
        },
        {
          type: "Laptop",
          brand: "Apple",
          model: "MacBook Pro",
          ports: ["USB-C"],
        },
      ],
      cables: [
        { type: "HDMI", length: "6ft", quantity: 3 },
        { type: "VGA", length: "6ft", quantity: 2 },
        { type: "USB-C", length: "3ft", quantity: 2 },
      ],
    };

    if (userId) {
      console.log(`Saving inventory for user ${userId}`);

      const session = getSession();
      if (session && session.user) {
        console.log(`Authenticated user ${session.user.id} saving inventory`);
      }
    }

    return {
      success: true,
      inventory: extractedInventory,
    };
  } catch (error) {
    console.error("Error processing inventory image:", error);
    return {
      success: false,
      error: "Failed to process inventory image",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}