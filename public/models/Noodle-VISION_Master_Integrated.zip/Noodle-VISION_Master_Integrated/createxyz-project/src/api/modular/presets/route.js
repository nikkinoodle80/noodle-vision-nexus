async function handler({ category, difficulty, tags } = {}) {
  try {
    const session = getSession();

    const moduleTypes = await sql`
      SELECT * FROM module_types 
      ORDER BY category, name
    `;

    let queryText = `
      SELECT up.*, 
             au.name as creator_name,
             COUNT(DISTINCT pm.id) as module_count,
             COUNT(DISTINCT pc.id) as connection_count,
             COALESCE(AVG(pr.rating), 0) as avg_rating,
             COUNT(DISTINCT pr.id) as rating_count
      FROM user_patches up
      LEFT JOIN auth_users au ON up.user_id = au.id
      LEFT JOIN patch_modules pm ON up.id = pm.patch_id
      LEFT JOIN patch_connections pc ON up.id = pc.patch_id
      LEFT JOIN patch_ratings pr ON up.id = pr.patch_id
    `;

    const whereConditions = [];
    const params = [];

    if (category) {
      whereConditions.push(`EXISTS (
        SELECT 1 FROM patch_modules pm2 
        JOIN module_types mt ON pm2.module_type_id = mt.id 
        WHERE pm2.patch_id = up.id AND mt.category = $${params.length + 1}
      )`);
      params.push(category);
    }

    if (tags && tags.length > 0) {
      whereConditions.push(`up.tags @> $${params.length + 1}`);
      params.push(JSON.stringify(tags));
    }

    if (whereConditions.length > 0) {
      queryText += ` WHERE ${whereConditions.join(" AND ")}`;
    }

    queryText += `
      GROUP BY up.id, au.name
      ORDER BY avg_rating DESC, up.created_at DESC
    `;

    const patches = await sql(queryText, params);

    const patchesWithDetails = await Promise.all(
      (patches || []).map(async (patch) => {
        const modules = await sql`
        SELECT pm.*, mt.name as module_type_name, mt.category
        FROM patch_modules pm
        JOIN module_types mt ON pm.module_type_id = mt.id
        WHERE pm.patch_id = ${patch.id}
        ORDER BY pm.position_x, pm.position_y
      `;

        const connections = await sql`
        SELECT pc.*,
               fm.custom_name as from_module_name,
               tm.custom_name as to_module_name,
               fmt.name as from_module_type,
               tmt.name as to_module_type
        FROM patch_connections pc
        JOIN patch_modules fm ON pc.from_module_id = fm.id
        JOIN patch_modules tm ON pc.to_module_id = tm.id
        JOIN module_types fmt ON fm.module_type_id = fmt.id
        JOIN module_types tmt ON tm.module_type_id = tmt.id
        WHERE pc.patch_id = ${patch.id}
      `;

        let userRating = null;
        if (session?.user?.id) {
          const userRatingResult = await sql`
          SELECT rating, comment
          FROM patch_ratings
          WHERE patch_id = ${patch.id} AND user_id = ${session.user.id}
        `;

          if (userRatingResult && userRatingResult.length > 0) {
            userRating = userRatingResult[0];
          }
        }

        return {
          id: patch.id,
          name: patch.name,
          description: patch.description,
          author: patch.creator_name,
          modules: modules.map((m) => ({
            id: m.id,
            type: m.module_type_name,
            settings: m.settings || {},
          })),
          connections: connections.map((c) => ({
            from: {
              module: c.from_module_id,
              port: c.from_port,
            },
            to: {
              module: c.to_module_id,
              port: c.to_port,
            },
            cableColor: c.cable_color,
          })),
          avgRating: patch.avg_rating,
          ratingCount: patch.rating_count,
          userRating,
        };
      })
    );

    return {
      moduleTypes: moduleTypes,
      presets: patchesWithDetails,
      userCanEdit: !!session?.user?.id,
    };
  } catch (error) {
    console.error("Error fetching modular synthesizer presets:", error);
    throw new Error(
      `Failed to fetch modular synthesizer presets: ${error.message}`
    );
  }
}
export async function POST(request) {
  return handler(await request.json());
}