function handler({
  name,
  description,
  isPublic,
  modules,
  connections,
  patchId,
}) {
  try {
    const session = getSession();

    if (!session?.user?.id) {
      throw new Error("You must be logged in to save a patch");
    }

    if (!name) {
      throw new Error("Patch name is required");
    }

    if (!modules || modules.length === 0) {
      throw new Error("Patch must contain at least one module");
    }

    return sql.transaction(async (txn) => {
      let patch;

      if (patchId) {
        const existingPatch = await txn(
          "SELECT * FROM user_patches WHERE id = $1 AND user_id = $2",
          [patchId, session.user.id]
        );

        if (existingPatch.length === 0) {
          throw new Error("You don't have permission to edit this patch");
        }

        const updatedPatch = await txn(
          "UPDATE user_patches SET name = $1, description = $2, is_public = $3, updated_at = CURRENT_TIMESTAMP WHERE id = $4 RETURNING *",
          [name, description, isPublic, patchId]
        );

        patch = updatedPatch[0];

        await txn("DELETE FROM patch_connections WHERE patch_id = $1", [
          patchId,
        ]);
        await txn("DELETE FROM patch_modules WHERE patch_id = $1", [patchId]);
      } else {
        const newPatch = await txn(
          "INSERT INTO user_patches (user_id, name, description, is_public) VALUES ($1, $2, $3, $4) RETURNING *",
          [session.user.id, name, description, isPublic]
        );

        patch = newPatch[0];
      }

      const moduleIdMap = {};

      for (const module of modules) {
        const newModule = await txn(
          "INSERT INTO patch_modules (patch_id, module_type_id, custom_name, position_x, position_y, settings) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *",
          [
            patch.id,
            module.moduleTypeId,
            module.customName || null,
            module.positionX,
            module.positionY,
            module.settings ? JSON.stringify(module.settings) : "{}",
          ]
        );

        moduleIdMap[module.tempId || module.id] = newModule[0].id;
      }

      for (const connection of connections) {
        const fromModuleId = moduleIdMap[connection.fromModuleId];
        const toModuleId = moduleIdMap[connection.toModuleId];

        if (!fromModuleId || !toModuleId) {
          console.warn("Invalid module reference in connection", connection);
          continue;
        }

        await txn(
          "INSERT INTO patch_connections (patch_id, from_module_id, from_port, to_module_id, to_port, cable_color) VALUES ($1, $2, $3, $4, $5, $6)",
          [
            patch.id,
            fromModuleId,
            connection.fromPort,
            toModuleId,
            connection.toPort,
            connection.cableColor || null,
          ]
        );
      }

      return {
        success: true,
        patchId: patch.id,
        message: patchId
          ? "Patch updated successfully"
          : "Patch saved successfully",
      };
    });
  } catch (error) {
    console.error("Error saving user patch:", error);
    throw new Error(`Failed to save patch: ${error.message}`);
  }
}
export async function POST(request) {
  return handler(await request.json());
}