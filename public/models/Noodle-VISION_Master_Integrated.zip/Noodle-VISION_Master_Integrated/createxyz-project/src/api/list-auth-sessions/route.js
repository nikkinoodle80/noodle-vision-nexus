async function handler({ filter = {}, page = 1, pageSize = 10 }) {
  const offset = (page - 1) * pageSize;
  const conditions = [];
  const values = [];

  if (filter.userId) {
    conditions.push(`"userId" = $${conditions.length + 1}`);
    values.push(filter.userId);
  }

  if (filter.sessionToken) {
    conditions.push(`"sessionToken" ILIKE $${conditions.length + 1}`);
    values.push(`%${filter.sessionToken}%`);
  }

  const whereClause = conditions.length
    ? `WHERE ${conditions.join(" AND ")}`
    : "";
  const query = `
    SELECT * FROM auth_sessions
    ${whereClause}
    ORDER BY id
    LIMIT $${conditions.length + 1} OFFSET $${conditions.length + 2}
  `;

  values.push(pageSize, offset);

  const sessions = await sql(query, values);
  return { sessions };
}
export async function POST(request) {
  return handler(await request.json());
}