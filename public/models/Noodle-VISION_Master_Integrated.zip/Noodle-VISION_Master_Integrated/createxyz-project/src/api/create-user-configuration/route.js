async function handler({ name, devices, connections, layout }) {
  const session = getSession();

  if (!session || !session.user) {
    return { error: "User not authenticated" };
  }

  const userId = session.user.id;

  try {
    const [newConfig] = await sql`
      INSERT INTO user_saved_setups (user_id, name, devices, connections, layout)
      VALUES (${userId}, ${name}, ${devices}, ${connections}, ${layout})
      RETURNING id
    `;

    return {
      success: true,
      message: "Configuration created successfully",
      configurationId: newConfig.id,
    };
  } catch (error) {
    return { error: "Failed to create configuration" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}