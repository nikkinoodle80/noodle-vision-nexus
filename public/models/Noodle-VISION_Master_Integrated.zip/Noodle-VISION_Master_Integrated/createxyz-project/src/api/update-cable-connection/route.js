async function handler({ id, startPosition, endPosition }) {
  if (!id) {
    return { error: "ID is required" };
  }

  const setClauses = [];
  const values = [];
  let paramCount = 1;

  if (startPosition !== undefined) {
    setClauses.push(`start_position = $${paramCount++}`);
    values.push(startPosition);
  }

  if (endPosition !== undefined) {
    setClauses.push(`end_position = $${paramCount++}`);
    values.push(endPosition);
  }

  if (setClauses.length === 0) {
    return { error: "No fields to update" };
  }

  values.push(id);

  const query = `
    UPDATE cable_connections
    SET ${setClauses.join(", ")}
    WHERE id = $${paramCount}
  `;

  try {
    await sql(query, values);
    return { success: true };
  } catch (error) {
    return { error: error.message };
  }
}
export async function POST(request) {
  return handler(await request.json());
}