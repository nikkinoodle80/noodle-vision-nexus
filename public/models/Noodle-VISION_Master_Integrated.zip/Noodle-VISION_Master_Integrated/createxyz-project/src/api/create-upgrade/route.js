async function handler({ user_id, upgrade_type, configuration }) {
  if (!user_id || !upgrade_type || !configuration) {
    return {
      error: "Missing required fields",
      details: { user_id, upgrade_type, configuration },
    };
  }

  const session = getSession();
  if (session && session.user) {
    if (!user_id) {
      user_id = session.user.id;
    } else if (user_id !== session.user.id) {
      const userCheck = await sql("SELECT * FROM auth_users WHERE id = $1", [
        user_id,
      ]);
      if (userCheck.length === 0) {
        return { error: "User not found" };
      }
    }
  }

  const validUpgradeTypes = [
    "hardware",
    "software",
    "connectivity",
    "storage",
    "performance",
  ];
  if (!validUpgradeTypes.includes(upgrade_type)) {
    return {
      error: "Invalid upgrade type",
      validTypes: validUpgradeTypes,
    };
  }

  const existingUpgrades = await sql(
    "SELECT * FROM user_upgrades WHERE user_id = $1",
    [user_id]
  );

  let configValidation = validateConfiguration(
    upgrade_type,
    configuration,
    existingUpgrades
  );
  if (configValidation.error) {
    return configValidation;
  }

  try {
    const result = await sql(
      "INSERT INTO user_upgrades (user_id, upgrade_type, configuration) VALUES ($1, $2, $3) RETURNING *",
      [user_id, upgrade_type, configuration]
    );

    if (result.length === 0) {
      return { error: "Failed to add upgrade" };
    }

    const newUpgrade = result[0];

    const userInfo = await sql(
      "SELECT name, email FROM auth_users WHERE id = $1",
      [user_id]
    );

    return {
      success: true,
      message: `${upgrade_type} upgrade added successfully`,
      upgrade: {
        id: newUpgrade.id,
        type: newUpgrade.upgrade_type,
        configuration: newUpgrade.configuration,
        user:
          userInfo.length > 0
            ? {
                id: user_id,
                name: userInfo[0].name,
                email: userInfo[0].email,
              }
            : { id: user_id },
        created_at: new Date().toISOString(),
      },
    };
  } catch (error) {
    return {
      error: "An error occurred while adding the upgrade",
      details: error.message || "Unknown database error",
    };
  }
}

function validateConfiguration(upgradeType, configuration, existingUpgrades) {
  if (typeof configuration !== "object") {
    return { error: "Configuration must be an object" };
  }

  switch (upgradeType) {
    case "hardware":
      if (!configuration.model || !configuration.specs) {
        return { error: "Hardware upgrades require model and specs" };
      }
      break;

    case "software":
      if (!configuration.version || !configuration.features) {
        return { error: "Software upgrades require version and features" };
      }
      break;

    case "connectivity":
      if (!configuration.protocol || !configuration.bandwidth) {
        return {
          error: "Connectivity upgrades require protocol and bandwidth",
        };
      }
      break;

    case "storage":
      if (!configuration.capacity || !configuration.type) {
        return { error: "Storage upgrades require capacity and type" };
      }
      break;

    case "performance":
      if (!configuration.level || !configuration.components) {
        return { error: "Performance upgrades require level and components" };
      }
      break;
  }

  for (const existing of existingUpgrades) {
    if (existing.upgrade_type === upgradeType) {
      if (
        JSON.stringify(existing.configuration) === JSON.stringify(configuration)
      ) {
        return {
          error: "Duplicate upgrade configuration",
          existingId: existing.id,
        };
      }

      if (
        upgradeType === "hardware" &&
        existing.configuration.model === configuration.model &&
        existing.configuration.specs !== configuration.specs
      ) {
        return {
          error: "Conflicting hardware upgrade",
          details: "Cannot have different specs for the same hardware model",
          existingId: existing.id,
        };
      }
    }
  }

  return { valid: true };
}
export async function POST(request) {
  return handler(await request.json());
}