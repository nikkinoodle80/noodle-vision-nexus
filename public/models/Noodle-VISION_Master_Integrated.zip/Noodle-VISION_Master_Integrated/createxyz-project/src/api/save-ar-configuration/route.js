async function handler({ name, devices, connections, arPosition }) {
  try {
    // Get current user session
    const session = getSession();
    if (!session || !session.user) {
      return { error: "Authentication required" };
    }

    // Validate input data
    if (!name || typeof name !== "string") {
      return { error: "Name is required and must be a string" };
    }

    if (!Array.isArray(devices) || devices.length === 0) {
      return { error: "Devices are required and must be an array" };
    }

    if (!Array.isArray(connections)) {
      return { error: "Connections must be an array" };
    }

    // Save AR configuration to database
    const result = await sql`
      INSERT INTO ar_configurations (
        user_id, 
        name, 
        devices, 
        connections, 
        ar_position, 
        created_at, 
        updated_at
      ) 
      VALUES (
        ${session.user.id}, 
        ${name}, 
        ${JSON.stringify(devices)}, 
        ${JSON.stringify(connections)}, 
        ${arPosition ? JSON.stringify(arPosition) : null}, 
        NOW(), 
        NOW()
      ) 
      RETURNING *
    `;

    if (result && result.length > 0) {
      return {
        success: true,
        configuration: result[0],
      };
    } else {
      return { error: "Failed to save AR configuration" };
    }
  } catch (error) {
    console.error("Error saving AR configuration:", error);
    return {
      error: "An unexpected error occurred while saving the configuration",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}