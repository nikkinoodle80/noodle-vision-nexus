async function handler({ name, devices, connections, layout }) {
  try {
    const session = getSession();

    if (!session || !session.user) {
      return {
        success: false,
        error: "You must be signed in to save configurations",
      };
    }

    // Validate input
    if (!name || !devices || !connections) {
      return {
        success: false,
        error: "Missing required fields",
      };
    }

    // Save to database
    const result = await sql(
      `
      INSERT INTO user_saved_setups 
      (user_id, name, devices, connections, layout, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, NOW(), NOW())
      RETURNING id`,
      [
        session.user.id,
        name,
        JSON.stringify(devices),
        JSON.stringify(connections),
        JSON.stringify(layout || {}),
      ]
    );

    return {
      success: true,
      id: result[0].id,
      message: "Configuration saved successfully",
    };
  } catch (error) {
    console.error("Error saving configuration:", error);
    return {
      success: false,
      error: "Failed to save configuration",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}