async function handler({ operations }) {
  if (!operations || !Array.isArray(operations)) {
    return { error: "Invalid operations array provided" };
  }

  try {
    const session = getSession();
    if (!session?.user?.id) {
      return { error: "Unauthorized" };
    }

    const results = await sql.transaction(async (txn) => {
      const operationResults = [];

      for (const op of operations) {
        const { type, data } = op;

        switch (type) {
          case "createDevice":
            const device = await txn`
              INSERT INTO devices (name, type, brand, model, ports)
              VALUES (${data.name}, ${data.type}, ${data.brand}, ${data.model}, ${data.ports})
              RETURNING *`;
            operationResults.push({ type, result: device[0] });
            break;

          case "updateAdapter":
            const adapter = await txn`
              UPDATE adapter_types
              SET name = ${data.name},
                  input_type = ${data.inputType},
                  output_type = ${data.outputType}
              WHERE id = ${data.id}
              RETURNING *`;
            operationResults.push({ type, result: adapter[0] });
            break;

          case "deleteSetup":
            await txn`DELETE FROM home_setups WHERE id = ${data.id} AND user_id = ${session.user.id}`;
            operationResults.push({ type, result: { success: true } });
            break;

          default:
            operationResults.push({
              type,
              error: "Unsupported operation type",
            });
        }
      }

      return operationResults;
    });

    return { results };
  } catch (error) {
    return { error: "Failed to process batch operations" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}