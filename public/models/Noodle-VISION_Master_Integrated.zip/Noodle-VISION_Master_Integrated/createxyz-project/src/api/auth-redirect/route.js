function handler({ requestedPath }) {
  const session = getSession();

  if (!session || !session.user) {
    // User is not authenticated, redirect to sign-in page
    return {
      authenticated: false,
      redirectTo: "/sign-in",
      message: "Please sign in to access this page",
    };
  }

  // User is authenticated, allow access to the requested page
  return {
    authenticated: true,
    user: {
      id: session.user.id,
      name: session.user.name,
      email: session.user.email,
    },
    redirectTo: requestedPath || "/",
  };
}
export async function POST(request) {
  return handler(await request.json());
}