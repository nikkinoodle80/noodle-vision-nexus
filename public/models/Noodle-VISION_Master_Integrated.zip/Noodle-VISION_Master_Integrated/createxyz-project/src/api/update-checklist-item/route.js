function handler({ id, is_completed, notes }) {
  try {
    if (!id) {
      return {
        success: false,
        error: "Item ID is required",
      };
    }

    const updateFields = [];
    const queryParams = [id];
    let paramCounter = 2;

    if (is_completed !== undefined) {
      updateFields.push(`is_completed = $${paramCounter}`);
      queryParams.push(is_completed);
      paramCounter++;

      if (is_completed) {
        updateFields.push(`completed_at = CURRENT_TIMESTAMP`);
      } else {
        updateFields.push(`completed_at = NULL`);
      }
    }

    if (notes !== undefined) {
      updateFields.push(`notes = $${paramCounter}`);
      queryParams.push(notes);
      paramCounter++;
    }

    if (updateFields.length === 0) {
      return {
        success: false,
        error: "No fields to update",
      };
    }

    const query = `
      UPDATE deployment_checklist
      SET ${updateFields.join(", ")}
      WHERE id = $1
      RETURNING *
    `;

    return sql(query, queryParams)
      .then((result) => {
        if (result.length === 0) {
          return {
            success: false,
            error: "Item not found",
          };
        }

        return {
          success: true,
          item: result[0],
        };
      })
      .catch((error) => {
        console.error("Error updating checklist item:", error);
        return {
          success: false,
          error: "Failed to update checklist item",
        };
      });
  } catch (error) {
    console.error("Error in handler:", error);
    return {
      success: false,
      error: "Failed to process request",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}