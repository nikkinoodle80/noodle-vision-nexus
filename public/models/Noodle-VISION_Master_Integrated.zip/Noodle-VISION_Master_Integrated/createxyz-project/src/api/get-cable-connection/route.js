async function handler({ id }) {
  if (!id) {
    return null;
  }

  const result = await sql(
    "SELECT position_x AS start_position, position_y AS end_position FROM patch_connections WHERE id = $1",
    [id]
  );

  if (result.length === 0) {
    return null;
  }

  return result[0];
}
export async function POST(request) {
  return handler(await request.json());
}