async function handler({ user_id }) {
  if (!user_id) {
    return { error: "Missing user_id" };
  }

  try {
    const upgrades = await sql(
      "SELECT * FROM user_upgrades WHERE user_id = $1",
      [user_id]
    );
    return upgrades.length > 0 ? { upgrades } : { error: "No upgrades found" };
  } catch (error) {
    return { error: "An error occurred while fetching the upgrades" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}