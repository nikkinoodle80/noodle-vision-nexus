async function handler({ userInput }) {
  const session = getSession();
  if (!session) {
    return { error: "User not authenticated" };
  }

  const { userId } = session.user;
  const { sourceDeviceId, targetDeviceId, options } = userInput;

  try {
    const [conventionalConnections, unconventionalConnections] =
      await sql.transaction((txn) => [
        txn`SELECT * FROM configuration_adapters WHERE configuration_id = ${sourceDeviceId} AND adapter_type_id = ${targetDeviceId}`,
        txn`SELECT * FROM compatibility_issues WHERE adapter_pattern @> ${JSON.stringify(
          options
        )}`,
      ]);

    const feedback = {
      conventional: conventionalConnections,
      unconventional: unconventionalConnections,
    };

    return { feedback };
  } catch (error) {
    return { error: "Failed to simulate configurations" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}