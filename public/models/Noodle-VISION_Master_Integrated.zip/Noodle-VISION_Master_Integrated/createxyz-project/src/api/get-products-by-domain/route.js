function handler({ domainId }) {
  try {
    const products = sql`
      SELECT p.* FROM products p
      WHERE p.is_active = true
      AND (p.category IN (
        SELECT name FROM domains WHERE id = ${domainId}
      ) OR ${domainId} IS NULL)
      ORDER BY p.name
    `;

    return {
      success: true,
      products,
    };
  } catch (error) {
    console.error("Error fetching products by domain:", error);
    return {
      success: false,
      error: "Failed to fetch products",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}