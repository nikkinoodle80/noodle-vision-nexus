async function handler({
  devices,
  adapters,
  cables,
  userQuestion,
  connections,
}) {
  if (connections && devices) {
    // First implementation format
  } else if (!devices || !adapters || !cables) {
    return {
      error:
        "Please provide either devices+connections or devices+adapters+cables for analysis",
    };
  }

  try {
    let deviceDetails = [];
    if (devices && Array.isArray(devices)) {
      const deviceIds = devices
        .filter((device) => device && typeof device.id === "number")
        .map((device) => device.id);

      if (deviceIds.length > 0) {
        deviceDetails = await sql(
          "SELECT id, name, category, input_ports, output_ports FROM devices WHERE id = ANY($1)",
          [deviceIds]
        );
      }
    }

    const enhancedDevices = Array.isArray(devices)
      ? devices.map((device) => {
          const details = deviceDetails.find((d) => d.id === device.id);
          return {
            ...device,
            details: details || null,
          };
        })
      : devices;

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-3-sonnet-20240229",
        max_tokens: 2000,
        messages: [
          {
            role: "user",
            content: `I need to analyze the compatibility between these hardware components:
            
            DEVICES:
            ${JSON.stringify(enhancedDevices, null, 2)}
            
            ${
              connections
                ? `CONNECTIONS:
            ${JSON.stringify(connections, null, 2)}`
                : `
            ADAPTERS:
            ${JSON.stringify(adapters, null, 2)}
            
            CABLES:
            ${JSON.stringify(cables, null, 2)}`
            }
            
            ${userQuestion ? `USER QUESTION: ${userQuestion}` : ""}
            
            Please provide a detailed analysis including:
            1. Overall compatibility assessment
            2. Any potential issues or limitations
            3. Specific connection paths that will work
            4. Alternative recommendations if there are compatibility issues
            5. Performance expectations
            
            Format your response in markdown with clear sections.`,
          },
        ],
      }),
    });

    if (!response.ok) {
      throw new Error(`Anthropic API error: ${response.status}`);
    }

    const message = await response.json();

    const session = getSession();
    if (session && session.user) {
      await sql(
        "INSERT INTO api_usage (user_id, api_type, request_type, tokens_used, created_at) VALUES ($1, $2, $3, $4, NOW())",
        [
          session.user.id,
          "anthropic",
          "compatibility-analysis",
          message.usage?.output_tokens || 0,
        ]
      );
    }

    return {
      analysis: message.content[0].text,
      success: true,
      setupData: {
        devices: enhancedDevices,
        connections: connections || null,
        adapters: adapters || null,
        cables: cables || null,
      },
    };
  } catch (error) {
    console.error("Compatibility analysis error:", error);
    return {
      error: "An error occurred during compatibility analysis",
      details: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}