async function handler({ deviceIds, connectorIds, useMockData }) {
  // If mock data is requested, return predefined simulation results
  if (useMockData) {
    return {
      results: [
        {
          devices: ["Main Device", "Display Screen"],
          connectors: ["Display Cable"],
          result:
            "Success! Your main device is now showing visuals on the display screen.",
          details:
            "The display cable carries visual information from your main device to your display screen.",
        },
        {
          devices: ["Main Device", "Display Screen"],
          connectors: ["Legacy Connector"],
          result:
            "Success! Your main device is now showing visuals on the display screen, but with limited features.",
          details:
            "The legacy connector provides basic visual output but may not support advanced features.",
        },
        {
          devices: ["Main Device", "Output Device"],
          connectors: ["Standard Cable"],
          result:
            "Success! Your main device can now send information to the output device.",
          details:
            "The standard cable allows your main device to communicate with the output device.",
        },
        {
          devices: ["Main Device", "Output Device"],
          connectors: ["Network Cable"],
          result:
            "Partial success. Both devices need to be on the same network to function properly.",
          details:
            "When using a network cable, both devices need to be connected to the same network hub.",
        },
        {
          devices: ["Main Device", "Network Hub"],
          connectors: ["Network Cable"],
          result:
            "Success! Your main device is now connected to the network with a fast, reliable connection.",
          details:
            "The network cable gives you the fastest and most reliable network connection.",
        },
        {
          devices: ["Output Device", "Network Hub"],
          connectors: ["Network Cable"],
          result:
            "Success! Your output device is now on the network and can be used by any device on the same network.",
          details:
            "Now any device connected to your network hub can use this output device without needing a direct cable.",
        },
        {
          devices: ["Main Device", "Audio Equipment"],
          connectors: ["Audio Connector"],
          result:
            "Success! Your main device can now play sound through the audio equipment.",
          details:
            "The audio connector carries sound from your main device to your audio equipment.",
        },
        {
          devices: ["Portable Device", "Main Device"],
          connectors: ["Modern Connector"],
          result:
            "Success! Your portable device is now connected to your main device. You can transfer data between them.",
          details:
            "The modern connector lets you move information between devices and may also provide power.",
        },
        {
          devices: ["Main Device", "Power Source"],
          connectors: ["Power Cable"],
          result: "Success! Your main device is now receiving power.",
          details: "The power cable supplies electricity to your device.",
        },
        {
          devices: ["Display Screen", "Power Source"],
          connectors: ["Power Cable"],
          result:
            "Success! Your display screen is now receiving power and can turn on.",
          details:
            "The power cable supplies electricity to your display screen.",
        },
        {
          devices: ["Main Device", "Wireless Transmitter"],
          connectors: ["Wireless Connection"],
          result:
            "Success! Your main device is now connected wirelessly to the transmitter.",
          details:
            "The wireless connection allows communication without physical cables.",
        },
        {
          devices: ["Portable Device", "Wireless Transmitter"],
          connectors: ["Wireless Connection"],
          result:
            "Success! Your portable device is now connected wirelessly to the transmitter.",
          details:
            "The wireless connection allows your portable device to communicate without cables.",
        },
      ],
    };
  }

  // If specific devices and connectors are provided, simulate their connection
  if (deviceIds && connectorIds) {
    try {
      // Fetch equipment data
      const equipmentResponse = await fetch("/api/get-equipment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const equipmentData = await equipmentResponse.json();

      // Fetch adapter types data
      const adapterResponse = await fetch("/api/get-adapter-types", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ useMockData: true }),
      });
      const adapterData = await adapterResponse.json();

      // Get the selected devices
      const selectedDevices = equipmentData.equipment.filter((device) =>
        deviceIds.includes(device.id)
      );

      // Get the selected connectors
      const selectedConnectors = adapterData.adapterTypes.filter((adapter) =>
        connectorIds.includes(adapter.id)
      );

      // Check if the connection is possible
      const connectionResult = simulateConnection(
        selectedDevices,
        selectedConnectors
      );

      return { results: [connectionResult] };
    } catch (error) {
      console.error("Error simulating connection:", error);
      return {
        error: "Failed to simulate connection",
        message: error.message,
      };
    }
  }

  // If no specific devices/connectors provided, try to get from database
  try {
    const simulators = await sql`SELECT * FROM simulators`;
    return { simulators };
  } catch (error) {
    console.error("Database error:", error);
    return {
      simulators: ["MockSimulator1", "MockSimulator2", "MockSimulator3"],
    };
  }
}

function simulateConnection(devices, connectors) {
  if (devices.length !== 2 || connectors.length === 0) {
    return {
      devices: devices.map((d) => d.name),
      connectors: connectors.map((c) => c.name),
      result: "Error: Need exactly 2 devices and at least 1 connector",
      details:
        "Please select exactly two devices to connect and at least one connector type.",
    };
  }

  // Check if devices have compatible ports
  const device1 = devices[0];
  const device2 = devices[1];
  const deviceNames = [device1.name, device2.name];
  const connectorNames = connectors.map((c) => c.name);

  // Check if both devices have the selected connector types
  const compatibleConnectors = connectors.filter((connector) => {
    const device1HasPort = device1.ports.some(
      (port) => port.type === connector.id
    );
    const device2HasPort = device2.ports.some(
      (port) => port.type === connector.id
    );
    return device1HasPort && device2HasPort;
  });

  if (compatibleConnectors.length === 0) {
    return {
      devices: deviceNames,
      connectors: connectorNames,
      result: "Connection failed: Incompatible ports",
      details: `${device1.name} and ${device2.name} don't share compatible ports for the selected connectors.`,
    };
  }

  // Look for predefined results based on device and connector combinations
  const predefinedResults = [
    {
      devices: ["Main Device", "Display Screen"],
      connectors: ["Display Cable"],
      result:
        "Success! Your main device is now showing visuals on the display screen.",
      details:
        "The display cable carries visual information from your main device to your display screen.",
    },
    {
      devices: ["Main Device", "Display Screen"],
      connectors: ["Legacy Connector"],
      result:
        "Success! Your main device is now showing visuals on the display screen, but with limited features.",
      details:
        "The legacy connector provides basic visual output but may not support advanced features.",
    },
    {
      devices: ["Main Device", "Output Device"],
      connectors: ["Standard Cable"],
      result:
        "Success! Your main device can now send information to the output device.",
      details:
        "The standard cable allows your main device to communicate with the output device.",
    },
    {
      devices: ["Main Device", "Output Device"],
      connectors: ["Network Cable"],
      result:
        "Partial success. Both devices need to be on the same network to function properly.",
      details:
        "When using a network cable, both devices need to be connected to the same network hub.",
    },
    {
      devices: ["Main Device", "Network Hub"],
      connectors: ["Network Cable"],
      result:
        "Success! Your main device is now connected to the network with a fast, reliable connection.",
      details:
        "The network cable gives you the fastest and most reliable network connection.",
    },
    {
      devices: ["Output Device", "Network Hub"],
      connectors: ["Network Cable"],
      result:
        "Success! Your output device is now on the network and can be used by any device on the same network.",
      details:
        "Now any device connected to your network hub can use this output device without needing a direct cable.",
    },
    {
      devices: ["Main Device", "Audio Equipment"],
      connectors: ["Audio Connector"],
      result:
        "Success! Your main device can now play sound through the audio equipment.",
      details:
        "The audio connector carries sound from your main device to your audio equipment.",
    },
    {
      devices: ["Portable Device", "Main Device"],
      connectors: ["Modern Connector"],
      result:
        "Success! Your portable device is now connected to your main device. You can transfer data between them.",
      details:
        "The modern connector lets you move information between devices and may also provide power.",
    },
    {
      devices: ["Main Device", "Power Source"],
      connectors: ["Power Cable"],
      result: "Success! Your main device is now receiving power.",
      details: "The power cable supplies electricity to your device.",
    },
    {
      devices: ["Display Screen", "Power Source"],
      connectors: ["Power Cable"],
      result:
        "Success! Your display screen is now receiving power and can turn on.",
      details: "The power cable supplies electricity to your display screen.",
    },
    {
      devices: ["Main Device", "Wireless Transmitter"],
      connectors: ["Wireless Connection"],
      result:
        "Success! Your main device is now connected wirelessly to the transmitter.",
      details:
        "The wireless connection allows communication without physical cables.",
    },
    {
      devices: ["Portable Device", "Wireless Transmitter"],
      connectors: ["Wireless Connection"],
      result:
        "Success! Your portable device is now connected wirelessly to the transmitter.",
      details:
        "The wireless connection allows your portable device to communicate without cables.",
    },
  ];

  // Sort device names to match predefined results format
  const sortedDeviceNames = [...deviceNames].sort();
  const sortedConnectorNames = [...connectorNames].sort();

  // Find matching predefined result
  for (const preset of predefinedResults) {
    const presetDevices = [...preset.devices].sort();
    const presetConnectors = [...preset.connectors].sort();

    const devicesMatch =
      presetDevices.length === sortedDeviceNames.length &&
      presetDevices.every((d, i) => d === sortedDeviceNames[i]);

    const connectorsMatch = presetConnectors.some((c) =>
      sortedConnectorNames.includes(c)
    );

    if (devicesMatch && connectorsMatch) {
      return {
        devices: deviceNames,
        connectors: compatibleConnectors.map((c) => c.name),
        result: preset.result,
        details: preset.details,
      };
    }
  }

  // Generic success response if no predefined result is found
  return {
    devices: deviceNames,
    connectors: compatibleConnectors.map((c) => c.name),
    result: `Success! ${device1.name} and ${device2.name} are now connected.`,
    details: `The connection using ${compatibleConnectors
      .map((c) => c.name)
      .join(", ")} allows these devices to communicate with each other.`,
  };
}
export async function POST(request) {
  return handler(await request.json());
}