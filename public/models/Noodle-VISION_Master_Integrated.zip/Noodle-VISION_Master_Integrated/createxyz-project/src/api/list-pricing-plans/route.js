async function handler() {
  const pricingPlans = await sql`SELECT * FROM stripe_configuration`;
  return { pricingPlans };
}
export async function POST(request) {
  return handler(await request.json());
}