async function handler({ id }) {
  if (!id) {
    return { error: "ID is required" };
  }

  const result = await sql("SELECT * FROM stored_urls WHERE id = $1", [id]);

  return result.length > 0 ? result[0] : { error: "URL not found" };
}
export async function POST(request) {
  return handler(await request.json());
}