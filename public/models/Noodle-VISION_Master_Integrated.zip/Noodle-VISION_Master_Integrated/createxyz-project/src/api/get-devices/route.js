async function handler({ category, search, page = 1, limit = 10 }) {
  try {
    // Start building the query
    let queryText = "SELECT * FROM devices WHERE 1=1";
    const queryParams = [];
    let paramCount = 1;

    // Add category filter if provided
    if (category) {
      queryText += ` AND category = $${paramCount}`;
      queryParams.push(category);
      paramCount++;
    }

    // Add search filter if provided
    if (search) {
      queryText += ` AND (
        name ILIKE $${paramCount} 
        OR description ILIKE $${paramCount + 1}
      )`;
      queryParams.push(`%${search}%`);
      queryParams.push(`%${search}%`);
      paramCount += 2;
    }

    // Add pagination
    const offset = (page - 1) * limit;
    queryText += ` ORDER BY name ASC LIMIT $${paramCount} OFFSET $${
      paramCount + 1
    }`;
    queryParams.push(limit);
    queryParams.push(offset);

    // Execute the query
    const devices = await sql(queryText, queryParams);

    // Get total count for pagination
    let countQueryText = "SELECT COUNT(*) FROM devices WHERE 1=1";
    const countParams = [];
    paramCount = 1;

    if (category) {
      countQueryText += ` AND category = $${paramCount}`;
      countParams.push(category);
      paramCount++;
    }

    if (search) {
      countQueryText += ` AND (
        name ILIKE $${paramCount} 
        OR description ILIKE $${paramCount + 1}
      )`;
      countParams.push(`%${search}%`);
      countParams.push(`%${search}%`);
    }

    const totalCountResult = await sql(countQueryText, countParams);
    const totalCount = parseInt(totalCountResult[0].count);
    const totalPages = Math.ceil(totalCount / limit);

    return {
      devices,
      pagination: {
        currentPage: page,
        totalPages,
        totalCount,
        hasNextPage: page < totalPages,
        hasPreviousPage: page > 1,
      },
    };
  } catch (error) {
    console.error("Error fetching devices:", error);
    return {
      error: "Failed to fetch devices",
      details: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}