async function handler({ adapterId }) {
  if (!adapterId) {
    return null;
  }

  const [adapter] = await sql("SELECT * FROM adapters WHERE id = $1", [
    adapterId,
  ]);

  return adapter || null;
}
export async function POST(request) {
  return handler(await request.json());
}