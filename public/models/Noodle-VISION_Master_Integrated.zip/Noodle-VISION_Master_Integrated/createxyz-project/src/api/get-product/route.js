async function handler({ productId }) {
  if (!productId) {
    return null;
  }

  const product = await sql("SELECT * FROM products WHERE id = $1", [
    productId,
  ]);

  if (product.length === 0) {
    return null;
  }

  return product[0];
}
export async function POST(request) {
  return handler(await request.json());
}