async function handler() {
  const session = getSession();
  if (!session || !session.user) {
    return { error: "Unauthorized" };
  }

  const userId = session.user.id;

  try {
    const result = await sql`
      SELECT 
        test_secret_key as "testSecretKey",
        live_secret_key as "liveSecretKey",
        test_webhook_secret as "testWebhookSecret",
        live_webhook_secret as "liveWebhookSecret",
        test_webhook_url as "testWebhookUrl",
        live_webhook_url as "liveWebhookUrl",
        basic_price_id as "basicPriceId",
        pro_price_id as "proPriceId",
        enterprise_price_id as "enterprisePriceId",
        is_test_mode as "isTestMode",
        use_env_variables as "useEnvVariables",
        env_prefix as "envPrefix"
      FROM stripe_configuration 
      WHERE user_id = ${userId}
    `;

    if (result.length === 0) {
      return {
        exists: false,
        config: null,
      };
    }

    const config = result[0];

    // If using environment variables, mask the sensitive values
    if (config.useEnvVariables) {
      return {
        exists: true,
        config: {
          ...config,
          testSecretKey: config.testSecretKey
            ? "[STORED IN ENVIRONMENT VARIABLE]"
            : "",
          liveSecretKey: config.liveSecretKey
            ? "[STORED IN ENVIRONMENT VARIABLE]"
            : "",
          testWebhookSecret: config.testWebhookSecret
            ? "[STORED IN ENVIRONMENT VARIABLE]"
            : "",
          liveWebhookSecret: config.liveWebhookSecret
            ? "[STORED IN ENVIRONMENT VARIABLE]"
            : "",
          testWebhookUrl: config.testWebhookUrl
            ? "[STORED IN ENVIRONMENT VARIABLE]"
            : "",
          liveWebhookUrl: config.liveWebhookUrl
            ? "[STORED IN ENVIRONMENT VARIABLE]"
            : "",
        },
      };
    }

    // Only show this config if the current user is the admin (you). Otherwise, show an access denied message.
    const { data: user, loading } = useUser();
    if (loading) return <div>Loading...</div>;
    if (!user || user.email !== "YOUR_ADMIN_EMAIL_HERE") {
      return (
        <div
          style={{
            color: "red",
            fontWeight: "bold",
            padding: 32,
            textAlign: "center",
          }}
        >
          Access Denied
        </div>
      );
    }

    return {
      exists: true,
      config: config,
    };
  } catch (error) {
    console.error("Error retrieving Stripe configuration:", error);
    return {
      error: "Failed to retrieve Stripe configuration",
      details: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}