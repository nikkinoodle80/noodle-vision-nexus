async function handler({
  name,
  description,
  color,
  source_type,
  target_type,
  domain_id,
  icon_url,
  specifications,
  compatibility_notes,
  manufacturer,
  model_number,
  is_bidirectional,
  max_resolution,
  supports_audio,
}) {
  const result = await sql(
    `INSERT INTO adapters (
      name, description, color, source_type, target_type, domain_id, icon_url, 
      specifications, compatibility_notes, manufacturer, model_number, 
      is_bidirectional, max_resolution, supports_audio
    ) VALUES (
      $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14
    ) RETURNING *`,
    [
      name,
      description,
      color,
      source_type,
      target_type,
      domain_id,
      icon_url,
      specifications,
      compatibility_notes,
      manufacturer,
      model_number,
      is_bidirectional,
      max_resolution,
      supports_audio,
    ]
  );

  return result[0] || null;
}
export async function POST(request) {
  return handler(await request.json());
}