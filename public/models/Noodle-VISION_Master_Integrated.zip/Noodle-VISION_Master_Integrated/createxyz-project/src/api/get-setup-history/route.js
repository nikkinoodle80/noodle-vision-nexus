function handler({ setupId }) {
  try {
    const session = getSession();

    if (!session || !session.user) {
      return {
        success: false,
        error: "Authentication required",
      };
    }

    const userId = session.user.id;

    // First verify the user owns this setup
    return sql
      .transaction(async (txn) => {
        const setupCheck = await txn`
        SELECT * FROM user_setups
        WHERE id = ${setupId} AND user_id = ${userId}
      `;

        if (setupCheck.length === 0) {
          return {
            success: false,
            error: "Setup not found or access denied",
          };
        }

        const history = await txn`
        SELECT * FROM setup_history
        WHERE setup_id = ${setupId}
        ORDER BY created_at DESC
        LIMIT 20
      `;

        return {
          success: true,
          history,
        };
      })
      .catch((error) => {
        console.error("Error fetching setup history:", error);
        return {
          success: false,
          error: "Failed to fetch history",
        };
      });
  } catch (error) {
    console.error("Error in get setup history handler:", error);
    return {
      success: false,
      error: "Failed to process request",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}