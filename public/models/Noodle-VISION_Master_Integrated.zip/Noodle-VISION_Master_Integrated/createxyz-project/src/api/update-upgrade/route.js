async function handler({ id, upgrade_type, configuration }) {
  if (!id) {
    return { error: "ID is required" };
  }

  const updates = [];
  const values = [id];
  let query = "UPDATE user_upgrades SET ";

  if (upgrade_type) {
    updates.push(`upgrade_type = $${updates.length + 2}`);
    values.push(upgrade_type);
  }

  if (configuration) {
    updates.push(`configuration = $${updates.length + 2}`);
    values.push(configuration);
  }

  if (updates.length === 0) {
    return { error: "No fields to update" };
  }

  query += updates.join(", ") + " WHERE id = $1 RETURNING *";

  try {
    const result = await sql(query, values);
    return result.length > 0 ? result[0] : { error: "Update failed" };
  } catch (error) {
    return { error: "An error occurred while updating the upgrade" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}