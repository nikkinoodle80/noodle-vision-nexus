async function handler({
  sourceDeviceId,
  targetDeviceId,
  connections,
  useInventoryOnly,
}) {
  const session = getSession();
  const userId = session?.user?.id;

  if (!sourceDeviceId || !targetDeviceId || !connections) {
    return {
      success: false,
      error: "Missing required parameters",
    };
  }

  try {
    // Get source and target devices
    const [sourceResult, targetResult] = await Promise.all([
      sql("SELECT * FROM devices WHERE id = $1", [sourceDeviceId]),
      sql("SELECT * FROM devices WHERE id = $1", [targetDeviceId]),
    ]);

    if (sourceResult.length === 0 || targetResult.length === 0) {
      return {
        success: false,
        error: "Source or target device not found",
      };
    }

    const sourceDevice = sourceResult[0];
    const targetDevice = targetResult[0];

    // Get adapter types used in the connections
    const adapterIds = connections
      .filter((conn) => conn.adapterTypeId)
      .map((conn) => conn.adapterTypeId);

    let adapters = [];
    if (adapterIds.length > 0) {
      const adapterResult = await sql(
        "SELECT * FROM adapter_types WHERE id = ANY($1)",
        [adapterIds]
      );
      adapters = adapterResult;
    }

    // Check if the connection is valid
    const simulationResult = validateConnection(
      sourceDevice,
      targetDevice,
      connections,
      adapters
    );

    // If user is logged in, check against their inventory if requested
    let inventoryCheck = null;
    if (userId && useInventoryOnly) {
      inventoryCheck = await checkAgainstInventory(userId, connections);

      if (!inventoryCheck.hasAllItems) {
        simulationResult.success = false;
        simulationResult.missingItems = inventoryCheck.missingItems;
      }
    }

    // If user is logged in, save the simulation result
    if (userId) {
      await sql(
        `
        INSERT INTO simulation_results
        (user_id, success, feedback, missing_items, alternative_solutions)
        VALUES ($1, $2, $3, $4, $5)
      `,
        [
          userId,
          simulationResult.success,
          simulationResult.feedback,
          JSON.stringify(simulationResult.missingItems || []),
          JSON.stringify(simulationResult.alternatives || []),
        ]
      );
    }

    return {
      success: true,
      simulationResult,
    };
  } catch (error) {
    console.error("Error simulating connection:", error);
    return {
      success: false,
      error: "Failed to simulate connection",
    };
  }
}

// Helper function to validate connections
function validateConnection(sourceDevice, targetDevice, connections, adapters) {
  // This is a simplified validation logic
  // In a real implementation, this would be much more sophisticated

  // Check if source and target have compatible ports
  const sourcePorts =
    typeof sourceDevice.ports === "string"
      ? JSON.parse(sourceDevice.ports)
      : sourceDevice.ports;

  const targetPorts =
    typeof targetDevice.ports === "string"
      ? JSON.parse(targetDevice.ports)
      : targetDevice.ports;

  // Check if the connection chain is valid
  let currentOutputType = null;
  let isValid = true;
  let feedback = "";

  // Check the first connection from source device
  const firstConnection = connections[0];
  if (!firstConnection || !sourcePorts[firstConnection.sourcePortType]) {
    isValid = false;
    feedback = `Source device doesn't have the required ${
      firstConnection?.sourcePortType || "unknown"
    } port`;
  } else {
    currentOutputType = firstConnection.sourcePortType;
  }

  // Check adapter chain
  for (let i = 0; i < connections.length; i++) {
    const conn = connections[i];

    if (conn.adapterTypeId) {
      const adapter = adapters.find((a) => a.id === conn.adapterTypeId);

      if (!adapter) {
        isValid = false;
        feedback = `Adapter not found in position ${i + 1}`;
        break;
      }

      if (adapter.input_type !== currentOutputType) {
        isValid = false;
        feedback = `Adapter in position ${
          i + 1
        } has incompatible input type. Expected ${currentOutputType}, got ${
          adapter.input_type
        }`;
        break;
      }

      currentOutputType = adapter.output_type;
    }
  }

  // Check final connection to target device
  const lastConnection = connections[connections.length - 1];
  if (
    isValid &&
    (!lastConnection || !targetPorts[lastConnection.targetPortType])
  ) {
    isValid = false;
    feedback = `Target device doesn't have the required ${
      lastConnection?.targetPortType || "unknown"
    } port`;
  } else if (isValid && lastConnection.targetPortType !== currentOutputType) {
    isValid = false;
    feedback = `Target port type (${lastConnection.targetPortType}) is incompatible with the output from the adapter chain (${currentOutputType})`;
  }

  // If valid, provide success feedback
  if (isValid) {
    feedback = "Connection is valid! All devices and adapters are compatible.";
  }

  // Generate alternative solutions if the connection is invalid
  const alternatives = isValid
    ? []
    : generateAlternatives(sourceDevice, targetDevice);

  return {
    success: isValid,
    feedback,
    alternatives,
  };
}

// Helper function to check against user's inventory
async function checkAgainstInventory(userId, connections) {
  const adapterIds = connections
    .filter((conn) => conn.adapterTypeId)
    .map((conn) => conn.adapterTypeId);

  if (adapterIds.length === 0) {
    return { hasAllItems: true, missingItems: [] };
  }

  // Get user's inventory
  const inventoryResult = await sql(
    `
    SELECT adapter_type_id, SUM(quantity) as total_quantity
    FROM user_inventory
    WHERE user_id = $1 AND adapter_type_id = ANY($2)
    GROUP BY adapter_type_id
  `,
    [userId, adapterIds]
  );

  const inventory = {};
  inventoryResult.forEach((item) => {
    inventory[item.adapter_type_id] = item.total_quantity;
  });

  // Count required adapters
  const required = {};
  adapterIds.forEach((id) => {
    required[id] = (required[id] || 0) + 1;
  });

  // Check if user has all required adapters
  const missingItems = [];
  for (const id in required) {
    const requiredCount = required[id];
    const availableCount = inventory[id] || 0;

    if (availableCount < requiredCount) {
      // Get adapter details
      const adapterResult = await sql(
        "SELECT name, brand, model FROM adapter_types WHERE id = $1",
        [id]
      );

      if (adapterResult.length > 0) {
        const adapter = adapterResult[0];
        missingItems.push({
          id,
          name: adapter.name,
          brand: adapter.brand,
          model: adapter.model,
          required: requiredCount,
          available: availableCount,
          missing: requiredCount - availableCount,
        });
      }
    }
  }

  return {
    hasAllItems: missingItems.length === 0,
    missingItems,
  };
}

// Helper function to generate alternative connection solutions
function generateAlternatives(sourceDevice, targetDevice) {
  // This would be a complex function that suggests alternative adapter chains
  // For now, we'll return a simplified placeholder
  return [
    {
      description: "Use an HDMI to DisplayPort adapter",
      requiredAdapters: ["HDMI to DisplayPort adapter"],
      estimatedCost: "$15-25",
    },
    {
      description: "Use a VGA to HDMI converter with audio extractor",
      requiredAdapters: ["VGA to HDMI converter", "Audio extractor"],
      estimatedCost: "$30-45",
    },
  ];
}
export async function POST(request) {
  return handler(await request.json());
}