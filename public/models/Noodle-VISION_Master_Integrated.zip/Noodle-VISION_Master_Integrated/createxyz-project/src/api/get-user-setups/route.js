function handler({ userId, domainId }) {
  try {
    const session = getSession();

    const userIdToUse = userId || session?.user?.id;

    if (!userIdToUse) {
      return {
        success: false,
        error: "User ID is required",
      };
    }

    const setups = sql`
      SELECT us.*, d.name as domain_name
      FROM user_setups us
      JOIN domains d ON us.domain_id = d.id
      WHERE us.user_id = ${userIdToUse}
      AND (us.domain_id = ${domainId} OR ${domainId} IS NULL)
      ORDER BY us.updated_at DESC
    `;

    return {
      success: true,
      setups,
    };
  } catch (error) {
    console.error("Error fetching user setups:", error);
    return {
      success: false,
      error: "Failed to fetch setups",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}