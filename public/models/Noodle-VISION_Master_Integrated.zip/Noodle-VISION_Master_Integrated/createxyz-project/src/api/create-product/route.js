async function handler({
  name,
  description,
  price,
  category,
  image_url,
  is_active,
  product_type,
  specifications,
  connection_points,
}) {
  const [newProduct] = await sql`
    INSERT INTO products (
      name, 
      description, 
      price, 
      category, 
      image_url, 
      is_active, 
      product_type, 
      specifications, 
      connection_points
    ) VALUES (
      ${name}, 
      ${description}, 
      ${price}, 
      ${category}, 
      ${image_url}, 
      ${is_active}, 
      ${product_type}, 
      ${specifications}, 
      ${connection_points}
    )
    RETURNING *
  `;

  return newProduct;
}
export async function POST(request) {
  return handler(await request.json());
}