async function handler({ id }) {
  if (!id) {
    return null;
  }

  const [adapterType] = await sql`SELECT * FROM adapter_types WHERE id = ${id}`;
  return adapterType || null;
}
export async function POST(request) {
  return handler(await request.json());
}