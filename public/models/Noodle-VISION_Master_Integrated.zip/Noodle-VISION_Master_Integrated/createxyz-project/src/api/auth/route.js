async function handler(req, res) {
  try {
    if (req.method === "POST") {
      const { email, password } = req.body;

      // Check if user exists in the database
      const [user] = await sql`
        SELECT * FROM auth_users 
        WHERE email = ${email}
      `;

      if (!user) {
        return res.status(401).json({ error: "Invalid email or password" });
      }

      // Verify the password
      // (You'll need to implement password hashing and verification)
      if (user.password !== password) {
        return res.status(401).json({ error: "Invalid email or password" });
      }

      // Create a new session for the user
      const session = await sql.transaction(async (txn) => {
        const [session] = await txn`
          INSERT INTO auth_sessions ("userId", expires, "sessionToken")
          VALUES (${
            user.id
          }, NOW() + INTERVAL 1 HOUR, ${generateSessionToken()})
          RETURNING *
        `;
        return session;
      });

      // Return the session token to the client
      return res.status(200).json({ sessionToken: session.sessionToken });
    } else {
      return res.status(404).json({ error: "Not found" });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error" });
  }
}

function generateSessionToken() {
  // Implement a function to generate a unique session token
  return `session-token-${Date.now()}`;
}
export async function POST(request) {
  return handler(await request.json());
}