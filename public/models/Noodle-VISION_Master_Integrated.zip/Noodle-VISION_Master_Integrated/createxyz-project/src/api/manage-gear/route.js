async function handler(params) {
  const { action } = params;

  const session = getSession();
  let userId;

  // Check for session and user ID
  if (session && session.user && session.user.id) {
    userId = session.user.id;
  } else {
    // Allow listCatalogDevices to proceed without a user session
    if (action !== "listCatalogDevices") {
      return { error: "Authentication required. Please log in." };
    }
  }

  if (action === "add") {
    const { deviceData, userDeviceData } = params;
    const {
      name,
      type,
      manufacturer,
      model_number,
      image_url,
      specifications,
    } = deviceData || {};
    const { custom_name, notes } = userDeviceData || {};

    if (!userId) {
      // Ensure userId is present for add
      return { error: "Authentication required to add gear." };
    }
    if (!name || !type) {
      return { error: "Device name and type are required for adding gear." };
    }

    try {
      const addedItemDetails = await sql.transaction(async (txn) => {
        let [device] = await txn`
          SELECT id FROM devices WHERE LOWER(name) = LOWER(${name}) AND LOWER(type) = LOWER(${type})
        `;
        let currentDeviceId;

        if (!device) {
          const [newDevice] = await txn`
            INSERT INTO devices (name, type, manufacturer, model_number, image_url, specifications)
            VALUES (${name}, ${type}, ${manufacturer || null}, ${
            model_number || null
          }, ${image_url || null}, ${specifications || null})
            RETURNING id
          `;
          currentDeviceId = newDevice.id;
        } else {
          currentDeviceId = device.id;
        }

        const [insertedUserDevice] = await txn`
          INSERT INTO user_devices (user_id, device_id, custom_name, notes)
          VALUES (${userId}, ${currentDeviceId}, ${custom_name || null}, ${
          notes || null
        })
          RETURNING id
        `;

        const [details] = await txn`
            SELECT
              ud.id AS user_device_id,
              d.id AS device_id,
              d.name,
              d.type,
              d.manufacturer,
              d.model_number,
              d.image_url,
              d.specifications,
              ud.custom_name,
              ud.notes,
              ud.user_id
            FROM
              user_devices ud
            JOIN
              devices d ON ud.device_id = d.id
            WHERE
              ud.id = ${insertedUserDevice.id} AND ud.user_id = ${userId}
        `;
        return details;
      });
      return { success: true, item: addedItemDetails };
    } catch (error) {
      console.error("Error in add action:", error);
      return { error: "Failed to add gear: " + error.message };
    }
  } else if (action === "listUserGear") {
    if (!userId) {
      return { error: "Authentication required to list user gear." };
    }
    try {
      const gearList = await sql`
        SELECT
          ud.id AS user_device_id,
          d.id AS device_id,
          d.name,
          d.type,
          d.manufacturer,
          d.model_number,
          d.image_url,
          d.specifications,
          ud.custom_name,
          ud.notes
        FROM
          user_devices ud
        JOIN
          devices d ON ud.device_id = d.id
        WHERE
          ud.user_id = ${userId}
      `;
      return { success: true, gear: gearList };
    } catch (error) {
      console.error("Error in listUserGear action:", error);
      return { error: "Failed to list user gear: " + error.message };
    }
  } else if (action === "listCatalogDevices") {
    try {
      const devices = await sql`
        SELECT id, name, type, manufacturer, model_number, image_url, specifications 
        FROM devices
        ORDER BY type, name
      `;
      return { success: true, devices: devices };
    } catch (error) {
      console.error("Error in listCatalogDevices action:", error);
      return { error: "Failed to list catalog devices: " + error.message };
    }
  } else if (action === "removeUserDevice") {
    if (!userId) {
      return { error: "Authentication required to remove device." };
    }
    const { userDeviceId } = params;
    if (!userDeviceId) {
      return { error: "User device ID is required to remove." };
    }
    try {
      const [deletedDevice] = await sql`
            DELETE FROM user_devices
            WHERE id = ${userDeviceId} AND user_id = ${userId}
            RETURNING id
        `;
      if (deletedDevice && deletedDevice.id) {
        return { success: true, removedUserDeviceId: deletedDevice.id };
      } else {
        return { error: "Device not found for this user or already removed." };
      }
    } catch (error) {
      console.error("Error in removeUserDevice action:", error);
      return { error: "Failed to remove device: " + error.message };
    }
  } else {
    return {
      error:
        "Invalid action specified. Use 'add', 'listUserGear', 'listCatalogDevices', or 'removeUserDevice'.",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}