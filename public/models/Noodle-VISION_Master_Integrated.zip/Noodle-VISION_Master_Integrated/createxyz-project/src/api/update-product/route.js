async function handler({
  productId,
  name,
  description,
  price,
  category,
  image_url,
  is_active,
  product_type,
  specifications,
  connection_points,
}) {
  if (!productId) {
    return { error: "Product ID is required" };
  }

  const fields = [];
  const values = [];
  let index = 1;

  if (name !== undefined) {
    fields.push(`name = $${index++}`);
    values.push(name);
  }
  if (description !== undefined) {
    fields.push(`description = $${index++}`);
    values.push(description);
  }
  if (price !== undefined) {
    fields.push(`price = $${index++}`);
    values.push(price);
  }
  if (category !== undefined) {
    fields.push(`category = $${index++}`);
    values.push(category);
  }
  if (image_url !== undefined) {
    fields.push(`image_url = $${index++}`);
    values.push(image_url);
  }
  if (is_active !== undefined) {
    fields.push(`is_active = $${index++}`);
    values.push(is_active);
  }
  if (product_type !== undefined) {
    fields.push(`product_type = $${index++}`);
    values.push(product_type);
  }
  if (specifications !== undefined) {
    fields.push(`specifications = $${index++}`);
    values.push(specifications);
  }
  if (connection_points !== undefined) {
    fields.push(`connection_points = $${index++}`);
    values.push(connection_points);
  }

  if (fields.length === 0) {
    return { error: "No fields to update" };
  }

  values.push(productId);

  const query = `UPDATE products SET ${fields.join(
    ", "
  )} WHERE id = $${index} RETURNING *`;
  const [updatedProduct] = await sql(query, values);

  return updatedProduct || { error: "Product not found or not updated" };
}
export async function POST(request) {
  return handler(await request.json());
}