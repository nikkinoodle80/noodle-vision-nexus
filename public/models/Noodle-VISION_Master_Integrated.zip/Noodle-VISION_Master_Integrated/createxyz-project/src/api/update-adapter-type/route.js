async function handler({ id, fieldsToUpdate }) {
  if (!id || !fieldsToUpdate || typeof fieldsToUpdate !== "object") {
    return { error: "Invalid input" };
  }

  const setClauses = [];
  const values = [];
  let paramCount = 1;

  for (const [key, value] of Object.entries(fieldsToUpdate)) {
    setClauses.push(`${key} = $${paramCount}`);
    values.push(value);
    paramCount++;
  }

  if (setClauses.length === 0) {
    return { error: "No fields to update" };
  }

  const query = `UPDATE adapter_types SET ${setClauses.join(
    ", "
  )} WHERE id = $${paramCount}`;
  values.push(id);

  try {
    await sql(query, values);
    return { success: true };
  } catch (error) {
    return { error: error.message };
  }
}
export async function POST(request) {
  return handler(await request.json());
}