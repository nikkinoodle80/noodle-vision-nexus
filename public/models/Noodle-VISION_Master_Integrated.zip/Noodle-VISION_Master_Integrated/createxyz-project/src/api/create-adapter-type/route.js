async function handler({
  name,
  input_type,
  output_type,
  brand,
  model,
  requires_power = false,
  max_resolution,
  supports_audio = false,
  price_range,
  image_url,
  visual_properties = {},
  common_use_cases,
  compatibility_notes,
  typical_home_devices = [],
  is_wireless = false,
  average_range_feet,
  is_smart_home_compatible = false,
  connection_quality_score,
  latency_ms,
  supports_dex = false,
  supports_video_passthrough = false,
  supports_audio_passthrough = false,
  max_bandwidth_gbps,
  recommended_use_cases = [],
}) {
  const result = await sql(
    `INSERT INTO adapter_types (
      name, input_type, output_type, brand, model, requires_power, max_resolution, 
      supports_audio, price_range, image_url, visual_properties, common_use_cases, 
      compatibility_notes, typical_home_devices, is_wireless, average_range_feet, 
      is_smart_home_compatible, connection_quality_score, latency_ms, supports_dex, 
      supports_video_passthrough, supports_audio_passthrough, max_bandwidth_gbps, 
      recommended_use_cases
    ) VALUES (
      $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, 
      $19, $20, $21, $22, $23, $24
    ) RETURNING *`,
    [
      name,
      input_type,
      output_type,
      brand,
      model,
      requires_power,
      max_resolution,
      supports_audio,
      price_range,
      image_url,
      visual_properties,
      common_use_cases,
      compatibility_notes,
      typical_home_devices,
      is_wireless,
      average_range_feet,
      is_smart_home_compatible,
      connection_quality_score,
      latency_ms,
      supports_dex,
      supports_video_passthrough,
      supports_audio_passthrough,
      max_bandwidth_gbps,
      recommended_use_cases,
    ]
  );

  return result[0] || null;
}
export async function POST(request) {
  return handler(await request.json());
}