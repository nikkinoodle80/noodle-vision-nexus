async function handler({ sourceDeviceId, targetDeviceId, adapterIds }) {
  if (
    !sourceDeviceId ||
    !targetDeviceId ||
    !adapterIds ||
    !Array.isArray(adapterIds)
  ) {
    return { error: "Missing required fields" };
  }

  try {
    const adapterPattern = adapterIds.map((id) => ({ adapter_type_id: id }));
    const adapterPatternJson = JSON.stringify(adapterPattern);

    const issues = await sql(
      "SELECT ci.* FROM compatibility_issues ci WHERE ci.adapter_pattern @> $1::jsonb OR ci.adapter_pattern <@ $1::jsonb",
      [adapterPatternJson]
    );

    const sourceDevice = await sql("SELECT * FROM devices WHERE id = $1", [
      sourceDeviceId,
    ]);

    const targetDevice = await sql("SELECT * FROM devices WHERE id = $1", [
      targetDeviceId,
    ]);

    const adapters = await sql(
      "SELECT * FROM adapter_types WHERE id = ANY($1)",
      [adapterIds]
    );

    const compatibilityResults = {
      issues: issues,
      portCompatibility: true,
      powerRequirements: adapters.some((a) => a.requires_power),
      maxResolution: calculateMaxResolution(adapters),
      audioSupport: adapters.every((a) => a.supports_audio),
      signalQuality: calculateSignalQuality(adapters.length),
      recommendations: generateRecommendations(
        sourceDevice[0],
        targetDevice[0],
        adapters
      ),
    };

    return compatibilityResults;
  } catch (error) {
    console.error("Error checking compatibility:", error);
    return { error: "Failed to check compatibility" };
  }
}

function calculateMaxResolution(adapters) {
  const resolutions = adapters
    .map((a) => a.max_resolution)
    .filter(Boolean)
    .map(parseResolution);

  if (resolutions.length === 0) return "Unknown";

  resolutions.sort((a, b) => a.totalPixels - b.totalPixels);

  const lowest = resolutions[0];
  return `${lowest.width}x${lowest.height}@${lowest.refreshRate}Hz`;
}

function parseResolution(resString) {
  const match = resString.match(/(\d+)x(\d+)@?(\d+)?Hz?/i);
  if (!match) return { width: 0, height: 0, refreshRate: 0, totalPixels: 0 };

  const width = parseInt(match[1], 10);
  const height = parseInt(match[2], 10);
  const refreshRate = match[3] ? parseInt(match[3], 10) : 60;

  return {
    width,
    height,
    refreshRate,
    totalPixels: width * height * refreshRate,
  };
}

function calculateSignalQuality(adapterCount) {
  return Math.max(100 - adapterCount * 10, 0);
}

function generateRecommendations(sourceDevice, targetDevice, adapters) {
  const recommendations = [];

  if (adapters.length > 1) {
    recommendations.push({
      type: "simplify",
      message:
        "Consider using a single adapter instead of multiple adapters to improve signal quality.",
    });
  }

  if (adapters.some((a) => a.requires_power && !a.supports_audio)) {
    recommendations.push({
      type: "audio",
      message:
        "This setup doesn't support audio. Consider adding a separate audio connection.",
    });
  }

  return recommendations;
}
export async function POST(request) {
  return handler(await request.json());
}