function handler({ id, limit = 10, offset = 0 }) {
  try {
    const session = getSession();
    const userId = session?.user?.id;

    if (!userId) {
      return {
        success: false,
        error: "Authentication required",
      };
    }

    // If an ID is provided, return that specific configuration
    if (id) {
      const result = sql`
        SELECT * FROM test_configurations 
        WHERE id = ${id} AND user_id = ${userId}
      `;

      if (result.length === 0) {
        return {
          success: false,
          error: `No configuration found with ID: ${id}`,
        };
      }

      return {
        success: true,
        configuration: result[0],
      };
    }

    // Get all configurations for the user with pagination
    const configurations = sql`
      SELECT * FROM test_configurations
      WHERE user_id = ${userId}
      ORDER BY updated_at DESC
      LIMIT ${limit} OFFSET ${offset}
    `;

    // Get total count for pagination
    const countResult = sql`
      SELECT COUNT(*) as total FROM test_configurations 
      WHERE user_id = ${userId}
    `;

    return {
      success: true,
      configurations,
      pagination: {
        total: parseInt(countResult[0].total),
        limit,
        offset,
        hasMore: parseInt(countResult[0].total) > offset + limit,
      },
    };
  } catch (error) {
    console.error("Error getting test configurations:", error);
    return {
      success: false,
      error: `Failed to get test configurations: ${error.message}`,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}