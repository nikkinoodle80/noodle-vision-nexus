async function handler({
  name,
  price,
  features,
  monthlyButtonId,
  annualButtonId,
}) {
  const session = getSession();
  if (!session) {
    return { error: "Unauthorized" };
  }

  const userId = session.user?.id;
  if (!userId) {
    return { error: "User not found" };
  }

  const query = `
    INSERT INTO pricing_plans (name, price, features, monthly_button_id, annual_button_id, created_by)
    VALUES ($1, $2, $3, $4, $5, $6)
    RETURNING id
  `;

  const values = [
    name,
    price,
    features,
    monthlyButtonId,
    annualButtonId,
    userId,
  ];

  try {
    const result = await sql(query, values);
    return { id: result[0]?.id };
  } catch (error) {
    return { error: error.message };
  }
}
export async function POST(request) {
  return handler(await request.json());
}