async function handler({ name, roomType, floorLevel, squareFootage, notes }) {
  const session = getSession();
  if (!session || !session.user) {
    return { error: "Authentication required" };
  }

  const userId = session.user.id;

  if (!name || !roomType) {
    return { error: "Name and room type are required" };
  }

  try {
    const result = await sql`
      INSERT INTO home_rooms (user_id, name, room_type, floor_level, square_footage, notes)
      VALUES (${userId}, ${name}, ${roomType}, ${floorLevel}, ${squareFootage}, ${notes})
      RETURNING *
    `;

    return { room: result[0], success: true };
  } catch (error) {
    console.error("Error creating home room:", error);
    return { error: "Failed to create room" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}