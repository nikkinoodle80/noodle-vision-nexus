async function handler() {
  const session = getSession();
  if (!session || !session.user) {
    return { error: "Authentication required" };
  }

  const userId = session.user.id;

  try {
    const rows = await sql`
      SELECT * FROM home_rooms
      WHERE user_id = ${userId}
      ORDER BY name ASC
    `;

    return { rooms: rows };
  } catch (error) {
    console.error("Error fetching home rooms:", error);
    return { error: "Failed to fetch rooms" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}