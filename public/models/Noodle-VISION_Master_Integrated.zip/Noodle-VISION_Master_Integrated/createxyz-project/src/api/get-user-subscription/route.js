async function handler({ userId }) {
  try {
    const session = getSession();

    // Check if user is authenticated
    if (!session || !session.user) {
      return {
        success: false,
        error: "Authentication required",
      };
    }

    // Use provided userId or default to authenticated user
    const targetUserId = userId || session.user.id;

    // Query database for subscription info with plan details
    const subscriptions = await sql`
      SELECT 
        us.id, 
        us.user_id, 
        us.status, 
        us.current_period_start, 
        us.current_period_end, 
        us.api_calls_used,
        us.stripe_subscription_id,
        us.stripe_customer_id,
        us.created_at,
        us.updated_at,
        sp.id as plan_id,
        sp.name as plan_name,
        sp.description as plan_description,
        sp.price as plan_price,
        sp.interval as plan_interval,
        sp.features as plan_features,
        sp.api_calls_limit as plan_api_calls_limit
      FROM 
        user_subscriptions us
      JOIN 
        subscription_plans sp ON us.plan_id = sp.id
      WHERE 
        us.user_id = ${targetUserId}
      ORDER BY 
        us.created_at DESC
      LIMIT 1
    `;

    if (subscriptions.length === 0) {
      return {
        success: true,
        subscription: null,
        message: "No subscription found for this user",
      };
    }

    const subscription = subscriptions[0];

    // Calculate usage percentage
    const usagePercentage = subscription.plan_api_calls_limit
      ? Math.min(
          100,
          Math.round(
            (subscription.api_calls_used / subscription.plan_api_calls_limit) *
              100
          )
        )
      : 0;

    return {
      success: true,
      subscription: {
        id: subscription.id,
        userId: subscription.user_id,
        status: subscription.status,
        currentPeriodStart: subscription.current_period_start,
        currentPeriodEnd: subscription.current_period_end,
        stripeSubscriptionId: subscription.stripe_subscription_id,
        stripeCustomerId: subscription.stripe_customer_id,
        createdAt: subscription.created_at,
        updatedAt: subscription.updated_at,
        plan: {
          id: subscription.plan_id,
          name: subscription.plan_name,
          description: subscription.plan_description,
          price: subscription.plan_price,
          interval: subscription.plan_interval,
          features: subscription.plan_features,
        },
        usage: {
          used: subscription.api_calls_used,
          limit: subscription.plan_api_calls_limit,
          percentage: usagePercentage,
        },
      },
    };
  } catch (error) {
    console.error("Error fetching subscription:", error);
    return {
      success: false,
      error: "Failed to retrieve subscription information",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}