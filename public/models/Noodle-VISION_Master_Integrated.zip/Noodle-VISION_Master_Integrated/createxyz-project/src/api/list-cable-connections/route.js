async function handler() {
  const cableConnections =
    await sql`SELECT from_port, to_port FROM patch_connections`;
  return cableConnections;
}
export async function POST(request) {
  return handler(await request.json());
}