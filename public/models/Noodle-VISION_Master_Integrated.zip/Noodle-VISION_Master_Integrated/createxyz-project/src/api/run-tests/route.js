function handler({ testSuite = "all", environment = "development" }) {
  try {
    const session = getSession();
    const userId = session?.user?.id;

    // Validate test suite parameter
    const validTestSuites = [
      "all",
      "device-management",
      "adapter-compatibility",
      "user-inventory",
      "connection-builder",
    ];
    if (!validTestSuites.includes(testSuite)) {
      return {
        success: false,
        error: `Invalid test suite: ${testSuite}. Valid options are: ${validTestSuites.join(
          ", "
        )}`,
      };
    }

    // Log test execution
    console.log(
      `Running Cypress tests: ${testSuite} in ${environment} environment by user ${
        userId || "anonymous"
      }`
    );

    // Mock test results for demonstration (in production, this would call actual Cypress)
    const testResults = {
      success: true,
      summary: {
        total: 24,
        passed: 22,
        failed: 2,
        skipped: 0,
        duration: "45.2s",
      },
      suites: [
        {
          name: "Device Management",
          tests: [
            {
              name: "Should list devices with pagination",
              status: "passed",
              duration: "1.2s",
            },
            {
              name: "Should filter devices by type",
              status: "passed",
              duration: "0.8s",
            },
            {
              name: "Should add a new device",
              status: "passed",
              duration: "1.5s",
            },
            {
              name: "Should update device details",
              status: "passed",
              duration: "1.1s",
            },
            {
              name: "Should delete a device",
              status: "passed",
              duration: "0.9s",
            },
          ],
        },
        {
          name: "Adapter Compatibility",
          tests: [
            {
              name: "Should show compatible adapters",
              status: "passed",
              duration: "1.3s",
            },
            {
              name: "Should filter adapters by type",
              status: "passed",
              duration: "0.7s",
            },
            {
              name: "Should show adapter details",
              status: "passed",
              duration: "0.6s",
            },
            {
              name: "Should validate connection between devices",
              status: "failed",
              duration: "2.1s",
              error: "Expected connection to be valid but got invalid status",
            },
          ],
        },
        {
          name: "User Inventory",
          tests: [
            {
              name: "Should list user inventory",
              status: "passed",
              duration: "0.9s",
            },
            {
              name: "Should add item to inventory",
              status: "passed",
              duration: "1.2s",
            },
            {
              name: "Should update inventory quantity",
              status: "passed",
              duration: "0.8s",
            },
            {
              name: "Should remove item from inventory",
              status: "passed",
              duration: "0.7s",
            },
            {
              name: "Should batch update inventory",
              status: "passed",
              duration: "1.5s",
            },
          ],
        },
        {
          name: "Connection Builder",
          tests: [
            {
              name: "Should create a new connection",
              status: "passed",
              duration: "1.4s",
            },
            {
              name: "Should add devices to connection",
              status: "passed",
              duration: "1.2s",
            },
            {
              name: "Should add adapters to connection",
              status: "passed",
              duration: "1.1s",
            },
            {
              name: "Should validate connection path",
              status: "passed",
              duration: "1.3s",
            },
            {
              name: "Should save connection configuration",
              status: "passed",
              duration: "1.0s",
            },
            {
              name: "Should generate shopping list",
              status: "failed",
              duration: "1.8s",
              error: "Timeout waiting for shopping list to generate",
            },
          ],
        },
      ],
      failedTests: [
        {
          suite: "Adapter Compatibility",
          test: "Should validate connection between devices",
          error: "Expected connection to be valid but got invalid status",
          screenshot:
            "/screenshots/adapter-compatibility-validation-failed.png",
        },
        {
          suite: "Connection Builder",
          test: "Should generate shopping list",
          error: "Timeout waiting for shopping list to generate",
          screenshot:
            "/screenshots/connection-builder-shopping-list-timeout.png",
        },
      ],
    };

    // Filter results based on test suite parameter
    if (testSuite !== "all") {
      const filteredSuites = testResults.suites.filter(
        (suite) => suite.name.toLowerCase().replace(/\s+/g, "-") === testSuite
      );

      if (filteredSuites.length === 0) {
        return {
          success: false,
          error: `No test suite found matching: ${testSuite}`,
        };
      }

      const filteredFailedTests = testResults.failedTests.filter((test) =>
        filteredSuites.some((suite) => suite.name === test.suite)
      );

      // Recalculate summary
      const allTests = filteredSuites.flatMap((suite) => suite.tests);
      const passed = allTests.filter((test) => test.status === "passed").length;
      const failed = allTests.filter((test) => test.status === "failed").length;
      const skipped = allTests.filter(
        (test) => test.status === "skipped"
      ).length;

      testResults.summary = {
        total: allTests.length,
        passed,
        failed,
        skipped,
        duration:
          allTests
            .reduce((sum, test) => sum + parseFloat(test.duration), 0)
            .toFixed(1) + "s",
      };
      testResults.suites = filteredSuites;
      testResults.failedTests = filteredFailedTests;
      testResults.success = failed === 0;
    }

    // Store test results in the database
    const result = sql`
      INSERT INTO test_results (
        test_suite, 
        environment, 
        success, 
        total_tests, 
        passed_tests, 
        failed_tests, 
        skipped_tests, 
        duration, 
        details,
        user_id
      ) VALUES (
        ${testSuite}, 
        ${environment}, 
        ${testResults.success}, 
        ${testResults.summary.total}, 
        ${testResults.summary.passed}, 
        ${testResults.summary.failed}, 
        ${testResults.summary.skipped}, 
        ${testResults.summary.duration}, 
        ${JSON.stringify(testResults)},
        ${userId}
      ) RETURNING id
    `;

    // Add the database ID to the results
    testResults.id = result[0]?.id;

    return testResults;
  } catch (error) {
    console.error("Error running tests:", error);
    return {
      success: false,
      error: `Failed to run tests: ${error.message}`,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}