async function handler({
  device1Id,
  device2Id,
  adapterId,
  existingConnections = [],
}) {
  try {
    // Get device information
    const devices = await sql`
      SELECT id, name, description
      FROM products
      WHERE id IN (${device1Id}, ${device2Id})
    `;

    if (devices.length !== 2) {
      return {
        valid: false,
        message: "Error: One or both devices not found",
        suggestion: "Please select two valid devices to connect.",
      };
    }

    const device1 = devices.find((d) => d.id === parseInt(device1Id));
    const device2 = devices.find((d) => d.id === parseInt(device2Id));

    // Get adapter information
    const adapters = await sql`
      SELECT id, name, description, source_type, target_type
      FROM adapters
      WHERE id = ${adapterId}
    `;

    if (adapters.length === 0) {
      return {
        valid: false,
        message: "Error: Adapter not found",
        suggestion: "Please select a valid adapter to connect the devices.",
      };
    }

    const adapter = adapters[0];

    // Get ports for both devices
    const device1Ports = await sql`
      SELECT port_name, port_type, count
      FROM device_ports
      WHERE device_id = ${device1Id}
    `;

    const device2Ports = await sql`
      SELECT port_name, port_type, count
      FROM device_ports
      WHERE device_id = ${device2Id}
    `;

    // Check if devices have compatible ports for this adapter
    const device1HasSourcePort = device1Ports.some(
      (port) => port.port_type === adapter.source_type
    );
    const device2HasTargetPort = device2Ports.some(
      (port) => port.port_type === adapter.target_type
    );
    const device2HasSourcePort = device2Ports.some(
      (port) => port.port_type === adapter.source_type
    );
    const device1HasTargetPort = device1Ports.some(
      (port) => port.port_type === adapter.target_type
    );

    // Check compatibility in both directions
    const forwardCompatible = device1HasSourcePort && device2HasTargetPort;
    const reverseCompatible = device2HasSourcePort && device1HasTargetPort;

    if (!forwardCompatible && !reverseCompatible) {
      return {
        valid: false,
        message: `Incompatible connection: ${adapter.name} cannot connect these devices`,
        suggestion: `The ${adapter.name} requires ${adapter.source_type} and ${adapter.target_type} ports, which these devices don't have in a compatible configuration.`,
      };
    }

    // Check port availability (considering existing connections)
    const usedPorts = {
      [device1Id]: {},
      [device2Id]: {},
    };

    // Count used ports from existing connections
    existingConnections.forEach((conn) => {
      if (conn.sourceDeviceId === device1Id) {
        usedPorts[device1Id][conn.sourcePortType] =
          (usedPorts[device1Id][conn.sourcePortType] || 0) + 1;
      }
      if (conn.targetDeviceId === device1Id) {
        usedPorts[device1Id][conn.targetPortType] =
          (usedPorts[device1Id][conn.targetPortType] || 0) + 1;
      }
      if (conn.sourceDeviceId === device2Id) {
        usedPorts[device2Id][conn.sourcePortType] =
          (usedPorts[device2Id][conn.sourcePortType] || 0) + 1;
      }
      if (conn.targetDeviceId === device2Id) {
        usedPorts[device2Id][conn.targetPortType] =
          (usedPorts[device2Id][conn.targetPortType] || 0) + 1;
      }
    });

    // Check if we have available ports
    let device1PortAvailable = false;
    let device2PortAvailable = false;

    if (forwardCompatible) {
      const device1SourcePorts = device1Ports.filter(
        (port) => port.port_type === adapter.source_type
      );
      const device2TargetPorts = device2Ports.filter(
        (port) => port.port_type === adapter.target_type
      );

      device1PortAvailable = device1SourcePorts.some(
        (port) => (usedPorts[device1Id][port.port_type] || 0) < port.count
      );

      device2PortAvailable = device2TargetPorts.some(
        (port) => (usedPorts[device2Id][port.port_type] || 0) < port.count
      );
    }

    if (reverseCompatible && (!device1PortAvailable || !device2PortAvailable)) {
      const device2SourcePorts = device2Ports.filter(
        (port) => port.port_type === adapter.source_type
      );
      const device1TargetPorts = device1Ports.filter(
        (port) => port.port_type === adapter.target_type
      );

      device2PortAvailable = device2SourcePorts.some(
        (port) => (usedPorts[device2Id][port.port_type] || 0) < port.count
      );

      device1PortAvailable = device1TargetPorts.some(
        (port) => (usedPorts[device1Id][port.port_type] || 0) < port.count
      );
    }

    if (!device1PortAvailable || !device2PortAvailable) {
      return {
        valid: false,
        message: "No available ports for this connection",
        suggestion:
          "One or both devices have all ports of this type already in use.",
      };
    }

    // Get compatibility information
    const compatibility = await sql`
      SELECT compatibility_level, notes
      FROM compatible_connections
      WHERE source_port_type = ${adapter.source_type} 
      AND target_port_type = ${adapter.target_type} 
      AND adapter_id = ${adapterId}
    `;

    if (compatibility.length === 0) {
      return {
        valid: true,
        message: "Connection possible, but performance unknown",
        details: "This combination hasn't been fully tested.",
      };
    }

    const compatInfo = compatibility[0];

    // Generate appropriate message based on compatibility level
    let message, details;

    switch (compatInfo.compatibility_level) {
      case "Full":
        message = `Success! Perfect connection between ${device1.name} and ${device2.name}`;
        details = compatInfo.notes || "Full audio and video quality preserved.";
        break;
      case "Partial":
        message = `Partial Success: ${device1.name} and ${device2.name} connected with limitations`;
        details =
          compatInfo.notes ||
          "Some features may not work or quality may be reduced.";
        break;
      case "Basic":
        message = `Basic Connection: ${device1.name} and ${device2.name} connected with significant limitations`;
        details = compatInfo.notes || "Only basic functionality available.";
        break;
      default:
        message = `Connection established between ${device1.name} and ${device2.name}`;
        details = "Connection quality unknown.";
    }

    // Add specific device combination messages
    if (
      (device1.name === "AVR Receiver" && device2.name === "Monitor") ||
      (device2.name === "AVR Receiver" && device1.name === "Monitor")
    ) {
      details +=
        " The AVR can pass through video signals to the monitor while processing audio.";
    } else if (
      (device1.name === "DVD Player" && device2.name === "AVR Receiver") ||
      (device2.name === "DVD Player" && device1.name === "AVR Receiver")
    ) {
      details +=
        " Connect your DVD player to the AVR, then connect the AVR to your display for the best audio experience.";
    } else if (
      (device1.name === "Smartphone" && device2.name === "Monitor") ||
      (device2.name === "Smartphone" && device1.name === "Monitor")
    ) {
      details += " This allows you to mirror your phone screen to the monitor.";
    } else if (
      (device1.name === "DVR" && device2.name === "Monitor") ||
      (device2.name === "DVR" && device1.name === "Monitor")
    ) {
      details += " You can view recorded content directly on your monitor.";
    }

    return {
      valid: true,
      message,
      details,
      sourcePortType: forwardCompatible
        ? adapter.source_type
        : adapter.target_type,
      targetPortType: forwardCompatible
        ? adapter.target_type
        : adapter.source_type,
      direction: forwardCompatible ? "forward" : "reverse",
    };
  } catch (error) {
    console.error("Error validating connection:", error);
    return {
      valid: false,
      message: "An error occurred while validating the connection.",
      error: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}