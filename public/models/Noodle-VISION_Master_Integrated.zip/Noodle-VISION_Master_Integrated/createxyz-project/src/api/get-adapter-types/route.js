async function handler({
  useMockData,
  sourceType,
  targetType,
  moduleType,
  page = 1,
  pageSize = 10,
  skipCache = false,
}) {
  const CACHE_KEY = "adapter_types_cache";
  const CACHE_EXPIRY = 5 * 60 * 1000;

  if (
    !skipCache &&
    global[CACHE_KEY] &&
    global[CACHE_KEY].timestamp > Date.now() - CACHE_EXPIRY
  ) {
    const cachedData = global[CACHE_KEY].data;
    return filterAndPaginateResults(
      cachedData,
      sourceType,
      targetType,
      moduleType,
      page,
      pageSize
    );
  }

  if (useMockData) {
    const mockAdapters = [
      {
        id: 1,
        name: "HDMI Cable",
        description: "Standard HDMI cable for digital audio/video",
        color: "#FF4500",
        sourceType: "HDMI",
        targetType: "HDMI",
        icon: "cable",
        compatibilityLevel: "high",
        maxResolution: "4K",
        audioSupport: true,
        maxLength: "15m",
        moduleTypes: ["display", "audio"],
      },
      {
        id: 2,
        name: "HDMI to DisplayPort",
        description: "Converts HDMI signal to DisplayPort",
        color: "#4169E1",
        sourceType: "HDMI",
        targetType: "DisplayPort",
        icon: "converter",
        compatibilityLevel: "medium",
        maxResolution: "4K",
        audioSupport: true,
        maxLength: "3m",
        moduleTypes: ["display"],
      },
      {
        id: 3,
        name: "HDMI to DVI",
        description: "Converts HDMI signal to DVI",
        color: "#32CD32",
        sourceType: "HDMI",
        targetType: "DVI",
        icon: "converter",
        compatibilityLevel: "medium",
        maxResolution: "1080p",
        audioSupport: false,
        maxLength: "3m",
        moduleTypes: ["display"],
      },
      {
        id: 4,
        name: "Component Cable",
        description: "RGB component video connection",
        color: "#FF6347",
        sourceType: "Component",
        targetType: "Component",
        icon: "cable",
        compatibilityLevel: "medium",
        maxResolution: "1080i",
        audioSupport: false,
        maxLength: "10m",
        moduleTypes: ["display", "legacy"],
      },
      {
        id: 5,
        name: "RCA Cable",
        description: "Composite audio/video connection",
        color: "#FFD700",
        sourceType: "Composite",
        targetType: "Composite",
        icon: "cable",
        compatibilityLevel: "low",
        maxResolution: "480i",
        audioSupport: true,
        maxLength: "10m",
        moduleTypes: ["audio", "legacy"],
      },
      {
        id: 6,
        name: "Optical Cable",
        description: "Digital audio connection using light",
        color: "#00BFFF",
        sourceType: "TOSLINK",
        targetType: "TOSLINK",
        icon: "cable",
        compatibilityLevel: "high",
        maxResolution: null,
        audioSupport: true,
        maxLength: "5m",
        moduleTypes: ["audio"],
      },
      {
        id: 7,
        name: "USB-C to HDMI",
        description: "Connects USB-C devices to HDMI displays",
        color: "#9932CC",
        sourceType: "USB-C",
        targetType: "HDMI",
        icon: "converter",
        compatibilityLevel: "high",
        maxResolution: "4K",
        audioSupport: true,
        maxLength: "2m",
        moduleTypes: ["display", "mobile"],
      },
      {
        id: 8,
        name: "3.5mm to RCA",
        description: "Connects 3.5mm audio to RCA inputs",
        color: "#8A2BE2",
        sourceType: "Aux",
        targetType: "Composite",
        icon: "adapter",
        compatibilityLevel: "high",
        maxResolution: null,
        audioSupport: true,
        maxLength: "2m",
        moduleTypes: ["audio"],
      },
      {
        id: 9,
        name: "VGA Cable",
        description: "Analog video connection",
        color: "#4682B4",
        sourceType: "VGA",
        targetType: "VGA",
        icon: "cable",
        compatibilityLevel: "medium",
        maxResolution: "1080p",
        audioSupport: false,
        maxLength: "15m",
        moduleTypes: ["display", "legacy"],
      },
      {
        id: 10,
        name: "HDMI to VGA",
        description: "Converts HDMI signal to VGA",
        color: "#2E8B57",
        sourceType: "HDMI",
        targetType: "VGA",
        icon: "converter",
        compatibilityLevel: "low",
        maxResolution: "1080p",
        audioSupport: false,
        maxLength: "3m",
        moduleTypes: ["display", "legacy"],
      },
      {
        id: 11,
        name: "DisplayPort Cable",
        description: "High-performance digital display interface",
        color: "#1E90FF",
        sourceType: "DisplayPort",
        targetType: "DisplayPort",
        icon: "cable",
        compatibilityLevel: "high",
        maxResolution: "8K",
        audioSupport: true,
        maxLength: "15m",
        moduleTypes: ["display"],
      },
      {
        id: 12,
        name: "USB-C to DisplayPort",
        description: "Connects USB-C devices to DisplayPort monitors",
        color: "#BA55D3",
        sourceType: "USB-C",
        targetType: "DisplayPort",
        icon: "converter",
        compatibilityLevel: "high",
        maxResolution: "8K",
        audioSupport: true,
        maxLength: "2m",
        moduleTypes: ["display", "mobile"],
      },
      {
        id: 13,
        name: "Ethernet Cable",
        description: "Network connection cable",
        color: "#808080",
        sourceType: "Ethernet",
        targetType: "Ethernet",
        icon: "cable",
        compatibilityLevel: "high",
        maxResolution: null,
        audioSupport: false,
        maxLength: "100m",
        moduleTypes: ["network"],
      },
      {
        id: 14,
        name: "USB Cable",
        description: "Universal Serial Bus connection",
        color: "#000000",
        sourceType: "USB",
        targetType: "USB",
        icon: "cable",
        compatibilityLevel: "high",
        maxResolution: null,
        audioSupport: false,
        maxLength: "5m",
        moduleTypes: ["data", "power"],
      },
      {
        id: 15,
        name: "XLR Cable",
        description: "Professional audio connection",
        color: "#708090",
        sourceType: "XLR",
        targetType: "XLR",
        icon: "cable",
        compatibilityLevel: "high",
        maxResolution: null,
        audioSupport: true,
        maxLength: "30m",
        moduleTypes: ["audio", "professional"],
      },
    ];

    global[CACHE_KEY] = {
      timestamp: Date.now(),
      data: mockAdapters,
    };

    return filterAndPaginateResults(
      mockAdapters,
      sourceType,
      targetType,
      moduleType,
      page,
      pageSize
    );
  } else {
    try {
      const adapterTypes = await sql`
        SELECT 
          a.id, 
          a.name, 
          a.description, 
          a.color, 
          a.source_type as "sourceType", 
          a.target_type as "targetType"
        FROM adapters a
      `;

      const adapterIds = adapterTypes.map((adapter) => adapter.id);

      let compatibilityData = [];
      if (adapterIds.length > 0) {
        const placeholders = adapterIds.map((_, i) => `$${i + 1}`).join(", ");
        const query = `
          SELECT 
            adapter_id, 
            source_port_type, 
            target_port_type, 
            compatibility_level, 
            notes
          FROM compatible_connections 
          WHERE adapter_id IN (${placeholders})
        `;

        compatibilityData = await sql(query, adapterIds);
      }

      const enhancedAdapters = adapterTypes.map((adapter) => {
        const compatibility = compatibilityData.filter(
          (c) => c.adapter_id === adapter.id
        );

        const icon = adapter.name.toLowerCase().includes("cable")
          ? "cable"
          : adapter.name.toLowerCase().includes("to")
          ? "converter"
          : "adapter";

        const moduleTypes = [];
        if (
          ["HDMI", "DisplayPort", "DVI", "VGA"].includes(adapter.sourceType) ||
          ["HDMI", "DisplayPort", "DVI", "VGA"].includes(adapter.targetType)
        ) {
          moduleTypes.push("display");
        }
        if (
          ["TOSLINK", "Aux", "Composite", "XLR"].includes(adapter.sourceType) ||
          ["TOSLINK", "Aux", "Composite", "XLR"].includes(adapter.targetType)
        ) {
          moduleTypes.push("audio");
        }
        if (
          ["VGA", "Composite", "Component"].includes(adapter.sourceType) ||
          ["VGA", "Composite", "Component"].includes(adapter.targetType)
        ) {
          moduleTypes.push("legacy");
        }
        if (["USB-C", "Aux"].includes(adapter.sourceType)) {
          moduleTypes.push("mobile");
        }
        if (
          ["Ethernet"].includes(adapter.sourceType) ||
          ["Ethernet"].includes(adapter.targetType)
        ) {
          moduleTypes.push("network");
        }
        if (
          ["USB", "USB-C"].includes(adapter.sourceType) ||
          ["USB", "USB-C"].includes(adapter.targetType)
        ) {
          moduleTypes.push("data");
        }

        return {
          ...adapter,
          icon,
          moduleTypes,
          compatibilityLevel:
            compatibility.length > 0
              ? compatibility[0].compatibility_level
              : "medium",
          compatibilityNotes:
            compatibility.length > 0 ? compatibility[0].notes : null,
          maxResolution: determineMaxResolution(
            adapter.sourceType,
            adapter.targetType
          ),
          audioSupport: determineAudioSupport(
            adapter.sourceType,
            adapter.targetType
          ),
          maxLength: determineMaxLength(adapter.sourceType, adapter.targetType),
        };
      });

      global[CACHE_KEY] = {
        timestamp: Date.now(),
        data: enhancedAdapters,
      };

      return filterAndPaginateResults(
        enhancedAdapters,
        sourceType,
        targetType,
        moduleType,
        page,
        pageSize
      );
    } catch (error) {
      console.error("Database error:", error);

      const fallbackAdapters = [
        {
          id: 1,
          name: "HDMI Cable",
          description: "Standard HDMI cable for digital audio/video",
          color: "#FF4500",
          sourceType: "HDMI",
          targetType: "HDMI",
          icon: "cable",
          compatibilityLevel: "high",
          maxResolution: "4K",
          audioSupport: true,
          maxLength: "15m",
          moduleTypes: ["display", "audio"],
        },
        {
          id: 2,
          name: "HDMI to DisplayPort",
          description: "Converts HDMI signal to DisplayPort",
          color: "#4169E1",
          sourceType: "HDMI",
          targetType: "DisplayPort",
          icon: "converter",
          compatibilityLevel: "medium",
          maxResolution: "4K",
          audioSupport: true,
          maxLength: "3m",
          moduleTypes: ["display"],
        },
        {
          id: 3,
          name: "HDMI to DVI",
          description: "Converts HDMI signal to DVI",
          color: "#32CD32",
          sourceType: "HDMI",
          targetType: "DVI",
          icon: "converter",
          compatibilityLevel: "medium",
          maxResolution: "1080p",
          audioSupport: false,
          maxLength: "3m",
          moduleTypes: ["display"],
        },
        {
          id: 4,
          name: "Component Cable",
          description: "RGB component video connection",
          color: "#FF6347",
          sourceType: "Component",
          targetType: "Component",
          icon: "cable",
          compatibilityLevel: "medium",
          maxResolution: "1080i",
          audioSupport: false,
          maxLength: "10m",
          moduleTypes: ["display", "legacy"],
        },
        {
          id: 5,
          name: "RCA Cable",
          description: "Composite audio/video connection",
          color: "#FFD700",
          sourceType: "Composite",
          targetType: "Composite",
          icon: "cable",
          compatibilityLevel: "low",
          maxResolution: "480i",
          audioSupport: true,
          maxLength: "10m",
          moduleTypes: ["audio", "legacy"],
        },
        {
          id: 6,
          name: "Optical Cable",
          description: "Digital audio connection using light",
          color: "#00BFFF",
          sourceType: "TOSLINK",
          targetType: "TOSLINK",
          icon: "cable",
          compatibilityLevel: "high",
          maxResolution: null,
          audioSupport: true,
          maxLength: "5m",
          moduleTypes: ["audio"],
        },
        {
          id: 7,
          name: "USB-C to HDMI",
          description: "Connects USB-C devices to HDMI displays",
          color: "#9932CC",
          sourceType: "USB-C",
          targetType: "HDMI",
          icon: "converter",
          compatibilityLevel: "high",
          maxResolution: "4K",
          audioSupport: true,
          maxLength: "2m",
          moduleTypes: ["display", "mobile"],
        },
        {
          id: 8,
          name: "3.5mm to RCA",
          description: "Connects 3.5mm audio to RCA inputs",
          color: "#8A2BE2",
          sourceType: "Aux",
          targetType: "Composite",
          icon: "adapter",
          compatibilityLevel: "high",
          maxResolution: null,
          audioSupport: true,
          maxLength: "2m",
          moduleTypes: ["audio"],
        },
        {
          id: 9,
          name: "VGA Cable",
          description: "Analog video connection",
          color: "#4682B4",
          sourceType: "VGA",
          targetType: "VGA",
          icon: "cable",
          compatibilityLevel: "medium",
          maxResolution: "1080p",
          audioSupport: false,
          maxLength: "15m",
          moduleTypes: ["display", "legacy"],
        },
        {
          id: 10,
          name: "HDMI to VGA",
          description: "Converts HDMI signal to VGA",
          color: "#2E8B57",
          sourceType: "HDMI",
          targetType: "VGA",
          icon: "converter",
          compatibilityLevel: "low",
          maxResolution: "1080p",
          audioSupport: false,
          maxLength: "3m",
          moduleTypes: ["display", "legacy"],
        },
      ];

      return filterAndPaginateResults(
        fallbackAdapters,
        sourceType,
        targetType,
        moduleType,
        page,
        pageSize
      );
    }
  }
}

function filterAndPaginateResults(
  adapters,
  sourceType,
  targetType,
  moduleType,
  page,
  pageSize
) {
  let filteredAdapters = [...adapters];

  if (sourceType) {
    filteredAdapters = filteredAdapters.filter(
      (adapter) => adapter.sourceType.toLowerCase() === sourceType.toLowerCase()
    );
  }

  if (targetType) {
    filteredAdapters = filteredAdapters.filter(
      (adapter) => adapter.targetType.toLowerCase() === targetType.toLowerCase()
    );
  }

  if (moduleType) {
    filteredAdapters = filteredAdapters.filter(
      (adapter) =>
        adapter.moduleTypes &&
        adapter.moduleTypes.includes(moduleType.toLowerCase())
    );
  }

  const totalItems = filteredAdapters.length;
  const totalPages = Math.ceil(totalItems / pageSize);
  const currentPage = Math.min(Math.max(1, page), totalPages || 1);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = Math.min(startIndex + pageSize, totalItems);

  const paginatedAdapters = filteredAdapters.slice(startIndex, endIndex);

  return {
    adapterTypes: paginatedAdapters,
    pagination: {
      totalItems,
      totalPages,
      currentPage,
      pageSize,
      hasNextPage: currentPage < totalPages,
      hasPrevPage: currentPage > 1,
    },
  };
}

function determineMaxResolution(sourceType, targetType) {
  const resolutionMap = {
    HDMI: "4K",
    DisplayPort: "8K",
    DVI: "1080p",
    VGA: "1080p",
    Component: "1080i",
    Composite: "480i",
  };

  if (sourceType in resolutionMap && targetType in resolutionMap) {
    const sourceRes = resolutionMap[sourceType];
    const targetRes = resolutionMap[targetType];

    const resolutionRank = {
      "8K": 5,
      "4K": 4,
      "1080p": 3,
      "1080i": 2,
      "480i": 1,
    };

    return resolutionRank[sourceRes] < resolutionRank[targetRes]
      ? sourceRes
      : targetRes;
  }

  if (sourceType in resolutionMap) {
    return resolutionMap[sourceType];
  }

  if (targetType in resolutionMap) {
    return resolutionMap[targetType];
  }

  return null;
}

function determineAudioSupport(sourceType, targetType) {
  const audioSupportTypes = [
    "HDMI",
    "DisplayPort",
    "TOSLINK",
    "Aux",
    "Composite",
    "XLR",
    "USB-C",
  ];

  return (
    audioSupportTypes.includes(sourceType) &&
    audioSupportTypes.includes(targetType)
  );
}

function determineMaxLength(sourceType, targetType) {
  const lengthMap = {
    HDMI: "15m",
    DisplayPort: "15m",
    DVI: "15m",
    VGA: "15m",
    Component: "10m",
    Composite: "10m",
    TOSLINK: "5m",
    Aux: "2m",
    "USB-C": "2m",
    USB: "5m",
    Ethernet: "100m",
    XLR: "30m",
  };

  if (sourceType in lengthMap && targetType in lengthMap) {
    const sourceLength = parseInt(lengthMap[sourceType]);
    const targetLength = parseInt(lengthMap[targetType]);

    return Math.min(sourceLength, targetLength) + "m";
  }

  if (sourceType in lengthMap) {
    return lengthMap[sourceType];
  }

  if (targetType in lengthMap) {
    return lengthMap[targetType];
  }

  return "3m";
}
export async function POST(request) {
  return handler(await request.json());
}