async function handler() {
  const modules = await sql`SELECT id, name, category FROM module_types`;
  const seen = {};
  const toDelete = [];
  for (const mod of modules) {
    const key = `${mod.name}::${mod.category}`;
    if (seen[key]) {
      toDelete.push(mod.id);
    } else {
      seen[key] = true;
    }
  }
  if (toDelete.length > 0) {
    const placeholders = toDelete.map((_, i) => `$${i + 1}`).join(",");
    await sql(
      `DELETE FROM module_types WHERE id IN (${placeholders})`,
      toDelete
    );
  }
  return { removed: toDelete.length };
}
export async function POST(request) {
  return handler(await request.json());
}