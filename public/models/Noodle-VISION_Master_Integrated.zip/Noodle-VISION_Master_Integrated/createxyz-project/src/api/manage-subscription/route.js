async function handler({
  action,
  planId,
  paymentMethodId,
  refundReason,
  sourceDevice,
  targetDevice,
  brands,
  maxAdapters,
}) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    switch (action) {
      case "getStatus": {
        const subscription = await sql`
          SELECT s.*, sp.name as plan_name, sp.price
          FROM subscriptions s
          JOIN subscription_plans sp ON s.plan_id = sp.id
          WHERE s.user_id = ${session.user.id}
          AND s.status != 'canceled'
          ORDER BY s.created_at DESC
          LIMIT 1
        `;

        return { subscription: subscription[0] || null };
      }

      case "updatePayment": {
        const subscription = await sql`
          SELECT stripe_subscription_id 
          FROM subscriptions 
          WHERE user_id = ${session.user.id} 
          AND status != 'canceled'
          LIMIT 1
        `;

        if (!subscription?.[0]) {
          return { error: "No active subscription found" };
        }

        const response = await fetch(
          "https://api.stripe.com/v1/subscriptions/" +
            subscription[0].stripe_subscription_id,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams({
              default_payment_method: paymentMethodId,
            }),
          }
        );

        if (!response.ok) {
          return { error: "Failed to update payment method" };
        }

        return { success: true };
      }

      case "changePlan": {
        const [currentSub, newPlan] = await sql.transaction([
          sql`
            SELECT stripe_subscription_id, plan_id 
            FROM subscriptions 
            WHERE user_id = ${session.user.id} 
            AND status != 'canceled'
            LIMIT 1
          `,
          sql`
            SELECT stripe_price_id, price 
            FROM subscription_plans 
            WHERE id = ${planId}
          `,
        ]);

        if (!currentSub?.[0]) {
          return { error: "No active subscription found" };
        }

        if (!newPlan?.[0]) {
          return { error: "Invalid plan selected" };
        }

        const response = await fetch(
          "https://api.stripe.com/v1/subscriptions/" +
            currentSub[0].stripe_subscription_id,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams({
              items: [{ price: newPlan[0].stripe_price_id }],
              proration_behavior: "always_invoice",
            }),
          }
        );

        if (!response.ok) {
          return { error: "Failed to update subscription plan" };
        }

        await sql`
          UPDATE subscriptions 
          SET plan_id = ${planId}, 
              amount = ${newPlan[0].price},
              updated_at = NOW()
          WHERE user_id = ${session.user.id} 
          AND status != 'canceled'
        `;

        return { success: true };
      }

      case "cancel": {
        const subscription = await sql`
          SELECT stripe_subscription_id 
          FROM subscriptions 
          WHERE user_id = ${session.user.id} 
          AND status != 'canceled'
          LIMIT 1
        `;

        if (!subscription?.[0]) {
          return { error: "No active subscription found" };
        }

        const response = await fetch(
          "https://api.stripe.com/v1/subscriptions/" +
            subscription[0].stripe_subscription_id,
          {
            method: "DELETE",
            headers: {
              Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
            },
          }
        );

        if (!response.ok) {
          return { error: "Failed to cancel subscription" };
        }

        await sql`
          UPDATE subscriptions 
          SET status = 'canceled',
              canceled_at = NOW()
          WHERE user_id = ${session.user.id} 
          AND status != 'canceled'
        `;

        return { success: true };
      }

      case "refund": {
        const payment = await sql`
          SELECT stripe_payment_id 
          FROM subscription_payments 
          WHERE user_id = ${session.user.id} 
          ORDER BY created_at DESC 
          LIMIT 1
        `;

        if (!payment?.[0]) {
          return { error: "No payment found to refund" };
        }

        const response = await fetch("https://api.stripe.com/v1/refunds", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            payment_intent: payment[0].stripe_payment_id,
            reason: refundReason || "requested_by_customer",
          }),
        });

        if (!response.ok) {
          return { error: "Failed to process refund" };
        }

        await sql`
          INSERT INTO subscription_refunds (
            user_id, 
            payment_id, 
            reason, 
            status
          ) VALUES (
            ${session.user.id}, 
            ${payment[0].id}, 
            ${refundReason}, 
            'processed'
          )
        `;

        return { success: true };
      }

      case "getCompatibleAdapters": {
        if (!sourceDevice || !targetDevice) {
          return { error: "Source and target devices are required" };
        }

        const deviceData = await sql`
          SELECT id, name, type, brand, model, ports, image_url
          FROM devices
          WHERE name IN (${sourceDevice}, ${targetDevice})
        `;

        if (deviceData.length < 2) {
          return { error: "One or both devices not found in database" };
        }

        const sourceDeviceData = deviceData.find(
          (d) => d.name === sourceDevice
        );
        const targetDeviceData = deviceData.find(
          (d) => d.name === targetDevice
        );

        const sourcePorts = sourceDeviceData.ports;
        const targetPorts = targetDeviceData.ports;

        let adapterQuery = `
          SELECT id, name, input_type, output_type, brand, model, 
                 requires_power, max_resolution, supports_audio, price_range, image_url
          FROM adapter_types
          WHERE 1=1
        `;

        const queryParams = [];
        let paramCounter = 1;

        if (brands && brands.length > 0) {
          adapterQuery += ` AND brand IN (`;
          brands.forEach((brand, index) => {
            adapterQuery +=
              index === 0 ? `$${paramCounter}` : `, $${paramCounter}`;
            queryParams.push(brand);
            paramCounter++;
          });
          adapterQuery += `)`;
        }

        const adapters = await sql(adapterQuery, queryParams);

        const directConnections = [];
        for (const sourcePort of sourcePorts) {
          for (const targetPort of targetPorts) {
            if (sourcePort === targetPort) {
              directConnections.push({
                path: [`Direct connection: ${sourcePort}`],
                quality: 100,
                limitations: [],
              });
            }
          }
        }

        const singleAdapterConnections = [];
        for (const sourcePort of sourcePorts) {
          for (const targetPort of targetPorts) {
            const adapter = adapters.find(
              (a) => a.input_type === sourcePort && a.output_type === targetPort
            );
            if (adapter) {
              singleAdapterConnections.push({
                path: [
                  `${adapter.input_type} to ${adapter.output_type} adapter`,
                ],
                brands: [adapter.brand],
                models: [adapter.model],
                quality: 90,
                powered: adapter.requires_power,
                maxResolution: adapter.max_resolution,
                supportsAudio: adapter.supports_audio,
                limitations: [],
              });
            }
          }
        }

        const twoAdapterConnections = [];
        if (!maxAdapters || maxAdapters >= 2) {
          for (const sourcePort of sourcePorts) {
            for (const targetPort of targetPorts) {
              for (const adapter1 of adapters) {
                if (adapter1.input_type === sourcePort) {
                  for (const adapter2 of adapters) {
                    if (
                      adapter2.input_type === adapter1.output_type &&
                      adapter2.output_type === targetPort
                    ) {
                      twoAdapterConnections.push({
                        path: [
                          `${adapter1.input_type} to ${adapter1.output_type} adapter`,
                          `${adapter2.input_type} to ${adapter2.output_type} adapter`,
                        ],
                        brands: [adapter1.brand, adapter2.brand],
                        models: [adapter1.model, adapter2.model],
                        quality: 70,
                        powered:
                          adapter1.requires_power || adapter2.requires_power,
                        maxResolution:
                          compareResolutions(
                            adapter1.max_resolution,
                            adapter2.max_resolution
                          ) < 0
                            ? adapter2.max_resolution
                            : adapter1.max_resolution,
                        supportsAudio:
                          adapter1.supports_audio && adapter2.supports_audio,
                        limitations: [
                          "Signal degradation possible with multiple adapters",
                        ],
                      });
                    }
                  }
                }
              }
            }
          }
        }

        const threeAdapterConnections = [];
        if (!maxAdapters || maxAdapters >= 3) {
          for (const sourcePort of sourcePorts) {
            for (const targetPort of targetPorts) {
              for (const adapter1 of adapters) {
                if (adapter1.input_type === sourcePort) {
                  for (const adapter2 of adapters) {
                    if (adapter2.input_type === adapter1.output_type) {
                      for (const adapter3 of adapters) {
                        if (
                          adapter3.input_type === adapter2.output_type &&
                          adapter3.output_type === targetPort
                        ) {
                          threeAdapterConnections.push({
                            path: [
                              `${adapter1.input_type} to ${adapter1.output_type} adapter`,
                              `${adapter2.input_type} to ${adapter2.output_type} adapter`,
                              `${adapter3.input_type} to ${adapter3.output_type} adapter`,
                            ],
                            brands: [
                              adapter1.brand,
                              adapter2.brand,
                              adapter3.brand,
                            ],
                            models: [
                              adapter1.model,
                              adapter2.model,
                              adapter3.model,
                            ],
                            quality: 50,
                            powered:
                              adapter1.requires_power ||
                              adapter2.requires_power ||
                              adapter3.requires_power,
                            maxResolution: getLowestResolution([
                              adapter1.max_resolution,
                              adapter2.max_resolution,
                              adapter3.max_resolution,
                            ]),
                            supportsAudio:
                              adapter1.supports_audio &&
                              adapter2.supports_audio &&
                              adapter3.supports_audio,
                            limitations: [
                              "Significant signal degradation likely",
                              "Not recommended for high-quality video/audio",
                            ],
                          });
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }

        const unconventionalSetups = await sql`
          SELECT ci.description, ci.severity, ci.adapter_pattern, ci.affects_functionality, ci.solution
          FROM compatibility_issues ci
          WHERE ci.adapter_pattern @> ${JSON.stringify({
            sourceDevice,
            targetDevice,
          })}
        `;

        const formattedUnconventionalSetups = unconventionalSetups.map(
          (setup) => ({
            path: setup.adapter_pattern.path || [],
            brands: setup.adapter_pattern.brands || [],
            models: setup.adapter_pattern.models || [],
            quality:
              setup.severity === "high"
                ? 30
                : setup.severity === "medium"
                ? 50
                : 70,
            powered: setup.adapter_pattern.powered || false,
            limitations: [setup.description],
            isUnconventional: true,
            explanation: setup.solution,
          })
        );

        const allConnections = [
          ...directConnections,
          ...singleAdapterConnections,
          ...twoAdapterConnections,
          ...threeAdapterConnections,
          ...formattedUnconventionalSetups,
        ];

        allConnections.sort((a, b) => b.quality - a.quality);

        return {
          sourceDevice,
          targetDevice,
          sourcePorts,
          targetPorts,
          connections: allConnections,
        };
      }

      default:
        return { error: "Invalid action" };
    }
  } catch (error) {
    console.error("Subscription management error:", error);
    return { error: "Failed to process subscription request" };
  }
}

function compareResolutions(res1, res2) {
  if (!res1) return -1;
  if (!res2) return 1;

  const getPixels = (res) => {
    const match = res.match(/(\d+)K?@(\d+)Hz/);
    if (!match) return 0;

    let pixels = parseInt(match[1]);
    if (res.includes("K")) {
      pixels *= 1000;
    }
    return pixels * parseInt(match[2]);
  };

  return getPixels(res1) - getPixels(res2);
}

function getLowestResolution(resolutions) {
  const filteredResolutions = resolutions.filter((r) => r);
  if (filteredResolutions.length === 0) return null;

  return filteredResolutions.reduce((lowest, current) => {
    if (!lowest) return current;
    return compareResolutions(lowest, current) < 0 ? lowest : current;
  }, null);
}
export async function POST(request) {
  return handler(await request.json());
}