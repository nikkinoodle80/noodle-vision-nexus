async function handler({ imageData, imageUrl }) {
  try {
    // Check if we have image data or URL
    if (!imageData && !imageUrl) {
      return {
        success: false,
        error: "No image data or URL provided",
      };
    }

    // Prepare the image source
    let imageSource;
    if (imageUrl) {
      imageSource = { url: imageUrl };
    } else {
      // Ensure the image data is properly formatted
      let base64Image = imageData;
      if (!base64Image.startsWith("data:image")) {
        base64Image = `data:image/jpeg;base64,${imageData}`;
      }
      imageSource = { url: base64Image };
    }

    // Prepare the prompt for GPT-4 Vision
    const prompt = `
    Analyze this hardware device image and provide the following information:
    1. Device type and category (e.g., router, switch, server, etc.)
    2. Identify all visible ports and connections (type, number, location)
    3. Suggest an optimal layout for wiring and connections
    4. Identify potential heat spots or cooling considerations
    
    Format your response as structured data with these sections clearly labeled.
    `;

    // Call GPT-4 Vision API using the integration
    const response = await fetch("/integrations/gpt-vision/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: prompt },
              {
                type: "image_url",
                image_url: imageSource,
              },
            ],
          },
        ],
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      return {
        success: false,
        error: `GPT Vision API error: ${errorData.error || "Unknown error"}`,
      };
    }

    const result = await response.json();

    // Extract the analysis from the response
    const analysis = result.choices[0].message.content;

    // Store the analysis in the database for future reference
    const session = getSession();
    let userId = null;

    if (session && session.user) {
      userId = session.user.id;

      try {
        // Check if device_analyses table exists
        const tableExists = await sql`
          SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name = 'device_analyses'
          )
        `;

        // If table doesn't exist, create it
        if (!tableExists[0].exists) {
          await sql`
            CREATE TABLE device_analyses (
              id SERIAL PRIMARY KEY,
              user_id TEXT NOT NULL,
              analysis TEXT NOT NULL,
              created_at TIMESTAMP NOT NULL
            )
          `;
        }

        // Save the analysis to the database if user is logged in
        await sql`
          INSERT INTO device_analyses (user_id, analysis, created_at)
          VALUES (${userId}, ${analysis}, NOW())
        `;
      } catch (dbError) {
        console.error("Database error:", dbError);
        // Continue execution even if database operation fails
      }
    }

    return {
      success: true,
      analysis,
      userId,
    };
  } catch (error) {
    console.error("Error analyzing device image:", error);
    return {
      success: false,
      error: `Failed to analyze image: ${error.message}`,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}