async function handler({
  name,
  description,
  adapterSequence,
  sourceDeviceType,
  targetDeviceType,
  useCase,
}) {
  const session = getSession();
  if (!session || !session.user) {
    return {
      success: false,
      error: "Authentication required",
    };
  }

  try {
    if (!name || !adapterSequence || adapterSequence.length === 0) {
      return {
        success: false,
        error: "Name and adapter sequence are required",
      };
    }

    const result = await sql(
      "INSERT INTO adapter_chains (name, description, adapter_sequence, source_device_type, target_device_type, use_case, is_verified) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id",
      [
        name,
        description,
        adapterSequence,
        sourceDeviceType,
        targetDeviceType,
        useCase,
        false,
      ]
    );

    await sql(
      "INSERT INTO security_audit_logs (user_id, action, details) VALUES ($1, $2, $3)",
      [
        session.user.id,
        "SAVE_ADAPTER_CHAIN",
        JSON.stringify({ chainId: result[0].id, name }),
      ]
    );

    return {
      success: true,
      chainId: result[0].id,
      message: "Adapter chain saved successfully",
    };
  } catch (error) {
    console.error("Error in SaveAdapterChain:", error);
    return {
      success: false,
      error: "Failed to save adapter chain",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}