function handler() {
  try {
    const plans = sql`
      SELECT * FROM subscription_plans
      ORDER BY price ASC
    `;

    return {
      success: true,
      plans,
    };
  } catch (error) {
    console.error("Error fetching subscription plans:", error);
    return {
      success: false,
      error: "Failed to fetch subscription plans",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}