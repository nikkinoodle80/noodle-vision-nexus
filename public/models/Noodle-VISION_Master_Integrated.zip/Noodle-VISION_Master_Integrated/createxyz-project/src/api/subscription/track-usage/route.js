async function handler({ apiType, requestType, tokensUsed }) {
  const session = getSession();

  if (!session || !session.user) {
    return {
      success: false,
      error: "User not authenticated",
    };
  }

  try {
    // Consolidate data insertion and update into a single transaction
    await sql.transaction(async (txn) => {
      await txn`
        INSERT INTO api_usage 
        (user_id, api_type, request_type, tokens_used)
        VALUES 
        (${session.user.id}, ${apiType}, ${requestType}, ${tokensUsed})
      `;

      await txn`
        UPDATE user_subscriptions
        SET api_calls_used = api_calls_used + 1,
            updated_at = NOW()
        WHERE user_id = ${session.user.id}
        AND status = 'active'
      `;
    });

    const rows = await sql`
      SELECT us.api_calls_used, sp.api_calls_limit
      FROM user_subscriptions us
      JOIN subscription_plans sp ON us.plan_id = sp.id
      WHERE us.user_id = ${session.user.id}
      AND us.status = 'active'
    `;

    if (rows.length > 0) {
      const { api_calls_used, api_calls_limit } = rows[0];
      const remaining = api_calls_limit - api_calls_used;

      return {
        success: true,
        usage: {
          used: api_calls_used,
          limit: api_calls_limit,
          remaining: remaining > 0 ? remaining : 0,
        },
        limitExceeded: api_calls_used >= api_calls_limit,
      };
    }

    return {
      success: true,
    };
  } catch (error) {
    console.error("Error tracking API usage:", error);
    return {
      success: false,
      error: "Failed to track API usage",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}