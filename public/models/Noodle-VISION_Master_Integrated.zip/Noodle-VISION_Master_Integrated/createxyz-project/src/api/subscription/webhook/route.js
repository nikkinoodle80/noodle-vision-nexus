async function handler(req) {
  try {
    // Get the signature from the headers
    const signature = req.headers["stripe-signature"];

    if (!signature) {
      return {
        success: false,
        error: "No Stripe signature found in request",
      };
    }

    // Verify and construct the event
    let event;
    try {
      const stripeSecret = process.env.STRIPE_WEBHOOK_SECRET;
      const stripe = await fetch(
        `${process.env.STRIPE_API_URL}/webhook-endpoints`,
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
            "Content-Type": "application/json",
          },
        }
      );

      // Construct the event using Stripe's API
      const response = await fetch(
        `${process.env.STRIPE_API_URL}/events/construct`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            payload: req.body,
            signature: signature,
            secret: stripeSecret,
          }),
        }
      );

      event = await response.json();

      if (event.error) {
        throw new Error(event.error.message);
      }
    } catch (err) {
      return {
        success: false,
        error: `Webhook signature verification failed: ${err.message}`,
      };
    }

    // Handle the event based on its type
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object;

        // Extract metadata
        const userId = session.metadata?.userId;
        const planId = session.metadata?.planId;

        if (!userId || !planId) {
          console.error("Missing metadata in checkout session");
          return { success: false };
        }

        // Create or update subscription record
        await sql(
          `
          INSERT INTO user_subscriptions 
          (user_id, plan_id, status, stripe_subscription_id, stripe_customer_id, current_period_start, current_period_end)
          VALUES 
          ($1, $2, $3, $4, $5, NOW(), NOW() + INTERVAL '1 month')
          ON CONFLICT (user_id) 
          DO UPDATE SET
            plan_id = $2,
            status = $3,
            stripe_subscription_id = $4,
            stripe_customer_id = $5,
            current_period_start = NOW(),
            current_period_end = NOW() + INTERVAL '1 month',
            updated_at = NOW()
          WHERE user_subscriptions.status = 'active'
        `,
          [
            parseInt(userId),
            parseInt(planId),
            "active",
            session.subscription,
            session.customer,
          ]
        );

        break;
      }

      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        const subscription = event.data.object;

        // Get the subscription from our database
        const rows = await sql(
          `
          SELECT * FROM user_subscriptions
          WHERE stripe_subscription_id = $1
        `,
          [subscription.id]
        );

        if (rows.length === 0) {
          console.error("Subscription not found:", subscription.id);
          return { success: false };
        }

        // Update the subscription status
        await sql(
          `
          UPDATE user_subscriptions
          SET status = $1,
              current_period_end = to_timestamp($2),
              updated_at = NOW()
          WHERE stripe_subscription_id = $3
        `,
          [
            subscription.status,
            subscription.current_period_end,
            subscription.id,
          ]
        );

        break;
      }
    }

    return {
      success: true,
    };
  } catch (error) {
    console.error("Error handling Stripe webhook:", error);
    return {
      success: false,
      error: "Failed to process webhook",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}