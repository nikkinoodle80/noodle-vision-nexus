async function handler({ planId, successUrl, cancelUrl }) {
  const session = getSession();

  if (!session || !session.user) {
    return {
      success: false,
      error: "User not authenticated",
    };
  }

  if (!planId) {
    return {
      success: false,
      error: "Plan ID is required",
    };
  }

  try {
    const planRows = await sql`
      SELECT * FROM subscription_plans WHERE id = ${planId}
    `;

    if (planRows.length === 0) {
      return {
        success: false,
        error: "Invalid plan ID",
      };
    }

    const plan = planRows[0];

    if (!plan.stripe_price_id) {
      return {
        success: false,
        error: "This plan doesn't have a valid Stripe price ID",
      };
    }

    let stripeCustomerId;
    const userRows = await sql`
      SELECT * FROM user_subscriptions 
      WHERE user_id = ${session.user.id} 
      AND stripe_customer_id IS NOT NULL
      LIMIT 1
    `;

    if (userRows.length > 0 && userRows[0].stripe_customer_id) {
      stripeCustomerId = userRows[0].stripe_customer_id;
    } else {
      const response = await fetch(`${process.env.STRIPE_API_URL}/customers`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          email: session.user.email,
          name: session.user.name || session.user.email,
        }),
      });

      const customer = await response.json();
      stripeCustomerId = customer.id;
    }

    const checkoutSessionParams = new URLSearchParams();
    checkoutSessionParams.append("customer", stripeCustomerId);
    checkoutSessionParams.append("line_items[0][price]", plan.stripe_price_id);
    checkoutSessionParams.append("line_items[0][quantity]", "1");
    checkoutSessionParams.append("mode", "subscription");
    checkoutSessionParams.append(
      "success_url",
      successUrl || `${process.env.APP_URL}/account?subscription=success`
    );
    checkoutSessionParams.append(
      "cancel_url",
      cancelUrl || `${process.env.APP_URL}/pricing?subscription=canceled`
    );
    checkoutSessionParams.append(
      "metadata[userId]",
      session.user.id.toString()
    );
    checkoutSessionParams.append("metadata[planId]", planId.toString());

    const checkoutResponse = await fetch(
      `${process.env.STRIPE_API_URL}/checkout/sessions`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: checkoutSessionParams,
      }
    );

    const checkoutSession = await checkoutResponse.json();

    if (checkoutSession.error) {
      throw new Error(checkoutSession.error.message);
    }

    return {
      success: true,
      url: checkoutSession.url,
    };
  } catch (error) {
    console.error("Error creating checkout session:", error);
    return {
      success: false,
      error: "Failed to create checkout session",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}