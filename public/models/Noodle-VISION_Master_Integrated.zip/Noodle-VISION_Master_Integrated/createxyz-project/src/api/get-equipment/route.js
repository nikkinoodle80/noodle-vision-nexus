async function handler() {
  try {
    // First try to get equipment from the equipment table
    const equipment = await sql`SELECT * FROM equipment`;

    if (equipment && equipment.length > 0) {
      return { equipment };
    }

    // If no equipment table or no data, get from products table
    const equipmentTypes = [
      "AVR Receiver",
      "DVD Player",
      "DVR",
      "Smartphone",
      "Monitor",
    ];

    // Query the database for these products
    const devices = await sql`
      SELECT id, name, description, price 
      FROM products
      WHERE name IN (${equipmentTypes[0]}, ${equipmentTypes[1]}, ${equipmentTypes[2]}, ${equipmentTypes[3]}, ${equipmentTypes[4]})
    `;

    // If we have devices from products table
    if (devices && devices.length > 0) {
      // For each device, get its ports
      const enhancedDevices = [];

      for (const device of devices) {
        const ports = await sql`
          SELECT port_name as name, port_type as type, count
          FROM device_ports
          WHERE device_id = ${device.id}
        `;

        // Add mock images based on device type
        let image = "";
        switch (device.name) {
          case "AVR Receiver":
            image =
              "https://images.unsplash.com/photo-1545454675-3531b543be5d?w=400&h=300&fit=crop";
            break;
          case "DVD Player":
            image =
              "https://images.unsplash.com/photo-1593078165899-c7d2ac0d6aea?w=400&h=300&fit=crop";
            break;
          case "DVR":
            image =
              "https://images.unsplash.com/photo-1586024486164-ce9b3d87e09f?w=400&h=300&fit=crop";
            break;
          case "Smartphone":
            image =
              "https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&h=300&fit=crop";
            break;
          case "Monitor":
            image =
              "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=400&h=300&fit=crop";
            break;
          default:
            image =
              "https://images.unsplash.com/photo-1550009158-9ebf69173e03?w=400&h=300&fit=crop";
        }

        enhancedDevices.push({
          ...device,
          image,
          ports,
        });
      }

      return { equipment: enhancedDevices };
    }

    // Fallback to mock data if no data in database
    return {
      equipment: [
        {
          id: 1,
          name: "Main Device",
          description: "The central device that connects to other equipment",
          image:
            "https://images.unsplash.com/photo-1593640408182-31c70c8268f5?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [
            { type: 1, name: "Standard Cable", count: 4 },
            { type: 2, name: "Display Cable", count: 1 },
            { type: 3, name: "Legacy Connector", count: 1 },
            { type: 4, name: "Network Cable", count: 1 },
            { type: 6, name: "Audio Connector", count: 2 },
            { type: 7, name: "Power Cable", count: 1 },
            { type: 8, name: "Wireless Connection", count: 1 },
          ],
        },
        {
          id: 2,
          name: "Display Screen",
          description: "Shows visual information from connected devices",
          image:
            "https://images.unsplash.com/photo-1586210579191-33b45e38fa2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [
            { type: 2, name: "Display Cable", count: 1 },
            { type: 3, name: "Legacy Connector", count: 1 },
            { type: 7, name: "Power Cable", count: 1 },
          ],
        },
        {
          id: 3,
          name: "Output Device",
          description: "Creates physical output from digital information",
          image:
            "https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [
            { type: 1, name: "Standard Cable", count: 1 },
            { type: 4, name: "Network Cable", count: 1 },
            { type: 7, name: "Power Cable", count: 1 },
            { type: 8, name: "Wireless Connection", count: 1 },
          ],
        },
        {
          id: 4,
          name: "Network Hub",
          description: "Connects multiple devices to a network",
          image:
            "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [
            { type: 4, name: "Network Cable", count: 4 },
            { type: 7, name: "Power Cable", count: 1 },
            { type: 8, name: "Wireless Connection", count: 1 },
          ],
        },
        {
          id: 5,
          name: "Portable Device",
          description: "A handheld device with multiple functions",
          image:
            "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [
            { type: 5, name: "Modern Connector", count: 1 },
            { type: 6, name: "Audio Connector", count: 1 },
            { type: 7, name: "Power Cable", count: 1 },
            { type: 8, name: "Wireless Connection", count: 1 },
          ],
        },
        {
          id: 6,
          name: "Audio Equipment",
          description: "Produces sound from connected devices",
          image:
            "https://images.unsplash.com/photo-1545454675-3531b543be5d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [
            { type: 6, name: "Audio Connector", count: 1 },
            { type: 7, name: "Power Cable", count: 1 },
            { type: 8, name: "Wireless Connection", count: 1 },
          ],
        },
        {
          id: 7,
          name: "Power Source",
          description: "Provides electricity to other devices",
          image:
            "https://images.unsplash.com/photo-1623126908029-58c31ac5eb9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [{ type: 7, name: "Power Cable", count: 6 }],
        },
        {
          id: 8,
          name: "Wireless Transmitter",
          description: "Sends signals to compatible devices without cables",
          image:
            "https://images.unsplash.com/photo-1552345386-6690de5b2c09?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [
            { type: 4, name: "Network Cable", count: 1 },
            { type: 7, name: "Power Cable", count: 1 },
            { type: 8, name: "Wireless Connection", count: 1 },
          ],
        },
      ],
    };
  } catch (error) {
    console.error("Error fetching equipment:", error);
    return {
      equipment: [
        {
          id: 1,
          name: "Main Device",
          description: "The central device that connects to other equipment",
          image:
            "https://images.unsplash.com/photo-1593640408182-31c70c8268f5?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [
            { type: 1, name: "Standard Cable", count: 4 },
            { type: 2, name: "Display Cable", count: 1 },
            { type: 3, name: "Legacy Connector", count: 1 },
            { type: 4, name: "Network Cable", count: 1 },
            { type: 6, name: "Audio Connector", count: 2 },
            { type: 7, name: "Power Cable", count: 1 },
            { type: 8, name: "Wireless Connection", count: 1 },
          ],
        },
        {
          id: 2,
          name: "Display Screen",
          description: "Shows visual information from connected devices",
          image:
            "https://images.unsplash.com/photo-1586210579191-33b45e38fa2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [
            { type: 2, name: "Display Cable", count: 1 },
            { type: 3, name: "Legacy Connector", count: 1 },
            { type: 7, name: "Power Cable", count: 1 },
          ],
        },
        {
          id: 3,
          name: "Output Device",
          description: "Creates physical output from digital information",
          image:
            "https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [
            { type: 1, name: "Standard Cable", count: 1 },
            { type: 4, name: "Network Cable", count: 1 },
            { type: 7, name: "Power Cable", count: 1 },
            { type: 8, name: "Wireless Connection", count: 1 },
          ],
        },
        {
          id: 4,
          name: "Network Hub",
          description: "Connects multiple devices to a network",
          image:
            "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [
            { type: 4, name: "Network Cable", count: 4 },
            { type: 7, name: "Power Cable", count: 1 },
            { type: 8, name: "Wireless Connection", count: 1 },
          ],
        },
        {
          id: 5,
          name: "Portable Device",
          description: "A handheld device with multiple functions",
          image:
            "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [
            { type: 5, name: "Modern Connector", count: 1 },
            { type: 6, name: "Audio Connector", count: 1 },
            { type: 7, name: "Power Cable", count: 1 },
            { type: 8, name: "Wireless Connection", count: 1 },
          ],
        },
        {
          id: 6,
          name: "Audio Equipment",
          description: "Produces sound from connected devices",
          image:
            "https://images.unsplash.com/photo-1545454675-3531b543be5d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [
            { type: 6, name: "Audio Connector", count: 1 },
            { type: 7, name: "Power Cable", count: 1 },
            { type: 8, name: "Wireless Connection", count: 1 },
          ],
        },
        {
          id: 7,
          name: "Power Source",
          description: "Provides electricity to other devices",
          image:
            "https://images.unsplash.com/photo-1623126908029-58c31ac5eb9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [{ type: 7, name: "Power Cable", count: 6 }],
        },
        {
          id: 8,
          name: "Wireless Transmitter",
          description: "Sends signals to compatible devices without cables",
          image:
            "https://images.unsplash.com/photo-1552345386-6690de5b2c09?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          ports: [
            { type: 4, name: "Network Cable", count: 1 },
            { type: 7, name: "Power Cable", count: 1 },
            { type: 8, name: "Wireless Connection", count: 1 },
          ],
        },
      ],
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}