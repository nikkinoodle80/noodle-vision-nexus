async function handler() {
  const session = getSession();

  if (!session) {
    return null;
  }

  const { user } = session;
  const cablePosition =
    await sql`SELECT layout->>'x' AS x, layout->>'y' AS y FROM user_saved_setups WHERE user_id = ${user.id} LIMIT 1`;

  if (cablePosition.length === 0) {
    return null;
  }

  return {
    x: parseFloat(cablePosition[0].x),
    y: parseFloat(cablePosition[0].y),
  };
}
export async function POST(request) {
  return handler(await request.json());
}