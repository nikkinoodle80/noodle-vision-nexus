async function handler({ name, description }) {
  const session = getSession();

  if (!session || !session.user) {
    return { error: "User not authenticated" };
  }

  const userId = session.user.id;

  const [newSetup] = await sql`
    INSERT INTO home_setups (user_id, name, description)
    VALUES (${userId}, ${name}, ${description})
    RETURNING id, name, description, created_at
  `;

  return newSetup ? { setup: newSetup } : { error: "Failed to create setup" };
}
export async function POST(request) {
  return handler(await request.json());
}