async function handler({ isWireless, isSmartHomeCompatible }) {
  try {
    const queryParts = ["SELECT * FROM adapter_types WHERE 1=1"];
    const values = [];
    let paramCount = 1;

    if (isWireless !== undefined) {
      queryParts.push(`AND is_wireless = $${paramCount}`);
      values.push(isWireless);
      paramCount++;
    }

    if (isSmartHomeCompatible !== undefined) {
      queryParts.push(`AND is_smart_home_compatible = $${paramCount}`);
      values.push(isSmartHomeCompatible);
      paramCount++;
    }

    queryParts.push("ORDER BY name ASC");

    const queryString = queryParts.join(" ");
    const adapters = await sql(queryString, values);

    return { adapters };
  } catch (error) {
    console.error("Error fetching home adapters:", error);
    return { error: "Failed to fetch adapters" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}