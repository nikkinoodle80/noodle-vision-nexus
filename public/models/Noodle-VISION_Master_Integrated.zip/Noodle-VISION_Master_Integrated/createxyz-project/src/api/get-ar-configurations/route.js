async function handler() {
  try {
    const session = getSession();

    if (!session || !session.user) {
      return {
        status: 401,
        error: "Unauthorized. Please sign in to access your AR configurations.",
      };
    }

    const userId = session.user.id;

    const configurations = await sql`
      SELECT * FROM ar_configurations 
      WHERE user_id = ${userId}
      ORDER BY updated_at DESC
    `;

    return {
      status: 200,
      configurations,
    };
  } catch (error) {
    console.error("Error fetching AR configurations:", error);
    return {
      status: 500,
      error: "Failed to retrieve AR configurations. Please try again later.",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}