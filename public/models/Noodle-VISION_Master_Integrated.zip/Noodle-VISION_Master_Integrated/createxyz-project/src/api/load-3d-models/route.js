async function handler({ deviceIds }) {
  if (!deviceIds || !Array.isArray(deviceIds)) {
    return {
      error: "Invalid input: deviceIds must be an array",
    };
  }

  try {
    // Query the database for device information including 3D model URLs
    const devices = await sql`
      SELECT 
        id, 
        name, 
        category, 
        image_url, 
        input_ports, 
        output_ports,
        COALESCE(model_url, 'https://example.com/default-model.glb') as model_url,
        COALESCE(model_scale, '{"x": 1, "y": 1, "z": 1}') as model_scale
      FROM devices 
      WHERE id = ANY(${deviceIds})
    `;

    if (devices.length === 0) {
      return {
        error: "No devices found with the provided IDs",
      };
    }

    // Transform the data to include model information
    const devicesWithModels = devices.map((device) => ({
      id: device.id,
      name: device.name,
      category: device.category,
      thumbnailUrl: device.image_url,
      modelUrl: device.model_url,
      modelScale: device.model_scale,
      inputPorts: device.input_ports || [],
      outputPorts: device.output_ports || [],
    }));

    return {
      devices: devicesWithModels,
    };
  } catch (error) {
    console.error("Error loading 3D models:", error);
    return {
      error: "Failed to load 3D models",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}