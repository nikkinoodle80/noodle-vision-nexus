function handler({ id, type, brand, search, forceRefresh }) {
  const CACHE_DURATION = 3600000; // 1 hour in milliseconds
  const cache = {};

  // Create a cache key based on the request parameters
  const cacheKey = JSON.stringify({ id, type, brand, search });

  // Check if we have a valid cached response
  if (
    !forceRefresh &&
    cache[cacheKey] &&
    Date.now() - cache[cacheKey].timestamp < CACHE_DURATION
  ) {
    console.log("Returning cached device data");
    return cache[cacheKey].data;
  }

  try {
    let queryParams = [];
    let queryString = "SELECT * FROM devices WHERE 1=1";
    let paramIndex = 1;

    // Build query based on parameters
    if (id) {
      queryString += ` AND id = $${paramIndex}`;
      queryParams.push(id);
      paramIndex++;
    }

    if (type) {
      queryString += ` AND type = $${paramIndex}`;
      queryParams.push(type);
      paramIndex++;
    }

    if (brand) {
      queryString += ` AND brand = $${paramIndex}`;
      queryParams.push(brand);
      paramIndex++;
    }

    if (search) {
      queryString += ` AND (name ILIKE $${paramIndex} OR model ILIKE $${paramIndex})`;
      queryParams.push(`%${search}%`);
      paramIndex++;
    }

    // Add order by
    queryString += " ORDER BY name ASC";

    // Execute the query using the function form of sql
    return sql.transaction(async () => {
      const result = await sql(queryString, queryParams);

      // If requesting a single device, return just that device
      if (id && result.length > 0) {
        const device = result[0];
        // Store in cache
        cache[cacheKey] = {
          data: device,
          timestamp: Date.now(),
        };
        return device;
      }

      // Store in cache
      cache[cacheKey] = {
        data: result,
        timestamp: Date.now(),
      };

      return result;
    });
  } catch (error) {
    console.error("Error fetching devices:", error);
    throw new Error("Failed to fetch devices");
  }
}
export async function POST(request) {
  return handler(await request.json());
}