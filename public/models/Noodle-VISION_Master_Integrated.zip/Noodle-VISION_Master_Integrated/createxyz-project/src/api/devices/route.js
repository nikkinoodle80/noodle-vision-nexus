async function handler() {
  try {
    const devices = await sql`
      SELECT * FROM devices
      ORDER BY name ASC
    `;

    return {
      success: true,
      devices: devices,
    };
  } catch (error) {
    console.error("Error fetching devices:", error);
    return {
      success: false,
      error: "Failed to fetch devices",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}