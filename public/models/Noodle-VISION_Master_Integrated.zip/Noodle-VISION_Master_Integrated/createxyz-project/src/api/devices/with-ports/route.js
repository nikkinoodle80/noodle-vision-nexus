async function handler({ deviceId }) {
  if (!deviceId) {
    return {
      success: false,
      error: "Device ID is required",
    };
  }

  try {
    const result = await sql`
      SELECT * FROM devices
      WHERE id = ${deviceId}
    `;

    if (result.length === 0) {
      return {
        success: false,
        error: "Device not found",
      };
    }

    const device = result[0];

    // If the device doesn't have port_layout data yet, generate some default ports
    if (!device.port_layout || Object.keys(device.port_layout).length === 0) {
      // Generate default ports based on device type
      const defaultPorts = generateDefaultPorts(device.type, device.ports);

      // Update the device with the generated ports
      await sql`
        UPDATE devices
        SET port_layout = ${defaultPorts}
        WHERE id = ${deviceId}
      `;

      device.port_layout = defaultPorts;
    }

    return {
      success: true,
      device,
    };
  } catch (error) {
    console.error("Error fetching device with ports:", error);
    return {
      success: false,
      error: "Failed to fetch device details",
    };
  }
}

// Helper function to generate default ports based on device type
function generateDefaultPorts(deviceType, portsData) {
  const ports =
    typeof portsData === "string" ? JSON.parse(portsData) : portsData;
  const defaultLayout = {
    positions: [],
  };

  // Create visual positions for each port
  let index = 0;
  for (const portType in ports) {
    const count = ports[portType];
    for (let i = 0; i < count; i++) {
      defaultLayout.positions.push({
        id: `${portType}_${i}`,
        type: portType,
        x: 50 + (index % 5) * 60,
        y: 50 + Math.floor(index / 5) * 60,
        label: `${portType} ${i + 1}`,
      });
      index++;
    }
  }

  return defaultLayout;
}
export async function POST(request) {
  return handler(await request.json());
}