async function handler({
  page = 1,
  limit = 20,
  type,
  brand,
  sortBy = "name",
  sortOrder = "asc",
}) {
  try {
    const offset = (page - 1) * limit;

    // Build the WHERE clause based on filters
    let whereClause = "";
    const queryParams = [];
    let paramCount = 1;

    if (type) {
      whereClause += `type = $${paramCount}`;
      queryParams.push(type);
      paramCount++;
    }

    if (brand) {
      if (whereClause) whereClause += " AND ";
      whereClause += `brand = $${paramCount}`;
      queryParams.push(brand);
      paramCount++;
    }

    if (whereClause) {
      whereClause = "WHERE " + whereClause;
    }

    // Validate sort parameters to prevent SQL injection
    const validSortColumns = [
      "name",
      "type",
      "brand",
      "created_at",
      "last_updated_at",
    ];
    const validSortOrders = ["asc", "desc"];

    const sanitizedSortBy = validSortColumns.includes(sortBy) ? sortBy : "name";
    const sanitizedSortOrder = validSortOrders.includes(sortOrder.toLowerCase())
      ? sortOrder
      : "asc";

    // Get total count for pagination
    const countQueryStr = `SELECT COUNT(*) FROM public.devices ${whereClause}`;
    const countResult = await sql(countQueryStr, queryParams);
    const totalCount = parseInt(countResult[0].count);

    // Get paginated results
    queryParams.push(limit, offset);
    const queryStr = `
      SELECT * FROM public.devices
      ${whereClause}
      ORDER BY ${sanitizedSortBy} ${sanitizedSortOrder}
      LIMIT $${paramCount} OFFSET $${paramCount + 1}
    `;

    const result = await sql(queryStr, queryParams);

    return {
      data: result,
      pagination: {
        total: totalCount,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(totalCount / limit),
      },
    };
  } catch (error) {
    console.error("Error in GetDevicesWithPagination:", error);
    return {
      error: `Failed to fetch devices: ${error.message}`,
      data: [],
      pagination: {
        total: 0,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: 0,
      },
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}