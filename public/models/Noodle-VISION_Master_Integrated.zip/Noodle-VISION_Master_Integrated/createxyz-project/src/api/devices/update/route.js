async function handler({ id, ...updateFields }) {
  try {
    if (!id) {
      return { error: "Device ID is required" };
    }

    // Validate that the device exists
    const checkResult = await sql(
      "SELECT id FROM public.devices WHERE id = $1",
      [id]
    );

    if (checkResult.length === 0) {
      return { error: `Device with ID ${id} not found` };
    }

    // If no update fields provided, return the existing device
    if (Object.keys(updateFields).length === 0) {
      const getResult = await sql(
        "SELECT * FROM public.devices WHERE id = $1",
        [id]
      );
      return { device: getResult[0], message: "No changes provided" };
    }

    // Build dynamic update query
    const validFields = [
      "name",
      "type",
      "brand",
      "model",
      "ports",
      "image_url",
      "port_layout",
      "category",
      "room_type",
      "is_wireless",
      "power_requirements",
      "typical_location",
      "is_vr_compatible",
      "vr_tracking_type",
      "vr_resolution",
      "vr_refresh_rate",
      "vr_field_of_view",
    ];

    // Filter out invalid fields
    const filteredUpdateFields = Object.entries(updateFields)
      .filter(([key]) => validFields.includes(key))
      .reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
      }, {});

    if (Object.keys(filteredUpdateFields).length === 0) {
      return { error: "No valid fields to update" };
    }

    // Build the SET clause and parameter array
    const setEntries = Object.entries(filteredUpdateFields);
    const setClauses = setEntries.map(
      (_, index) => `${setEntries[index][0]} = $${index + 2}`
    );
    const setClause = setClauses.join(", ");

    const queryParams = [id, ...setEntries.map((entry) => entry[1])];

    const updateQuery = `
      UPDATE public.devices 
      SET ${setClause} 
      WHERE id = $1 
      RETURNING *
    `;

    const result = await sql(updateQuery, queryParams);

    return {
      device: result[0],
      message: "Device updated successfully",
    };
  } catch (error) {
    console.error("Error in UpdateDevice:", error);
    return { error: `Failed to update device: ${error.message}` };
  }
}
export async function POST(request) {
  return handler(await request.json());
}