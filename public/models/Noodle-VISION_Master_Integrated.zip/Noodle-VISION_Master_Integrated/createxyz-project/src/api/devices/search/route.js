function handler({ term, deviceType, maxResults = 20 }) {
  try {
    // If no search term and no device type, return limited results
    if ((!term || term.length < 2) && !deviceType) {
      return { devices: [] };
    }

    let queryText = `
      SELECT id, name, brand, model, type, image_url, ports
      FROM devices
      WHERE 1=1
    `;

    const params = [];

    // Add search term condition if provided
    if (term && term.length >= 2) {
      params.push(`%${term}%`);
      queryText += ` AND (name ILIKE $${params.length} OR brand ILIKE $${params.length} OR model ILIKE $${params.length})`;
    }

    // Add device type filter if provided
    if (deviceType) {
      params.push(deviceType);
      queryText += ` AND type = $${params.length}`;
    }

    // Add ordering - prioritize matches in name if search term exists
    if (term && term.length >= 2) {
      queryText += `
        ORDER BY 
          CASE WHEN name ILIKE $${params.length + 1} THEN 1
               WHEN brand ILIKE $${params.length + 1} THEN 2
               ELSE 3 END,
          type, brand, name
      `;
      params.push(`%${term}%`);
    } else {
      queryText += ` ORDER BY type, brand, name`;
    }

    // Add limit
    params.push(maxResults);
    queryText += ` LIMIT $${params.length}`;

    const devices = sql(queryText, params);

    // If no results found, provide fallback options
    if (devices.length === 0 && (term || deviceType)) {
      let fallbackQueryText = `
        SELECT id, name, brand, model, type, image_url, ports
        FROM devices
      `;

      const fallbackParams = [];

      // If device type was specified, use it for fallback
      if (deviceType) {
        fallbackParams.push(deviceType);
        fallbackQueryText += ` WHERE type = $${fallbackParams.length}`;
      }

      fallbackQueryText += ` ORDER BY type, brand, name LIMIT $${
        fallbackParams.length + 1
      }`;
      fallbackParams.push(maxResults);

      const fallbackDevices = sql(fallbackQueryText, fallbackParams);

      return {
        devices: fallbackDevices,
        message: "Showing similar devices as no exact matches were found.",
      };
    }

    return {
      devices,
      message: `Found ${devices.length} device(s) matching your criteria.`,
    };
  } catch (error) {
    console.error("Error searching devices:", error);

    // Return some default devices even on error
    try {
      const fallbackDevices = sql(
        `
        SELECT id, name, brand, model, type, image_url, ports
        FROM devices
        ORDER BY type, brand, name
        LIMIT $1
      `,
        [maxResults]
      );

      return {
        devices: fallbackDevices,
        message:
          "There was an issue with your search, showing popular devices instead.",
        error: error.message,
      };
    } catch (fallbackError) {
      return {
        devices: [],
        error: "Failed to search devices",
      };
    }
  }
}
export async function POST(request) {
  return handler(await request.json());
}