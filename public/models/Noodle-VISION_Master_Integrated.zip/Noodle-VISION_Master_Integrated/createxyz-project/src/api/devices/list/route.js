function handler({ query }) {
  const {
    type,
    brand,
    search,
    category,
    connectionType,
    limit = 50,
    offset = 0,
  } = query || {};

  let queryText = `
    SELECT id, name, type, brand, model, ports, image_url
    FROM devices
    WHERE 1=1
  `;

  const params = [];

  if (type) {
    params.push(type);
    queryText += ` AND type = $${params.length}`;
  }

  if (brand) {
    params.push(brand);
    queryText += ` AND brand = $${params.length}`;
  }

  if (category) {
    params.push(category);
    queryText += ` AND type LIKE $${params.length}`;
  }

  if (connectionType) {
    params.push(`%"${connectionType}"%`);
    queryText += ` AND ports::text ILIKE $${params.length}`;
  }

  if (search) {
    params.push(`%${search}%`);
    queryText += ` AND (name ILIKE $${params.length} OR model ILIKE $${params.length})`;
  }

  let countQueryText = `
    SELECT COUNT(*) as total
    FROM devices
    WHERE 1=1
  `;

  if (type) {
    countQueryText += ` AND type = $${params.indexOf(type) + 1}`;
  }

  if (brand) {
    countQueryText += ` AND brand = $${params.indexOf(brand) + 1}`;
  }

  if (category) {
    countQueryText += ` AND type LIKE $${params.indexOf(category) + 1}`;
  }

  if (connectionType) {
    countQueryText += ` AND ports::text ILIKE $${
      params.indexOf(`%"${connectionType}"%`) + 1
    }`;
  }

  if (search) {
    countQueryText += ` AND (name ILIKE $${
      params.indexOf(`%${search}%`) + 1
    } OR model ILIKE $${params.indexOf(`%${search}%`) + 1})`;
  }

  const paginationParams = [...params];
  paginationParams.push(parseInt(limit), parseInt(offset));

  const finalQueryText =
    queryText +
    ` ORDER BY name ASC LIMIT $${paginationParams.length - 1} OFFSET $${
      paginationParams.length
    }`;

  try {
    const devices = sql(finalQueryText, paginationParams);

    const totalCount = sql(countQueryText, params);

    const categories = sql(
      "SELECT DISTINCT type FROM devices ORDER BY type ASC"
    );

    const brands = sql("SELECT DISTINCT brand FROM devices ORDER BY brand ASC");

    const connectionTypes = sql(
      "SELECT DISTINCT jsonb_object_keys(ports) as connection_type FROM devices"
    );

    return {
      devices,
      pagination: {
        total: totalCount[0]?.total || 0,
        limit: parseInt(limit),
        offset: parseInt(offset),
      },
      filters: {
        categories: categories.map((c) => c.type),
        brands: brands.map((b) => b.brand),
        connectionTypes: connectionTypes.map((c) => c.connection_type),
      },
    };
  } catch (error) {
    console.error("Error fetching devices:", error);
    return { error: "Failed to fetch devices", details: error.message };
  }
}
export async function POST(request) {
  return handler(await request.json());
}