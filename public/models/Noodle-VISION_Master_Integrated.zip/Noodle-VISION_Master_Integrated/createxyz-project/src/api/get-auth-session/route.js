async function handler({ sessionId }) {
  if (!sessionId) {
    return null;
  }

  const [authSession] = await sql("SELECT * FROM auth_sessions WHERE id = $1", [
    sessionId,
  ]);

  return authSession || null;
}
export async function POST(request) {
  return handler(await request.json());
}