async function handler({ filter = {}, page = 1, pageSize = 10 }) {
  const offset = (page - 1) * pageSize;
  const conditions = [];
  const values = [];

  if (filter.name) {
    conditions.push(`LOWER(name) LIKE LOWER($${conditions.length + 1})`);
    values.push(`%${filter.name}%`);
  }

  if (filter.category) {
    conditions.push(`category = $${conditions.length + 1}`);
    values.push(filter.category);
  }

  if (filter.isActive !== undefined) {
    conditions.push(`is_active = $${conditions.length + 1}`);
    values.push(filter.isActive);
  }

  const whereClause = conditions.length
    ? `WHERE ${conditions.join(" AND ")}`
    : "";
  const query = `
    SELECT * FROM products
    ${whereClause}
    ORDER BY id
    LIMIT $${conditions.length + 1} OFFSET $${conditions.length + 2}
  `;

  values.push(pageSize, offset);

  const products = await sql(query, values);
  return { products };
}
export async function POST(request) {
  return handler(await request.json());
}