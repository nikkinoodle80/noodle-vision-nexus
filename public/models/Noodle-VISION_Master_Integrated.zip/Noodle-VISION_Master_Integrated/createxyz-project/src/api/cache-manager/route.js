async function handler({ action, key, value, ttl = 3600 }) {
  if (!action || !key) {
    return { error: "Missing required parameters" };
  }

  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    switch (action) {
      case "set": {
        if (!value) {
          return { error: "Missing value parameter for set action" };
        }

        const expiresAt = new Date(Date.now() + ttl * 1000);

        await sql`
          INSERT INTO stored_urls (url, description, created_at)
          VALUES (${JSON.stringify(value)}, ${key}, ${expiresAt})
          ON CONFLICT (id) 
          WHERE description = ${key}
          DO UPDATE SET 
            url = ${JSON.stringify(value)},
            created_at = ${expiresAt}
        `;

        return { success: true };
      }

      case "get": {
        const result = await sql`
          SELECT url, created_at 
          FROM stored_urls 
          WHERE description = ${key}
        `;

        if (result.length === 0) {
          return { value: null };
        }

        const cache = result[0];
        const now = new Date();

        if (now > cache.created_at) {
          await sql`DELETE FROM stored_urls WHERE description = ${key}`;
          return { value: null };
        }

        return { value: JSON.parse(cache.url) };
      }

      case "delete": {
        await sql`DELETE FROM stored_urls WHERE description = ${key}`;
        return { success: true };
      }

      case "clear": {
        await sql`DELETE FROM stored_urls WHERE description LIKE ${key + "%"}`;
        return { success: true };
      }

      default:
        return { error: "Invalid action" };
    }
  } catch (error) {
    return { error: error.message };
  }
}
export async function POST(request) {
  return handler(await request.json());
}