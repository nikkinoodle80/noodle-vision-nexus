function handler() {
  try {
    const domains = sql`
      SELECT * FROM domains 
      WHERE is_active = true
      ORDER BY name
    `;

    return {
      success: true,
      domains,
    };
  } catch (error) {
    console.error("Error fetching domains:", error);
    return {
      success: false,
      error: "Failed to fetch domains",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}