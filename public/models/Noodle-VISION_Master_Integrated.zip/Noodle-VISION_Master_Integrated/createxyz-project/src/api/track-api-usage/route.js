async function handler({ apiType, requestType, tokensUsed = 0 }) {
  try {
    const session = getSession();

    if (!session || !session.user) {
      return {
        success: false,
        error: "Authentication required",
      };
    }

    const userId = session.user.id;

    await sql`
      INSERT INTO api_usage (user_id, api_type, request_type, tokens_used, created_at)
      VALUES (${userId}, ${apiType}, ${requestType}, ${tokensUsed}, NOW())
    `;

    await sql`
      UPDATE user_subscriptions
      SET api_calls_used = api_calls_used + 1,
          updated_at = NOW()
      WHERE user_id = ${userId}
    `;

    const subscriptionData = await sql`
      SELECT us.api_calls_used, sp.api_calls_limit
      FROM user_subscriptions us
      JOIN subscription_plans sp ON us.plan_id = sp.id
      WHERE us.user_id = ${userId}
    `;

    if (subscriptionData.length === 0) {
      return {
        success: true,
        message: "API usage tracked successfully",
        usage: {
          used: 0,
          limit: 0,
          percentage: 0,
        },
      };
    }

    const { api_calls_used, api_calls_limit } = subscriptionData[0];
    const usagePercentage =
      api_calls_limit > 0
        ? Math.min(100, Math.round((api_calls_used / api_calls_limit) * 100))
        : 0;

    return {
      success: true,
      message: "API usage tracked successfully",
      usage: {
        used: api_calls_used,
        limit: api_calls_limit,
        percentage: usagePercentage,
      },
    };
  } catch (error) {
    console.error("Error tracking API usage:", error);
    return {
      success: false,
      error: "Failed to track API usage",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}