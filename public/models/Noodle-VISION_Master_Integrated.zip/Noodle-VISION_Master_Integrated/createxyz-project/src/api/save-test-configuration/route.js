function handler({
  id,
  name,
  testSuites,
  environment = "development",
  schedule,
  isActive = true,
}) {
  try {
    const session = getSession();
    const userId = session?.user?.id;

    if (!userId) {
      return {
        success: false,
        error: "Authentication required",
      };
    }

    if (!name) {
      return {
        success: false,
        error: "Configuration name is required",
      };
    }

    if (!testSuites || !Array.isArray(testSuites) || testSuites.length === 0) {
      return {
        success: false,
        error: "At least one test suite must be selected",
      };
    }

    // Validate test suites
    const validTestSuites = [
      "all",
      "device-management",
      "adapter-compatibility",
      "user-inventory",
      "connection-builder",
    ];
    const invalidSuites = testSuites.filter(
      (suite) => !validTestSuites.includes(suite)
    );

    if (invalidSuites.length > 0) {
      return {
        success: false,
        error: `Invalid test suites: ${invalidSuites.join(
          ", "
        )}. Valid options are: ${validTestSuites.join(", ")}`,
      };
    }

    let result;

    // Update existing configuration or create a new one
    if (id) {
      // Check if the configuration exists and belongs to the user
      const existingConfig = sql`
        SELECT * FROM test_configurations WHERE id = ${id}
      `;

      if (existingConfig.length === 0) {
        return {
          success: false,
          error: `No configuration found with ID: ${id}`,
        };
      }

      if (existingConfig[0].user_id !== userId) {
        return {
          success: false,
          error: "You don't have permission to update this configuration",
        };
      }

      result = sql`
        UPDATE test_configurations
        SET 
          name = ${name},
          test_suites = ${testSuites},
          environment = ${environment},
          schedule = ${schedule},
          is_active = ${isActive},
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ${id}
        RETURNING *
      `;
    } else {
      result = sql`
        INSERT INTO test_configurations (
          name,
          test_suites,
          environment,
          schedule,
          is_active,
          user_id
        ) VALUES (
          ${name},
          ${testSuites},
          ${environment},
          ${schedule},
          ${isActive},
          ${userId}
        ) RETURNING *
      `;
    }

    return {
      success: true,
      configuration: result[0],
    };
  } catch (error) {
    console.error("Error saving test configuration:", error);
    return {
      success: false,
      error: `Failed to save test configuration: ${error.message}`,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}