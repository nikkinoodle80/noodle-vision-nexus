async function handler({ startPosition, endPosition }) {
  if (!startPosition || !endPosition) {
    return { error: "Start and end positions are required" };
  }

  const result = await sql(
    "INSERT INTO patch_connections (from_port, to_port) VALUES ($1, $2) RETURNING id",
    [startPosition, endPosition]
  );

  if (result.length > 0) {
    return { success: true, id: result[0].id };
  } else {
    return { error: "Failed to create cable connection" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}