function handler() {
  const session = getSession();

  if (!session || !session.user) {
    return {
      success: false,
      error: "User not authenticated",
    };
  }

  try {
    // Check if user_configurations table exists
    const tableCheck = sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'user_configurations'
      );
    `;

    // If table doesn't exist, create it
    if (!tableCheck[0].exists) {
      sql`
        CREATE TABLE public.user_configurations (
          id SERIAL PRIMARY KEY,
          user_id TEXT NOT NULL,
          name TEXT NOT NULL,
          devices JSON NOT NULL,
          adapters JSON NOT NULL,
          cables JSON NOT NULL,
          layout JSON,
          created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
      `;
    }

    // Get user's configurations
    const configurations = sql`
      SELECT * FROM user_configurations
      WHERE user_id = ${session.user.id}
      ORDER BY created_at DESC
    `;

    return {
      success: true,
      configurations,
    };
  } catch (error) {
    console.error("Error fetching user configurations:", error);
    return {
      success: false,
      error: "Failed to fetch configurations",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}