async function handler({ tier, price, features, paymentMethod, userId }) {
  if (!tier || !price) {
    return { error: "Tier name and price are required" };
  }

  if (typeof price !== "number" || price <= 0) {
    return { error: "Price must be a positive number" };
  }

  if (
    !["basic", "standard", "premium", "enterprise"].includes(tier.toLowerCase())
  ) {
    return {
      error:
        "Invalid subscription tier. Must be one of: basic, standard, premium, enterprise",
    };
  }

  if (!features || !Array.isArray(features)) {
    features = [];
  }

  if (!paymentMethod) {
    return { error: "Payment method is required" };
  }

  try {
    let paymentResult;
    try {
      const response = await fetch("/api/process-subscription-payment", {
        method: "POST",
        body: JSON.stringify({
          amount: price,
          paymentMethod,
          description: `Subscription: ${tier}`,
        }),
        headers: {
          "Content-Type": "application/json",
        },
      });

      paymentResult = await response.json();

      if (!paymentResult.success) {
        return {
          error: "Payment processing failed",
          details: paymentResult.error,
        };
      }
    } catch (paymentError) {
      return {
        error: "Payment processing error",
        details: paymentError.message,
      };
    }

    const session = getSession();
    const actualUserId = userId || session?.user?.id;

    const featuresString = Array.isArray(features)
      ? features.join(", ")
      : features;

    const result = await sql(
      "INSERT INTO subscriptions (tier, price, features) VALUES ($1, $2, $3) RETURNING *",
      [tier, price, featuresString]
    );

    if (actualUserId) {
      await sql(
        "INSERT INTO user_upgrades (user_id, upgrade_type, configuration) VALUES ($1, $2, $3)",
        [
          actualUserId,
          "subscription",
          JSON.stringify({
            subscription_id: result[0].id,
            payment_id: paymentResult.paymentId,
            activated_at: new Date().toISOString(),
          }),
        ]
      );
    }

    return {
      success: true,
      message: "Subscription tier added successfully",
      subscription: result[0],
      paymentConfirmation: paymentResult.confirmationCode,
    };
  } catch (error) {
    if (error.code === "23505") {
      return { error: "A subscription with this tier already exists" };
    }

    if (error.code === "23503") {
      return { error: "Referenced user does not exist" };
    }

    return {
      error: "An error occurred while adding the subscription tier",
      details: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}