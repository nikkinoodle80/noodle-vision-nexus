function handler() {
  const session = getSession();
  if (!session || !session.user) {
    return { error: "Unauthorized" };
  }

  const userId = session.user.id;

  try {
    const result = sql`
      SELECT 
        test_secret_key as "testSecretKey",
        live_secret_key as "liveSecretKey",
        test_webhook_secret as "testWebhookSecret",
        live_webhook_secret as "liveWebhookSecret",
        test_webhook_url as "testWebhookUrl",
        live_webhook_url as "liveWebhookUrl",
        basic_price_id as "basicPriceId",
        pro_price_id as "proPriceId",
        enterprise_price_id as "enterprisePriceId",
        is_test_mode as "isTestMode"
      FROM stripe_configuration 
      WHERE user_id = ${userId}
    `;

    if (result.length === 0) {
      return {
        exists: false,
        message: "No Stripe configuration found",
      };
    }

    const config = result[0];
    const isTestMode = config.isTestMode;

    return {
      exists: true,
      secretKey: isTestMode ? config.testSecretKey : config.liveSecretKey,
      webhookSecret: isTestMode
        ? config.testWebhookSecret
        : config.liveWebhookSecret,
      webhookUrl: isTestMode ? config.testWebhookUrl : config.liveWebhookUrl,
      basicPriceId: config.basicPriceId,
      proPriceId: config.proPriceId,
      enterprisePriceId: config.enterprisePriceId,
      isTestMode: isTestMode,
    };
  } catch (error) {
    console.error("Error retrieving active Stripe keys:", error);
    return {
      error: "Failed to retrieve active Stripe keys",
      details: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}