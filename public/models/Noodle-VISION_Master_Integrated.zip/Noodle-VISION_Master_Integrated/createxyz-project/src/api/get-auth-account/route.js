async function handler({ id }) {
  if (!id) {
    return null;
  }

  const [authAccount] = await sql`SELECT * FROM auth_accounts WHERE id = ${id}`;
  return authAccount || null;
}
export async function POST(request) {
  return handler(await request.json());
}