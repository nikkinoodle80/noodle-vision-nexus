function handler({
  inputType,
  outputType,
  brand,
  search,
  limit = 50,
  offset = 0,
}) {
  try {
    // Build query parameters and conditions
    let queryParams = [];
    let conditions = [];

    if (inputType) {
      queryParams.push(inputType);
      conditions.push(`input_type = $${queryParams.length}`);
    }

    if (outputType) {
      queryParams.push(outputType);
      conditions.push(`output_type = $${queryParams.length}`);
    }

    if (brand) {
      queryParams.push(brand);
      conditions.push(`brand = $${queryParams.length}`);
    }

    if (search) {
      queryParams.push(`%${search}%`);
      conditions.push(
        `(name ILIKE $${queryParams.length} OR model ILIKE $${queryParams.length})`
      );
    }

    // Build the WHERE clause
    const whereClause =
      conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";

    // Add pagination parameters
    queryParams.push(parseInt(limit), parseInt(offset));

    // Construct the final query
    const query = `
      SELECT id, name, input_type, output_type, brand, model, 
             requires_power, max_resolution, supports_audio, price_range, image_url
      FROM adapter_types
      ${whereClause}
      ORDER BY name ASC 
      LIMIT $${queryParams.length - 1} 
      OFFSET $${queryParams.length}
    `;

    // Execute the query
    const adapters = sql(query, queryParams);

    return { adapters };
  } catch (error) {
    console.error("Error fetching adapter types:", error);
    return { error: "Failed to fetch adapter types" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}