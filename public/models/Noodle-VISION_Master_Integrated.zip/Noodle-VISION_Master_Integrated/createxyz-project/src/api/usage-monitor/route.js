async function handler({ endpoint, method }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  const userId = session.user.id;
  const timestamp = new Date().toISOString();

  // Get user's subscription tier
  const subscription = await sql`
    SELECT plan_type, status 
    FROM user_subscriptions 
    WHERE user_id = ${userId} 
    AND status = 'active'
  `;

  // Default to basic tier limits if no subscription found
  const tier = subscription?.[0]?.plan_type || "basic";
  const limits = {
    basic: 100,
    pro: 1000,
    enterprise: 10000,
  };

  // Count today's requests
  const today = new Date().toISOString().split("T")[0];
  const dailyUsage = await sql`
    SELECT COUNT(*) 
    FROM security_audit_logs 
    WHERE user_id = ${userId} 
    AND action = 'api_request' 
    AND created_at::date = ${today}::date
  `;

  const currentUsage = parseInt(dailyUsage[0]?.count || "0");
  const tierLimit = limits[tier];

  // Log the API request
  await sql`
    INSERT INTO security_audit_logs (user_id, action, details)
    VALUES (
      ${userId},
      'api_request',
      ${JSON.stringify({
        endpoint,
        method,
        timestamp,
        tier,
        currentUsage,
      })}
    )
  `;

  // Check if user has exceeded their tier limit
  if (currentUsage >= tierLimit) {
    return {
      error: "Rate limit exceeded",
      tier,
      limit: tierLimit,
      usage: currentUsage,
    };
  }

  // Generate usage report
  const usageStats = await sql`
    SELECT 
      COUNT(*) as total_requests,
      COUNT(DISTINCT DATE(created_at)) as active_days
    FROM security_audit_logs
    WHERE user_id = ${userId}
    AND action = 'api_request'
    AND created_at >= NOW() - INTERVAL '30 days'
  `;

  return {
    success: true,
    usage: {
      today: currentUsage,
      limit: tierLimit,
      tier,
      thirtyDayTotal: parseInt(usageStats[0]?.total_requests || "0"),
      activeDays: parseInt(usageStats[0]?.active_days || "0"),
    },
  };
}
export async function POST(request) {
  return handler(await request.json());
}