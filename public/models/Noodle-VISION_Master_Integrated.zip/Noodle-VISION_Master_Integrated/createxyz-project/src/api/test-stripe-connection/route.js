function handler({
  testMode = true,
  verifyWebhooks = true,
  testBuyButton = true,
  priceId,
}) {
  const session = getSession();

  if (!session || !session.user) {
    throw new Error("Authentication required to test Stripe connection");
  }

  try {
    const stripeApiKey = testMode
      ? process.env.STRIPE_TEST_SECRET_KEY
      : process.env.STRIPE_LIVE_SECRET_KEY;

    if (!stripeApiKey) {
      throw new Error(
        `Stripe ${testMode ? "test" : "live"} API key is not configured`
      );
    }

    const results = {
      success: false,
      apiConnection: false,
      webhookStatus: null,
      buyButtonStatus: null,
      errors: [],
      timestamp: new Date().toISOString(),
    };

    return testStripeConnection().then(async (apiResult) => {
      results.apiConnection = apiResult.success;

      if (!apiResult.success) {
        results.errors.push(`API Connection Error: ${apiResult.error}`);
        return results;
      }

      const testPromises = [];

      if (verifyWebhooks) {
        testPromises.push(
          testWebhooks().then((webhookResult) => {
            results.webhookStatus = webhookResult;
            if (!webhookResult.success) {
              results.errors.push(`Webhook Error: ${webhookResult.error}`);
            }
          })
        );
      }

      if (testBuyButton) {
        if (!priceId) {
          results.errors.push(
            "Buy Button Test Error: priceId is required for buy button testing"
          );
          results.buyButtonStatus = {
            success: false,
            error: "Missing priceId parameter",
          };
        } else {
          testPromises.push(
            testBuyButtonFlow(priceId).then((buttonResult) => {
              results.buyButtonStatus = buttonResult;
              if (!buttonResult.success) {
                results.errors.push(`Buy Button Error: ${buttonResult.error}`);
              }
            })
          );
        }
      }

      await Promise.all(testPromises);

      results.success = results.errors.length === 0;

      await logTestResults(results);

      return results;
    });
  } catch (error) {
    console.error("Error testing Stripe connection:", error);
    return {
      success: false,
      error: `Failed to test Stripe connection: ${error.message}`,
      timestamp: new Date().toISOString(),
    };
  }

  async function testStripeConnection() {
    try {
      const response = await fetch("https://api.stripe.com/v1/balance", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${stripeApiKey}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
      });

      const data = await response.json();

      if (response.ok) {
        return {
          success: true,
          balance: data.available,
          accountType: testMode ? "test" : "live",
        };
      } else {
        return {
          success: false,
          error: data.error?.message || "Unknown API error",
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error.message,
      };
    }
  }

  async function testWebhooks() {
    try {
      const webhookEndpointUrl = testMode
        ? process.env.STRIPE_TEST_WEBHOOK_URL
        : process.env.STRIPE_LIVE_WEBHOOK_URL;

      const webhookSecret = testMode
        ? process.env.STRIPE_TEST_WEBHOOK_SECRET
        : process.env.STRIPE_LIVE_WEBHOOK_SECRET;

      if (!webhookEndpointUrl || !webhookSecret) {
        return {
          success: false,
          error: "Webhook URL or secret not configured",
          configured: false,
        };
      }

      const response = await fetch(
        "https://api.stripe.com/v1/webhook_endpoints",
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${stripeApiKey}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: data.error?.message || "Failed to retrieve webhooks",
          configured: false,
        };
      }

      const configuredEndpoint = data.data.find((endpoint) =>
        endpoint.url.includes(webhookEndpointUrl)
      );

      if (!configuredEndpoint) {
        return {
          success: false,
          error: "Webhook endpoint not found in Stripe configuration",
          configured: false,
        };
      }

      const requiredEvents = [
        "customer.subscription.created",
        "customer.subscription.updated",
        "customer.subscription.deleted",
        "checkout.session.completed",
      ];

      const missingEvents = requiredEvents.filter(
        (event) =>
          !configuredEndpoint.enabled_events.includes(event) &&
          !configuredEndpoint.enabled_events.includes("*")
      );

      if (missingEvents.length > 0) {
        return {
          success: false,
          error: `Missing required webhook events: ${missingEvents.join(", ")}`,
          configured: true,
          missingEvents,
        };
      }

      return {
        success: true,
        configured: true,
        endpoint: configuredEndpoint.url,
        enabledEvents: configuredEndpoint.enabled_events,
      };
    } catch (error) {
      return {
        success: false,
        error: error.message,
        configured: false,
      };
    }
  }

  async function testBuyButtonFlow(priceId) {
    try {
      const sessionParams = new URLSearchParams();
      sessionParams.append("success_url", "https://example.com/success");
      sessionParams.append("cancel_url", "https://example.com/cancel");
      sessionParams.append("mode", "subscription");
      sessionParams.append("line_items[0][price]", priceId);
      sessionParams.append("line_items[0][quantity]", "1");

      const response = await fetch(
        "https://api.stripe.com/v1/checkout/sessions",
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${stripeApiKey}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: sessionParams,
        }
      );

      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: data.error?.message || "Failed to create checkout session",
          priceId,
        };
      }

      return {
        success: true,
        checkoutSessionId: data.id,
        checkoutUrl: data.url,
        priceId,
      };
    } catch (error) {
      return {
        success: false,
        error: error.message,
        priceId,
      };
    }
  }

  async function logTestResults(results) {
    try {
      await sql.transaction(async (txn) => {
        await txn(
          "INSERT INTO stripe_test_logs (user_id, test_mode, success, api_connection, webhook_status, buy_button_status, errors, created_at) VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP)",
          [
            session.user.id,
            testMode,
            results.success,
            results.apiConnection,
            JSON.stringify(results.webhookStatus),
            JSON.stringify(results.buyButtonStatus),
            JSON.stringify(results.errors),
          ]
        );
      });
    } catch (error) {
      console.error("Failed to log Stripe test results:", error);
    }
  }
}
export async function POST(request) {
  return handler(await request.json());
}