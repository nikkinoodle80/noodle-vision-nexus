async function handler({ setupId, deviceIds, roomDimensions }) {
  try {
    let devices = [];

    // Fetch devices with a single query based on input
    if (setupId) {
      const setupDevicesResult = await sql`
        SELECT d.* 
        FROM devices d
        JOIN setup_devices sd ON d.id = sd.device_id
        WHERE sd.setup_id = ${setupId}
      `;
      devices = setupDevicesResult;
    } else if (deviceIds && deviceIds.length > 0) {
      devices = await sql`SELECT * FROM devices WHERE id IN ${sql(deviceIds)}`;
    }

    if (devices.length === 0) {
      return { error: "No devices found to analyze" };
    }

    // Filter devices locally instead of additional queries
    const vrHeadsets = devices.filter(
      (d) =>
        d.type === "vr_headset" ||
        (d.is_vr_compatible && d.category === "display")
    );

    const vrComputers = devices.filter(
      (d) =>
        (d.type === "computer" || d.type === "console") && d.is_vr_compatible
    );

    const neededAdapters = [];
    const missingComponents = [];
    let isCompatible = vrHeadsets.length > 0 && vrComputers.length > 0;

    // Check connection compatibility only if we have both headset and computer
    if (isCompatible) {
      const headset = vrHeadsets[0];
      const computer = vrComputers[0];

      // Optimize adapter query by extracting port information first
      const computerPorts = await sql`
        SELECT ports->'outputs' as outputs FROM devices WHERE id = ${computer.id}
      `;

      const headsetPorts = await sql`
        SELECT ports->'inputs' as inputs FROM devices WHERE id = ${headset.id}
      `;

      if (computerPorts.length > 0 && headsetPorts.length > 0) {
        // Build query parameters for adapter search
        const queryParams = [];
        let queryStr = `
          SELECT * FROM adapter_types 
          WHERE input_type IN (
            SELECT jsonb_array_elements_text($1)
          )
          AND output_type IN (
            SELECT jsonb_array_elements_text($2)
          )
        `;

        queryParams.push(computerPorts[0].outputs);
        queryParams.push(headsetPorts[0].inputs);

        const adaptersResult = await sql(queryStr, queryParams);

        if (adaptersResult.length === 0 && !headset.is_wireless) {
          isCompatible = false;

          // Find potential adapters with a single optimized query
          const potentialAdaptersResult = await sql(
            `
            SELECT * FROM adapter_types 
            WHERE input_type IN (SELECT jsonb_array_elements_text($1))
            OR output_type IN (SELECT jsonb_array_elements_text($2))
          `,
            [computerPorts[0].outputs, headsetPorts[0].inputs]
          );

          neededAdapters.push(...potentialAdaptersResult);
        }
      }
    } else {
      // Identify missing components
      if (vrHeadsets.length === 0) missingComponents.push("VR Headset");
      if (vrComputers.length === 0)
        missingComponents.push("VR-capable computer or console");
    }

    // Check space requirements if provided
    let spaceCompatible = true;
    let spaceRecommendations = [];

    if (roomDimensions && vrHeadsets.length > 0) {
      const headset = vrHeadsets[0];

      // Simplify space requirements query
      const spaceRequirementsResult = await sql`
        SELECT min_width_feet, min_length_feet, min_height_feet 
        FROM vr_space_requirements 
        WHERE setup_id IN (
          SELECT setup_id FROM setup_devices WHERE device_id = ${headset.id}
        )
        LIMIT 1
      `;

      // Default values
      let minWidth = 6.5,
        minLength = 6.5,
        minHeight = 6.5;

      if (spaceRequirementsResult.length > 0) {
        const req = spaceRequirementsResult[0];
        minWidth = req.min_width_feet;
        minLength = req.min_length_feet;
        minHeight = req.min_height_feet;
      }

      if (
        roomDimensions.width < minWidth ||
        roomDimensions.length < minLength ||
        roomDimensions.height < minHeight
      ) {
        spaceCompatible = false;
        spaceRecommendations.push(
          `Your room dimensions (${roomDimensions.width}' × ${roomDimensions.length}' × ${roomDimensions.height}') ` +
            `are smaller than the recommended minimum (${minWidth}' × ${minLength}' × ${minHeight}') for optimal VR experience.`
        );
      }
    }

    // Get compatibility issues with a single query
    const deviceIds = devices.map((d) => d.id);
    const compatibilityIssues = await sql`
      SELECT * FROM vr_compatibility_issues 
      WHERE device_id IN ${sql(deviceIds)}
    `;

    // Generate recommendations
    const recommendations = [];

    if (!isCompatible) {
      if (missingComponents.length > 0) {
        recommendations.push(
          `You need the following components: ${missingComponents.join(", ")}`
        );
      }

      if (neededAdapters.length > 0) {
        recommendations.push(
          "You need the following adapters to connect your devices:"
        );
        neededAdapters.forEach((adapter) => {
          recommendations.push(
            `- ${adapter.name} (${adapter.input_type} to ${adapter.output_type})`
          );
        });
      }
    }

    if (!spaceCompatible) {
      recommendations.push(...spaceRecommendations);
    }

    if (compatibilityIssues.length > 0) {
      recommendations.push("Known compatibility issues with your setup:");
      compatibilityIssues.forEach((issue) => {
        recommendations.push(
          `- ${issue.description} (${
            issue.solution || "No solution available"
          })`
        );
      });
    }

    return {
      isCompatible: isCompatible && spaceCompatible,
      vrHeadsets,
      vrComputers,
      neededAdapters,
      missingComponents,
      spaceCompatible,
      recommendations,
      compatibilityIssues,
    };
  } catch (error) {
    console.error("Error analyzing VR compatibility:", error);
    return {
      error: "Failed to analyze VR compatibility",
      details: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}