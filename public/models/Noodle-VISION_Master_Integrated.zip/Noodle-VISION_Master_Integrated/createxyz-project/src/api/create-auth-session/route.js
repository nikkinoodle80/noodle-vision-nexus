async function handler({ userId, expires, sessionToken }) {
  const result = await sql(
    'INSERT INTO auth_sessions ("userId", expires, "sessionToken") VALUES ($1, $2, $3) RETURNING *',
    [userId, expires, sessionToken]
  );
  return result[0] || null;
}
export async function POST(request) {
  return handler(await request.json());
}