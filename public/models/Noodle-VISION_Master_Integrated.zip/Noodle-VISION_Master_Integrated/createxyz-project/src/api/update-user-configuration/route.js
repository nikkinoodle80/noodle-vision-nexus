async function handler({
  configurationId,
  name,
  devices,
  connections,
  layout,
}) {
  const session = getSession();

  if (!session) {
    return { error: "User not authenticated" };
  }

  const userId = session.user?.id;
  if (!userId) {
    return { error: "User ID not found" };
  }

  const fieldsToUpdate = [];
  const values = [];
  let paramCount = 1;

  if (name) {
    fieldsToUpdate.push(`name = $${paramCount++}`);
    values.push(name);
  }
  if (devices) {
    fieldsToUpdate.push(`devices = $${paramCount++}`);
    values.push(devices);
  }
  if (connections) {
    fieldsToUpdate.push(`connections = $${paramCount++}`);
    values.push(connections);
  }
  if (layout) {
    fieldsToUpdate.push(`layout = $${paramCount++}`);
    values.push(layout);
  }

  if (fieldsToUpdate.length === 0) {
    return { error: "No fields to update" };
  }

  values.push(configurationId, userId);

  try {
    await sql(
      `UPDATE user_saved_setups SET ${fieldsToUpdate.join(
        ", "
      )} WHERE id = $${paramCount++} AND user_id = $${paramCount}`,
      values
    );

    return { success: true, configurationId };
  } catch (error) {
    return { error: "Failed to update configuration", details: error.message };
  }
}
export async function POST(request) {
  return handler(await request.json());
}