async function handler({ adapterId, fieldsToUpdate }) {
  if (
    !adapterId ||
    !fieldsToUpdate ||
    Object.keys(fieldsToUpdate).length === 0
  ) {
    return null;
  }

  const setClauses = [];
  const values = [];
  let paramCount = 1;

  for (const [key, value] of Object.entries(fieldsToUpdate)) {
    setClauses.push(`${key} = $${paramCount}`);
    values.push(value);
    paramCount++;
  }

  const query = `
    UPDATE adapters
    SET ${setClauses.join(", ")}
    WHERE id = $${paramCount}
    RETURNING *
  `;

  values.push(adapterId);

  const [updatedAdapter] = await sql(query, values);

  return updatedAdapter || null;
}
export async function POST(request) {
  return handler(await request.json());
}