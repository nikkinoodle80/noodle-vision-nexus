function handler({ id }) {
  try {
    const session = getSession();
    const userId = session?.user?.id;

    if (!userId) {
      return {
        success: false,
        error: "Authentication required",
      };
    }

    if (!id) {
      return {
        success: false,
        error: "Configuration ID is required",
      };
    }

    // Check if the configuration exists and belongs to the user
    const existingConfig = sql`
      SELECT * FROM test_configurations WHERE id = ${id}
    `;

    if (existingConfig.length === 0) {
      return {
        success: false,
        error: `No configuration found with ID: ${id}`,
      };
    }

    if (existingConfig[0].user_id !== userId) {
      return {
        success: false,
        error: "You don't have permission to delete this configuration",
      };
    }

    // Delete the configuration
    sql`DELETE FROM test_configurations WHERE id = ${id}`;

    return {
      success: true,
      message: "Configuration deleted successfully",
    };
  } catch (error) {
    console.error("Error deleting test configuration:", error);
    return {
      success: false,
      error: `Failed to delete test configuration: ${error.message}`,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}