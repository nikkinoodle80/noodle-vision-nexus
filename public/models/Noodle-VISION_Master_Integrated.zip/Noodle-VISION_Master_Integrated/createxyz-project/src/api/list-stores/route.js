async function handler() {
  try {
    const stores = await sql`SELECT * FROM stores`;
    return { stores };
  } catch (error) {
    return { error: "An error occurred while fetching the stores" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}