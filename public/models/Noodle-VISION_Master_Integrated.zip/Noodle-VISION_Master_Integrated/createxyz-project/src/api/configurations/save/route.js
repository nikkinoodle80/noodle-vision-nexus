function handler({
  name,
  description,
  sourceDeviceId,
  targetDeviceId,
  adapters,
  isPublic = false,
  notes = "",
}) {
  const session = getSession();
  if (!session || !session.user) {
    return { error: "Authentication required" };
  }

  const userId = session.user.id;

  if (
    !name ||
    !sourceDeviceId ||
    !targetDeviceId ||
    !adapters ||
    !Array.isArray(adapters)
  ) {
    return { error: "Missing required fields" };
  }

  try {
    // Start a transaction
    return sql
      .transaction(async (txn) => {
        // Insert the configuration
        const configResult = await txn`
        INSERT INTO user_configurations 
        (user_id, name, description, source_device_id, target_device_id, is_public, notes)
        VALUES (${userId}, ${name}, ${description}, ${sourceDeviceId}, ${targetDeviceId}, ${isPublic}, ${notes})
        RETURNING id
      `;

        const configId = configResult[0].id;

        // Insert the adapters
        for (let i = 0; i < adapters.length; i++) {
          const adapter = adapters[i];
          await txn`
          INSERT INTO configuration_adapters
          (configuration_id, adapter_type_id, position, notes)
          VALUES (${configId}, ${adapter.adapterTypeId}, ${i}, ${
            adapter.notes || null
          })
        `;
        }

        return {
          success: true,
          configurationId: configId,
          message: "Configuration saved successfully",
        };
      })
      .catch((error) => {
        console.error("Error saving configuration:", error);
        return { error: "Failed to save configuration" };
      });
  } catch (error) {
    console.error("Error in transaction setup:", error);
    return { error: "Failed to save configuration" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}