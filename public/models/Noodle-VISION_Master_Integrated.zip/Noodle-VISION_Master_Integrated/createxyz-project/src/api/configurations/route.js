async function handler() {
  const session = getSession();
  const userId = session?.user?.id;

  if (!userId) {
    return {
      success: false,
      error: "You must be logged in to view your configurations",
    };
  }

  try {
    const configurations = await sql`
      SELECT 
        uc.id, 
        uc.name, 
        uc.description, 
        uc.is_public, 
        uc.notes,
        uc.created_at,
        uc.updated_at,
        sd.name as source_device_name,
        td.name as target_device_name,
        sd.image_url as source_device_image,
        td.image_url as target_device_image,
        (SELECT COUNT(*) FROM configuration_adapters WHERE configuration_id = uc.id) as adapter_count
      FROM user_configurations uc
      JOIN devices sd ON uc.source_device_id = sd.id
      JOIN devices td ON uc.target_device_id = td.id
      WHERE uc.user_id = ${userId}
      ORDER BY uc.updated_at DESC
    `;

    return {
      success: true,
      configurations: configurations,
    };
  } catch (error) {
    console.error("Error fetching configurations:", error);
    return {
      success: false,
      error: "Failed to fetch configurations",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}