async function handler({ includePublic = true, limit = 50, offset = 0 }) {
  const session = getSession();

  let query;
  let params = [];

  if (session && session.user) {
    if (includePublic === "true" || includePublic === true) {
      query = `
        SELECT c.*, u.name as user_name, u.email as user_email,
               sd.name as source_device_name, td.name as target_device_name,
               (SELECT COUNT(*) FROM configuration_adapters WHERE configuration_id = c.id) as adapter_count
        FROM user_configurations c
        JOIN auth_users u ON c.user_id = u.id
        JOIN devices sd ON c.source_device_id = sd.id
        JOIN devices td ON c.target_device_id = td.id
        WHERE c.user_id = $1 OR c.is_public = true
        ORDER BY c.created_at DESC
        LIMIT $2 OFFSET $3
      `;
      params = [session.user.id, parseInt(limit), parseInt(offset)];
    } else {
      query = `
        SELECT c.*, u.name as user_name, u.email as user_email,
               sd.name as source_device_name, td.name as target_device_name,
               (SELECT COUNT(*) FROM configuration_adapters WHERE configuration_id = c.id) as adapter_count
        FROM user_configurations c
        JOIN auth_users u ON c.user_id = u.id
        JOIN devices sd ON c.source_device_id = sd.id
        JOIN devices td ON c.target_device_id = td.id
        WHERE c.user_id = $1
        ORDER BY c.created_at DESC
        LIMIT $2 OFFSET $3
      `;
      params = [session.user.id, parseInt(limit), parseInt(offset)];
    }
  } else {
    query = `
      SELECT c.*, u.name as user_name, u.email as user_email,
             sd.name as source_device_name, td.name as target_device_name,
             (SELECT COUNT(*) FROM configuration_adapters WHERE configuration_id = c.id) as adapter_count
      FROM user_configurations c
      JOIN auth_users u ON c.user_id = u.id
      JOIN devices sd ON c.source_device_id = sd.id
      JOIN devices td ON c.target_device_id = td.id
      WHERE c.is_public = true
      ORDER BY c.created_at DESC
      LIMIT $1 OFFSET $2
    `;
    params = [parseInt(limit), parseInt(offset)];
  }

  try {
    const configurations = await sql(query, params);
    return { configurations };
  } catch (error) {
    console.error("Error fetching configurations:", error);
    return { error: "Failed to fetch configurations" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}