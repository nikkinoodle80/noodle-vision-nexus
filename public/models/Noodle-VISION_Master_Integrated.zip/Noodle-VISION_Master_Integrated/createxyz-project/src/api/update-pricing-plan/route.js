async function handler({ id, name, price, features, buttonIds }) {
  if (!id) {
    return { error: "Pricing plan ID is required" };
  }

  const updates = [];
  const values = [];
  let paramCount = 1;

  if (name !== undefined) {
    updates.push(`name = $${paramCount++}`);
    values.push(name);
  }
  if (price !== undefined) {
    updates.push(`price = $${paramCount++}`);
    values.push(price);
  }
  if (features !== undefined) {
    updates.push(`features = $${paramCount++}`);
    values.push(features);
  }
  if (buttonIds !== undefined) {
    updates.push(`button_ids = $${paramCount++}`);
    values.push(buttonIds);
  }

  if (updates.length === 0) {
    return { error: "No fields to update" };
  }

  values.push(id);
  const query = `UPDATE pricing_plans SET ${updates.join(
    ", "
  )} WHERE id = $${paramCount}`;

  await sql(query, values);

  return { success: true };
}
export async function POST(request) {
  return handler(await request.json());
}