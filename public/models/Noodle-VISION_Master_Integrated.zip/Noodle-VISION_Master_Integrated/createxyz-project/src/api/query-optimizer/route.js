async function handler({ query, analyze = false }) {
  if (!query) {
    return { error: "Query is required" };
  }

  try {
    const startTime = Date.now();

    const queryResult = await sql(query);

    const executionTime = Date.now() - startTime;

    await sql(
      `
      INSERT INTO test_results 
      (test_suite, environment, success, total_tests, passed_tests, failed_tests, 
       skipped_tests, duration, details)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
    `,
      [
        "query_optimization",
        "production",
        true,
        1,
        1,
        0,
        0,
        `${executionTime}ms`,
        JSON.stringify({
          query,
          rowCount: queryResult.length,
          executionTime,
          timestamp: new Date().toISOString(),
        }),
      ]
    );

    if (!analyze) {
      return {
        result: queryResult,
        metrics: {
          executionTime,
          rowCount: queryResult.length,
        },
      };
    }

    const explainResult = await sql(`EXPLAIN ANALYZE ${query}`);

    const suggestions = [];
    const explainPlan = explainResult[0]["QUERY PLAN"];

    if (explainPlan.includes("Seq Scan")) {
      suggestions.push("Consider adding an index to improve query performance");
    }

    if (explainPlan.includes("Hash Join")) {
      suggestions.push(
        "Review join conditions and ensure proper indexes exist on joined columns"
      );
    }

    if (executionTime > 1000) {
      suggestions.push(
        "Query execution time exceeds 1 second - consider optimization"
      );
    }

    return {
      result: queryResult,
      metrics: {
        executionTime,
        rowCount: queryResult.length,
        explainPlan,
      },
      suggestions,
    };
  } catch (error) {
    await sql(
      `
      INSERT INTO test_results 
      (test_suite, environment, success, total_tests, passed_tests, failed_tests, 
       skipped_tests, duration, details)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
    `,
      [
        "query_optimization",
        "production",
        false,
        1,
        0,
        1,
        0,
        "0ms",
        JSON.stringify({
          query,
          error: error.message,
          timestamp: new Date().toISOString(),
        }),
      ]
    );

    return { error: error.message };
  }
}
export async function POST(request) {
  return handler(await request.json());
}