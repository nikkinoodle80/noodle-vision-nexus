async function handler({ query, category }) {
  if (!query && !category) {
    return {
      error: "Please provide a search query or category",
    };
  }

  try {
    let results = {};

    // If we have a direct category filter, we can skip the AI analysis
    if (category) {
      if (category === "device" || category === "all") {
        const devices = await sql(
          `
          SELECT id, name, category, description, image_url, input_ports, output_ports
          FROM devices 
          WHERE name ILIKE $1 OR description ILIKE $1
          ORDER BY name ASC
        `,
          [`%${query || ""}%`]
        );

        results.devices = devices;
      }

      if (category === "adapter" || category === "all") {
        const adapters = await sql(
          `
          SELECT id, name, input_type, output_type, description, image_url
          FROM adapters 
          WHERE name ILIKE $1 OR description ILIKE $1
          ORDER BY name ASC
        `,
          [`%${query || ""}%`]
        );

        results.adapters = adapters;
      }

      if (category === "cable" || category === "all") {
        const cables = await sql(
          `
          SELECT id, name, connector_type_a, connector_type_b, description, image_url
          FROM cables 
          WHERE name ILIKE $1 OR description ILIKE $1
          ORDER BY name ASC
        `,
          [`%${query || ""}%`]
        );

        results.cables = cables;
      }

      return {
        query,
        category,
        results,
      };
    }

    // If no category specified, use AI to analyze the query
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-3-sonnet-20240229",
        max_tokens: 1000,
        messages: [
          {
            role: "user",
            content: `I'm searching for hardware devices, adapters, or cables. My query is: "${query}"
            
            Please analyze my query and return a JSON object with:
            1. The likely category (device, adapter, cable, or all)
            2. Specific search terms to use
            3. Any identified device types, connector types, or features
            
            Format your response as valid JSON only, no explanation.`,
          },
        ],
      }),
    });

    if (!response.ok) {
      throw new Error(`Anthropic API error: ${response.status}`);
    }

    const message = await response.json();

    const aiResponseText = message.content[0].text;
    const aiResponse = JSON.parse(aiResponseText);

    // Track API usage if user is authenticated
    const session = getSession();
    if (session && session.user) {
      await sql(
        `
        INSERT INTO api_usage 
        (user_id, api_type, request_type, tokens_used, created_at)
        VALUES ($1, $2, $3, $4, NOW())`,
        [
          session.user.id,
          "anthropic",
          "search-analysis",
          message.usage?.output_tokens || 0,
        ]
      );
    }

    if (aiResponse.category === "device" || aiResponse.category === "all") {
      const devices = await sql(
        `
        SELECT id, name, category, description, image_url, input_ports, output_ports
        FROM devices 
        WHERE name ILIKE $1 
        OR category ILIKE $2 
        OR description ILIKE $3
        ORDER BY name ASC
      `,
        [
          `%${aiResponse.searchTerms}%`,
          `%${aiResponse.searchTerms}%`,
          `%${aiResponse.searchTerms}%`,
        ]
      );

      results.devices = devices;
    }

    if (aiResponse.category === "adapter" || aiResponse.category === "all") {
      const adapters = await sql(
        `
        SELECT id, name, input_type, output_type, description, image_url
        FROM adapters 
        WHERE name ILIKE $1 
        OR input_type ILIKE $2 
        OR output_type ILIKE $3 
        OR description ILIKE $4
        ORDER BY name ASC
      `,
        [
          `%${aiResponse.searchTerms}%`,
          `%${aiResponse.searchTerms}%`,
          `%${aiResponse.searchTerms}%`,
          `%${aiResponse.searchTerms}%`,
        ]
      );

      results.adapters = adapters;
    }

    if (aiResponse.category === "cable" || aiResponse.category === "all") {
      const cables = await sql(
        `
        SELECT id, name, connector_type_a, connector_type_b, description, image_url
        FROM cables 
        WHERE name ILIKE $1 
        OR connector_type_a ILIKE $2 
        OR connector_type_b ILIKE $3 
        OR description ILIKE $4
        ORDER BY name ASC
      `,
        [
          `%${aiResponse.searchTerms}%`,
          `%${aiResponse.searchTerms}%`,
          `%${aiResponse.searchTerms}%`,
          `%${aiResponse.searchTerms}%`,
        ]
      );

      results.cables = cables;
    }

    return {
      query,
      aiAnalysis: aiResponse,
      results,
    };
  } catch (error) {
    console.error("Search error:", error);
    return {
      error: "An error occurred during search",
      details: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}