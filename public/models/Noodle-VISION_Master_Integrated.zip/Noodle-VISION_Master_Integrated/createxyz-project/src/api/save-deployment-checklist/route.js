function handler({ sections }) {
  if (!sections) {
    return {
      statusCode: 400,
      body: { error: "Missing sections data" },
    };
  }

  try {
    // Get the current user session
    const session = getSession();
    const userId = session?.user?.id;

    if (!userId) {
      return {
        statusCode: 401,
        body: { error: "Unauthorized" },
      };
    }

    // First, check if there's an existing checklist for this user
    const existingChecklist = sql`
      SELECT id FROM deployment_checklist 
      WHERE user_id = ${userId} AND category = 'user_checklist'
    `;

    // If there's no existing checklist, create new entries
    if (existingChecklist.length === 0) {
      // Insert each section and its items
      for (const [sectionKey, section] of Object.entries(sections)) {
        for (const item of section.items) {
          sql`
            INSERT INTO deployment_checklist 
            (user_id, category, item_name, description, is_completed, notes) 
            VALUES (${userId}, ${sectionKey}, ${item.id}, ${item.text}, ${item.checked}, '')
          `;
        }
      }
    } else {
      // Update existing entries
      for (const [sectionKey, section] of Object.entries(sections)) {
        for (const item of section.items) {
          sql`
            UPDATE deployment_checklist 
            SET is_completed = ${item.checked}, 
                completed_at = ${item.checked ? new Date() : null}
            WHERE user_id = ${userId} AND category = ${sectionKey} AND item_name = ${
            item.id
          }
          `;
        }
      }
    }

    return {
      statusCode: 200,
      body: {
        success: true,
        message: "Deployment checklist saved successfully",
      },
    };
  } catch (error) {
    console.error("Error saving deployment checklist:", error);
    return {
      statusCode: 500,
      body: { error: "Failed to save deployment checklist" },
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}