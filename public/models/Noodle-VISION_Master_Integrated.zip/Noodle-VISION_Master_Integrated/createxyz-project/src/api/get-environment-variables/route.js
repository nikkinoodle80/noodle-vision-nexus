async function handler({ environment_name }) {
  try {
    let queryText = `
      SELECT id, environment_name, is_active, 
      (SELECT COUNT(*) FROM jsonb_object_keys(variables)) as variable_count,
      created_at, updated_at
      FROM deployment_environments
    `;

    const queryParams = [];

    if (environment_name) {
      queryText += ` WHERE environment_name = $1`;
      queryParams.push(environment_name);
    }

    const result = await sql(queryText, queryParams);

    return {
      success: true,
      environments: result,
    };
  } catch (error) {
    console.error("Error fetching environment variables:", error);
    return {
      success: false,
      error: "Failed to fetch environment variables",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}