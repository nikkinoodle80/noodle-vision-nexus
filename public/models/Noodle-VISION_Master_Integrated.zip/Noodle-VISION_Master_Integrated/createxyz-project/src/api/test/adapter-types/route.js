function handler() {
  // Get test utilities
  const testUtils = fetch("/api/setup-test-utils", { method: "POST" }).then(
    (res) => res.json()
  );

  // Run the adapter type tests
  const runTests = async () => {
    const utils = await testUtils;
    const mockSql = utils.createMockSql();
    const testAdapterTypes = utils.createTestAdapterTypes();

    const results = {
      tests: [],
      summary: { passed: 0, failed: 0, total: 0 },
    };

    // Test 1: Get all adapter types (no filters)
    try {
      // Setup mock
      const originalSql = global.sql;
      global.sql = (query, params) => {
        if (
          query.includes("SELECT * FROM adapter_types") &&
          !query.includes("WHERE")
        ) {
          return Promise.resolve(testAdapterTypes);
        }
        return Promise.resolve([]);
      };

      // Make the API call
      const response = await fetch("/api/adapter-types", { method: "GET" });
      const data = await response.json();

      // Verify results
      const passed =
        Array.isArray(data) && data.length === testAdapterTypes.length;

      results.tests.push({
        name: "Get all adapter types (no filters)",
        passed,
        expected: testAdapterTypes,
        actual: data,
        error: passed ? null : "Response did not match expected adapter types",
      });

      if (passed) results.summary.passed++;
      else results.summary.failed++;

      // Restore original
      global.sql = originalSql;
    } catch (error) {
      results.tests.push({
        name: "Get all adapter types (no filters)",
        passed: false,
        error: error.message,
      });
      results.summary.failed++;
    }

    // Test 2: Filter adapter types by input_type
    try {
      // Setup mock
      const originalSql = global.sql;
      global.sql = (query, params) => {
        if (
          query.includes("WHERE input_type =") &&
          params &&
          params[0] === "HDMI"
        ) {
          return Promise.resolve(
            testAdapterTypes.filter((a) => a.input_type === "HDMI")
          );
        }
        return Promise.resolve([]);
      };

      // Make the API call
      const response = await fetch("/api/adapter-types?input_type=HDMI", {
        method: "GET",
      });
      const data = await response.json();

      // Verify results
      const expected = testAdapterTypes.filter((a) => a.input_type === "HDMI");
      const passed =
        Array.isArray(data) &&
        data.length === expected.length &&
        data.every((item) => item.input_type === "HDMI");

      results.tests.push({
        name: "Filter adapter types by input_type",
        passed,
        expected,
        actual: data,
        error: passed
          ? null
          : "Response did not correctly filter by input_type",
      });

      if (passed) results.summary.passed++;
      else results.summary.failed++;

      // Restore original
      global.sql = originalSql;
    } catch (error) {
      results.tests.push({
        name: "Filter adapter types by input_type",
        passed: false,
        error: error.message,
      });
      results.summary.failed++;
    }

    // Test 3: Error handling
    try {
      // Setup mock to throw error
      const originalSql = global.sql;
      global.sql = () => {
        throw new Error("Database connection failed");
      };

      // Make the API call
      const response = await fetch("/api/adapter-types", { method: "GET" });
      const data = await response.json();

      // Verify results
      const passed = response.status === 500 && data.error;

      results.tests.push({
        name: "Handle database errors gracefully",
        passed,
        expected: { status: 500, body: { error: "Database error" } },
        actual: { status: response.status, body: data },
        error: passed ? null : "API did not handle database error correctly",
      });

      if (passed) results.summary.passed++;
      else results.summary.failed++;

      // Restore original
      global.sql = originalSql;
    } catch (error) {
      results.tests.push({
        name: "Handle database errors gracefully",
        passed: false,
        error: error.message,
      });
      results.summary.failed++;
    }

    // Update summary
    results.summary.total = results.tests.length;

    return results;
  };

  return runTests();
}
export async function POST(request) {
  return handler(await request.json());
}