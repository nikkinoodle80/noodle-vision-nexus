async function handler({
  setupId,
  action,
  presetName,
  presetDescription,
  connectionData,
}) {
  if (action === "save_preset" && connectionData) {
    return await saveConnectionPreset(
      presetName,
      presetDescription,
      connectionData
    );
  } else if (action === "load_preset" && presetName) {
    return await loadConnectionPreset(presetName);
  } else if (!setupId) {
    return {
      success: false,
      message: "Setup ID is required for viewing or validating connections",
    };
  }

  try {
    const setups = await sql`
      SELECT id, name, description
      FROM device_setups
      WHERE id = ${setupId}
    `;

    if (setups.length === 0) {
      return {
        success: false,
        message: "Setup not found",
        errorCode: "SETUP_NOT_FOUND",
      };
    }

    const setup = setups[0];

    const connections = await sql`
      SELECT 
        sc.id,
        sc.source_device_id,
        sc.target_device_id,
        sc.adapter_id,
        sc.source_port_type,
        sc.target_port_type,
        sc.position_data,
        p1.name as source_device_name,
        p2.name as target_device_name,
        a.name as adapter_name,
        a.color as adapter_color,
        a.source_type as adapter_source_type,
        a.target_type as adapter_target_type
      FROM setup_connections sc
      JOIN products p1 ON sc.source_device_id = p1.id
      JOIN products p2 ON sc.target_device_id = p2.id
      JOIN adapters a ON sc.adapter_id = a.id
      WHERE sc.setup_id = ${setupId}
    `;

    const deviceIds = new Set();
    connections.forEach((conn) => {
      deviceIds.add(conn.source_device_id);
      deviceIds.add(conn.target_device_id);
    });

    const deviceIdsArray = Array.from(deviceIds);

    if (deviceIdsArray.length === 0) {
      return {
        success: true,
        setup,
        connections: [],
        devices: [],
        visualData: {
          patchCables: [],
        },
      };
    }

    const devices = await sql`
      SELECT p.id, p.name, p.description
      FROM products p
      WHERE p.id = ANY(${deviceIdsArray})
    `;

    const ports = await sql`
      SELECT device_id, port_name, port_type, count
      FROM device_ports
      WHERE device_id = ANY(${deviceIdsArray})
    `;

    const devicePorts = {};
    ports.forEach((port) => {
      if (!devicePorts[port.device_id]) {
        devicePorts[port.device_id] = [];
      }
      devicePorts[port.device_id].push(port);
    });

    const enhancedDevices = devices.map((device) => ({
      ...device,
      ports: devicePorts[device.id] || [],
    }));

    const validationResults = validateAudioConnections(
      connections,
      enhancedDevices
    );

    const visualData = generateVisualData(connections);

    return {
      success: true,
      setup,
      connections,
      devices: enhancedDevices,
      validationResults,
      visualData,
      audioConnectionTypes: [
        { type: "CV", description: "Control Voltage", color: "#FF5500" },
        { type: "GATE", description: "Gate/Trigger Signal", color: "#00AAFF" },
        { type: "AUDIO", description: "Audio Signal", color: "#55FF00" },
        { type: "MIDI", description: "MIDI Control", color: "#FF00AA" },
        { type: "CLOCK", description: "Clock Signal", color: "#FFFF00" },
      ],
    };
  } catch (error) {
    return {
      success: false,
      message: "Error retrieving setup data",
      errorCode: "DATABASE_ERROR",
      errorDetails: error.message,
    };
  }
}

function validateAudioConnections(connections, devices) {
  const results = {
    valid: true,
    incompatibleConnections: [],
    overloadedPorts: [],
    missingAdapters: [],
  };

  const deviceMap = {};
  devices.forEach((device) => {
    deviceMap[device.id] = device;
  });

  const portUsage = {};

  connections.forEach((connection) => {
    const sourceDevice = deviceMap[connection.source_device_id];
    const targetDevice = deviceMap[connection.target_device_id];

    if (!sourceDevice || !targetDevice) {
      results.valid = false;
      results.incompatibleConnections.push({
        connectionId: connection.id,
        reason: "Missing device",
        details: "One of the connected devices no longer exists",
      });
      return;
    }

    if (connection.source_port_type !== connection.adapter_source_type) {
      results.valid = false;
      results.incompatibleConnections.push({
        connectionId: connection.id,
        reason: "Incompatible source port",
        details: `${sourceDevice.name}'s ${connection.source_port_type} port is incompatible with ${connection.adapter_name}'s ${connection.adapter_source_type} input`,
      });
    }

    if (connection.target_port_type !== connection.adapter_target_type) {
      results.valid = false;
      results.incompatibleConnections.push({
        connectionId: connection.id,
        reason: "Incompatible target port",
        details: `${connection.adapter_name}'s ${connection.adapter_target_type} output is incompatible with ${targetDevice.name}'s ${connection.target_port_type} port`,
      });
    }

    const sourcePortKey = `${connection.source_device_id}-${connection.source_port_type}`;
    const targetPortKey = `${connection.target_device_id}-${connection.target_port_type}`;

    portUsage[sourcePortKey] = (portUsage[sourcePortKey] || 0) + 1;
    portUsage[targetPortKey] = (portUsage[targetPortKey] || 0) + 1;

    const sourcePort = sourceDevice.ports.find(
      (p) => p.port_type === connection.source_port_type
    );
    const targetPort = targetDevice.ports.find(
      (p) => p.port_type === connection.target_port_type
    );

    if (sourcePort && portUsage[sourcePortKey] > sourcePort.count) {
      results.valid = false;
      results.overloadedPorts.push({
        deviceId: sourceDevice.id,
        deviceName: sourceDevice.name,
        portType: connection.source_port_type,
        maxConnections: sourcePort.count,
        currentConnections: portUsage[sourcePortKey],
      });
    }

    if (targetPort && portUsage[targetPortKey] > targetPort.count) {
      results.valid = false;
      results.overloadedPorts.push({
        deviceId: targetDevice.id,
        deviceName: targetDevice.name,
        portType: connection.target_port_type,
        maxConnections: targetPort.count,
        currentConnections: portUsage[targetPortKey],
      });
    }
  });

  return results;
}

function generateVisualData(connections) {
  const patchCables = connections.map((connection) => {
    let cableColor = connection.adapter_color || "#CCCCCC";

    let cableThickness = 2;
    if (connection.source_port_type === "AUDIO") {
      cableThickness = 3;
    } else if (
      connection.source_port_type === "CV" ||
      connection.source_port_type === "GATE"
    ) {
      cableThickness = 1.5;
    }

    const positionData = connection.position_data || {
      sourceX: 0,
      sourceY: 0,
      targetX: 100,
      targetY: 100,
      controlPoints: [],
    };

    return {
      id: connection.id,
      sourceDeviceId: connection.source_device_id,
      targetDeviceId: connection.target_device_id,
      sourcePortType: connection.source_port_type,
      targetPortType: connection.target_port_type,
      color: cableColor,
      thickness: cableThickness,
      adapterId: connection.adapter_id,
      adapterName: connection.adapter_name,
      position: positionData,
    };
  });

  return {
    patchCables,
  };
}

async function saveConnectionPreset(name, description, connectionData) {
  if (!name || !connectionData) {
    return {
      success: false,
      message: "Preset name and connection data are required",
      errorCode: "MISSING_REQUIRED_DATA",
    };
  }

  try {
    const setupResult = await sql`
      INSERT INTO device_setups (name, description)
      VALUES (${name}, ${description || ""})
      RETURNING id
    `;

    if (!setupResult || setupResult.length === 0) {
      return {
        success: false,
        message: "Failed to create preset",
        errorCode: "PRESET_CREATION_FAILED",
      };
    }

    const newSetupId = setupResult[0].id;

    for (const connection of connectionData) {
      await sql`
        INSERT INTO setup_connections (
          setup_id, 
          source_device_id, 
          target_device_id, 
          adapter_id, 
          source_port_type, 
          target_port_type, 
          position_data
        )
        VALUES (
          ${newSetupId}, 
          ${connection.sourceDeviceId}, 
          ${connection.targetDeviceId}, 
          ${connection.adapterId}, 
          ${connection.sourcePortType}, 
          ${connection.targetPortType}, 
          ${connection.position || null}
        )
      `;
    }

    return {
      success: true,
      message: "Connection preset saved successfully",
      setupId: newSetupId,
    };
  } catch (error) {
    return {
      success: false,
      message: "Error saving connection preset",
      errorCode: "PRESET_SAVE_ERROR",
      errorDetails: error.message,
    };
  }
}

async function loadConnectionPreset(presetName) {
  try {
    const setups = await sql`
      SELECT id, name, description
      FROM device_setups
      WHERE name = ${presetName}
    `;

    if (setups.length === 0) {
      return {
        success: false,
        message: "Preset not found",
        errorCode: "PRESET_NOT_FOUND",
      };
    }

    return {
      success: true,
      message: "Preset found",
      setupId: setups[0].id,
      setupName: setups[0].name,
      setupDescription: setups[0].description,
    };
  } catch (error) {
    return {
      success: false,
      message: "Error loading connection preset",
      errorCode: "PRESET_LOAD_ERROR",
      errorDetails: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}