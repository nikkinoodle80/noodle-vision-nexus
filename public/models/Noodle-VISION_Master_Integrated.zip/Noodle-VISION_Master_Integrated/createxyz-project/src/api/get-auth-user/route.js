async function handler({ userId }) {
  if (!userId) {
    return null;
  }

  const [user] = await sql`SELECT * FROM auth_users WHERE id = ${userId}`;
  return user || null;
}
export async function POST(request) {
  return handler(await request.json());
}