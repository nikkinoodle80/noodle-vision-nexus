async function handler() {
  const urls = await sql("SELECT * FROM stored_urls");
  return urls;
}
export async function POST(request) {
  return handler(await request.json());
}