async function handler({
  trackingType,
  minRefreshRate,
  minResolution,
  minFieldOfView,
  brand,
}) {
  try {
    // Build query conditions and parameters
    let conditions = ["is_vr_compatible = true"];
    let params = [];

    if (trackingType) {
      conditions.push(`vr_tracking_type = $${params.length + 1}`);
      params.push(trackingType);
    }

    if (minRefreshRate) {
      conditions.push(`vr_refresh_rate >= $${params.length + 1}`);
      params.push(minRefreshRate);
    }

    if (minResolution) {
      conditions.push(`vr_resolution = $${params.length + 1}`);
      params.push(minResolution);
    }

    if (minFieldOfView) {
      conditions.push(`vr_field_of_view >= $${params.length + 1}`);
      params.push(minFieldOfView);
    }

    if (brand) {
      conditions.push(`brand ILIKE $${params.length + 1}`);
      params.push(`%${brand}%`);
    }

    // Construct the query string
    const queryString = `
      SELECT * FROM devices 
      WHERE ${conditions.join(" AND ")}
      ORDER BY brand, model
    `;

    // Execute the query using the function form of sql
    const devices = await sql(queryString, params);

    return {
      devices,
    };
  } catch (error) {
    console.error("Error fetching VR devices:", error);
    return {
      error: "Failed to fetch VR devices",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}