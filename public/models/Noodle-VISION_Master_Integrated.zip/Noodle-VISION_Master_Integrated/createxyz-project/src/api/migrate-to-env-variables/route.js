async function handler() {
  try {
    const session = getSession();
    if (!session || !session.user) {
      return {
        success: false,
        error: "You must be logged in to migrate Stripe configuration",
      };
    }

    // Get existing configuration
    const configs = await sql`
      SELECT * FROM stripe_configuration WHERE user_id = ${session.user.id}
    `;

    if (configs.length === 0) {
      return {
        success: false,
        error: "No configuration found to migrate",
      };
    }

    const config = configs[0];

    // Create a backup of the current configuration
    await sql`
      INSERT INTO security_audit_logs 
      (user_id, action, details) 
      VALUES 
      (${session.user.id}, 'CONFIGURATION_BACKUP', ${JSON.stringify({
      timestamp: new Date().toISOString(),
      config_id: config.id,
      // We're not including the actual keys in the log for security
      has_test_secret_key: !!config.test_secret_key,
      has_live_secret_key: !!config.live_secret_key,
      has_test_webhook_secret: !!config.test_webhook_secret,
      has_live_webhook_secret: !!config.live_webhook_secret,
      has_test_webhook_url: !!config.test_webhook_url,
      has_live_webhook_url: !!config.live_webhook_url,
    })})
    `;

    // Update the configuration to use environment variables
    await sql`
      UPDATE stripe_configuration
      SET 
        use_env_variables = true,
        env_prefix = 'STRIPE_',
        updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ${session.user.id}
    `;

    // Return the environment variable names that need to be set
    return {
      success: true,
      message: "Configuration migrated to use environment variables",
      environmentVariables: {
        test_secret_key: "STRIPE_TEST_SECRET_KEY",
        live_secret_key: "STRIPE_LIVE_SECRET_KEY",
        test_webhook_secret: "STRIPE_TEST_WEBHOOK_SECRET",
        live_webhook_secret: "STRIPE_LIVE_WEBHOOK_SECRET",
        test_webhook_url: "STRIPE_TEST_WEBHOOK_URL",
        live_webhook_url: "STRIPE_LIVE_WEBHOOK_URL",
        basic_price_id: "STRIPE_BASIC_PRICE_ID",
        pro_price_id: "STRIPE_PRO_PRICE_ID",
        enterprise_price_id: "STRIPE_ENTERPRISE_PRICE_ID",
      },
    };
  } catch (error) {
    console.error("Error migrating to environment variables:", error);
    return {
      success: false,
      error: "Failed to migrate configuration",
      details: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}