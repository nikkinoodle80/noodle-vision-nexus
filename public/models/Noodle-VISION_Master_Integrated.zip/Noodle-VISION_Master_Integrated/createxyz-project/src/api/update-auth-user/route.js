async function handler({ id, name, email, emailVerified, image }) {
  if (!id) {
    return { error: "User ID is required" };
  }

  const fields = [];
  const values = [];
  let paramCount = 1;

  if (name !== undefined) {
    fields.push(`name = $${paramCount++}`);
    values.push(name);
  }
  if (email !== undefined) {
    fields.push(`email = $${paramCount++}`);
    values.push(email);
  }
  if (emailVerified !== undefined) {
    fields.push(`"emailVerified" = $${paramCount++}`);
    values.push(emailVerified);
  }
  if (image !== undefined) {
    fields.push(`image = $${paramCount++}`);
    values.push(image);
  }

  if (fields.length === 0) {
    return { error: "No fields to update" };
  }

  values.push(id);

  const query = `UPDATE auth_users SET ${fields.join(
    ", "
  )} WHERE id = $${paramCount}`;
  await sql(query, values);

  return { success: true };
}
export async function POST(request) {
  return handler(await request.json());
}