function handler({ action, subscriptionId, planType, cancelAtPeriodEnd }) {
  const session = getSession();

  if (!session || !session.user) {
    return { error: "Authentication required" };
  }

  const userId = session.user.id;

  const stripeApiKey = process.env.STRIPE_SECRET_KEY;

  if (!stripeApiKey) {
    return { error: "Stripe API key is not configured" };
  }

  switch (action) {
    case "getStatus":
      return getUserSubscription(userId);

    case "upgrade":
    case "downgrade":
      if (!planType) {
        return { error: "Plan type is required for upgrade/downgrade" };
      }
      return changePlan(userId, planType);

    case "cancel":
      if (!subscriptionId) {
        return { error: "Subscription ID is required for cancellation" };
      }
      return cancelSubscription(userId, subscriptionId, cancelAtPeriodEnd);

    case "reactivate":
      if (!subscriptionId) {
        return { error: "Subscription ID is required for reactivation" };
      }
      return reactivateSubscription(userId, subscriptionId);

    default:
      return {
        error:
          "Invalid action. Supported actions: getStatus, upgrade, downgrade, cancel, reactivate",
      };
  }

  async function getUserSubscription(userId) {
    try {
      const subscriptions = await sql(
        "SELECT * FROM user_subscriptions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1",
        [userId]
      );

      if (subscriptions.length === 0) {
        return {
          status: "no_subscription",
          subscription: null,
        };
      }

      return {
        status: "success",
        subscription: subscriptions[0],
      };
    } catch (error) {
      console.error("Error fetching subscription:", error);
      return {
        status: "error",
        error: "Failed to fetch subscription information",
      };
    }
  }

  async function changePlan(userId, newPlanType) {
    try {
      const { subscription, status, error } = await getUserSubscription(userId);

      if (status === "error") {
        return { status, error };
      }

      if (status === "no_subscription") {
        return {
          status: "error",
          error: "No active subscription found to change",
        };
      }

      if (subscription.plan_type === newPlanType) {
        return {
          status: "unchanged",
          message: "User is already on this plan",
        };
      }

      const planPriceMap = {
        basic: process.env.STRIPE_BASIC_PRICE_ID,
        pro: process.env.STRIPE_PRO_PRICE_ID,
        enterprise: process.env.STRIPE_ENTERPRISE_PRICE_ID,
      };

      const newPriceId = planPriceMap[newPlanType];

      if (!newPriceId) {
        return {
          status: "error",
          error: "Invalid plan type",
        };
      }

      const stripeResponse = await fetch(
        `https://api.stripe.com/v1/subscriptions/${subscription.stripe_subscription_id}`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${stripeApiKey}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            "items[0][id]": subscription.stripe_subscription_id,
            "items[0][price]": newPriceId,
            proration_behavior: "create_prorations",
          }),
        }
      );

      const stripeData = await stripeResponse.json();

      if (!stripeResponse.ok) {
        return {
          status: "error",
          error:
            stripeData.error?.message ||
            "Failed to update subscription in Stripe",
        };
      }

      await sql(
        "UPDATE user_subscriptions SET plan_type = $1, status = $2, current_period_start = to_timestamp($3), current_period_end = to_timestamp($4), updated_at = CURRENT_TIMESTAMP WHERE user_id = $5 AND stripe_subscription_id = $6",
        [
          newPlanType,
          stripeData.status,
          stripeData.current_period_start,
          stripeData.current_period_end,
          userId,
          subscription.stripe_subscription_id,
        ]
      );

      return {
        status: "success",
        message: `Subscription successfully changed to ${newPlanType}`,
        subscription: {
          ...subscription,
          plan_type: newPlanType,
          status: stripeData.status,
          current_period_start: new Date(
            stripeData.current_period_start * 1000
          ),
          current_period_end: new Date(stripeData.current_period_end * 1000),
        },
      };
    } catch (error) {
      console.error("Error changing subscription plan:", error);
      return {
        status: "error",
        error: "Failed to change subscription plan",
      };
    }
  }

  async function cancelSubscription(
    userId,
    subscriptionId,
    cancelAtPeriodEnd = true
  ) {
    try {
      const subscriptions = await sql(
        "SELECT * FROM user_subscriptions WHERE user_id = $1 AND stripe_subscription_id = $2",
        [userId, subscriptionId]
      );

      if (subscriptions.length === 0) {
        return {
          status: "error",
          error: "Subscription not found or does not belong to this user",
        };
      }

      const subscription = subscriptions[0];

      const cancelParams = new URLSearchParams();
      if (cancelAtPeriodEnd) {
        cancelParams.append("cancel_at_period_end", "true");
      }

      const stripeResponse = await fetch(
        `https://api.stripe.com/v1/subscriptions/${subscriptionId}`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${stripeApiKey}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: cancelParams,
        }
      );

      const stripeData = await stripeResponse.json();

      if (!stripeResponse.ok) {
        return {
          status: "error",
          error:
            stripeData.error?.message ||
            "Failed to cancel subscription in Stripe",
        };
      }

      await sql(
        "UPDATE user_subscriptions SET status = $1, cancel_at_period_end = $2, updated_at = CURRENT_TIMESTAMP WHERE user_id = $3 AND stripe_subscription_id = $4",
        [
          cancelAtPeriodEnd ? "active" : "canceled",
          cancelAtPeriodEnd,
          userId,
          subscriptionId,
        ]
      );

      return {
        status: "success",
        message: cancelAtPeriodEnd
          ? "Subscription will be canceled at the end of the billing period"
          : "Subscription has been canceled immediately",
        subscription: {
          ...subscription,
          status: cancelAtPeriodEnd ? "active" : "canceled",
          cancel_at_period_end: cancelAtPeriodEnd,
        },
      };
    } catch (error) {
      console.error("Error canceling subscription:", error);
      return {
        status: "error",
        error: "Failed to cancel subscription",
      };
    }
  }

  async function reactivateSubscription(userId, subscriptionId) {
    try {
      const subscriptions = await sql(
        "SELECT * FROM user_subscriptions WHERE user_id = $1 AND stripe_subscription_id = $2",
        [userId, subscriptionId]
      );

      if (subscriptions.length === 0) {
        return {
          status: "error",
          error: "Subscription not found or does not belong to this user",
        };
      }

      const subscription = subscriptions[0];

      if (!subscription.cancel_at_period_end) {
        return {
          status: "unchanged",
          message: "Subscription is not scheduled for cancellation",
        };
      }

      const stripeResponse = await fetch(
        `https://api.stripe.com/v1/subscriptions/${subscriptionId}`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${stripeApiKey}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            cancel_at_period_end: "false",
          }),
        }
      );

      const stripeData = await stripeResponse.json();

      if (!stripeResponse.ok) {
        return {
          status: "error",
          error:
            stripeData.error?.message ||
            "Failed to reactivate subscription in Stripe",
        };
      }

      await sql(
        "UPDATE user_subscriptions SET cancel_at_period_end = false, updated_at = CURRENT_TIMESTAMP WHERE user_id = $1 AND stripe_subscription_id = $2",
        [userId, subscriptionId]
      );

      return {
        status: "success",
        message: "Subscription has been reactivated",
        subscription: {
          ...subscription,
          cancel_at_period_end: false,
        },
      };
    } catch (error) {
      console.error("Error reactivating subscription:", error);
      return {
        status: "error",
        error: "Failed to reactivate subscription",
      };
    }
  }
}
export async function POST(request) {
  return handler(await request.json());
}