function handler({ setupId, name, domainId, configuration }) {
  try {
    const session = getSession();
    if (!session || !session.user) {
      return {
        success: false,
        error: "Authentication required",
      };
    }

    const userId = session.user.id;
    let setup;

    return sql
      .transaction(async (txn) => {
        if (setupId) {
          // Update existing setup
          const updatedSetups = await txn`
          UPDATE user_setups
          SET name = ${name}, 
              configuration = ${configuration},
              updated_at = CURRENT_TIMESTAMP
          WHERE id = ${setupId} AND user_id = ${userId}
          RETURNING *
        `;

          if (updatedSetups.length === 0) {
            return {
              success: false,
              error:
                "Setup not found or you don't have permission to update it",
            };
          }

          setup = updatedSetups[0];

          // Save to history for undo functionality
          await txn`
          INSERT INTO setup_history (setup_id, configuration)
          VALUES (${setupId}, ${configuration})
        `;
        } else {
          // Create new setup
          const newSetups = await txn`
          INSERT INTO user_setups (user_id, name, domain_id, configuration)
          VALUES (${userId}, ${name}, ${domainId}, ${configuration})
          RETURNING *
        `;

          setup = newSetups[0];

          // Save initial state to history
          await txn`
          INSERT INTO setup_history (setup_id, configuration)
          VALUES (${setup.id}, ${configuration})
        `;
        }

        return {
          success: true,
          setup,
        };
      })
      .catch((error) => {
        console.error("Error saving user setup:", error);
        return {
          success: false,
          error: "Failed to save setup",
        };
      });
  } catch (error) {
    console.error("Error in save user setup handler:", error);
    return {
      success: false,
      error: "Failed to process request",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}