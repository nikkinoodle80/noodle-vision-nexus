async function handler() {
  try {
    // Get the user's session to ensure they're logged in
    const session = getSession();
    if (!session || !session.user) {
      return {
        success: false,
        error: "You must be logged in to test Stripe webhook",
      };
    }

    // Get the user's Stripe configuration from the database
    const configs =
      await sql`SELECT * FROM stripe_configuration WHERE user_id = ${session.user.id}`;

    const config = configs[0];
    if (!config) {
      return {
        success: false,
        error:
          "No Stripe configuration found. Please set up your API keys first.",
      };
    }

    // Determine which key and webhook to use based on test/live mode
    let secretKey, webhookUrl, webhookSecret;

    if (config.use_env_variables) {
      // Use environment variables instead of stored values
      const envPrefix = config.env_prefix || "STRIPE_";
      const modePrefix = config.is_test_mode ? "TEST_" : "LIVE_";

      secretKey = process.env[`${envPrefix}${modePrefix}SECRET_KEY`];
      webhookUrl = process.env[`${envPrefix}${modePrefix}WEBHOOK_URL`];
      webhookSecret = process.env[`${envPrefix}${modePrefix}WEBHOOK_SECRET`];

      // Log that we're using environment variables
      await sql`
        INSERT INTO security_audit_logs 
        (user_id, action, details) 
        VALUES 
        (${session.user.id}, 'USED_ENV_VARIABLES', ${JSON.stringify({
        mode: config.is_test_mode ? "test" : "live",
        keys_used: ["secretKey", "webhookUrl", "webhookSecret"],
      })})
      `;
    } else {
      // Use stored values (legacy approach)
      secretKey = config.is_test_mode
        ? config.test_secret_key
        : config.live_secret_key;
      webhookUrl = config.is_test_mode
        ? config.test_webhook_url
        : config.live_webhook_url;
      webhookSecret = config.is_test_mode
        ? config.test_webhook_secret
        : config.live_webhook_secret;
    }

    if (!secretKey) {
      return {
        success: false,
        error: `No ${
          config.is_test_mode ? "test" : "live"
        } secret key configured.`,
      };
    }

    if (!webhookUrl) {
      return {
        success: false,
        error: `No ${
          config.is_test_mode ? "test" : "live"
        } webhook URL configured.`,
      };
    }

    if (!webhookSecret) {
      return {
        success: false,
        error: `No ${
          config.is_test_mode ? "test" : "live"
        } webhook secret configured.`,
      };
    }

    // Make a request to the Stripe API to list webhooks
    const response = await fetch(
      "https://api.stripe.com/v1/webhook_endpoints",
      {
        method: "GET",
        headers: {
          Authorization: `Bearer ${secretKey}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
      }
    );

    if (!response.ok) {
      throw new Error(`Stripe API responded with status: ${response.status}`);
    }

    const webhooks = await response.json();

    // Check if our webhook URL is registered
    const matchingWebhook = webhooks.data.find(
      (webhook) => webhook.url === webhookUrl
    );

    let webhookStatus = {
      tested: true,
      registered: !!matchingWebhook,
      url: webhookUrl,
      events: matchingWebhook ? matchingWebhook.enabled_events : [],
    };

    // Log the test attempt
    await sql`
      INSERT INTO stripe_test_logs 
      (user_id, test_mode, success, api_connection, webhook_status, errors) 
      VALUES 
      (${session.user.id}, ${
      config.is_test_mode
    }, ${true}, ${true}, ${JSON.stringify(webhookStatus)}, ${JSON.stringify(
      {}
    )})
    `;

    if (!matchingWebhook) {
      return {
        success: false,
        message: "Webhook URL is not registered with Stripe",
        webhookStatus,
        mode: config.is_test_mode ? "test" : "live",
      };
    }

    return {
      success: true,
      message: "Webhook is properly configured with Stripe!",
      webhookStatus,
      mode: config.is_test_mode ? "test" : "live",
    };
  } catch (error) {
    console.error("Stripe webhook test error:", error);

    // Try to log the failure
    try {
      const session = getSession();
      if (session && session.user) {
        await sql`
          INSERT INTO stripe_test_logs 
          (user_id, test_mode, success, api_connection, webhook_status, errors) 
          VALUES 
          (${session.user.id}, ${true}, ${false}, ${false}, ${JSON.stringify({
          tested: true,
          error: true,
        })}, ${JSON.stringify({ message: error.message, stack: error.stack })})
        `;
      }
    } catch (logError) {
      console.error("Failed to log Stripe test error:", logError);
    }

    return {
      success: false,
      error: "Failed to test Stripe webhook configuration",
      details: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}