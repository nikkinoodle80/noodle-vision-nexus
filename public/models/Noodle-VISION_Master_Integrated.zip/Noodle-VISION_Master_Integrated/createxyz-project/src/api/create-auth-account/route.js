async function handler({
  userId,
  type,
  provider,
  providerAccountId,
  refresh_token,
  access_token,
  expires_at,
  id_token,
  scope,
  session_state,
  token_type,
  password,
}) {
  const result = await sql`
    INSERT INTO auth_accounts (
      "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, id_token, scope, session_state, token_type, password
    ) VALUES (
      ${userId}, ${type}, ${provider}, ${providerAccountId}, ${refresh_token}, ${access_token}, ${expires_at}, ${id_token}, ${scope}, ${session_state}, ${token_type}, ${password}
    )
    RETURNING *
  `;

  return result[0] || null;
}
export async function POST(request) {
  return handler(await request.json());
}