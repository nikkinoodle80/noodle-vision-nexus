async function handler({ userId, courseId, paymentDetails, useMockData }) {
  const session = getSession();

  if (!session || !session.user) {
    return { error: "User not authenticated" };
  }

  if (!userId || !courseId || !paymentDetails) {
    return { error: "Missing required information" };
  }

  try {
    let user, course;

    if (useMockData) {
      user = [{ id: userId, name: "Mock User" }];
      course = [{ id: courseId, name: "Mock Course" }];
    } else {
      user = await sql`SELECT * FROM auth_users WHERE id = ${userId}`;
      course = await sql`SELECT * FROM simulators WHERE id = ${courseId}`;
    }

    if (!user.length) {
      return { error: "User not found" };
    }

    if (!course.length) {
      return { error: "Course not found" };
    }

    // Process the payment using paymentDetails
    // For example, you might call an external payment API

    // Assuming payment is successful, update the user's subscription
    await sql`INSERT INTO user_subscriptions (user_id, course_id, status) VALUES (${userId}, ${courseId}, 'active')`;

    return { success: true, message: "Subscription successful" };
  } catch (error) {
    return { error: "An error occurred while processing the payment" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}