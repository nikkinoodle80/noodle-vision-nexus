async function handler({ url, description }) {
  if (!url) {
    return { error: "URL is required" };
  }

  const result = await sql(
    "INSERT INTO stored_urls (url, description) VALUES ($1, $2) RETURNING *",
    [url, description]
  );

  return result.length > 0 ? result[0] : { error: "Failed to add URL" };
}
export async function POST(request) {
  return handler(await request.json());
}