async function handler({
  testSecretKey,
  liveSecretKey,
  testWebhookSecret,
  liveWebhookSecret,
  testWebhookUrl,
  liveWebhookUrl,
  basicPriceId,
  proPriceId,
  enterprisePriceId,
  isTestMode,
  use_env_variables,
  env_prefix,
}) {
  const session = getSession();
  if (!session || !session.user) {
    return { error: "Unauthorized" };
  }

  const userId = session.user.id;

  const useEnvVariables = use_env_variables === true;
  const envPrefix = env_prefix || "STRIPE_";

  if (!useEnvVariables && !testSecretKey && !liveSecretKey) {
    return { error: "At least one API key is required" };
  }

  try {
    const existingConfig =
      await sql`SELECT id, use_env_variables FROM stripe_configuration WHERE user_id = ${userId}`;

    if (
      useEnvVariables &&
      (existingConfig.length === 0 || !existingConfig[0].use_env_variables)
    ) {
      await sql`
        INSERT INTO security_audit_logs 
        (user_id, action, details) 
        VALUES 
        (${userId}, 'SWITCHED_TO_ENV_VARIABLES', ${JSON.stringify({
        timestamp: new Date().toISOString(),
        previous_state:
          existingConfig.length > 0 ? "had_stored_keys" : "no_previous_config",
      })})
      `;
    }

    let result;

    if (existingConfig.length > 0) {
      result = await sql`
        UPDATE stripe_configuration 
        SET test_secret_key = ${useEnvVariables ? null : testSecretKey}, 
            live_secret_key = ${useEnvVariables ? null : liveSecretKey}, 
            test_webhook_secret = ${
              useEnvVariables ? null : testWebhookSecret
            }, 
            live_webhook_secret = ${
              useEnvVariables ? null : liveWebhookSecret
            }, 
            test_webhook_url = ${useEnvVariables ? null : testWebhookUrl}, 
            live_webhook_url = ${useEnvVariables ? null : liveWebhookUrl}, 
            basic_price_id = ${basicPriceId}, 
            pro_price_id = ${proPriceId}, 
            enterprise_price_id = ${enterprisePriceId}, 
            is_test_mode = ${isTestMode !== undefined ? isTestMode : true},
            use_env_variables = ${useEnvVariables},
            env_prefix = ${envPrefix},
            updated_at = CURRENT_TIMESTAMP
        WHERE user_id = ${userId}
        RETURNING id`;
    } else {
      result = await sql`
        INSERT INTO stripe_configuration 
        (user_id, test_secret_key, live_secret_key, test_webhook_secret, 
         live_webhook_secret, test_webhook_url, live_webhook_url, 
         basic_price_id, pro_price_id, enterprise_price_id, is_test_mode,
         use_env_variables, env_prefix)
        VALUES (
          ${userId}, 
          ${useEnvVariables ? null : testSecretKey}, 
          ${useEnvVariables ? null : liveSecretKey}, 
          ${useEnvVariables ? null : testWebhookSecret}, 
          ${useEnvVariables ? null : liveWebhookSecret}, 
          ${useEnvVariables ? null : testWebhookUrl}, 
          ${useEnvVariables ? null : liveWebhookUrl}, 
          ${basicPriceId}, 
          ${proPriceId}, 
          ${enterprisePriceId}, 
          ${isTestMode !== undefined ? isTestMode : true},
          ${useEnvVariables},
          ${envPrefix}
        )
        RETURNING id`;
    }

    return {
      success: true,
      message: "Stripe configuration saved successfully",
      id: result[0].id,
      usingEnvVariables: useEnvVariables,
    };
  } catch (error) {
    console.error("Error saving Stripe configuration:", error);
    return {
      error: "Failed to save Stripe configuration",
      details: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}