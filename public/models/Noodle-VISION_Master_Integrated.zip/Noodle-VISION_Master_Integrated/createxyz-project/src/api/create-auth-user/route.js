async function handler({ name, email, emailVerified, image }) {
  const result = await sql(
    'INSERT INTO auth_users (name, email, "emailVerified", image) VALUES ($1, $2, $3, $4) RETURNING *',
    [name, email, emailVerified, image]
  );
  return result[0] || null;
}
export async function POST(request) {
  return handler(await request.json());
}