function handler({ domainId }) {
  try {
    const tutorials = sql`
      SELECT * FROM tutorials
      WHERE domain_id = ${domainId} OR ${domainId} IS NULL
      ORDER BY created_at DESC
    `;

    return {
      success: true,
      tutorials,
    };
  } catch (error) {
    console.error("Error fetching tutorials:", error);
    return {
      success: false,
      error: "Failed to fetch tutorials",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}