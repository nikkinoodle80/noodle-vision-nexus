"use client";
import React from "react";

function MainComponent() {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 py-8 px-4 md:px-8 print:p-0 print:bg-white">
      <div className="max-w-4xl mx-auto">
        <header className="mb-10 flex flex-col md:flex-row justify-between items-center print:hidden">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
              AR Hardware Simulator Manual
            </h1>
            <p className="text-lg text-gray-700 dark:text-gray-300 font-inter">
              Complete guide to using our AR Hardware Simulator
            </p>
          </div>
          <div className="mt-4 md:mt-0 flex space-x-4">
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md flex items-center"
            >
              <i className="fas fa-print mr-2"></i> Print Manual
            </button>
            <a
              href="/ar-simulator"
              className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-md flex items-center"
            >
              <i className="fas fa-vr-cardboard mr-2"></i> Open Simulator
            </a>
          </div>
        </header>

        <div className="hidden print:block mb-8">
          <h1 className="text-3xl font-bold text-black">
            AR Hardware Simulator Manual
          </h1>
          <p className="text-gray-700">
            Printed from AR Hardware Simulator -{" "}
            {new Date().toLocaleDateString()}
          </p>
        </div>

        <div className="mb-12 bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 print:p-4 print:shadow-none print:border print:border-gray-300">
          <h2
            className="text-2xl font-bold text-gray-900 dark:text-white mb-4"
            id="toc"
          >
            Table of Contents
          </h2>
          <ul className="space-y-2 text-gray-700 dark:text-gray-300 font-inter">
            <li className="hover:text-blue-600 dark:hover:text-blue-400">
              <a href="#introduction" className="flex items-center">
                <i className="fas fa-info-circle mr-2"></i> 1. Introduction
              </a>
            </li>
            <li className="hover:text-blue-600 dark:hover:text-blue-400">
              <a href="#getting-started" className="flex items-center">
                <i className="fas fa-play-circle mr-2"></i> 2. Getting Started
              </a>
            </li>
            <li className="hover:text-blue-600 dark:hover:text-blue-400">
              <a href="#creating-setups" className="flex items-center">
                <i className="fas fa-tools mr-2"></i> 3. Creating Device Setups
              </a>
            </li>
            <li className="hover:text-blue-600 dark:hover:text-blue-400">
              <a href="#connecting-devices" className="flex items-center">
                <i className="fas fa-plug mr-2"></i> 4. Connecting Devices
              </a>
            </li>
            <li className="hover:text-blue-600 dark:hover:text-blue-400">
              <a href="#saving-loading" className="flex items-center">
                <i className="fas fa-save mr-2"></i> 5. Saving & Loading
                Configurations
              </a>
            </li>
            <li className="hover:text-blue-600 dark:hover:text-blue-400">
              <a href="#troubleshooting" className="flex items-center">
                <i className="fas fa-exclamation-triangle mr-2"></i> 6.
                Troubleshooting
              </a>
            </li>
            <li className="hover:text-blue-600 dark:hover:text-blue-400">
              <a href="#faq" className="flex items-center">
                <i className="fas fa-question-circle mr-2"></i> 7. Frequently
                Asked Questions
              </a>
            </li>
            <li className="hover:text-blue-600 dark:hover:text-blue-400">
              <a href="#tips" className="flex items-center">
                <i className="fas fa-lightbulb mr-2"></i> 8. Tips & Best
                Practices
              </a>
            </li>
          </ul>
        </div>

        <section className="mb-12 bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 print:p-4 print:shadow-none print:border print:border-gray-300">
          <h2
            className="text-2xl font-bold text-gray-900 dark:text-white mb-4"
            id="introduction"
          >
            1. Introduction
          </h2>

          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
              What is the AR Hardware Simulator?
            </h3>
            <p className="text-gray-700 dark:text-gray-300 font-inter mb-4">
              The AR Hardware Simulator is an advanced tool that allows you to
              visualize and test hardware configurations in augmented reality.
              By placing virtual representations of real hardware devices in
              your physical space, you can:
            </p>
            <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 font-inter space-y-2 ml-4">
              <li>Preview how devices will look and fit in your environment</li>
              <li>Test connections between different hardware components</li>
              <li>Identify potential compatibility issues before purchasing</li>
              <li>Plan complex hardware setups with confidence</li>
              <li>Share configurations with team members or clients</li>
            </ul>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
              System Requirements
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-md">
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                  Mobile AR Mode
                </h4>
                <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 font-inter space-y-1 ml-2">
                  <li>iOS 12+ or Android 8.0+</li>
                  <li>Device with ARKit or ARCore support</li>
                  <li>At least 2GB RAM recommended</li>
                  <li>Camera access required</li>
                  <li>Stable internet connection</li>
                </ul>
              </div>
              <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-md">
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                  Desktop 3D Mode
                </h4>
                <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 font-inter space-y-1 ml-2">
                  <li>Modern web browser (Chrome, Firefox, Safari, Edge)</li>
                  <li>WebGL support</li>
                  <li>At least 4GB RAM recommended</li>
                  <li>Discrete graphics card recommended for complex setups</li>
                  <li>Stable internet connection</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="flex justify-end print:hidden">
            <a
              href="#toc"
              className="text-blue-600 dark:text-blue-400 hover:underline flex items-center"
            >
              <i className="fas fa-arrow-up mr-1"></i> Back to Contents
            </a>
          </div>
        </section>

        <section className="mb-12 bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 print:p-4 print:shadow-none print:border print:border-gray-300">
          <h2
            className="text-2xl font-bold text-gray-900 dark:text-white mb-4"
            id="getting-started"
          >
            2. Getting Started
          </h2>

          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
              Accessing the Simulator
            </h3>
            <p className="text-gray-700 dark:text-gray-300 font-inter mb-4">
              The AR Hardware Simulator can be accessed from the main navigation
              menu or directly at{" "}
              <a
                href="/ar-simulator"
                className="text-blue-600 dark:text-blue-400 hover:underline"
              >
                /ar-simulator
              </a>
              .
            </p>
            <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-md mb-4">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                First-Time Setup
              </h4>
              <ol className="list-decimal list-inside text-gray-700 dark:text-gray-300 font-inter space-y-2 ml-2">
                <li>Navigate to the AR Simulator page</li>
                <li>
                  Review and accept the permissions prompt for camera access
                  (mobile AR mode)
                </li>
                <li>Complete the brief tutorial to learn basic controls</li>
                <li>Choose between AR Mode (mobile) or 3D Mode (desktop)</li>
              </ol>
            </div>
            <div className="bg-blue-50 dark:bg-blue-900 p-4 rounded-md">
              <p className="text-blue-800 dark:text-blue-200 font-inter">
                <i className="fas fa-info-circle mr-2"></i>{" "}
                <strong>Note:</strong> On first launch, the simulator will
                detect your device capabilities and automatically suggest the
                best mode for your device.
              </p>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
              Understanding the Interface
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                  Main Controls
                </h4>
                <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 font-inter space-y-1 ml-2">
                  <li>
                    <strong>Device Library:</strong> Browse available hardware
                  </li>
                  <li>
                    <strong>Placement Controls:</strong> Position and rotate
                    devices
                  </li>
                  <li>
                    <strong>Connection Tool:</strong> Create virtual connections
                  </li>
                  <li>
                    <strong>Save/Load:</strong> Manage your configurations
                  </li>
                  <li>
                    <strong>Settings:</strong> Adjust simulator preferences
                  </li>
                  <li>
                    <strong>Help:</strong> Access this manual and tutorials
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                  Viewing Modes
                </h4>
                <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 font-inter space-y-1 ml-2">
                  <li>
                    <strong>AR Mode:</strong> Place devices in your real
                    environment
                  </li>
                  <li>
                    <strong>3D Mode:</strong> Place devices in a virtual space
                  </li>
                  <li>
                    <strong>Top-Down View:</strong> Bird's eye perspective of
                    your setup
                  </li>
                  <li>
                    <strong>First-Person View:</strong> See setup from eye level
                  </li>
                  <li>
                    <strong>X-Ray View:</strong> See through devices for port
                    visibility
                  </li>
                </ul>
              </div>
            </div>
            <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-md">
              <img
                src="/images/simulator-interface.jpg"
                alt="AR Hardware Simulator interface showing the main control panel and a virtual device placement"
                className="w-full h-auto rounded-md mb-2"
              />
              <p className="text-sm text-gray-600 dark:text-gray-400 font-inter text-center">
                The AR Hardware Simulator interface with labeled controls and a
                device being placed
              </p>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
              AR Mode vs. 3D Mode
            </h3>
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700">
                <thead>
                  <tr className="bg-gray-100 dark:bg-gray-700">
                    <th className="py-2 px-4 border-b border-gray-300 dark:border-gray-700 text-left text-gray-900 dark:text-white">
                      Feature
                    </th>
                    <th className="py-2 px-4 border-b border-gray-300 dark:border-gray-700 text-left text-gray-900 dark:text-white">
                      AR Mode (Mobile)
                    </th>
                    <th className="py-2 px-4 border-b border-gray-300 dark:border-gray-700 text-left text-gray-900 dark:text-white">
                      3D Mode (Desktop)
                    </th>
                  </tr>
                </thead>
                <tbody className="text-gray-700 dark:text-gray-300">
                  <tr>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      Real Environment
                    </td>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      <i className="fas fa-check text-green-500"></i> Yes
                    </td>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      <i className="fas fa-times text-red-500"></i> No (Virtual
                      space)
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      Spatial Awareness
                    </td>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      <i className="fas fa-check text-green-500"></i> Yes
                    </td>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      <i className="fas fa-times text-red-500"></i> No
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      Device Required
                    </td>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      AR-capable mobile device
                    </td>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      Any computer with modern browser
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      Complex Setups
                    </td>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      Limited by physical space
                    </td>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      Unlimited virtual space
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      Performance
                    </td>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      Depends on device capabilities
                    </td>
                    <td className="py-2 px-4 border-b border-gray-300 dark:border-gray-700">
                      Generally better for complex setups
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex justify-end print:hidden">
            <a
              href="#toc"
              className="text-blue-600 dark:text-blue-400 hover:underline flex items-center"
            >
              <i className="fas fa-arrow-up mr-1"></i> Back to Contents
            </a>
          </div>
        </section>

        <section className="mb-12 bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 print:p-4 print:shadow-none print:border print:border-gray-300">
          <h2
            className="text-2xl font-bold text-gray-900 dark:text-white mb-4"
            id="creating-setups"
          >
            3. Creating Device Setups
          </h2>

          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
              Browsing the Device Library
            </h3>
            <p className="text-gray-700 dark:text-gray-300 font-inter mb-4">
              The Device Library contains a comprehensive collection of virtual
              hardware models that you can place in your setup.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                  Device Categories
                </h4>
                <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 font-inter space-y-1 ml-2">
                  <li>
                    <strong>Computers:</strong> Desktops, laptops, servers
                  </li>
                  <li>
                    <strong>Networking:</strong> Routers, switches, access
                    points
                  </li>
                  <li>
                    <strong>Storage:</strong> NAS devices, external drives
                  </li>
                  <li>
                    <strong>Peripherals:</strong> Monitors, keyboards, mice
                  </li>
                  <li>
                    <strong>Adapters:</strong> Various connection adapters
                  </li>
                  <li>
                    <strong>Cables:</strong> Different cable types and lengths
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                  Finding Devices
                </h4>
                <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 font-inter space-y-1 ml-2">
                  <li>Browse by category using the sidebar</li>
                  <li>Use the search bar to find specific models</li>
                  <li>Filter by manufacturer, connection type, etc.</li>
                  <li>View recently used devices in the "Recent" tab</li>
                  <li>Save favorites for quick access</li>
                </ul>
              </div>
            </div>
            <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-md">
              <img
                src="/images/device-library.jpg"
                alt="Device library showing categories of hardware and a search function"
                className="w-full h-auto rounded-md mb-2"
              />
              <p className="text-sm text-gray-600 dark:text-gray-400 font-inter text-center">
                The Device Library interface showing categories and search
                functionality
              </p>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
              Placing Devices
            </h3>
            <div className="mb-4">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                Step-by-Step Placement (AR Mode)
              </h4>
              <ol className="list-decimal list-inside text-gray-700 dark:text-gray-300 font-inter space-y-2 ml-2">
                <li>Select a device from the Device Library</li>
                <li>
                  Point your camera at a flat surface where you want to place
                  the device
                </li>
                <li>
                  Wait for surface detection (highlighted areas will appear)
                </li>
                <li>Tap on the detected surface to place the virtual device</li>
                <li>Use pinch gestures to resize the device if needed</li>
                <li>Use rotation controls to orient the device correctly</li>
                <li>Tap "Confirm Placement" when satisfied</li>
              </ol>
            </div>
            <div className="mb-4">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                Step-by-Step Placement (3D Mode)
              </h4>
              <ol className="list-decimal list-inside text-gray-700 dark:text-gray-300 font-inter space-y-2 ml-2">
                <li>Select a device from the Device Library</li>
                <li>
                  Click in the virtual space where you want to place the device
                </li>
                <li>Use the mouse to drag and position the device</li>
                <li>Use the rotation controls to orient the device</li>
                <li>Use the scroll wheel to resize the device if needed</li>
                <li>Click "Confirm Placement" when satisfied</li>
              </ol>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-md">
                <img
                  src="/images/ar-placement.jpg"
                  alt="AR mode showing a virtual router being placed on a real desk with surface detection highlighted"
                  className="w-full h-auto rounded-md mb-2"
                />
                <p className="text-sm text-gray-600 dark:text-gray-400 font-inter text-center">
                  AR Mode: Placing a virtual router on a detected surface
                </p>
              </div>
              <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-md">
                <img
                  src="/images/3d-placement.jpg"
                  alt="3D mode showing a virtual computer being placed in a virtual environment with positioning controls"
                  className="w-full h-auto rounded-md mb-2"
                />
                <p className="text-sm text-gray-600 dark:text-gray-400 font-inter text-center">
                  3D Mode: Placing a virtual computer in the virtual space
                </p>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
              Manipulating Devices
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                  Basic Controls
                </h4>
                <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 font-inter space-y-1 ml-2">
                  <li>
                    <strong>Move:</strong> Drag device to reposition
                  </li>
                  <li>
                    <strong>Rotate:</strong> Use rotation handles or twist
                    gesture
                  </li>
                  <li>
                    <strong>Resize:</strong> Pinch gesture or scale handles
                  </li>
                  <li>
                    <strong>Delete:</strong> Select device and press trash icon
                  </li>
                  <li>
                    <strong>Duplicate:</strong> Select device and press copy
                    icon
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                  Advanced Controls
                </h4>
                <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 font-inter space-y-1 ml-2">
                  <li>
                    <strong>Group:</strong> Select multiple devices and group
                    them
                  </li>
                  <li>
                    <strong>Align:</strong> Automatically align devices to grid
                  </li>
                  <li>
                    <strong>Lock:</strong> Prevent accidental movement
                  </li>
                  <li>
                    <strong>Exploded View:</strong> See internal components
                  </li>
                  <li>
                    <strong>Port View:</strong> Highlight available ports
                  </li>
                </ul>
              </div>
            </div>
            <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-md">
              <img
                src="/images/device-manipulation.jpg"
                alt="Device manipulation controls showing rotation, scaling, and positioning handles on a virtual server"
                className="w-full h-auto rounded-md mb-2"
              />
              <p className="text-sm text-gray-600 dark:text-gray-400 font-inter text-center">
                Device manipulation controls for adjusting position, rotation,
                and scale
              </p>
            </div>
          </div>

          <div className="flex justify-end print:hidden">
            <a
              href="#toc"
              className="text-blue-600 dark:text-blue-400 hover:underline flex items-center"
            >
              <i className="fas fa-arrow-up mr-1"></i> Back to Contents
            </a>
          </div>
        </section>

        <section className="mb-12 bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 print:p-4 print:shadow-none print:border print:border-gray-300">
          <h2
            className="text-2xl font-bold text-gray-900 dark:text-white mb-4"
            id="connecting-devices"
          >
            4. Connecting Devices
          </h2>

          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
              Creating Connections
            </h3>
            <p className="text-gray-700 dark:text-gray-300 font-inter mb-4">
              The Connection Tool allows you to create virtual connections
              between devices to test compatibility and visualize your complete
              setup.
            </p>
            <div className="mb-4">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                Step-by-Step Connection Process
              </h4>
              <ol className="list-decimal list-inside text-gray-700 dark:text-gray-300 font-inter space-y-2 ml-2">
                <li>Select the "Connect" tool from the toolbar</li>
                <li>Click or tap on the first device you want to connect</li>
                <li>Select the specific port you want to use (if prompted)</li>
                <li>Click or tap on the second device</li>
                <li>Select the port on the second device</li>
                <li>Choose a cable type from the menu that appears</li>
                <li>Confirm the connection</li>
              </ol>
            </div>
            <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-md mb-4">
              <img
                src="/images/connection-process.jpg"
                alt="Connection process showing a virtual cable being created between a laptop and monitor with port selection interface"
                className="w-full h-auto rounded-md mb-2"
              />
              <p className="text-sm text-gray-600 dark:text-gray-400 font-inter text-center">
                Creating a connection between devices with the port selection
                interface
              </p>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
              Understanding Compatibility
            </h3>
            <p className="text-gray-700 dark:text-gray-300 font-inter mb-4">
              The simulator provides visual feedback about the compatibility of
              your connections:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-4">
              <div className="bg-green-50 dark:bg-green-900 p-4 rounded-md">
                <div className="flex items-center mb-2">
                  <div className="w-4 h-4 bg-green-500 rounded-full mr-2"></div>
                  <h4 className="font-semibold text-gray-900 dark:text-white">
                    Compatible
                  </h4>
                </div>
                <p className="text-gray-700 dark:text-gray-300 font-inter text-sm">
                  Green connections indicate fully compatible devices and ports.
                  These connections will work without issues.
                </p>
              </div>
              <div className="bg-yellow-50 dark:bg-yellow-900 p-4 rounded-md">
                <div className="flex items-center mb-2">
                  <div className="w-4 h-4 bg-yellow-500 rounded-full mr-2"></div>
                  <h4 className="font-semibold text-gray-900 dark:text-white">
                    Partially Compatible
                  </h4>
                </div>
                <p className="text-gray-700 dark:text-gray-300 font-inter text-sm">
                  Yellow connections indicate partial compatibility. These may
                  work with limited functionality or require additional
                  adapters.
                </p>
              </div>
              <div className="bg-red-50 dark:bg-red-900 p-4 rounded-md">
                <div className="flex items-center mb-2">
                  <div className="w-4 h-4 bg-red-500 rounded-full mr-2"></div>
                  <h4 className="font-semibold text-gray-900 dark:text-white">
                    Incompatible
                  </h4>
                </div>
                <p className="text-gray-700 dark:text-gray-300 font-inter text-sm">
                  Red connections indicate incompatible devices or ports. These
                  connections will not work without significant modifications.
                </p>
              </div>
            </div>
          </div>

          <div className="flex justify-end print:hidden">
            <a
              href="#toc"
              className="text-blue-600 dark:text-blue-400 hover:underline flex items-center"
            >
              <i className="fas fa-arrow-up mr-1"></i> Back to Contents
            </a>
          </div>
        </section>
      </div>
    </div>
  );
}

export default MainComponent;