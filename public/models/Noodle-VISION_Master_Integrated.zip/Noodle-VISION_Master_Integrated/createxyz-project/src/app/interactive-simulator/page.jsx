"use client";
import React from "react";

function MainComponent() {
  const [showManual, setShowManual] = React.useState(false);
  const [showTooltip, setShowTooltip] = React.useState(null);
  const [error, setError] = React.useState(null);
  const [manualLoading, setManualLoading] = React.useState(false);
  const workspaceRef = React.useRef(null);
  const scale = 1;
  const pan = { x: 0, y: 0 };
  const entertainmentDevices = {};
  const manualSections = {};

  const handleDrop = (module, position) => {};

  const generateManualPDF = () => {};

  const printManual = () => {};

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-[#20B2AA] to-[#7FFFD4]">
      <div className="w-full max-w-7xl p-4 flex justify-between items-center mb-2">
        <h1 className="text-2xl font-bold text-white">
          Interactive Entertainment System Simulator
        </h1>
        <div className="flex space-x-2">
          <button
            onClick={() => setShowManual(true)}
            className="bg-[#00CED1] hover:bg-[#00BFBF] text-white font-bold py-2 px-4 rounded-md shadow-md transition-all duration-200 flex items-center"
          >
            <i className="fas fa-book mr-2"></i>
            User Manual
          </button>
        </div>
      </div>

      <div className="w-full max-w-7xl p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-1 bg-white bg-opacity-90 p-4 rounded-lg shadow-lg overflow-y-auto max-h-[600px]">
            <div className="space-y-4">
              {Object.entries(entertainmentDevices).map(
                ([category, devices]) => (
                  <div key={category}>
                    <h3 className="font-bold mb-2 text-teal-800">
                      {category}
                      <button
                        className="ml-2 text-teal-600 hover:text-teal-800"
                        onMouseEnter={() => setShowTooltip(category)}
                        onMouseLeave={() => setShowTooltip(null)}
                      >
                        <i className="fas fa-question-circle text-sm"></i>
                      </button>
                    </h3>
                    {showTooltip === category && (
                      <div className="bg-teal-50 p-2 rounded-md text-sm mb-2 border border-teal-200">
                        {category === "Display Devices" &&
                          "Devices that show content, like TVs and monitors"}
                        {category === "Source Devices" &&
                          "Devices that generate content, like gaming consoles and media players"}
                        {category === "Audio Equipment" &&
                          "Devices that process or output audio"}
                        {category === "Adapters & Converters" &&
                          "Devices that convert between different connection types"}
                        {category === "Cables" &&
                          "Cables that connect devices together"}
                      </div>
                    )}
                    <div className="space-y-2">
                      {devices.map((device, idx) => (
                        <div
                          key={idx}
                          draggable
                          onDragStart={(e) => {
                            e.dataTransfer.setData(
                              "module",
                              JSON.stringify(device)
                            );
                          }}
                          className="p-2 bg-gradient-to-r from-teal-50 to-teal-100 rounded cursor-move hover:from-teal-100 hover:to-teal-200 text-gray-800 border border-teal-200 shadow-sm transition-all duration-200 transform hover:scale-[1.02]"
                        >
                          <div className="flex items-center">
                            <i
                              className={`fas ${device.icon} mr-2 text-teal-700`}
                            ></i>
                            <span className="font-medium">{device.name}</span>
                          </div>
                          <div className="text-sm text-teal-700">
                            {
                              device.ports.filter((p) => p.type === "input")
                                .length
                            }{" "}
                            in /{" "}
                            {
                              device.ports.filter((p) => p.type === "output")
                                .length
                            }{" "}
                            out
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )
              )}
            </div>
          </div>

          <div
            ref={workspaceRef}
            className="md:col-span-3 bg-white bg-opacity-80 p-4 rounded-lg shadow-lg h-[600px] relative overflow-hidden"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              const rect = e.currentTarget.getBoundingClientRect();
              const moduleData = e.dataTransfer.getData("module");
              if (moduleData) {
                const module = JSON.parse(moduleData);
                const position = {
                  x: (e.clientX - rect.left) / scale - pan.x,
                  y: (e.clientY - rect.top) / scale - pan.y,
                };
                handleDrop(module, position);
              }
            }}
          ></div>
        </div>
      </div>

      {showManual && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
            <div className="p-4 border-b flex justify-between items-center">
              <h2 className="text-xl font-bold text-teal-800">User Manual</h2>
              <div className="flex space-x-2">
                <button
                  onClick={generateManualPDF}
                  className="px-3 py-1 bg-teal-600 text-white rounded hover:bg-teal-700"
                  disabled={manualLoading}
                >
                  {manualLoading ? "Generating..." : "Download PDF"}
                </button>
                <button
                  onClick={printManual}
                  className="px-3 py-1 bg-teal-600 text-white rounded hover:bg-teal-700"
                >
                  Print
                </button>
                <button
                  onClick={() => setShowManual(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <i className="fas fa-times"></i>
                </button>
              </div>
            </div>
            <div className="p-4 overflow-y-auto max-h-[calc(90vh-4rem)]">
              <div className="space-y-6">
                {Object.entries(manualSections).map(([key, section]) => (
                  <div key={key} className="manual-section">
                    <h3 className="text-lg font-bold text-teal-800 mb-2">
                      {section.title}
                    </h3>
                    <div
                      dangerouslySetInnerHTML={{ __html: section.content }}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {error && (
        <div className="fixed bottom-4 right-4 bg-red-500 text-white px-4 py-2 rounded shadow-lg">
          {error}
        </div>
      )}

      <style jsx global>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
        
        @keyframes drawPath {
          from { stroke-dashoffset: 1000; }
          to { stroke-dashoffset: 0; }
        }

        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }

        .animate-drawPath {
          animation: drawPath 1s ease-out;
        }
      `}</style>
    </div>
  );
}

export default MainComponent;