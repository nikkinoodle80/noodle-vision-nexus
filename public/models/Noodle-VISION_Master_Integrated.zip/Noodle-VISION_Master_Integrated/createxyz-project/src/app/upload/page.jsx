"use client";
import React from "react";

function MainComponent() {
  const [files, setFiles] = React.useState([]);
  const [equipment, setEquipment] = React.useState([]);
  const [previewImage, setPreviewImage] = React.useState(null);
  const [error, setError] = React.useState(null);

  const handleFileUpload = async (event) => {
    try {
      const file = event.target.files[0];
      const { url, mimeType } = await upload({ file });

      if (mimeType.startsWith("image/")) {
        const { data } = await fetch(`/api/vision?url=${url}`);
        const equipment = data.equipment;
        setEquipment(equipment);
        setPreviewImage(url);
        setFiles([...files, file]);
      } else {
        setError("Please upload an image file.");
      }
    } catch (err) {
      console.error(err);
      setError("Error uploading file. Please try again.");
    }
  };

  const handleEquipmentDetails = (index, details) => {
    const updatedEquipment = [...equipment];
    updatedEquipment[index] = { ...updatedEquipment[index], ...details };
    setEquipment(updatedEquipment);
  };

  const handleSaveEquipment = () => {
    // Save the equipment to the user's personal library
    // This could involve making an API call or storing the data locally
    console.log("Saving equipment:", equipment);
  };

  return (
    <div className="bg-white py-8 px-4 md:px-8">
      <h1 className="text-4xl font-bold mb-8">Upload Equipment</h1>

      {/* File Upload Area */}
      <div className="bg-[#f5f5f5] p-8 rounded-md shadow-md mb-8">
        <h2 className="text-2xl font-bold mb-4">Upload Equipment Images</h2>
        <input
          type="file"
          accept="image/*"
          onChange={handleFileUpload}
          className="w-full px-4 py-2 mb-4 rounded-md"
        />
        {error && <div className="text-red-500 mb-4">{error}</div>}
      </div>

      {/* Equipment Details Form */}
      {equipment.map((item, index) => (
        <div
          key={index}
          className="bg-[#f5f5f5] p-8 rounded-md shadow-md mb-8 animate-fade-in"
        >
          <h2 className="text-2xl font-bold mb-4">
            {item.name} - {item.model}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor={`model-${index}`}
                className="block font-bold mb-2"
              >
                Model
              </label>
              <input
                type="text"
                id={`model-${index}`}
                name={`model-${index}`}
                defaultValue={item.model}
                onChange={(e) =>
                  handleEquipmentDetails(index, { model: e.target.value })
                }
                className="w-full px-4 py-2 rounded-md"
              />
            </div>
            <div>
              <label
                htmlFor={`specs-${index}`}
                className="block font-bold mb-2"
              >
                Specifications
              </label>
              <textarea
                id={`specs-${index}`}
                name={`specs-${index}`}
                defaultValue={item.specs}
                onChange={(e) =>
                  handleEquipmentDetails(index, { specs: e.target.value })
                }
                className="w-full px-4 py-2 rounded-md"
              ></textarea>
            </div>
          </div>
        </div>
      ))}

      {/* Preview Area */}
      {previewImage && (
        <div className="bg-[#f5f5f5] p-8 rounded-md shadow-md mb-8">
          <h2 className="text-2xl font-bold mb-4">Preview</h2>
          <img
            src={previewImage}
            alt="Equipment Preview"
            className="w-full h-auto mb-4"
          />
        </div>
      )}

      {/* Save Equipment Button */}
      <div className="flex justify-end">
        <button
          onClick={handleSaveEquipment}
          className="bg-[#121212] text-white px-6 py-3 rounded-md hover:bg-[#333] transition-colors duration-300"
        >
          Save Equipment
        </button>
      </div>

      <style jsx global>
        {`
          @keyframes fadeIn {
            0% {
              opacity: 0;
            }
            100% {
              opacity: 1;
            }
          }

          .animate-fade-in {
            animation: fadeIn 0.5s ease-in-out;
          }
        `}
      </style>
    </div>
  );
}

export default MainComponent;