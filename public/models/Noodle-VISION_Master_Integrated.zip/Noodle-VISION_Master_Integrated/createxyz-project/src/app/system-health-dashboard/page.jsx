"use client";
import React from "react";

function MainComponent() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [showDebugOverlay, setShowDebugOverlay] = useState(false);
  const [lastRefresh, setLastRefresh] = useState(new Date());
  const [refreshing, setRefreshing] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [refreshInterval, setRefreshInterval] = useState(60);
  const { data: user, loading } = useUser();
  const refreshTimerRef = useRef(null);

  const handleRefresh = useCallback(() => {
    setRefreshing(true);
    setLastRefresh(new Date());
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  }, []);

  const toggleDebugOverlay = () => {
    setShowDebugOverlay(!showDebugOverlay);
  };

  const toggleAutoRefresh = () => {
    setAutoRefresh(!autoRefresh);
  };

  useEffect(() => {
    if (autoRefresh) {
      refreshTimerRef.current = setInterval(() => {
        handleRefresh();
      }, refreshInterval * 1000);
    } else if (refreshTimerRef.current) {
      clearInterval(refreshTimerRef.current);
    }
    return () => {
      if (refreshTimerRef.current) {
        clearInterval(refreshTimerRef.current);
      }
    };
  }, [autoRefresh, refreshInterval, handleRefresh]);

  if (loading) return <div>Loading...</div>;
  if (!user || user.email !== "YOUR_ADMIN_EMAIL_HERE") {
    return (
      <div
        style={{
          color: "red",
          fontWeight: "bold",
          padding: 32,
          textAlign: "center",
        }}
      >
        Access Denied
      </div>
    );
  }

  const isAdmin =
    user.email &&
    (user.email.endsWith("@yourdomain.com") ||
      user.email === "admin@example.com");

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-[#F6F6F6] p-4 md:p-8 font-inter">
        <div className="max-w-4xl mx-auto bg-white rounded-lg border border-[#E4E7EA] p-6 md:p-8">
          <h1 className="text-2xl font-medium text-[#191919] mb-4">
            Access Denied
          </h1>
          <p className="mb-6 text-[#5D646C]">
            You don't have permission to view this page. This page is restricted
            to administrators only.
          </p>
          <a
            href="/"
            className="px-4 py-2 bg-[#6567EF] text-white rounded hover:bg-[#7A7CF0] font-medium"
          >
            Return to Home
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F6F6F6] font-inter">
      <div className="bg-white border-b border-[#E4E7EA]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:justify-between py-4 md:h-16 md:py-0">
            <div className="flex flex-col md:flex-row md:items-center">
              <div className="flex-shrink-0 flex items-center">
                <h1 className="text-xl font-medium text-[#191919]">
                  System Health Dashboard
                </h1>
              </div>
              <nav className="mt-2 md:mt-0 md:ml-6 flex flex-wrap gap-2 md:space-x-4">
                <button
                  onClick={() => setActiveTab("dashboard")}
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    activeTab === "dashboard"
                      ? "bg-[#E4E7EA] text-[#191919]"
                      : "text-[#5D646C] hover:text-[#191919]"
                  }`}
                >
                  <i className="fal fa-tachometer-alt mr-2"></i>
                  <span className="hidden sm:inline">Dashboard</span>
                </button>
                <button
                  onClick={() => setActiveTab("stripe")}
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    activeTab === "stripe"
                      ? "bg-[#E4E7EA] text-[#191919]"
                      : "text-[#5D646C] hover:text-[#191919]"
                  }`}
                >
                  <i className="fab fa-stripe mr-2"></i>
                  <span className="hidden sm:inline">Stripe</span>
                </button>
                <button
                  onClick={() => setActiveTab("devices")}
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    activeTab === "devices"
                      ? "bg-[#E4E7EA] text-[#191919]"
                      : "text-[#5D646C] hover:text-[#191919]"
                  }`}
                >
                  <i className="fal fa-laptop mr-2"></i>
                  <span className="hidden sm:inline">Devices</span>
                </button>
                <button
                  onClick={() => setActiveTab("adapters")}
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    activeTab === "adapters"
                      ? "bg-[#E4E7EA] text-[#191919]"
                      : "text-[#5D646C] hover:text-[#191919]"
                  }`}
                >
                  <i className="fal fa-plug mr-2"></i>
                  <span className="hidden sm:inline">Adapters</span>
                </button>
              </nav>
            </div>
            <div className="flex items-center mt-4 md:mt-0">
              <div className="flex items-center space-x-2 mr-4">
                <button
                  onClick={toggleAutoRefresh}
                  className={`p-2 rounded-md ${
                    autoRefresh
                      ? "bg-[#E4E7EA] text-[#191919]"
                      : "text-[#5D646C] hover:text-[#191919] hover:bg-[#F6F6F6]"
                  }`}
                  title={autoRefresh ? "Auto-refresh on" : "Auto-refresh off"}
                >
                  <i className="fal fa-clock"></i>
                </button>
                {autoRefresh && (
                  <select
                    value={refreshInterval}
                    onChange={(e) => setRefreshInterval(Number(e.target.value))}
                    className="text-xs border rounded p-1"
                  >
                    <option value="30">30s</option>
                    <option value="60">1m</option>
                    <option value="300">5m</option>
                    <option value="600">10m</option>
                  </select>
                )}
              </div>
              <button
                onClick={handleRefresh}
                disabled={refreshing}
                className={`mr-2 p-2 rounded-md ${
                  refreshing
                    ? "text-[#6567EF]"
                    : "text-[#5D646C] hover:text-[#191919] hover:bg-[#F6F6F6]"
                }`}
                title="Refresh data"
              >
                <i
                  className={`fal fa-sync-alt ${
                    refreshing ? "animate-spin" : ""
                  }`}
                ></i>
              </button>
              <button
                onClick={toggleDebugOverlay}
                className={`mr-2 p-2 rounded-md ${
                  showDebugOverlay
                    ? "bg-[#E4E7EA] text-[#191919]"
                    : "text-[#5D646C] hover:text-[#191919] hover:bg-[#F6F6F6]"
                }`}
                title="Toggle debug overlay"
              >
                <i className="fal fa-bug"></i>
              </button>
              <div className="relative">
                <div className="flex items-center">
                  <span className="hidden md:inline text-sm font-medium text-[#5D646C] mr-2">
                    {user.email}
                  </span>
                  <a
                    href="/account/logout"
                    className="text-sm text-[#6567EF] hover:text-[#191919]"
                  >
                    <span className="hidden md:inline">Sign Out</span>
                    <i className="fal fa-sign-out-alt md:hidden"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <h2 className="text-2xl font-medium text-[#191919] mb-2 sm:mb-0">
            {activeTab === "dashboard" && "System Health Overview"}
            {activeTab === "stripe" && "Stripe Connection Tester"}
            {activeTab === "devices" && "Device Selector"}
            {activeTab === "adapters" && "Adapter Visualizer"}
          </h2>
          <div className="flex items-center text-sm text-[#8C8C8C]">
            <i className="fal fa-history mr-2"></i>
            Last refreshed: {lastRefresh.toLocaleTimeString()}
            {autoRefresh && (
              <span className="ml-2 px-2 py-1 bg-[#E4E7EA] text-[#5D646C] text-xs rounded-full">
                Auto-refresh: {refreshInterval}s
              </span>
            )}
          </div>
        </div>

        {activeTab === "dashboard" && (
          <div className="bg-white border border-[#E4E7EA] rounded-lg overflow-hidden">
            <div className="p-4 bg-[#F6F6F6] border-b border-[#E4E7EA]">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-[#6567EF]">
                    System Health Overview
                  </h3>
                  <p className="text-sm text-[#5D646C]">
                    Monitoring critical system components and services
                  </p>
                </div>
                <div className="mt-2 sm:mt-0">
                  <button
                    onClick={handleRefresh}
                    className="px-3 py-1 bg-[#6567EF] text-white text-sm rounded hover:bg-[#7A7CF0] font-medium"
                  >
                    <i
                      className={`fal fa-sync-alt mr-1 ${
                        refreshing ? "animate-spin" : ""
                      }`}
                    ></i>
                    Refresh Now
                  </button>
                </div>
              </div>
            </div>
            <div className="p-6 text-[#5D646C]">
              <div className="flex items-center space-x-4">
                <i className="fal fa-server text-2xl text-[#6567EF]"></i>
                <span>All systems operational</span>
              </div>
              <div className="mt-4 flex flex-col md:flex-row gap-4">
                <div className="flex-1 bg-[#F6F6F6] rounded-lg p-4 border border-[#E4E7EA]">
                  <div className="flex items-center mb-2">
                    <i className="fal fa-database mr-2 text-[#6567EF]"></i>
                    <span className="font-medium text-[#191919]">Database</span>
                  </div>
                  <div className="text-[#5D646C]">Healthy</div>
                </div>
                <div className="flex-1 bg-[#F6F6F6] rounded-lg p-4 border border-[#E4E7EA]">
                  <div className="flex items-center mb-2">
                    <i className="fal fa-network-wired mr-2 text-[#6567EF]"></i>
                    <span className="font-medium text-[#191919]">API</span>
                  </div>
                  <div className="text-[#5D646C]">Healthy</div>
                </div>
                <div className="flex-1 bg-[#F6F6F6] rounded-lg p-4 border border-[#E4E7EA]">
                  <div className="flex items-center mb-2">
                    <i className="fal fa-credit-card mr-2 text-[#6567EF]"></i>
                    <span className="font-medium text-[#191919]">Payments</span>
                  </div>
                  <div className="text-[#5D646C]">Healthy</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "stripe" && (
          <div className="bg-white border border-[#E4E7EA] rounded-lg overflow-hidden">
            <div className="p-4 bg-[#F6F6F6] border-b border-[#E4E7EA]">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-[#6567EF]">
                    Stripe Integration Tests
                  </h3>
                  <p className="text-sm text-[#5D646C]">
                    Verify your Stripe API keys and webhook configuration
                  </p>
                </div>
              </div>
            </div>
            <div className="p-6 text-[#5D646C]">
              <div className="flex items-center space-x-4">
                <i className="fab fa-stripe-s text-2xl text-[#6567EF]"></i>
                <span>Stripe connection healthy</span>
              </div>
            </div>
          </div>
        )}

        {activeTab === "devices" && (
          <div className="bg-white border border-[#E4E7EA] rounded-lg overflow-hidden">
            <div className="p-4 bg-[#F6F6F6] border-b border-[#E4E7EA]">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-[#6567EF]">
                    Device Management
                  </h3>
                  <p className="text-sm text-[#5D646C]">
                    Browse and manage connected devices
                  </p>
                </div>
              </div>
            </div>
            <div className="p-6 text-[#5D646C]">
              <div className="flex items-center space-x-4">
                <i className="fal fa-laptop text-2xl text-[#6567EF]"></i>
                <span>All devices connected</span>
              </div>
            </div>
          </div>
        )}

        {activeTab === "adapters" && (
          <div className="bg-white border border-[#E4E7EA] rounded-lg overflow-hidden">
            <div className="p-4 bg-[#F6F6F6] border-b border-[#E4E7EA]">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-[#6567EF]">
                    Adapter Visualization
                  </h3>
                  <p className="text-sm text-[#5D646C]">
                    Visualize connection paths between devices
                  </p>
                </div>
              </div>
            </div>
            <div className="p-6 text-[#5D646C]">
              <div className="flex items-center space-x-4">
                <i className="fal fa-plug text-2xl text-[#6567EF]"></i>
                <span>All adapters functioning</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {showDebugOverlay && (
        <div
          className="fixed bottom-0 left-0 right-0 bg-[#191919] bg-opacity-90 text-white p-4 font-mono text-xs overflow-auto z-50"
          style={{ maxHeight: "30vh" }}
        >
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-medium">Debug Information</h3>
            <div className="flex space-x-2">
              <button
                onClick={handleRefresh}
                className="text-[#8C8C8C] hover:text-white px-2 py-1 rounded border border-[#5D646C]"
              >
                Refresh Data
              </button>
              <button
                onClick={toggleDebugOverlay}
                className="text-[#8C8C8C] hover:text-white"
              >
                <i className="fal fa-times"></i>
              </button>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            <div>
              <span className="text-[#6567EF]">User ID:</span> {user.id}
            </div>
            <div>
              <span className="text-[#6567EF]">Email:</span> {user.email}
            </div>
            <div>
              <span className="text-[#6567EF]">Last Refresh:</span>{" "}
              {lastRefresh.toISOString()}
            </div>
            <div>
              <span className="text-[#6567EF]">Active Tab:</span> {activeTab}
            </div>
            <div>
              <span className="text-[#6567EF]">Admin Status:</span>{" "}
              {isAdmin ? "Admin" : "Not Admin"}
            </div>
            <div>
              <span className="text-[#6567EF]">Auto Refresh:</span>{" "}
              {autoRefresh ? `Enabled (${refreshInterval}s)` : "Disabled"}
            </div>
            <div>
              <span className="text-[#6567EF]">Browser:</span>{" "}
              {typeof window !== "undefined"
                ? window.navigator.userAgent
                : "SSR"}
            </div>
            <div>
              <span className="text-[#6567EF]">Screen:</span>{" "}
              {typeof window !== "undefined"
                ? `${window.innerWidth}x${window.innerHeight}`
                : "Unknown"}
            </div>
          </div>
          <div className="mt-2 pt-2 border-t border-[#5D646C]">
            <div>
              <span className="text-[#00C48C]">API Endpoints:</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-1 mt-1">
              <div className="text-[#E4E7EA]">/api/system-health-check</div>
              <div className="text-[#E4E7EA]">/api/test-api-keys</div>
              <div className="text-[#E4E7EA]">/api/test-stripe-connection</div>
            </div>
          </div>
        </div>
      )}
      <style jsx global>{`
        .animate-spin {
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          0% { transform: rotate(0deg);}
          100% { transform: rotate(360deg);}
        }
      `}</style>
    </div>
  );
}

export default MainComponent;