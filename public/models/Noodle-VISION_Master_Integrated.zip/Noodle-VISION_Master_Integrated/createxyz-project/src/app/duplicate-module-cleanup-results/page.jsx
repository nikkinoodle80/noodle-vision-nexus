"use client";
import React from "react";
import Button from "../../components/button";

function MainComponent() {
  const [loading, setLoading] = React.useState(true);
  const [result, setResult] = React.useState(null);
  const [error, setError] = React.useState(null);

  React.useEffect(() => {
    async function runCleanup() {
      setLoading(true);
      setError(null);
      try {
        const response = await fetch("/api/remove-duplicate-modules", {
          method: "POST",
        });
        if (!response.ok) {
          throw new Error(
            `Failed to clean up modules: [${response.status}] ${response.statusText}`
          );
        }
        const data = await response.json();
        setResult(data);
      } catch (err) {
        console.error(err);
        setError(
          "Could not clean up duplicate modules. Please try again later."
        );
      } finally {
        setLoading(false);
      }
    }
    runCleanup();
  }, []);

  let content;
  if (loading) {
    content = (
      <div className="flex flex-col items-center justify-center py-16">
        <i className="fas fa-spinner fa-spin text-3xl text-[#6567EF] mb-4"></i>
        <div className="font-inter text-[#5D646C] text-lg">
          Cleaning up duplicate modules...
        </div>
      </div>
    );
  } else if (error) {
    content = (
      <div className="flex flex-col items-center justify-center py-16">
        <i className="fas fa-times-circle text-3xl text-[#E53E3E] mb-4"></i>
        <div className="font-inter text-[#E53E3E] text-lg mb-2">
          Cleanup failed
        </div>
        <div className="font-inter text-[#5D646C]">{error}</div>
        <a href="/dashboard" className="mt-6">
          <Button text="Return to Dashboard" highlighted={true} />
        </a>
      </div>
    );
  } else if (result && result.success) {
    const removed = Array.isArray(result.removed) ? result.removed : [];
    const kept = Array.isArray(result.kept) ? result.kept : [];
    content = (
      <div className="max-w-xl mx-auto bg-white rounded-lg shadow p-8 mt-12">
        <div className="flex flex-col items-center mb-6">
          <i className="fas fa-check-circle text-3xl text-[#6567EF] mb-2"></i>
          <div className="font-inter text-[#191919] text-xl mb-1">
            Cleanup Complete
          </div>
          <div className="font-inter text-[#5D646C] text-base">
            Duplicate modules have been removed.
          </div>
        </div>
        <div className="mb-6">
          <div className="font-inter text-[#191919] text-lg mb-2">Summary</div>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 bg-[#F6F6F6] rounded-lg p-4">
              <div className="font-inter text-[#5D646C] mb-1">
                Removed Modules
              </div>
              <ul className="list-disc pl-5 text-[#E53E3E] font-inter text-sm">
                {removed.length === 0 ? (
                  <li>No duplicates found</li>
                ) : (
                  removed.map((mod, idx) => (
                    <li key={idx}>{mod.name || mod.id || "Unnamed module"}</li>
                  ))
                )}
              </ul>
            </div>
            <div className="flex-1 bg-[#F6F6F6] rounded-lg p-4">
              <div className="font-inter text-[#5D646C] mb-1">Kept Modules</div>
              <ul className="list-disc pl-5 text-[#191919] font-inter text-sm">
                {kept.length === 0 ? (
                  <li>No modules kept</li>
                ) : (
                  kept.map((mod, idx) => (
                    <li key={idx}>{mod.name || mod.id || "Unnamed module"}</li>
                  ))
                )}
              </ul>
            </div>
          </div>
        </div>
        <div className="flex justify-center">
          <a href="/dashboard">
            <Button text="Return to Dashboard" highlighted={true} />
          </a>
        </div>
      </div>
    );
  } else {
    content = (
      <div className="flex flex-col items-center justify-center py-16">
        <i className="fas fa-exclamation-circle text-3xl text-[#E53E3E] mb-4"></i>
        <div className="font-inter text-[#E53E3E] text-lg mb-2">
          Unexpected error
        </div>
        <div className="font-inter text-[#5D646C]">
          Something went wrong. Please try again.
        </div>
        <a href="/dashboard" className="mt-6">
          <Button text="Return to Dashboard" highlighted={true} />
        </a>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F6F6F6] font-inter">
      <div className="max-w-2xl mx-auto py-8 px-4">{content}</div>
    </div>
  );
}

export default MainComponent;