"use client";
import React from "react";

function MainComponent() {
  const { data: user } = useUser();
  const [devicesOnCanvas, setDevicesOnCanvas] = React.useState([]);
  const receiverImageUrl =
    "https://ucarecdn.com/7e292465-4252-49b0-9d35-8411041bab08/-/format/auto/";

  // New state for canvas style
  const [canvasStyle, setCanvasStyle] = React.useState("neutral"); // 'neutral', 'studio', 'room'

  const canvasStyles = [
    {
      id: "neutral",
      name: "Neutral",
      bgClass: "bg-gray-700",
      borderClass: "border-gray-600",
    },
    {
      id: "studio",
      name: "Studio Dark",
      bgClass: "bg-slate-800",
      borderClass: "border-slate-700",
    },
    {
      id: "room",
      name: "Warm Room",
      bgClass: "bg-stone-700",
      borderClass: "border-stone-600",
    },
  ];

  const currentStyle =
    canvasStyles.find((style) => style.id === canvasStyle) || canvasStyles[0];

  // State for dragging
  const [draggingDevice, setDraggingDevice] = React.useState(null); // { id: deviceId, offsetX: number, offsetY: number }
  const canvasRef = React.useRef(null); // Ref for the canvas area to get its bounds

  const handleAddDeviceToCanvas = () => {
    const canvasRect = canvasRef.current
      ? canvasRef.current.getBoundingClientRect()
      : { left: 0, top: 0 };
    // Add new devices near the top-left of the canvas, slightly offset
    const initialX = 20 + (devicesOnCanvas.length % 5) * 30; // Basic staggering
    const initialY = 20 + Math.floor(devicesOnCanvas.length / 5) * 30;

    setDevicesOnCanvas((prevDevices) => [
      ...prevDevices,
      {
        id: Date.now(),
        imageUrl: receiverImageUrl,
        name: "Sample Receiver",
        x: initialX,
        y: initialY,
      },
    ]);
  };

  // Renamed from handleMouseDownOnDevice to handleDragStart
  const handleDragStart = (e, deviceId) => {
    const isTouchEvent = e.type.startsWith("touch");

    if (!isTouchEvent) {
      e.preventDefault(); // Prevent default image drag behavior for mouse
    }
    // For touch events, preventDefault is called in handleDragMove to allow other touch interactions like tap if drag doesn't occur.

    let clientX, clientY;
    if (isTouchEvent) {
      if (e.touches && e.touches.length > 0) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      } else {
        return; // No touch information
      }
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const device = devicesOnCanvas.find((d) => d.id === deviceId);
    if (!device || !canvasRef.current) return;

    const canvasRect = canvasRef.current.getBoundingClientRect();
    const offsetX = clientX - canvasRect.left - device.x;
    const offsetY = clientY - canvasRect.top - device.y;

    setDraggingDevice({ id: deviceId, offsetX, offsetY });
  };

  // Renamed from handleMouseMoveOnCanvas to handleDragMove
  const handleDragMove = (e) => {
    if (!draggingDevice || !canvasRef.current) return;

    // Prevent scrolling or other default actions while dragging
    e.preventDefault();

    let clientX, clientY;
    const isTouchEvent = e.type.startsWith("touch");
    if (isTouchEvent) {
      if (e.touches && e.touches.length > 0) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      } else {
        return; // No touch information
      }
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const canvasRect = canvasRef.current.getBoundingClientRect();
    let newX = clientX - canvasRect.left - draggingDevice.offsetX;
    let newY = clientY - canvasRect.top - draggingDevice.offsetY;

    const deviceWidth = 100; // Adjusted for smaller default device display
    const deviceHeight = 70; // Adjusted for smaller default device display

    newX = Math.max(0, Math.min(newX, canvasRect.width - deviceWidth));
    newY = Math.max(0, Math.min(newY, canvasRect.height - deviceHeight));

    setDevicesOnCanvas((prevDevices) =>
      prevDevices.map((d) =>
        d.id === draggingDevice.id ? { ...d, x: newX, y: newY } : d
      )
    );
  };

  // Renamed from handleMouseUpOnCanvas to handleDragEnd
  const handleDragEnd = () => {
    setDraggingDevice(null);
  };

  // Also add onMouseLeave to the canvas to stop dragging if mouse leaves the area
  const handleMouseLeaveCanvas = () => {
    // Optional: if you want dragging to stop when the mouse leaves the canvas area
    // setDraggingDevice(null); // Current behavior is to allow dragging outside canvas if mouse is still down
  };

  return (
    <div
      className="flex flex-col min-h-screen bg-gray-800 text-white font-roboto"
      onMouseMove={draggingDevice ? handleDragMove : null} // Attach mousemove and mouseup to the whole page for smoother dragging
      onMouseUp={draggingDevice ? handleDragEnd : null}
      onTouchMove={draggingDevice ? handleDragMove : null}
      onTouchEnd={draggingDevice ? handleDragEnd : null}
      onTouchCancel={draggingDevice ? handleDragEnd : null} // Handle touch cancel as well
    >
      <nav className="w-full bg-black bg-opacity-50 p-4 shadow-lg">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
          <a
            href="/"
            className="text-2xl font-bold text-[#00B2FF] hover:text-white transition-colors mb-2 md:mb-0"
          >
            Noodle-VISION  A/V Simulation
          </a>
          <div className="flex flex-wrap justify-center md:justify-end space-x-2 md:space-x-4 text-sm md:text-base">
            <a
              href="/devices"
              className="hover:text-[#00B2FF] transition-colors px-1 py-1 md:px-0"
            >
              Browse Devices
            </a>
            <a
              href="/blog"
              className="hover:text-[#00B2FF] transition-colors px-1 py-1 md:px-0"
            >
              Blog
            </a>
            <a
              href="/community"
              className="hover:text-[#00B2FF] transition-colors px-1 py-1 md:px-0"
            >
              Community
            </a>
            {user ? (
              <>
                <a
                  href="/my-gear"
                  className="hover:text-[#00B2FF] transition-colors px-1 py-1 md:px-0"
                >
                  My Gear
                </a>
                <a
                  href="/subscription"
                  className="hover:text-[#00B2FF] transition-colors px-1 py-1 md:px-0"
                >
                  Subscription
                </a>
                <a
                  href="/account/logout"
                  className="hover:text-[#00B2FF] transition-colors px-1 py-1 md:px-0"
                >
                  Sign Out
                </a>
              </>
            ) : (
              <>
                <a
                  href="/account/signin"
                  className="hover:text-[#00B2FF] transition-colors px-1 py-1 md:px-0"
                >
                  Sign In
                </a>
                <a
                  href="/account/signup"
                  className="bg-[#0072C6] text-white px-3 py-1 md:px-4 md:py-2 rounded-md hover:bg-[#0052A6] transition-colors text-xs md:text-sm"
                >
                  Sign Up
                </a>
              </>
            )}
          </div>
        </div>
      </nav>

      <main className="flex-grow flex flex-col items-center justify-center text-center p-4 md:p-8 bg-black bg-opacity-30">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-[#00B2FF] mb-4 md:mb-6">
          A/V Setup Simulator
        </h1>
        <p className="text-base sm:text-lg md:text-xl text-gray-300 mb-4 md:mb-6 max-w-md md:max-w-xl px-2">
          Visually plan your A/V setups!
        </p>

        <div className="mb-4 flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
          {canvasStyles.map((style) => (
            <button
              key={style.id}
              onClick={() => setCanvasStyle(style.id)}
              className={`px-3 py-1.5 md:px-4 md:py-2 rounded-md text-xs md:text-sm font-medium transition-colors w-full sm:w-auto
                ${
                  canvasStyle === style.id
                    ? "bg-[#0072C6] text-white"
                    : "bg-gray-600 hover:bg-gray-500 text-gray-300"
                }`}
            >
              {style.name}
            </button>
          ))}
        </div>

        <div
          ref={canvasRef}
          className={`border-2 border-solid ${currentStyle.borderClass} ${currentStyle.bgClass} rounded-lg p-2 sm:p-4 w-full max-w-xs sm:max-w-sm md:max-w-3xl min-h-[20rem] sm:min-h-[24rem] md:min-h-[32rem] relative overflow-hidden transition-colors duration-300`}
          onMouseLeave={handleMouseLeaveCanvas} // Stop dragging if mouse leaves canvas
          // Note: onMouseMove and onMouseUp are on the parent div for smoother dragging outside device bounds
        >
          <button
            className="absolute top-2 left-2 sm:top-4 sm:left-4 bg-[#0072C6] text-white font-bold py-1.5 px-3 sm:py-2 sm:px-4 rounded-lg text-xs sm:text-sm hover:bg-[#0052A6] transition-colors duration-300 shadow-xl z-10"
            onClick={handleAddDeviceToCanvas}
          >
            Add Device
          </button>
          {/* Devices are absolutely positioned within this relative container */}
          {devicesOnCanvas.map((device) => (
            <div
              key={device.id}
              className="m-1 p-0.5 sm:m-2 sm:p-1 border border-gray-500 rounded bg-gray-600 shadow-lg touch-none" // Added touch-none to potentially help with scrolling issues on some browsers for the element itself
              title={device.name}
              style={{
                position: "absolute",
                left: `${device.x}px`,
                top: `${device.y}px`,
                cursor:
                  draggingDevice && draggingDevice.id === device.id
                    ? "grabbing"
                    : "grab",
                width: "100px", // Smaller base width for devices
                height: "auto", // Maintain aspect ratio
              }}
              onMouseDown={(e) => handleDragStart(e, device.id)}
              onTouchStart={(e) => handleDragStart(e, device.id)}
            >
              <img
                src={device.imageUrl}
                alt={device.name}
                className="w-full h-auto object-contain rounded select-none pointer-events-none" // Added pointer-events-none to img to ensure parent div captures drag events
              />
            </div>
          ))}
          {devicesOnCanvas.length === 0 && (
            <p className="text-gray-400 text-center text-sm sm:text-base w-full self-center absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 p-2">
              Canvas is empty. Click "Add Device" to start.
            </p>
          )}
        </div>
      </main>

      <footer className="w-full bg-black bg-opacity-70 p-4 text-center mt-8 md:mt-12">
        <p className="text-xs sm:text-sm text-gray-400">
          &copy; 2025 A/V Connect. All rights reserved.
        </p>
        <p className="text-[10px] sm:text-xs text-gray-500">
          High-tech connections, simplified.
        </p>
      </footer>
    </div>
  );
}

export default MainComponent;