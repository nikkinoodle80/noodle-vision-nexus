"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [recentConfigurations, setRecentConfigurations] = useState([]);
  const [loadingConfigs, setLoadingConfigs] = useState(true);
  const [error, setError] = useState(null);
  const [usageStats, setUsageStats] = useState({ used: 0, limit: 100 });
  const router = useRouter();

  useEffect(() => {
    if (!userLoading && !user) {
      router.push("/account/signin?callbackUrl=/dashboard");
    }
  }, [user, userLoading, router]);

  useEffect(() => {
    if (user) {
      const fetchConfigurations = async () => {
        try {
          setLoadingConfigs(true);
          const response = await fetch("/api/get-user-configurations", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ userId: user.id }),
          });

          if (!response.ok) {
            throw new Error(`Error: ${response.status} ${response.statusText}`);
          }

          const data = await response.json();
          if (data.error) {
            throw new Error(data.error);
          }

          setRecentConfigurations(data.configurations || []);

          const usageResponse = await fetch("/api/get-user-subscription", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ userId: user.id }),
          });

          if (usageResponse.ok) {
            const usageData = await usageResponse.json();
            if (usageData.subscription) {
              setUsageStats({
                used: usageData.subscription.usedCredits || 0,
                limit: usageData.subscription.totalCredits || 100,
              });
            }
          }
        } catch (err) {
          console.error("Failed to load configurations:", err);
          setError(
            "Failed to load your recent configurations. Please try again later."
          );
        } finally {
          setLoadingConfigs(false);
        }
      };

      fetchConfigurations();
    }
  }, [user]);

  if (userLoading) {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-900 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="ml-3 text-gray-700 dark:text-gray-300">Loading...</p>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <nav className="bg-white dark:bg-gray-800 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">
                  Hardware Compatibility
                </h1>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                <a
                  href="/dashboard"
                  className="border-blue-500 text-gray-900 dark:text-white inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                >
                  Dashboard
                </a>
                <a
                  href="/device-library"
                  className="border-transparent text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-white inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                >
                  Device Library
                </a>
                <a
                  href="/ar-simulator"
                  className="border-transparent text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-white inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                >
                  AR Simulator
                </a>
                <a
                  href="/"
                  className="border-transparent text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-white inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                >
                  User Guide
                </a>
              </div>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:items-center">
              <button
                onClick={() => signOut({ callbackUrl: "/", redirect: true })}
                className="ml-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Sign Out
              </button>
            </div>
            <div className="flex items-center sm:hidden">
              <button className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500">
                <i className="fas fa-bars"></i>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="bg-white dark:bg-gray-800 overflow-hidden shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                    Welcome back, {user.name || user.email.split("@")[0]}
                  </h2>
                  <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                    Here's an overview of your hardware compatibility tools and
                    recent activity
                  </p>
                </div>
                <div className="mt-4 md:mt-0 w-full md:w-64">
                  <></>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="px-4 py-6 sm:px-0">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
            Quick Access
          </h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div className="bg-white dark:bg-gray-800 overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0 bg-blue-500 rounded-md p-3">
                    <i className="fas fa-server text-white"></i>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">
                        Device Library
                      </dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900 dark:text-white">
                          Browse Devices
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 dark:bg-gray-700 px-5 py-3">
                <div className="text-sm">
                  <a
                    href="/device-library"
                    className="font-medium text-blue-600 dark:text-blue-400 hover:text-blue-500"
                  >
                    View all devices →
                  </a>
                </div>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0 bg-purple-500 rounded-md p-3">
                    <i className="fas fa-vr-cardboard text-white"></i>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">
                        AR Simulator
                      </dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900 dark:text-white">
                          Visualize in AR
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 dark:bg-gray-700 px-5 py-3">
                <div className="text-sm">
                  <a
                    href="/ar-simulator"
                    className="font-medium text-blue-600 dark:text-blue-400 hover:text-blue-500"
                  >
                    Launch simulator →
                  </a>
                </div>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0 bg-green-500 rounded-md p-3">
                    <i className="fas fa-brain text-white"></i>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">
                        AI Analysis
                      </dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900 dark:text-white">
                          Check Compatibility
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 dark:bg-gray-700 px-5 py-3">
                <div className="text-sm">
                  <a
                    href="/analyze"
                    className="font-medium text-blue-600 dark:text-blue-400 hover:text-blue-500"
                  >
                    Analyze hardware →
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="px-4 py-6 sm:px-0">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
            Recent Configurations
          </h3>

          {loadingConfigs ? (
            <div className="flex justify-center items-center py-12">
              <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
              <p className="ml-3 text-gray-700 dark:text-gray-300">
                Loading your configurations...
              </p>
            </div>
          ) : error ? (
            <div className="bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 p-4 rounded-md">
              {error}
            </div>
          ) : recentConfigurations.length > 0 ? (
            <div className="bg-white dark:bg-gray-800 shadow overflow-hidden sm:rounded-md">
              <ul className="divide-y divide-gray-200 dark:divide-gray-700">
                {recentConfigurations.slice(0, 5).map((config) => (
                  <li key={config.id}>
                    <a
                      href={`/configuration/${config.id}`}
                      className="block hover:bg-gray-50 dark:hover:bg-gray-700"
                    >
                      <div className="px-4 py-4 sm:px-6">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium text-blue-600 dark:text-blue-400 truncate">
                            {config.name}
                          </p>
                          <div className="ml-2 flex-shrink-0 flex">
                            <p className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100">
                              {config.deviceCount} devices
                            </p>
                          </div>
                        </div>
                        <div className="mt-2 sm:flex sm:justify-between">
                          <div className="sm:flex">
                            <p className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                              <i className="fas fa-tag flex-shrink-0 mr-1.5 text-gray-400 dark:text-gray-500"></i>
                              {config.type || "Standard Configuration"}
                            </p>
                          </div>
                          <div className="mt-2 flex items-center text-sm text-gray-500 dark:text-gray-400 sm:mt-0">
                            <i className="fas fa-calendar flex-shrink-0 mr-1.5 text-gray-400 dark:text-gray-500"></i>
                            <p>
                              Created on{" "}
                              {new Date(config.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </div>
                    </a>
                  </li>
                ))}
              </ul>
              {recentConfigurations.length > 5 && (
                <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 text-right sm:px-6">
                  <a
                    href="/configurations"
                    className="font-medium text-blue-600 dark:text-blue-400 hover:text-blue-500"
                  >
                    View all configurations →
                  </a>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 shadow overflow-hidden sm:rounded-md p-6 text-center">
              <div className="text-gray-500 dark:text-gray-400 mb-4">
                <i className="fas fa-folder-open text-4xl"></i>
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">
                No configurations yet
              </h3>
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                Start by creating a new hardware configuration
              </p>
              <a
                href="/ar-simulator"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
              >
                Create your first configuration
              </a>
            </div>
          )}
        </div>

        <div className="px-4 py-6 sm:px-0">
          <div className="bg-blue-50 dark:bg-blue-900 rounded-lg p-6">
            <h3 className="text-lg font-medium text-blue-800 dark:text-blue-200 mb-3">
              Tips for Getting Started
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <i className="fas fa-search text-blue-500 mt-1"></i>
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-blue-800 dark:text-blue-200">
                    Browse the Device Library
                  </h4>
                  <p className="mt-1 text-sm text-blue-700 dark:text-blue-300">
                    Explore our comprehensive collection of hardware devices,
                    adapters, and cables.
                  </p>
                </div>
              </div>
              <div className="flex">
                <div className="flex-shrink-0">
                  <i className="fas fa-vr-cardboard text-blue-500 mt-1"></i>
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-blue-800 dark:text-blue-200">
                    Try the AR Simulator
                  </h4>
                  <p className="mt-1 text-sm text-blue-700 dark:text-blue-300">
                    Visualize how devices would look and connect in your actual
                    physical space.
                  </p>
                </div>
              </div>
              <div className="flex">
                <div className="flex-shrink-0">
                  <i className="fas fa-save text-blue-500 mt-1"></i>
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-blue-800 dark:text-blue-200">
                    Save Your Configurations
                  </h4>
                  <p className="mt-1 text-sm text-blue-700 dark:text-blue-300">
                    Create and save hardware setups to reference later or share
                    with colleagues.
                  </p>
                </div>
              </div>
              <div className="flex">
                <div className="flex-shrink-0">
                  <i className="fas fa-brain text-blue-500 mt-1"></i>
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-blue-800 dark:text-blue-200">
                    Get AI-Powered Analysis
                  </h4>
                  <p className="mt-1 text-sm text-blue-700 dark:text-blue-300">
                    Use our AI to check compatibility between devices, adapters,
                    and cables.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default MainComponent;