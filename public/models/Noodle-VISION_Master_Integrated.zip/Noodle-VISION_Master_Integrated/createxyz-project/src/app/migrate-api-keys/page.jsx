"use client";
import React from "react";

function MainComponent() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [envVariables, setEnvVariables] = useState(null);
  const [configStatus, setConfigStatus] = useState(null);
  const { data: user, loading: userLoading } = useUser();

  useEffect(() => {
    async function fetchConfigStatus() {
      if (!user) return;

      try {
        const response = await fetch("/api/get-stripe-configuration", {
          method: "POST",
        });

        if (!response.ok) {
          throw new Error(`Error fetching configuration: ${response.status}`);
        }

        const data = await response.json();
        setConfigStatus(data);
      } catch (err) {
        console.error("Error fetching configuration status:", err);
        setError(
          "Failed to load your current configuration. Please try again."
        );
      }
    }

    fetchConfigStatus();
  }, [user]);

  const handleMigration = async () => {
    setLoading(true);
    setError(null);
    setSuccess(false);

    try {
      const response = await fetch("/api/migrate-to-env-variables", {
        method: "POST",
        body: JSON.stringify({}),
      });

      if (!response.ok) {
        throw new Error(`Error during migration: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        setSuccess(true);
        setEnvVariables(data.environmentVariables);

        const configResponse = await fetch("/api/get-stripe-configuration", {
          method: "POST",
        });

        if (configResponse.ok) {
          const configData = await configResponse.json();
          setConfigStatus(configData);
        }
      } else {
        throw new Error(data.error || "Migration failed");
      }
    } catch (err) {
      console.error("Migration error:", err);
      setError(
        err.message ||
          "Failed to migrate to environment variables. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-[#F6F6F6] py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <div className="text-center">
            <h1 className="text-3xl font-inter text-[#191919]">Loading...</h1>
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F6F6F6] py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <div className="text-center">
            <h1 className="text-3xl font-inter text-[#191919]">
              Authentication Required
            </h1>
            <p className="mt-2 text-lg font-inter text-[#5D646C]">
              Please{" "}
              <a
                href="/account/signin?callbackUrl=/security/migrate-keys"
                className="text-[#6567EF] hover:text-[#5D646C]"
              >
                sign in
              </a>{" "}
              to access this page.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F6F6F6] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-inter text-[#191919]">
            Migrate Stripe API Keys to Environment Variables
          </h1>
          <p className="mt-2 text-lg font-inter text-[#5D646C]">
            Enhance your application's security by moving sensitive API keys to
            environment variables
          </p>
        </div>

        <div className="bg-white shadow rounded-lg overflow-hidden mb-8">
          <div className="px-6 py-8">
            <h2 className="text-xl font-inter text-[#191919] mb-4">
              Why Use Environment Variables?
            </h2>

            <div className="bg-[#E4E7EA] border-l-4 border-[#6567EF] p-4 mb-6">
              <div className="flex">
                <div className="flex-shrink-0">
                  <i className="fa fa-info-circle text-[#6567EF]"></i>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-inter text-[#5D646C]">
                    Environment variables provide several security benefits:
                  </p>
                  <ul className="mt-2 list-disc pl-5 text-sm font-inter text-[#5D646C]">
                    <li>
                      API keys are not stored in your database, reducing risk of
                      data breaches
                    </li>
                    <li>
                      Keys are not included in your source code or version
                      control
                    </li>
                    <li>
                      Different environments (development, staging, production)
                      can use different keys
                    </li>
                    <li>
                      Access to environment variables can be restricted at the
                      server level
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <h2 className="text-xl font-inter text-[#191919] mb-4">
              Current Configuration Status
            </h2>

            {configStatus ? (
              <div className="mb-6">
                {configStatus.exists ? (
                  <div
                    className={`p-4 border-l-4 ${
                      configStatus.config?.useEnvVariables
                        ? "bg-[#E4E7EA] border-[#6567EF]"
                        : "bg-[#E4E7EA] border-[#6567EF]"
                    }`}
                  >
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <i
                          className={`fa ${
                            configStatus.config?.useEnvVariables
                              ? "fa-check-circle text-[#6567EF]"
                              : "fa-exclamation-triangle text-[#6567EF]"
                          }`}
                        ></i>
                      </div>
                      <div className="ml-3">
                        <p
                          className={`text-sm font-inter ${
                            configStatus.config?.useEnvVariables
                              ? "text-[#5D646C]"
                              : "text-[#5D646C]"
                          }`}
                        >
                          {configStatus.config?.useEnvVariables
                            ? "Your Stripe configuration is already using environment variables."
                            : "Your Stripe API keys are currently stored in the database."}
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-[#F6F6F6] border-l-4 border-[#8C8C8C]">
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <i className="fa fa-info-circle text-[#8C8C8C]"></i>
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-inter text-[#5D646C]">
                          No Stripe configuration found. Please set up your
                          Stripe configuration first.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="animate-pulse flex space-x-4 mb-6">
                <div className="flex-1 space-y-4 py-1">
                  <div className="h-4 bg-[#E4E7EA] rounded w-3/4"></div>
                  <div className="h-4 bg-[#E4E7EA] rounded"></div>
                  <div className="h-4 bg-[#E4E7EA] rounded w-5/6"></div>
                </div>
              </div>
            )}

            {configStatus?.exists && !configStatus.config?.useEnvVariables && (
              <>
                <div className="bg-[#E4E7EA] border-l-4 border-[#6567EF] p-4 mb-6">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <i className="fa fa-exclamation-circle text-[#6567EF]"></i>
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-inter text-[#5D646C]">
                        Warning: One-Way Process
                      </p>
                      <p className="text-sm font-inter text-[#5D646C] mt-1">
                        Migrating to environment variables is a one-way process.
                        After migration, your API keys will no longer be stored
                        in the database. Make sure to save your keys in a secure
                        location before proceeding.
                      </p>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleMigration}
                  disabled={loading}
                  className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-inter text-white bg-[#6567EF] hover:bg-[#5D646C] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#6567EF] disabled:bg-[#8C8C8C]"
                >
                  {loading ? (
                    <>
                      <i className="fa fa-circle-notch fa-spin mr-2"></i>
                      Migrating...
                    </>
                  ) : (
                    <>
                      <i className="fa fa-shield-alt mr-2"></i>
                      Migrate to Environment Variables
                    </>
                  )}
                </button>
              </>
            )}

            {error && (
              <div className="mt-4 p-4 bg-[#E4E7EA] border-l-4 border-[#6567EF]">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <i className="fa fa-times-circle text-[#6567EF]"></i>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-inter text-[#5D646C]">{error}</p>
                  </div>
                </div>
              </div>
            )}

            {success && envVariables && (
              <div className="mt-6">
                <div className="p-4 bg-[#E4E7EA] border-l-4 border-[#6567EF] mb-4">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <i className="fa fa-check-circle text-[#6567EF]"></i>
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-inter text-[#5D646C]">
                        Migration Successful!
                      </p>
                      <p className="text-sm font-inter text-[#5D646C] mt-1">
                        Your Stripe configuration has been migrated to use
                        environment variables.
                      </p>
                    </div>
                  </div>
                </div>

                <h3 className="text-lg font-inter text-[#191919] mb-3">
                  Next Steps: Set Up Environment Variables
                </h3>
                <p className="text-sm font-inter text-[#5D646C] mb-4">
                  You need to set the following environment variables in your
                  hosting environment:
                </p>

                <div className="bg-[#191919] rounded-md p-4 overflow-x-auto">
                  <pre className="text-sm font-inter text-[#F6F6F6]">
                    {Object.entries(envVariables).map(
                      ([key, value]) => `${value}="your_${key}_here"\n`
                    )}
                  </pre>
                </div>

                <div className="mt-4">
                  <h4 className="text-md font-inter text-[#191919] mb-2">
                    How to Set Environment Variables
                  </h4>

                  <div className="space-y-3 text-sm font-inter text-[#5D646C]">
                    <p>
                      <strong>Vercel:</strong> Go to Project Settings →
                      Environment Variables and add each variable.
                    </p>
                    <p>
                      <strong>Netlify:</strong> Go to Site Settings → Build &
                      Deploy → Environment → Environment Variables.
                    </p>
                    <p>
                      <strong>Heroku:</strong> Use{" "}
                      <code className="bg-[#E4E7EA] px-1 py-0.5 rounded">
                        heroku config:set VARIABLE_NAME=value
                      </code>
                      .
                    </p>
                    <p>
                      <strong>Railway:</strong> Go to your project, click
                      Variables, and add each variable.
                    </p>
                    <p>
                      <strong>Local Development:</strong> Create a{" "}
                      <code className="bg-[#E4E7EA] px-1 py-0.5 rounded">
                        .env
                      </code>{" "}
                      file (don't commit this to version control).
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="text-center text-sm font-inter text-[#8C8C8C]">
          <p>
            Need help? Visit our{" "}
            <a href="#" className="text-[#6567EF] hover:text-[#5D646C]">
              documentation
            </a>{" "}
            or{" "}
            <a href="#" className="text-[#6567EF] hover:text-[#5D646C]">
              contact support
            </a>
            .
          </p>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;