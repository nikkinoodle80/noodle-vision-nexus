"use client";
import React from "react";

function MainComponent() {
  const categories = [
    {
      title: "Home Office",
      description: "Optimize your home office setup with these solutions.",
      link: "/solutions/home-office",
    },
    {
      title: "Gaming",
      description: "Enhance your gaming experience with these setups.",
      link: "/solutions/gaming",
    },
    {
      title: "Entertainment",
      description: "Create the perfect entertainment system.",
      link: "/solutions/entertainment",
    },
    {
      title: "Smart Home",
      description: "Integrate smart devices seamlessly.",
      link: "/solutions/smart-home",
    },
  ];

  return (
    <div className="min-h-screen bg-[#1D1D1F] text-white font-inter">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-semibold mb-8 text-center">
          Pre-Made Device Connection Setups
        </h1>
        <p className="text-center text-[#86868B] mb-12">
          Explore our curated solutions to quickly find the setup that fits your
          needs.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {categories.map((category, index) => (
            <div
              key={index}
              className="bg-[#2A2A2A] p-6 rounded-lg hover:bg-[#3A3A3A] transition-colors"
            >
              <h2 className="text-2xl font-semibold mb-4">{category.title}</h2>
              <p className="text-[#86868B] mb-4">{category.description}</p>
              <a
                href={category.link}
                className="text-blue-500 hover:text-blue-400"
              >
                View Details
              </a>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default MainComponent;