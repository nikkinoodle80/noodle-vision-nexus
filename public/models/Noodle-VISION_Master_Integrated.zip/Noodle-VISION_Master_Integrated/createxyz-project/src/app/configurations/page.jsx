"use client";
import React from "react";

function MainComponent() {
  const [configurations, setConfigurations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [configToDelete, setConfigToDelete] = useState(null);
  const { data: user, loading: userLoading } = useUser();

  useEffect(() => {
    const fetchConfigurations = async () => {
      if (!user) return;

      try {
        setLoading(true);
        const response = await fetch("/api/get-user-configurations", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ userId: user.id }),
        });

        if (!response.ok) {
          throw new Error(`Error: ${response.status} ${response.statusText}`);
        }

        const data = await response.json();
        if (data.error) {
          throw new Error(data.error);
        }

        setConfigurations(data.configurations || []);
      } catch (err) {
        console.error("Failed to load configurations:", err);
        setError(
          "Failed to load your saved configurations. Please try again later."
        );
      } finally {
        setLoading(false);
      }
    };

    if (!userLoading && user) {
      fetchConfigurations();
    } else if (!userLoading && !user) {
      setLoading(false);
    }
  }, [user, userLoading]);

  const handleDeleteConfig = async () => {
    if (!configToDelete) return;

    try {
      const response = await fetch("/api/save-user-configuration", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: user.id,
          configurationId: configToDelete.id,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.status} ${response.statusText}`);
      }

      setConfigurations(
        configurations.filter((config) => config.id !== configToDelete.id)
      );
      setDeleteModalOpen(false);
      setConfigToDelete(null);
    } catch (err) {
      console.error("Failed to delete configuration:", err);
      setError("Failed to delete configuration. Please try again later.");
    }
  };

  const openDeleteModal = (config) => {
    setConfigToDelete(config);
    setDeleteModalOpen(true);
  };

  const loadConfiguration = (configId) => {
    window.location.href = `/simulator?configId=${configId}`;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-900 py-8 px-4 md:px-8 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="ml-3 text-gray-700 dark:text-gray-300 font-inter">
          Loading user data...
        </p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-900 py-8 px-4 md:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
            Saved Configurations
          </h1>
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
              Sign in to view your configurations
            </h2>
            <p className="text-gray-700 dark:text-gray-300 font-inter mb-6">
              You need to be signed in to view and manage your saved hardware
              configurations.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/account/signin?callbackUrl=/configurations"
                className="bg-blue-600 hover:bg-blue-700 text-white font-inter py-2 px-6 rounded-md transition-colors"
              >
                Sign In
              </a>
              <a
                href="/account/signup?callbackUrl=/configurations"
                className="bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-white font-inter py-2 px-6 rounded-md transition-colors"
              >
                Create Account
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 py-8 px-4 md:px-8">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Your Saved Configurations
          </h1>
          <p className="text-gray-700 dark:text-gray-300 font-inter">
            View, load, and manage your saved hardware setups
          </p>
        </header>

        {error && (
          <div className="mb-6 bg-red-100 dark:bg-red-900 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-200 px-4 py-3 rounded-md">
            <p className="font-inter">{error}</p>
            <button
              onClick={() => setError(null)}
              className="ml-2 text-red-700 dark:text-red-200 hover:text-red-900 dark:hover:text-red-100"
            >
              <i className="fas fa-times"></i>
            </button>
          </div>
        )}

        {loading ? (
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 flex justify-center items-center">
            <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="ml-3 text-gray-700 dark:text-gray-300 font-inter">
              Loading your configurations...
            </p>
          </div>
        ) : configurations.length === 0 ? (
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 text-center">
            <div className="text-gray-400 dark:text-gray-500 mb-4">
              <i className="fas fa-folder-open text-5xl"></i>
            </div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              No configurations yet
            </h2>
            <p className="text-gray-700 dark:text-gray-300 font-inter mb-6">
              You haven't saved any hardware configurations yet. Create one in
              the simulator!
            </p>
            <a
              href="/simulator"
              className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-inter py-2 px-6 rounded-md transition-colors"
            >
              <i className="fas fa-plus mr-2"></i> Create New Configuration
            </a>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {configurations.map((config) => (
              <div
                key={config.id}
                className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden"
              >
                <div className="p-6">
                  <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2 truncate">
                    {config.name}
                  </h2>
                  <p className="text-gray-500 dark:text-gray-400 text-sm font-inter mb-4">
                    <i className="fas fa-calendar-alt mr-1"></i>{" "}
                    {formatDate(config.createdAt)}
                  </p>

                  <div className="mb-4">
                    <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                      Devices ({config.devices?.length || 0})
                    </h3>
                    <div className="max-h-24 overflow-y-auto">
                      {config.devices && config.devices.length > 0 ? (
                        <ul className="text-sm text-gray-600 dark:text-gray-400 font-inter">
                          {config.devices.map((device, idx) => (
                            <li key={idx} className="mb-1 flex items-center">
                              <i className="fas fa-hdd mr-2 text-gray-400 dark:text-gray-500"></i>
                              {device.name || device.model}
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-sm text-gray-500 dark:text-gray-400 font-inter italic">
                          No devices in this configuration
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="mb-4">
                    <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                      Connections ({config.connections?.length || 0})
                    </h3>
                    <div className="max-h-24 overflow-y-auto">
                      {config.connections && config.connections.length > 0 ? (
                        <ul className="text-sm text-gray-600 dark:text-gray-400 font-inter">
                          {config.connections.map((connection, idx) => (
                            <li key={idx} className="mb-1 flex items-center">
                              <i className="fas fa-plug mr-2 text-gray-400 dark:text-gray-500"></i>
                              {connection.type || "Connection"} {idx + 1}
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-sm text-gray-500 dark:text-gray-400 font-inter italic">
                          No connections in this configuration
                        </p>
                      )}
                    </div>
                  </div>

                  {config.notes && (
                    <div className="mb-4">
                      <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1">
                        Notes
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400 font-inter line-clamp-2">
                        {config.notes}
                      </p>
                    </div>
                  )}
                </div>

                <div className="px-6 py-4 bg-gray-50 dark:bg-gray-750 border-t border-gray-200 dark:border-gray-700 flex justify-between">
                  <button
                    onClick={() => loadConfiguration(config.id)}
                    className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 font-inter text-sm flex items-center"
                  >
                    <i className="fas fa-play-circle mr-1"></i> Load
                  </button>
                  <button
                    onClick={() => openDeleteModal(config)}
                    className="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 font-inter text-sm flex items-center"
                  >
                    <i className="fas fa-trash-alt mr-1"></i> Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-8 text-center">
          <a
            href="/simulator"
            className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-inter py-2 px-6 rounded-md transition-colors"
          >
            <i className="fas fa-plus mr-2"></i> Create New Configuration
          </a>
        </div>
      </div>

      {deleteModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
              Delete Configuration
            </h3>
            <p className="text-gray-700 dark:text-gray-300 font-inter mb-6">
              Are you sure you want to delete "{configToDelete?.name}"? This
              action cannot be undone.
            </p>
            <div className="flex justify-end space-x-4">
              <button
                onClick={() => setDeleteModalOpen(false)}
                className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 font-inter"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteConfig}
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 font-inter"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default MainComponent;