"use client";
import React from "react";

function MainComponent() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 flex items-center justify-center">
      <div className="text-center p-8">
        <h1 className="text-3xl font-inter font-bold text-gray-900 dark:text-white mb-4">
          Modular System
        </h1>
        <p className="text-gray-700 dark:text-gray-300 mb-6">
          Explore our modular system to customize your device connections.
        </p>
        <a
          href="/"
          className="px-6 py-2 bg-blue-600 text-white rounded-md font-inter hover:bg-blue-700 transition-colors"
        >
          Return to Home
        </a>
      </div>
    </div>
  );
}

export default MainComponent;