"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [selectedKey, setSelectedKey] = useState("");
  const [secretValue, setSecretValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [keyStatus, setKeyStatus] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [userSubscription, setUserSubscription] = useState(null);
  const [subscriptionLoading, setSubscriptionLoading] = useState(true);

  const keyOptions = [
    { value: "ANTHROPIC_API_KEY", label: "Anthropic API Key" },
    { value: "STRIPE_SECRET_KEY", label: "Stripe Secret Key" },
    { value: "STRIPE_WEBHOOK_SECRET", label: "Stripe Webhook Secret" },
    { value: "GOOGLE_API_KEY", label: "Google API Key" },
    { value: "OPENAI_API_KEY", label: "OpenAI API Key" },
  ];

  useEffect(() => {
    setSecretValue("");
    setError(null);
    setSuccess(null);
    setShowConfirmation(false);
  }, [selectedKey]);

  useEffect(() => {
    async function fetchSubscription() {
      if (user) {
        try {
          const response = await fetch("/api/get-user-subscription", {
            method: "POST",
          });
          const data = await response.json();

          if (data.success) {
            setUserSubscription(data.subscription);
          }
        } catch (err) {
          console.error("Error fetching subscription:", err);
        } finally {
          setSubscriptionLoading(false);
        }
      }
    }

    fetchSubscription();
  }, [user]);

  const isAdmin = user && user.role === "admin";
  const isEnterprise =
    userSubscription &&
    userSubscription.plan &&
    userSubscription.plan.name === "Enterprise";

  const handleTestKey = async () => {
    if (!selectedKey || !secretValue) {
      setError("Please select a key and enter a value");
      return;
    }

    setIsTesting(true);
    setError(null);
    setSuccess(null);

    try {
      const response = await fetch("/api/configure-secrets", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "test",
          key: selectedKey,
          value: secretValue,
        }),
      });

      const data = await response.json();

      if (data.success) {
        setSuccess(`Key tested successfully: ${selectedKey}`);
        setKeyStatus((prev) => ({
          ...prev,
          [selectedKey]: {
            ...prev[selectedKey],
            tested: true,
            testTimestamp: new Date().toISOString(),
          },
        }));
      } else {
        setError(`Test failed: ${data.error || "Unknown error"}`);
      }
    } catch (err) {
      setError(`Error testing key: ${err.message}`);
    } finally {
      setIsTesting(false);
    }
  };

  const handleSaveKey = async () => {
    if (!selectedKey || !secretValue) {
      setError("Please select a key and enter a value");
      return;
    }

    if (keyStatus[selectedKey]?.exists && !showConfirmation) {
      setShowConfirmation(true);
      return;
    }

    setIsLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const response = await fetch("/api/configure-secrets", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "set",
          key: selectedKey,
          value: secretValue,
        }),
      });

      const data = await response.json();

      if (data.success) {
        setSuccess(`Key saved successfully: ${selectedKey}`);
        setKeyStatus((prev) => ({
          ...prev,
          [selectedKey]: {
            exists: true,
            lastUpdated: new Date().toISOString(),
          },
        }));
        setSecretValue("");
        setShowConfirmation(false);
      } else {
        setError(`Save failed: ${data.error || "Unknown error"}`);
      }
    } catch (err) {
      setError(`Error saving key: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  if (userLoading || subscriptionLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-pulse text-xl font-semibold text-gray-700 dark:text-gray-300">
          Loading...
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col items-center justify-center p-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 max-w-md w-full">
          <h1 className="text-2xl font-bold text-red-600 dark:text-red-400 mb-4">
            Access Denied
          </h1>
          <p className="text-gray-700 dark:text-gray-300 mb-6">
            You must be logged in to access this page.
          </p>
          <a
            href="/account/signin?callbackUrl=/admin/secrets"
            className="block w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded text-center"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  if (!isAdmin && !isEnterprise) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col items-center justify-center p-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 max-w-md w-full">
          <h1 className="text-2xl font-bold text-red-600 dark:text-red-400 mb-4">
            Enterprise Access Required
          </h1>
          <p className="text-gray-700 dark:text-gray-300 mb-6">
            API key management is only available for Enterprise subscription
            users.
          </p>
          <div className="space-y-4">
            <a
              href="/pricing"
              className="block w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded text-center"
            >
              View Enterprise Plans
            </a>
            <a
              href="/"
              className="block w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded text-center"
            >
              Return to Home
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            API Key Management
          </h1>
          <a
            href="/"
            className="text-blue-600 dark:text-blue-400 hover:underline flex items-center"
          >
            <i className="fas fa-arrow-left mr-2"></i>
            Back to Dashboard
          </a>
        </div>

        <div className="bg-blue-50 dark:bg-blue-900/20 border-l-4 border-blue-500 p-4 mb-8">
          <div className="flex items-start">
            <i className="fas fa-info-circle text-blue-500 mt-1 mr-3"></i>
            <div>
              <h3 className="text-lg font-medium text-blue-800 dark:text-blue-400">
                Enterprise Feature
              </h3>
              <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
                API key management is an Enterprise subscription feature. This
                allows you to integrate our platform with your own systems and
                applications.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-red-50 dark:bg-red-900/20 border-l-4 border-red-500 p-4 mb-8">
          <div className="flex items-start">
            <i className="fas fa-exclamation-triangle text-red-500 mt-1 mr-3"></i>
            <div>
              <h3 className="text-lg font-medium text-red-800 dark:text-red-400">
                Security Warning
              </h3>
              <p className="text-sm text-red-700 dark:text-red-300 mt-1">
                This page contains sensitive information. API keys provide
                access to paid services and should be treated as passwords.
                Never share these keys or commit them to public repositories.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
            Configure API Keys
          </h2>

          <div className="space-y-4">
            <div>
              <label
                htmlFor="keyName"
                className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
              >
                Key Name
              </label>
              <select
                id="keyName"
                value={selectedKey}
                onChange={(e) => setSelectedKey(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
              >
                <option value="">Select a key</option>
                {keyOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              {keyStatus[selectedKey]?.exists && (
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  Last updated:{" "}
                  {new Date(
                    keyStatus[selectedKey].lastUpdated
                  ).toLocaleString()}
                </p>
              )}
            </div>

            <div>
              <label
                htmlFor="secretValue"
                className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
              >
                Secret Value
              </label>
              <div className="relative">
                <input
                  id="secretValue"
                  type={showPassword ? "text" : "password"}
                  value={secretValue}
                  onChange={(e) => setSecretValue(e.target.value)}
                  placeholder="Enter API key value"
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-500"
                >
                  <i
                    className={`fas ${
                      showPassword ? "fa-eye-slash" : "fa-eye"
                    }`}
                  ></i>
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 dark:bg-red-900/20 border-l-4 border-red-500 p-3">
                <p className="text-sm text-red-700 dark:text-red-300">
                  {error}
                </p>
              </div>
            )}

            {success && (
              <div className="bg-green-50 dark:bg-green-900/20 border-l-4 border-green-500 p-3">
                <p className="text-sm text-green-700 dark:text-green-300">
                  {success}
                </p>
              </div>
            )}

            {showConfirmation && (
              <div className="bg-yellow-50 dark:bg-yellow-900/20 border-l-4 border-yellow-500 p-3">
                <p className="text-sm text-yellow-700 dark:text-yellow-300 mb-2">
                  This key already exists. Are you sure you want to update it?
                </p>
                <div className="flex space-x-2">
                  <button
                    onClick={handleSaveKey}
                    className="px-3 py-1 bg-yellow-500 hover:bg-yellow-600 text-white text-sm rounded"
                  >
                    Confirm Update
                  </button>
                  <button
                    onClick={() => setShowConfirmation(false)}
                    className="px-3 py-1 bg-gray-300 hover:bg-gray-400 dark:bg-gray-600 dark:hover:bg-gray-700 text-gray-800 dark:text-white text-sm rounded"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            <div className="flex space-x-4 pt-2">
              <button
                onClick={handleTestKey}
                disabled={
                  !selectedKey || !secretValue || isTesting || isLoading
                }
                className={`px-4 py-2 rounded-md text-white font-medium flex items-center ${
                  !selectedKey || !secretValue || isTesting
                    ? "bg-gray-400 cursor-not-allowed"
                    : "bg-blue-600 hover:bg-blue-700"
                }`}
              >
                {isTesting ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Testing...
                  </>
                ) : (
                  <>
                    <i className="fas fa-vial mr-2"></i>
                    Test Key
                  </>
                )}
              </button>

              <button
                onClick={handleSaveKey}
                disabled={
                  !selectedKey || !secretValue || isLoading || isTesting
                }
                className={`px-4 py-2 rounded-md text-white font-medium flex items-center ${
                  !selectedKey || !secretValue || isLoading
                    ? "bg-gray-400 cursor-not-allowed"
                    : "bg-green-600 hover:bg-green-700"
                }`}
              >
                {isLoading ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Saving...
                  </>
                ) : (
                  <>
                    <i className="fas fa-save mr-2"></i>
                    Save Key
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
            Best Practices
          </h2>

          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 flex items-center">
                <i className="fas fa-shield-alt text-blue-500 mr-2"></i>
                Security Guidelines
              </h3>
              <ul className="mt-2 space-y-2 text-gray-700 dark:text-gray-300">
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>
                    Never share API keys in public repositories, chat
                    applications, or emails
                  </span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>
                    Rotate keys periodically (every 30-90 days) to minimize risk
                    from potential leaks
                  </span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>
                    Use different API keys for development and production
                    environments
                  </span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 flex items-center">
                <i className="fas fa-tachometer-alt text-blue-500 mr-2"></i>
                Usage and Rate Limits
              </h3>
              <ul className="mt-2 space-y-2 text-gray-700 dark:text-gray-300">
                <li className="flex items-start">
                  <i className="fas fa-info-circle text-blue-500 mt-1 mr-2"></i>
                  <span>Anthropic API: 100 requests per minute per key</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-info-circle text-blue-500 mt-1 mr-2"></i>
                  <span>
                    Stripe API: No strict rate limit, but excessive requests may
                    be throttled
                  </span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-info-circle text-blue-500 mt-1 mr-2"></i>
                  <span>
                    Google APIs: Varies by service, typically 10,000 requests
                    per day
                  </span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 flex items-center">
                <i className="fas fa-book text-blue-500 mr-2"></i>
                Additional Resources
              </h3>
              <ul className="mt-2 space-y-2 text-gray-700 dark:text-gray-300">
                <li className="flex items-start">
                  <i className="fas fa-external-link-alt text-blue-500 mt-1 mr-2"></i>
                  <a
                    href="https://docs.anthropic.com/claude/reference/getting-started-with-the-api"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    Anthropic API Documentation
                  </a>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-external-link-alt text-blue-500 mt-1 mr-2"></i>
                  <a
                    href="https://stripe.com/docs/api"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    Stripe API Documentation
                  </a>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-external-link-alt text-blue-500 mt-1 mr-2"></i>
                  <a
                    href="https://cloud.google.com/apis/docs/overview"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    Google API Documentation
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;