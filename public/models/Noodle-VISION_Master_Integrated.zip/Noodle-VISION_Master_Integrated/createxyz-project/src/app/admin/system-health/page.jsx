"use client";
import React from "react";
import DeviceSelector from "../../components/device-selector";
import SystemHealthDashboard from "../../components/system-health-dashboard";
import StripeConnectionTester from "../../components/stripe-connection-tester";
import DeviceSelector from "../../components/device-selector";
import AdapterVisualizer from "../../components/adapter-visualizer";
import AdapterVisualizer from "../../components/adapter-visualizer";

function MainComponent() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [showDebugOverlay, setShowDebugOverlay] = useState(false);
  const [lastRefresh, setLastRefresh] = useState(new Date());
  const [refreshing, setRefreshing] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [refreshInterval, setRefreshInterval] = useState(60); // seconds
  const { data: user, loading } = useUser();
  const refreshTimerRef = useRef(null);

  const handleRefresh = useCallback(() => {
    setRefreshing(true);
    setLastRefresh(new Date());

    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  }, []);

  const toggleDebugOverlay = () => {
    setShowDebugOverlay(!showDebugOverlay);
  };

  const toggleAutoRefresh = () => {
    setAutoRefresh(!autoRefresh);
  };

  useEffect(() => {
    if (autoRefresh) {
      refreshTimerRef.current = setInterval(() => {
        handleRefresh();
      }, refreshInterval * 1000);
    } else if (refreshTimerRef.current) {
      clearInterval(refreshTimerRef.current);
    }

    return () => {
      if (refreshTimerRef.current) {
        clearInterval(refreshTimerRef.current);
      }
    };
  }, [autoRefresh, refreshInterval, handleRefresh]);

  if (loading) return <div>Loading...</div>;
  if (!user || user.email !== "YOUR_ADMIN_EMAIL_HERE") {
    return (
      <div
        style={{
          color: "red",
          fontWeight: "bold",
          padding: 32,
          textAlign: "center",
        }}
      >
        Access Denied
      </div>
    );
  }

  const isAdmin =
    user.email &&
    (user.email.endsWith("@yourdomain.com") ||
      user.email === "admin@example.com");

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gray-50 p-4 md:p-8">
        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow p-6 md:p-8">
          <h1 className="text-xl md:text-2xl font-medium text-red-600 mb-4">
            Access Denied
          </h1>
          <p className="mb-6">
            You don't have permission to view this page. This page is restricted
            to administrators only.
          </p>
          <a
            href="/"
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Return to Home
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:justify-between py-4 md:h-16 md:py-0">
            <div className="flex flex-col md:flex-row md:items-center">
              <div className="flex-shrink-0 flex items-center">
                <h1 className="text-xl font-medium text-gray-900">
                  Admin Dashboard
                </h1>
              </div>
              <nav className="mt-2 md:mt-0 md:ml-6 flex flex-wrap gap-2 md:space-x-4">
                <button
                  onClick={() => setActiveTab("dashboard")}
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    activeTab === "dashboard"
                      ? "bg-blue-100 text-blue-700"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  <i className="fas fa-tachometer-alt mr-2"></i>
                  <span className="hidden sm:inline">Dashboard</span>
                </button>
                <button
                  onClick={() => setActiveTab("stripe")}
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    activeTab === "stripe"
                      ? "bg-blue-100 text-blue-700"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  <i className="fab fa-stripe mr-2"></i>
                  <span className="hidden sm:inline">Stripe</span>
                </button>
                <button
                  onClick={() => setActiveTab("devices")}
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    activeTab === "devices"
                      ? "bg-blue-100 text-blue-700"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  <i className="fas fa-laptop mr-2"></i>
                  <span className="hidden sm:inline">Devices</span>
                </button>
                <button
                  onClick={() => setActiveTab("adapters")}
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    activeTab === "adapters"
                      ? "bg-blue-100 text-blue-700"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  <i className="fas fa-plug mr-2"></i>
                  <span className="hidden sm:inline">Adapters</span>
                </button>
              </nav>
            </div>
            <div className="flex items-center mt-4 md:mt-0">
              <div className="flex items-center space-x-2 mr-4">
                <button
                  onClick={toggleAutoRefresh}
                  className={`p-2 rounded-md ${
                    autoRefresh
                      ? "bg-green-100 text-green-700"
                      : "text-gray-500 hover:text-gray-700 hover:bg-gray-100"
                  }`}
                  title={autoRefresh ? "Auto-refresh on" : "Auto-refresh off"}
                >
                  <i
                    className={`fas fa-${autoRefresh ? "clock" : "clock"}`}
                  ></i>
                </button>
                {autoRefresh && (
                  <select
                    value={refreshInterval}
                    onChange={(e) => setRefreshInterval(Number(e.target.value))}
                    className="text-xs border rounded p-1"
                  >
                    <option value="30">30s</option>
                    <option value="60">1m</option>
                    <option value="300">5m</option>
                    <option value="600">10m</option>
                  </select>
                )}
              </div>
              <button
                onClick={handleRefresh}
                disabled={refreshing}
                className={`mr-2 p-2 rounded-md ${
                  refreshing
                    ? "text-blue-500"
                    : "text-gray-500 hover:text-gray-700 hover:bg-gray-100"
                }`}
                title="Refresh data"
              >
                <i
                  className={`fas fa-sync-alt ${
                    refreshing ? "animate-spin" : ""
                  }`}
                ></i>
              </button>
              <button
                onClick={toggleDebugOverlay}
                className={`mr-2 p-2 rounded-md ${
                  showDebugOverlay
                    ? "bg-blue-100 text-blue-700"
                    : "text-gray-500 hover:text-gray-700 hover:bg-gray-100"
                }`}
                title="Toggle debug overlay"
              >
                <i className="fas fa-bug"></i>
              </button>
              <div className="relative">
                <div className="flex items-center">
                  <span className="hidden md:inline text-sm font-medium text-gray-700 mr-2">
                    {user.email}
                  </span>
                  <a
                    href="/account/logout"
                    className="text-sm text-red-600 hover:text-red-800"
                  >
                    <span className="hidden md:inline">Sign Out</span>
                    <i className="fas fa-sign-out-alt md:hidden"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <h2 className="text-xl md:text-2xl font-medium text-gray-900 mb-2 sm:mb-0">
            {activeTab === "dashboard" && "System Health Dashboard"}
            {activeTab === "stripe" && "Stripe Connection Tester"}
            {activeTab === "devices" && "Device Selector"}
            {activeTab === "adapters" && "Adapter Visualizer"}
          </h2>
          <div className="flex items-center text-sm text-gray-500">
            <i className="fas fa-history mr-2"></i>
            Last refreshed: {lastRefresh.toLocaleTimeString()}
            {autoRefresh && (
              <span className="ml-2 px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                Auto-refresh: {refreshInterval}s
              </span>
            )}
          </div>
        </div>

        {activeTab === "dashboard" && (
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="p-4 bg-blue-50 border-b border-blue-100">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-blue-800">
                    System Health Overview
                  </h3>
                  <p className="text-sm text-blue-600">
                    Monitoring critical system components and services
                  </p>
                </div>
                <div className="mt-2 sm:mt-0">
                  <button
                    onClick={handleRefresh}
                    className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 flex items-center"
                  >
                    <i
                      className={`fas fa-sync-alt mr-1 ${
                        refreshing ? "animate-spin" : ""
                      }`}
                    ></i>
                    Refresh Now
                  </button>
                </div>
              </div>
            </div>
            <SystemHealthDashboard />
          </div>
        )}

        {activeTab === "stripe" && (
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="p-4 bg-purple-50 border-b border-purple-100">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-purple-800">
                    Stripe Integration Tests
                  </h3>
                  <p className="text-sm text-purple-600">
                    Verify your Stripe API keys and webhook configuration
                  </p>
                </div>
              </div>
            </div>
            <StripeConnectionTester />
          </div>
        )}

        {activeTab === "devices" && (
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="p-4 bg-green-50 border-b border-green-100">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-green-800">
                    Device Management
                  </h3>
                  <p className="text-sm text-green-600">
                    Browse and manage connected devices
                  </p>
                </div>
              </div>
            </div>
            <div className="p-6">
              <DeviceSelector />
            </div>
          </div>
        )}

        {activeTab === "adapters" && (
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="p-4 bg-amber-50 border-b border-amber-100">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-amber-800">
                    Adapter Visualization
                  </h3>
                  <p className="text-sm text-amber-600">
                    Visualize connection paths between devices
                  </p>
                </div>
              </div>
            </div>
            <div className="p-6">
              <AdapterVisualizer />
            </div>
          </div>
        )}
      </div>

      {showDebugOverlay && (
        <div
          className="fixed bottom-0 left-0 right-0 bg-gray-900 bg-opacity-90 text-white p-4 font-mono text-xs overflow-auto z-50"
          style={{ maxHeight: "30vh" }}
        >
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-medium">Debug Information</h3>
            <div className="flex space-x-2">
              <button
                onClick={handleRefresh}
                className="text-gray-400 hover:text-white px-2 py-1 rounded border border-gray-700"
              >
                Refresh Data
              </button>
              <button
                onClick={toggleDebugOverlay}
                className="text-gray-400 hover:text-white"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            <div>
              <span className="text-blue-400">User ID:</span> {user.id}
            </div>
            <div>
              <span className="text-blue-400">Email:</span> {user.email}
            </div>
            <div>
              <span className="text-blue-400">Last Refresh:</span>{" "}
              {lastRefresh.toISOString()}
            </div>
            <div>
              <span className="text-blue-400">Active Tab:</span> {activeTab}
            </div>
            <div>
              <span className="text-blue-400">Admin Status:</span>{" "}
              {isAdmin ? "Admin" : "Not Admin"}
            </div>
            <div>
              <span className="text-blue-400">Auto Refresh:</span>{" "}
              {autoRefresh ? `Enabled (${refreshInterval}s)` : "Disabled"}
            </div>
            <div>
              <span className="text-blue-400">Browser:</span>{" "}
              {typeof window !== "undefined"
                ? window.navigator.userAgent
                : "SSR"}
            </div>
            <div>
              <span className="text-blue-400">Screen:</span>{" "}
              {typeof window !== "undefined"
                ? `${window.innerWidth}x${window.innerHeight}`
                : "Unknown"}
            </div>
          </div>
          <div className="mt-2 pt-2 border-t border-gray-700">
            <div>
              <span className="text-green-400">API Endpoints:</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-1 mt-1">
              <div className="text-gray-300">/api/system-health-check</div>
              <div className="text-gray-300">/api/test-api-keys</div>
              <div className="text-gray-300">/api/test-stripe-connection</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default MainComponent;