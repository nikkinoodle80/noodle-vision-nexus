"use client";
import React from "react";

// Assuming useUser is available globally or via context
// Assuming useAuth is available globally or via context

function MainComponent() {
  const [searchQuery, setSearchQuery] = React.useState("");
  const [selectedDevices, setSelectedDevices] = React.useState([]);
  const [searchResults, setSearchResults] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  const [checkingCompatibility, setCheckingCompatibility] =
    React.useState(false);
  const [error, setError] = React.useState(null);
  const [compatibilityResults, setCompatibilityResults] = React.useState(null);
  const [purchaseRecommendations, setPurchaseRecommendations] = React.useState(
    []
  );
  const { data: user } = useUser(); // Assuming useUser hook exists

  const searchProducts = React.useCallback(async () => {
    if (!searchQuery.trim()) return;

    setLoading(true);
    setError(null);
    setSearchResults([]);
    setCompatibilityResults(null);
    try {
      const response = await fetch(
        `/integrations/product-search/search?q=${encodeURIComponent(
          searchQuery
        )}`
      );
      if (!response.ok) {
        throw new Error(
          `Failed to fetch products: ${response.status} ${response.statusText}`
        );
      }
      const data = await response.json();

      // Make data handling more flexible
      if (Array.isArray(data)) {
        // Check if the response itself is the array
        setSearchResults(data);
      } else if (data && Array.isArray(data.data)) {
        // Original check
        setSearchResults(data.data);
      } else {
        // Log the unexpected structure and set an error
        console.error(
          "API response was not an array and did not contain a 'data' array:",
          data
        );
        setSearchResults([]);
        setError("Received unexpected data format from the server."); // Updated error message
      }
    } catch (err) {
      console.error(err);
      setError("Failed to search products. Please try again.");
      setSearchResults([]); // Ensure it's an empty array on error
    } finally {
      setLoading(false);
    }
  }, [searchQuery]);

  const addDevice = React.useCallback((device) => {
    setSelectedDevices((prev) => {
      if (prev.find((d) => d.product_id === device.product_id)) {
        return prev;
      }
      // Extract only necessary info if needed, but keep structure for now
      return [...prev, device];
    });
  }, []);

  const removeDevice = React.useCallback((productId) => {
    setSelectedDevices((prev) =>
      prev.filter((d) => d.product_id !== productId)
    );
    setCompatibilityResults(null);
  }, []);

  const checkCompatibility = React.useCallback(async () => {
    if (selectedDevices.length < 2) {
      setError("Please select at least two devices to check compatibility.");
      return;
    }
    setCheckingCompatibility(true);
    setError(null);
    setCompatibilityResults(null);
    try {
      const response = await fetch("/api/analyze-vr-compatibility", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ devices: selectedDevices }),
      });

      if (!response.ok) {
        const errorData = await response.text();
        throw new Error(
          `Compatibility check failed: ${response.status} ${response.statusText}. ${errorData}`
        );
      }

      const results = await response.json();
      setCompatibilityResults(results);
      setPurchaseRecommendations(results.recommendations || []);
    } catch (err) {
      console.error(err);
      setError("Failed to check compatibility. Please try again.");
      setCompatibilityResults({
        compatible: false,
        issues: ["Error during compatibility check."],
      });
    } finally {
      setCheckingCompatibility(false);
    }
  }, [selectedDevices]);

  const renderSearchResults = () => {
    if (loading)
      return (
        <div className="text-center py-4 text-[#5D646C]">
          Loading results...
        </div>
      );
    // Display error message if search failed or format was invalid
    if (error && searchResults.length === 0) {
      // Use the error state directly which might now be "Received unexpected data format..."
      return <div className="text-center py-4 text-red-600">{error}</div>;
    }

    // Check if searchResults is an array before mapping (this check remains important)
    if (!Array.isArray(searchResults)) {
      console.error(
        "Error: searchResults state is not an array after processing API response.",
        searchResults
      );
      // Show a generic error if searchResults isn't an array for some reason
      return (
        <div className="text-center py-4 text-red-600">
          Error displaying search results.
        </div>
      );
    }
    if (searchResults.length === 0 && !loading)
      return (
        <div className="text-center py-4 text-[#8C8C8C]">
          No products found. Try another search.
        </div>
      );

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
        {searchResults.map((device) => {
          const isAdded = selectedDevices.some(
            (d) => d.product_id === device.product_id
          );
          const buttonClasses = `mt-3 w-full py-2 rounded-lg text-sm font-medium transition-colors ${
            isAdded
              ? "bg-[#E4E7EA] text-[#8C8C8C] cursor-not-allowed"
              : "bg-[#6567EF] text-white hover:bg-[#4f51d1]"
          }`;
          const deviceImage =
            device.product_photos?.[0] ||
            "https://via.placeholder.com/150?text=No+Image";
          const devicePrice = device.offer?.price;

          return (
            <div
              key={device.product_id}
              className="bg-white p-4 rounded-lg flex flex-col justify-between border border-[#E4E7EA]"
            >
              <div>
                <img
                  src={deviceImage}
                  alt={`Product image for ${device.product_title}`}
                  className="w-full h-32 object-contain mb-2 rounded"
                />
                <h3
                  className="text-[#191919] font-medium truncate"
                  title={device.product_title}
                >
                  {device.product_title}
                </h3>
                {devicePrice && (
                  <p className="text-[#5D646C] text-sm mt-1">{devicePrice}</p>
                )}
              </div>
              <button
                onClick={() => addDevice(device)}
                disabled={isAdded}
                className={buttonClasses}
              >
                {isAdded ? "Added" : "Add to Setup"}
              </button>
            </div>
          );
        })}
      </div>
    );
  };

  const renderSelectedDevices = () => {
    if (selectedDevices.length === 0) {
      return (
        <p className="text-[#8C8C8C] text-center py-4">
          No devices added yet. Add some from the search results.
        </p>
      );
    }

    return (
      <div className="space-y-3">
        {selectedDevices.map((device) => {
          const deviceImage =
            device.product_photos?.[0] ||
            "https://via.placeholder.com/50?text=N/A";
          return (
            <div
              key={device.product_id}
              className="bg-white p-3 rounded-lg flex items-center justify-between border border-[#E4E7EA]"
            >
              <div className="flex items-center gap-3 overflow-hidden">
                <img
                  src={deviceImage}
                  alt={`Selected device: ${device.product_title}`}
                  className="w-10 h-10 object-contain rounded flex-shrink-0"
                />
                <span
                  className="text-[#191919] truncate"
                  title={device.product_title}
                >
                  {device.product_title}
                </span>
              </div>
              <button
                onClick={() => removeDevice(device.product_id)}
                className="text-red-600 hover:text-red-800 text-sm font-medium px-2 py-1 rounded transition-colors flex-shrink-0 ml-2"
              >
                Remove
              </button>
            </div>
          );
        })}
      </div>
    );
  };

  const renderCompatibilityResults = () => {
    if (checkingCompatibility) {
      return (
        <div className="text-center py-4 text-[#5D646C]">
          Checking compatibility...
        </div>
      );
    }
    // Display general compatibility error if check failed
    if (
      error &&
      !checkingCompatibility &&
      compatibilityResults?.issues?.includes(
        "Error during compatibility check."
      )
    ) {
      return (
        <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      );
    }
    if (!compatibilityResults) return null;

    const isCompatible = compatibilityResults.compatible;
    const resultBg = isCompatible ? "bg-green-50" : "bg-red-50";
    const resultBorder = isCompatible ? "border-green-200" : "border-red-200";
    const resultTitleColor = isCompatible ? "text-green-700" : "text-red-700";
    const resultTextColor = isCompatible ? "text-green-600" : "text-red-600";

    return (
      <div className={`mt-4 p-4 rounded-lg border ${resultBg} ${resultBorder}`}>
        <h3 className={`text-lg font-medium ${resultTitleColor}`}>
          Compatibility Check: {isCompatible ? "Compatible!" : "Issues Found"}
        </h3>
        {compatibilityResults.issues &&
          compatibilityResults.issues.length > 0 && (
            <ul
              className={`list-disc list-inside mt-2 ${resultTextColor} text-sm`}
            >
              {compatibilityResults.issues.map((issue, index) => (
                <li key={index}>{issue}</li>
              ))}
            </ul>
          )}
        {compatibilityResults.notes && (
          <p className="mt-2 text-[#5D646C] text-sm">
            {compatibilityResults.notes}
          </p>
        )}
        {purchaseRecommendations.length > 0 && (
          <div className="mt-4 pt-3 border-t border-[#E4E7EA]">
            <h4 className="font-medium text-[#191919]">Recommendations:</h4>
            <ul className="list-disc list-inside text-[#5D646C] text-sm mt-1">
              {purchaseRecommendations.map((rec, index) => (
                <li key={index}>{rec}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    );
  };

  const searchButtonClasses = `bg-[#6567EF] text-white px-6 py-2 rounded-lg font-medium hover:bg-[#4f51d1] transition-colors ${
    loading || !searchQuery.trim() ? "opacity-50 cursor-not-allowed" : ""
  }`;
  const checkButtonClasses = `w-full bg-[#6567EF] text-white px-6 py-3 rounded-lg font-medium hover:bg-[#4f51d1] transition-colors ${
    checkingCompatibility || selectedDevices.length < 2
      ? "opacity-50 cursor-not-allowed"
      : ""
  }`;

  return (
    <div className="font-inter bg-white text-[#191919] min-h-screen p-4 md:p-8">
      <h1 className="text-2xl md:text-3xl font-medium mb-6 text-center text-[#191919]">
        Interactive Setup Simulator
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-[#F6F6F6] rounded-lg p-6 border border-[#E4E7EA]">
          <h2 className="text-xl font-medium mb-4 text-[#191919]">
            1. Find Your Devices
          </h2>
          <div className="flex flex-col sm:flex-row gap-3 mb-6">
            <input
              type="text"
              name="deviceSearch"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && searchProducts()}
              placeholder="Search for TVs, consoles, adapters..."
              className="flex-1 bg-white text-[#191919] px-4 py-2 rounded-lg border border-[#E4E7EA] focus:outline-none focus:ring-2 focus:ring-[#6567EF] focus:border-transparent"
            />
            <button
              onClick={searchProducts}
              disabled={loading || !searchQuery.trim()}
              className={searchButtonClasses}
            >
              {loading ? "Searching..." : "Search"}
            </button>
          </div>
          <div>{renderSearchResults()}</div>
        </div>

        <div className="bg-[#F6F6F6] rounded-lg p-6 border border-[#E4E7EA] flex flex-col">
          <h2 className="text-xl font-medium mb-4 text-[#191919]">
            2. Your Setup
          </h2>
          <div className="flex-grow overflow-y-auto mb-4 pr-2 -mr-2 max-h-96">
            {renderSelectedDevices()}
          </div>

          {selectedDevices.length >= 2 && (
            <div className="mt-auto pt-4 border-t border-[#E4E7EA]">
              <h2 className="text-xl font-medium mb-4 text-[#191919]">
                3. Check Compatibility
              </h2>
              <button
                onClick={checkCompatibility}
                disabled={checkingCompatibility || selectedDevices.length < 2}
                className={checkButtonClasses}
              >
                {checkingCompatibility ? "Checking..." : "Check Compatibility"}
              </button>
              <div className="mt-4">{renderCompatibilityResults()}</div>
            </div>
          )}
          {selectedDevices.length < 2 && (
            <p className="text-[#8C8C8C] text-sm text-center mt-auto pt-4 border-t border-[#E4E7EA]">
              Add at least two devices to check compatibility.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

export default MainComponent;