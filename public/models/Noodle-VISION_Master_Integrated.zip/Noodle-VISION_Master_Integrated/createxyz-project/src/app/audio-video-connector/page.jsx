"use client";
import React from "react";
import DeviceSelector from "../../components/device-selector";
import DeviceSelector from "../../components/device-selector";
import InteractiveEquipmentRack from "../../components/interactive-equipment-rack";
import InteractiveEquipmentRack from "../../components/interactive-equipment-rack";
import { useHandleStreamResponse } from "../utilities/runtime-helpers";

function MainComponent() {
  const [error, setError] = React.useState(null);
  const [loading, setLoading] = React.useState(false);
  const [devices, setDevices] = React.useState([]);
  const [selectedDevice, setSelectedDevice] = React.useState(null);
  const [sourceDevice, setSourceDevice] = React.useState(null);
  const [targetDevice, setTargetDevice] = React.useState(null);
  const [adapters, setAdapters] = React.useState([]);
  const [connections, setConnections] = React.useState([]);
  const [selectedPorts, setSelectedPorts] = React.useState({
    source: null,
    target: null,
  });
  const [connectionQuality, setConnectionQuality] = React.useState(85);
  const [showAdapterSelector, setShowAdapterSelector] = React.useState(false);
  const [rackEquipment, setRackEquipment] = React.useState([]);
  const [uploadedImage, setUploadedImage] = React.useState(
    "https://ucarecdn.com/4b2b75b7-3ed1-469c-ae98-dc6837e65657/-/format/auto/"
  );
  const [showAIChat, setShowAIChat] = React.useState(false);
  const [chatMessages, setChatMessages] = React.useState([]);
  const [userInput, setUserInput] = React.useState("");
  const [streamingMessage, setStreamingMessage] = React.useState("");
  const [showModularInterface, setShowModularInterface] = React.useState(true);
  const [activeConnections, setActiveConnections] = React.useState([]);
  const [connectionPaths, setConnectionPaths] = React.useState([]);
  const [availableModules, setAvailableModules] = React.useState([]);
  const [selectedModule, setSelectedModule] = React.useState(null);
  const [portConnections, setPortConnections] = React.useState([]);
  const [activePort, setActivePort] = React.useState(null);

  const useHandleStreamResponse = ({ onChunk, onFinish }) => {
    return React.useCallback(
      async (response) => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder("utf-8");
        let buffer = "";

        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value, { stream: true });
            buffer += chunk;

            let startIdx = 0;
            let endIdx = buffer.indexOf("}\n", startIdx);

            while (endIdx !== -1) {
              const jsonStr = buffer.substring(startIdx, endIdx + 1);
              try {
                const data = JSON.parse(jsonStr);
                if (
                  data.choices &&
                  data.choices[0] &&
                  data.choices[0].message
                ) {
                  onChunk(data.choices[0].message.content);
                }
              } catch (e) {
                console.error("Error parsing JSON:", e);
              }

              startIdx = endIdx + 2;
              endIdx = buffer.indexOf("}\n", startIdx);
            }

            buffer = buffer.substring(startIdx);
          }

          if (buffer.length > 0) {
            try {
              const data = JSON.parse(buffer);
              if (data.choices && data.choices[0] && data.choices[0].message) {
                onChunk(data.choices[0].message.content);
              }
            } catch (e) {
              console.error("Error parsing JSON:", e);
            }
          }

          onFinish(buffer);
        } catch (error) {
          console.error("Error reading stream:", error);
        }
      },
      [onChunk, onFinish]
    );
  };

  React.useEffect(() => {
    const fetchDevices = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/get-devices", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ query: { limit: 10 } }),
        });
        if (!response.ok) {
          throw new Error(
            `Error fetching devices: ${response.status} ${response.statusText}`
          );
        }
        const data = await response.json();
        setDevices(data.devices || []);
      } catch (error) {
        console.error("Error fetching devices:", error);
        setError("Failed to load devices. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchDevices();

    setAvailableModules([
      {
        id: 1,
        name: "Oscillator",
        type: "sound",
        ports: ["out", "cv", "fm", "sync"],
      },
      {
        id: 2,
        name: "Filter",
        type: "sound",
        ports: ["in", "out", "cv", "resonance"],
      },
      {
        id: 3,
        name: "Envelope",
        type: "modulation",
        ports: ["gate", "out", "attack", "decay"],
      },
      {
        id: 4,
        name: "LFO",
        type: "modulation",
        ports: ["out", "rate", "shape", "sync"],
      },
      {
        id: 5,
        name: "Mixer",
        type: "utility",
        ports: ["in1", "in2", "in3", "out"],
      },
      {
        id: 6,
        name: "Sequencer",
        type: "control",
        ports: ["clock", "reset", "cv", "gate"],
      },
    ]);
  }, []);

  const handleDeviceSelect = (device) => {
    setSelectedDevice(device);
  };

  const handleSourceDeviceSelect = (device) => {
    setSourceDevice(device);
    setSelectedPorts((prev) => ({ ...prev, source: null }));
  };

  const handleTargetDeviceSelect = (device) => {
    setTargetDevice(device);
    setSelectedPorts((prev) => ({ ...prev, target: null }));
  };

  const handlePortSelect = (deviceType, port) => {
    setSelectedPorts((prev) => ({
      ...prev,
      [deviceType]: port,
    }));
  };

  const handleAddAdapter = (adapter) => {
    setAdapters([...adapters, adapter]);
    setShowAdapterSelector(false);
  };

  const handleRemoveAdapter = (index) => {
    const newAdapters = [...adapters];
    newAdapters.splice(index, 1);
    setAdapters(newAdapters);
  };

  const handleAddToRack = (equipment) => {
    setRackEquipment([...rackEquipment, equipment]);
  };

  const handleRemoveFromRack = (index) => {
    const newRackEquipment = [...rackEquipment];
    newRackEquipment.splice(index, 1);
    setRackEquipment(newRackEquipment);
  };

  const handleCreateConnection = () => {
    if (
      sourceDevice &&
      targetDevice &&
      selectedPorts.source &&
      selectedPorts.target
    ) {
      const newConnection = {
        id: `conn-${Date.now()}`,
        source: sourceDevice,
        target: targetDevice,
        sourcePort: selectedPorts.source,
        targetPort: selectedPorts.target,
        adapters: [...adapters],
      };
      setConnections([...connections, newConnection]);

      setActiveConnections((prev) => [
        ...prev,
        {
          id: newConnection.id,
          sourceId: sourceDevice.id,
          targetId: targetDevice.id,
          color: getRandomColor(),
        },
      ]);

      setAdapters([]);
      setSelectedPorts({ source: null, target: null });
    }
  };

  const getRandomColor = () => {
    const colors = [
      "#ff00ff",
      "#00ffff",
      "#00ff00",
      "#ff0000",
      "#0000ff",
      "#ffff00",
    ];
    return colors[Math.floor(Math.random() * colors.length)];
  };

  const fetchCompatibleAdapters = async () => {
    if (!sourceDevice || !targetDevice) return;

    setLoading(true);
    try {
      const response = await fetch("/api/manage-subscription", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "getCompatibleAdapters",
          sourceDevice: sourceDevice.name,
          targetDevice: targetDevice.name,
        }),
      });

      if (!response.ok) {
        throw new Error(
          `Error fetching adapters: ${response.status} ${response.statusText}`
        );
      }

      const data = await response.json();
      if (data.connections) {
        setConnectionQuality(data.connections[0]?.quality || 0);
      }
    } catch (error) {
      console.error("Error fetching compatible adapters:", error);
      setError("Failed to load adapter options. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    if (sourceDevice && targetDevice) {
      fetchCompatibleAdapters();
    }
  }, [sourceDevice, targetDevice]);

  const handleSendMessage = async () => {
    if (!userInput.trim()) return;

    const newMessage = { role: "user", content: userInput };
    setChatMessages([...chatMessages, newMessage]);
    setUserInput("");

    try {
      const response = await fetch("/integrations/chat-gpt/conversationgpt4", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...chatMessages, newMessage],
          stream: true,
        }),
      });

      handleStreamResponse(response);
    } catch (error) {
      console.error("Error sending message:", error);
      setError("Failed to get a response. Please try again.");
    }
  };

  const handleFinish = React.useCallback((message) => {
    setChatMessages((prev) => [
      ...prev,
      { role: "assistant", content: message },
    ]);
    setStreamingMessage("");
  }, []);

  const handleStreamResponse = useHandleStreamResponse({
    onChunk: setStreamingMessage,
    onFinish: handleFinish,
  });

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setUploadedImage(event.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const getModularSynthesizerDevice = () => {
    return {
      name: "Modular Synthesizer",
      description: "Virtual modular synthesizer",
      status: "Connected",
      ports: [
        { name: "Note CV", type: "input/output", color: "#00ffff" },
        { name: "Mod", type: "input/output", color: "#ff00ff" },
        { name: "Sync", type: "input", color: "#ffff00" },
        { name: "FM", type: "input", color: "#ff00ff" },
        { name: "AM", type: "input", color: "#ff0000" },
        { name: "Pitch", type: "input", color: "#00ff00" },
        { name: "Out", type: "output", color: "#0000ff" },
      ],
    };
  };

  const renderModularInterface = () => {
    return (
      <div className="relative">
        <img
          src={uploadedImage}
          alt="Modular synthesizer interface"
          className="w-full h-auto rounded-lg border border-gray-700"
        />
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="flex flex-wrap">
            {getModularSynthesizerDevice().ports.map((port, index) => (
              <div
                key={index}
                className="m-2 p-1 bg-gray-900 bg-opacity-70 rounded-full border-2 cursor-pointer hover:border-yellow-400 transition-colors"
                style={{
                  width: "30px",
                  height: "30px",
                  position: "absolute",
                  left: `${10 + index * 12}%`,
                  top: `${70 + (index % 3) * 10}%`,
                  borderColor: port.color,
                }}
                onClick={() => handlePortClick(port, index)}
              >
                <div className="w-full h-full rounded-full bg-gray-800 flex items-center justify-center">
                  <span className="text-xs text-white">
                    {port.name.charAt(0)}
                  </span>
                </div>
              </div>
            ))}

            {connectionPaths.map((path, index) => (
              <div
                key={`path-${index}`}
                className="connection-line"
                style={{
                  position: "absolute",
                  left: `${path.startX}%`,
                  top: `${path.startY}%`,
                  width: `${path.width}%`,
                  height: "3px",
                  transform: `rotate(${path.angle}deg)`,
                  background: `linear-gradient(90deg, ${path.color}, ${path.color})`,
                  transformOrigin: "left center",
                  zIndex: 10,
                }}
              ></div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const handlePortClick = (port, index) => {
    if (
      connectionPaths.length === 0 ||
      connectionPaths[connectionPaths.length - 1].complete
    ) {
      setConnectionPaths([
        ...connectionPaths,
        {
          startX: 10 + index * 12,
          startY: 70 + (index % 3) * 10,
          endX: null,
          endY: null,
          width: 0,
          angle: 0,
          color: port.color || getRandomColor(),
          complete: false,
          startPort: port,
        },
      ]);
      setActivePort(port);
    } else {
      const currentPath = { ...connectionPaths[connectionPaths.length - 1] };
      const endX = 10 + index * 12;
      const endY = 70 + (index % 3) * 10;

      const deltaX = endX - currentPath.startX;
      const deltaY = endY - currentPath.startY;
      const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
      const angle = Math.atan2(deltaY, deltaX) * (180 / Math.PI);

      currentPath.endX = endX;
      currentPath.endY = endY;
      currentPath.width = distance;
      currentPath.angle = angle;
      currentPath.complete = true;
      currentPath.endPort = port;

      const updatedPaths = [...connectionPaths];
      updatedPaths[updatedPaths.length - 1] = currentPath;
      setConnectionPaths(updatedPaths);

      setPortConnections([
        ...portConnections,
        {
          sourcePort: currentPath.startPort,
          targetPort: port,
          color: currentPath.color,
        },
      ]);

      setActivePort(null);
    }
  };

  const renderConnectionVisualizer = () => {
    return (
      <div className="relative h-64 bg-gray-900 rounded-lg p-4 mb-4 overflow-hidden">
        <img
          src={uploadedImage}
          alt="Modular synthesizer interface"
          className="w-full h-full object-cover rounded-lg opacity-50"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <h3 className="text-xl font-bold mb-2">
              Interactive Connection Visualizer
            </h3>
            <p className="text-sm text-gray-300 mb-4">
              Connect ports by clicking on them in sequence
            </p>
          </div>
        </div>
        {renderModularInterface()}
      </div>
    );
  };

  const renderModuleSelector = () => {
    return (
      <div className="mt-4 p-4 bg-gray-700 rounded-lg">
        <h3 className="font-semibold mb-2">Available Modules</h3>
        <div className="grid grid-cols-2 gap-2">
          {availableModules.map((module) => (
            <div
              key={module.id}
              onClick={() => setSelectedModule(module)}
              className={`p-2 border rounded-lg cursor-pointer ${
                selectedModule?.id === module.id
                  ? "border-yellow-400 bg-gray-600"
                  : "border-gray-600 hover:border-gray-500"
              }`}
            >
              <div className="font-medium">{module.name}</div>
              <div className="text-xs text-gray-400">{module.type}</div>
              <div className="flex flex-wrap mt-1">
                {module.ports.map((port, idx) => (
                  <span
                    key={idx}
                    className="text-xs bg-gray-800 px-1 py-0.5 rounded mr-1 mb-1"
                  >
                    {port}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
        {selectedModule && (
          <div className="mt-3 flex justify-end">
            <button
              onClick={() => handleAddToRack(selectedModule)}
              className="px-3 py-1 bg-blue-600 text-white rounded-lg text-sm"
            >
              Add to Rack
            </button>
          </div>
        )}
      </div>
    );
  };

  const renderModularRack = () => {
    return (
      <div className="bg-gray-800 p-4 rounded-lg">
        <h3 className="font-semibold mb-2">Modular Rack</h3>
        <div className="relative">
          <img
            src={uploadedImage}
            alt="Modular synthesizer rack"
            className="w-full h-auto rounded-lg"
          />
          <div className="absolute top-0 left-0 w-full h-full">
            {portConnections.map((connection, index) => (
              <div
                key={`connection-${index}`}
                className="absolute"
                style={{
                  top: "50%",
                  left: "50%",
                  width: "100px",
                  height: "2px",
                  backgroundColor: connection.color,
                  transform: "translate(-50%, -50%)",
                }}
              ></div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="p-4 bg-gray-900 text-white min-h-screen">
      <h1 className="text-2xl font-bold mb-4">
        Interactive Audio and Video Connector
      </h1>
      <p className="mb-4 text-gray-300">
        Connect audio and video devices with our interactive simulator. Select
        source and target devices, then configure connections.
      </p>

      {loading && (
        <div className="flex justify-center items-center p-8">
          <div className="loading w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
          <span className="ml-2">Loading...</span>
        </div>
      )}

      {error && (
        <div className="bg-red-900 text-white p-4 rounded-lg mb-4">
          <p className="font-bold">Error</p>
          <p>{error}</p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="bg-gray-800 p-4 rounded-lg">
          <h2 className="text-xl font-bold mb-4 border-b border-gray-700 pb-2">
            Device Selection
          </h2>

          <div className="mb-6">
            <h3 className="font-semibold mb-2">Source Device</h3>
            <DeviceSelector
              onSelectDevice={(type, device) =>
                handleSourceDeviceSelect(device)
              }
              selectedSource={sourceDevice}
              selectedTarget={targetDevice}
            />
          </div>

          <div className="mb-6">
            <h3 className="font-semibold mb-2">Target Device</h3>
            <DeviceSelector
              onSelectDevice={(type, device) =>
                handleTargetDeviceSelect(device)
              }
              selectedSource={sourceDevice}
              selectedTarget={targetDevice}
            />
          </div>

          <div className="mt-4">
            <h3 className="font-semibold mb-2">Upload Custom Image</h3>
            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700"
            />
          </div>

          <div className="mt-4">{renderModularInterface()}</div>

          {renderModuleSelector()}
        </div>

        <div className="bg-gray-800 p-4 rounded-lg">
          <h2 className="text-xl font-bold mb-4 border-b border-gray-700 pb-2">
            Connection Visualizer
          </h2>

          <div className="mb-4">{renderConnectionVisualizer()}</div>

          <div className="flex justify-center mt-4">
            <button
              onClick={handleCreateConnection}
              disabled={
                !sourceDevice ||
                !targetDevice ||
                !selectedPorts.source ||
                !selectedPorts.target
              }
              className="px-4 py-2 bg-blue-600 text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Create Connection
            </button>
          </div>

          <div className="mt-4">{renderModularInterface()}</div>

          {renderModularRack()}
        </div>

        <div className="bg-gray-800 p-4 rounded-lg">
          <h2 className="text-xl font-bold mb-4 border-b border-gray-700 pb-2">
            Equipment Rack
          </h2>

          <div className="mb-4">
            <InteractiveEquipmentRack
              devices={
                rackEquipment.length > 0
                  ? rackEquipment
                  : [getModularSynthesizerDevice()]
              }
              adapters={adapters.map((a) => a.name || "Adapter")}
            />
          </div>

          <div className="mt-4">{renderModularInterface()}</div>

          <div className="mt-4">
            <button
              onClick={() => setShowAIChat(!showAIChat)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg"
            >
              {showAIChat ? "Hide AI Assistant" : "Show AI Assistant"}
            </button>
          </div>

          {showAIChat && (
            <div className="mt-4 border border-gray-700 rounded-lg p-4">
              <h3 className="font-semibold mb-2">AI Assistant</h3>
              <div className="h-48 overflow-y-auto mb-4 bg-gray-900 p-3 rounded">
                {chatMessages.map((msg, index) => (
                  <div
                    key={index}
                    className={`mb-2 ${
                      msg.role === "user" ? "text-blue-400" : "text-green-400"
                    }`}
                  >
                    <span className="font-bold">
                      {msg.role === "user" ? "You: " : "AI: "}
                    </span>
                    <span>{msg.content}</span>
                  </div>
                ))}
                {streamingMessage && (
                  <div className="text-green-400">
                    <span className="font-bold">AI: </span>
                    <span>{streamingMessage}</span>
                  </div>
                )}
              </div>
              <div className="flex">
                <input
                  type="text"
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                  placeholder="Ask about connections, adapters, etc."
                  className="flex-grow p-2 rounded-l-lg bg-gray-700 text-white border-none focus:outline-none"
                />
                <button
                  onClick={handleSendMessage}
                  className="bg-blue-600 text-white px-4 py-2 rounded-r-lg"
                >
                  Send
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800 p-4 rounded-lg">
          <h2 className="text-xl font-bold mb-4 border-b border-gray-700 pb-2">
            Connection Results
          </h2>

          <ConnectionResults
            connectionData={{
              quality: connectionQuality,
              maxResolution: "4K (3840x2160)",
              maxRefreshRate: "60Hz",
              supportedFeatures: ["Audio", "HDR", "Charging (15W)"],
              powerRequirements: {
                direction: "Source to Target",
                voltage: "5V",
                current: "3A",
                power: "15W",
              },
              knownIssues: [
                "May experience occasional flickering at 4K 60Hz",
                "Audio may have slight delay",
              ],
              explanation:
                "This connection works because both devices support compatible standards. The signal quality is sufficient for this bandwidth requirement.",
            }}
            onTestConnection={() => console.log("Testing connection...")}
            onShareResults={() => console.log("Sharing results...")}
            onExportResults={() => console.log("Exporting results...")}
          />

          <div className="mt-4">{renderModularInterface()}</div>
        </div>

        <div className="bg-gray-800 p-4 rounded-lg">
          <h2 className="text-xl font-bold mb-4 border-b border-gray-700 pb-2">
            Alternative Options
          </h2>

          <AlternativeOptions
            currentConnection={
              sourceDevice && targetDevice
                ? {
                    id: "conn-current",
                    source: {
                      id: sourceDevice.id,
                      name: sourceDevice.name,
                      brand: sourceDevice.brand,
                      image: sourceDevice.image_url || "/default-device.png",
                    },
                    sourcePort: {
                      id: selectedPorts.source?.id || "port-1",
                      name: selectedPorts.source?.name || "Default Port",
                      type: "output",
                    },
                    adapter:
                      adapters.length > 0
                        ? {
                            id: adapters[0].id,
                            name: adapters[0].name,
                            image:
                              adapters[0].image_url || "/default-adapter.png",
                          }
                        : null,
                    target: {
                      id: targetDevice.id,
                      name: targetDevice.name,
                      brand: targetDevice.brand,
                      image: targetDevice.image_url || "/default-device.png",
                    },
                    targetPort: {
                      id: selectedPorts.target?.id || "port-2",
                      name: selectedPorts.target?.name || "Default Port",
                      type: "input",
                    },
                    qualityScore: connectionQuality / 10,
                    price: 25.99,
                  }
                : null
            }
            alternatives={[]}
            onSelectAlternative={(alternative) =>
              console.log("Selected alternative:", alternative)
            }
          />

          <div className="mt-4">{renderModularInterface()}</div>
        </div>
      </div>

      <div className="mt-6 bg-gray-800 p-4 rounded-lg">
        <h2 className="text-xl font-bold mb-4 border-b border-gray-700 pb-2">
          Troubleshooting Tips
        </h2>

        <TroubleshootingTips
          connectionSetup={
            sourceDevice && targetDevice
              ? {
                  source: {
                    name: sourceDevice.name,
                    image: sourceDevice.image_url || "/default-device.png",
                  },
                  sourcePort: {
                    name: selectedPorts.source?.name || "Default Port",
                    type: "output",
                  },
                  target: {
                    name: targetDevice.name,
                    image: targetDevice.image_url || "/default-device.png",
                  },
                  targetPort: {
                    name: selectedPorts.target?.name || "Default Port",
                    type: "input",
                  },
                  commonIssues: [
                    "Signal may degrade over longer cable runs",
                    "Some adapters require external power",
                    "Audio and video may desynchronize with certain adapters",
                  ],
                }
              : null
          }
          onReportHelpful={(issueId) =>
            console.log("Reported helpful:", issueId)
          }
          onSearchIssues={(query) => console.log("Searching issues:", query)}
        />

        <div className="mt-4">{renderModularInterface()}</div>
      </div>

      <style jsx global>{`
        .loading {
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        
        .signal-dot {
          position: absolute;
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background-color: white;
          top: -3px;
          left: -8px;
          box-shadow: 0 0 5px 2px rgba(255, 255, 255, 0.5);
          animation: moveDot 2s infinite linear;
        }
        
        @keyframes moveDot {
          0% { left: -8px; }
          100% { left: calc(100% + 8px); }
        }
        
        .port-connector {
          position: absolute;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background-color: rgba(255, 255, 255, 0.2);
          border: 2px solid rgba(255, 255, 255, 0.5);
          cursor: pointer;
          transition: all 0.2s ease;
        }
        
        .port-connector:hover {
          background-color: rgba(255, 255, 255, 0.4);
          transform: scale(1.2);
        }
        
        .connection-line {
          position: absolute;
          height: 3px;
          background: linear-gradient(90deg, #ff00ff, #00ffff);
          transform-origin: left center;
          z-index: 10;
        }
      `}</style>
    </div>
  );
}

export default MainComponent;