"use client";
import React from "react";

import { useUpload } from "../utilities/runtime-helpers";

function UnnamedProject({
  backgroundImage,
  onUpload,
  error,
  addCable,
  cables,
  onDrag,
}) {
  return (
    <div
      className="relative w-full h-screen overflow-hidden bg-cover"
      style={{
        backgroundImage: `url(${backgroundImage})`,
      }}
    >
      <input
        type="file"
        accept="image/*"
        className="block mb-4"
        onChange={(e) => e.target.files && onUpload(e.target.files[0])}
      />
      {error && <div className="text-red-500">{error}</div>}
      <button
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4"
        onClick={addCable}
      >
        Add Cable
      </button>
      {cables.map((cable, index) => (
        <div
          key={index}
          className="absolute pointer-events-none"
          style={{
            left: 0,
            top: 0,
          }}
        >
          <svg className="w-full h-full">
            <line
              x1={cable.x1}
              y1={cable.y1}
              x2={cable.x2}
              y2={cable.y2}
              stroke="red"
              strokeWidth="2"
            />
          </svg>
          <div
            className="absolute w-[10px] h-[10px] bg-blue-500 rounded-full cursor-pointer"
            style={{
              left: cable.x1,
              top: cable.y1,
            }}
            draggable
            onDrag={(e) => onDrag(index, e, "start")}
          />
          <div
            className="absolute w-[10px] h-[10px] bg-blue-500 rounded-full cursor-pointer"
            style={{
              left: cable.x2,
              top: cable.y2,
            }}
            draggable
            onDrag={(e) => onDrag(index, e, "end")}
          />
        </div>
      ))}
    </div>
  );
}

function MainComponent() {
  const [error, setError] = React.useState(null);
  const [upload, { loading }] = useUpload();
  const [backgroundImage, setBackgroundImage] = React.useState(
    "https://ucarecdn.com/78dbf917-d9b4-43a7-80e3-41c218f8f735/-/format/auto/"
  );
  const [cables, setCables] = React.useState([]);

  const onUpload = React.useCallback(
    async (file) => {
      const { url, error } = await upload({ file });
      if (error) {
        setError(error);
        return;
      }
      setBackgroundImage(url);
    },
    [upload]
  );

  const addCable = () => {
    setCables([...cables, { x1: 50, y1: 50, x2: 150, y2: 150 }]);
  };

  const onDrag = (index, e, endPoint) => {
    const newCables = [...cables];
    if (endPoint === "start") {
      newCables[index] = { ...newCables[index], x1: e.clientX, y1: e.clientY };
    } else {
      newCables[index] = { ...newCables[index], x2: e.clientX, y2: e.clientY };
    }
    setCables(newCables);
  };

  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        height: "100vh",
        overflow: "hidden",
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: "cover",
      }}
    >
      <input
        type="file"
        accept="image/*"
        onChange={(e) => e.target.files && onUpload(e.target.files[0])}
      />
      {error && <div>{error}</div>}
      <button onClick={addCable}>Add Cable</button>
      {cables.map((cable, index) => (
        <svg
          key={index}
          style={{
            position: "absolute",
            left: 0,
            top: 0,
            pointerEvents: "none",
          }}
        >
          <line
            x1={cable.x1}
            y1={cable.y1}
            x2={cable.x2}
            y2={cable.y2}
            stroke="red"
            strokeWidth="2"
          />
        </svg>
      ))}
      {cables.map((cable, index) => (
        <>
          <div
            key={`start-${index}`}
            style={{
              position: "absolute",
              left: cable.x1,
              top: cable.y1,
              width: "10px",
              height: "10px",
              backgroundColor: "blue",
              borderRadius: "50%",
              cursor: "pointer",
            }}
            draggable
            onDrag={(e) => onDrag(index, e, "start")}
          />
          <div
            key={`end-${index}`}
            style={{
              position: "absolute",
              left: cable.x2,
              top: cable.y2,
              width: "10px",
              height: "10px",
              backgroundColor: "blue",
              borderRadius: "50%",
              cursor: "pointer",
            }}
            draggable
            onDrag={(e) => onDrag(index, e, "end")}
          />
        </>
      ))}
    </div>
  );
}

export default MainComponent;