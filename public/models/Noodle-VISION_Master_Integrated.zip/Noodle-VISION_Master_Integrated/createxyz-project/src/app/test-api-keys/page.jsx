"use client";
import React from "react";
import StripeTestResults from "../../components/stripe-test-results";
import StripeConfigurationForm from "../../components/stripe-configuration-form";
import StripeKeyTester from "../../components/stripe-key-tester";
import StripeConnectionTester from "../../components/stripe-connection-tester";
import StripeTestButton from "../../components/stripe-test-button";

function MainComponent() {
  const { data: user, loading } = useUser();
  if (loading) return <div>Loading...</div>;
  if (!user || user.email !== "YOUR_ADMIN_EMAIL_HERE") {
    return (
      <div
        style={{
          color: "#191919",
          fontWeight: "500",
          padding: 32,
          textAlign: "center",
        }}
      >
        Access Denied
      </div>
    );
  }

  const [activeTab, setActiveTab] = useState("stripe");
  const [loading2, setLoading2] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);
  const [testResult, setTestResult] = useState(null);
  const [stripeConfig, setStripeConfig] = useState(null);
  const [configLoading, setConfigLoading] = useState(false);

  const handleTestApiKeys = async () => {
    setLoading2(true);
    setError(null);
    try {
      const response = await fetch("/api/test-api-keys", {
        method: "POST",
      });

      if (!response.ok) {
        throw new Error(
          `Error testing API keys: ${response.status} ${response.statusText}`
        );
      }

      const data = await response.json();
      setResults(data);
    } catch (err) {
      console.error(err);
      setError("Failed to test API connections. Please try again.");
    } finally {
      setLoading2(false);
    }
  };

  const handleTestComplete = (result) => {
    setTestResult(result);
  };

  useEffect(() => {
    if (user) {
      loadStripeConfiguration();
    }
  }, [user]);

  const loadStripeConfiguration = async () => {
    setConfigLoading(true);
    try {
      const response = await fetch("/api/get-stripe-configuration", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = await response.json();

      if (data.exists && data.config) {
        setStripeConfig(data.config);
      }
    } catch (error) {
      console.error("Error loading configuration:", error);
    } finally {
      setConfigLoading(false);
    }
  };

  if (loading || configLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#6567EF]"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F6F6F6]">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-medium text-[#191919] text-center mb-8">
            Test Your API Keys
          </h1>

          <div className="bg-white shadow overflow-hidden sm:rounded-lg">
            <div className="border-b border-[#E4E7EA]">
              <nav className="-mb-px flex">
                <button
                  onClick={() => setActiveTab("stripe")}
                  className={`${
                    activeTab === "stripe"
                      ? "border-[#6567EF] text-[#6567EF]"
                      : "border-transparent text-[#5D646C] hover:text-[#191919] hover:border-[#E4E7EA]"
                  } whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm`}
                >
                  Stripe
                </button>
                <button
                  onClick={() => setActiveTab("adapter")}
                  className={`${
                    activeTab === "adapter"
                      ? "border-[#6567EF] text-[#6567EF]"
                      : "border-transparent text-[#5D646C] hover:text-[#191919] hover:border-[#E4E7EA]"
                  } whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm`}
                >
                  Adapter Test
                </button>
              </nav>
            </div>

            <div className="p-6">
              {activeTab === "stripe" && (
                <div>
                  <p className="text-[#5D646C] mb-6">
                    Test your Stripe API keys and webhook configuration to
                    ensure everything is set up correctly.
                  </p>

                  <div className="mb-8">
                    <h2 className="text-xl font-medium mb-4">
                      Stripe Configuration
                    </h2>
                    <StripeConfigurationForm />
                  </div>

                  <div className="mt-8">
                    <h2 className="text-xl font-medium mb-4">
                      Connection Testing
                    </h2>
                    <StripeConnectionTester
                      onTestComplete={handleTestComplete}
                    />
                  </div>

                  <div className="mt-8">
                    <h2 className="text-xl font-medium mb-4">
                      API Key Testing
                    </h2>
                    <StripeKeyTester />
                  </div>

                  <div className="mt-8">
                    <h2 className="text-xl font-medium mb-4">
                      Direct API Connection Test
                    </h2>
                    <StripeTestButton onTestComplete={handleTestComplete} />

                    {testResult && (
                      <div className="mt-4">
                        <StripeTestResults testResult={testResult} />
                      </div>
                    )}
                  </div>

                  {stripeConfig && (
                    <div className="mt-6 p-4 bg-[#E4E7EA] rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <i className="fas fa-info-circle text-[#6567EF]"></i>
                        <h3 className="font-medium">
                          Current Configuration Status
                        </h3>
                      </div>
                      <p className="text-sm text-[#5D646C]">
                        You are currently in{" "}
                        <span className="font-medium">
                          {stripeConfig.isTestMode ? "TEST" : "LIVE"}
                        </span>{" "}
                        mode.
                        {stripeConfig.isTestMode
                          ? " Test mode is safe for development and testing."
                          : " Live mode will process real payments. Be careful!"}
                      </p>
                      <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <span className="font-medium">API Key:</span>{" "}
                          {stripeConfig.isTestMode
                            ? stripeConfig.testSecretKey
                              ? "✓ Configured"
                              : "✗ Not configured"
                            : stripeConfig.liveSecretKey
                            ? "✓ Configured"
                            : "✗ Not configured"}
                        </div>
                        <div>
                          <span className="font-medium">Webhook Secret:</span>{" "}
                          {stripeConfig.isTestMode
                            ? stripeConfig.testWebhookSecret
                              ? "✓ Configured"
                              : "✗ Not configured"
                            : stripeConfig.liveWebhookSecret
                            ? "✓ Configured"
                            : "✗ Not configured"}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {activeTab === "adapter" && (
                <div>
                  <p className="text-[#5D646C] mb-6">
                    Test adapter compatibility between different devices and
                    connection types.
                  </p>

                  <div className="bg-white rounded-lg shadow p-6">
                    <h2 className="text-xl font-medium mb-4">
                      Adapter Compatibility Test
                    </h2>

                    <form
                      className="space-y-6"
                      onSubmit={(e) => {
                        e.preventDefault();
                        const formData = new FormData(e.target);
                        const sourceDevice = formData.get("sourceDevice");
                        const targetDevice = formData.get("targetDevice");
                        const adapters = formData
                          .get("adapters")
                          .split(",")
                          .map((a) => a.trim());

                        fetch("/api/test-api-keys", {
                          method: "POST",
                          headers: {
                            "Content-Type": "application/json",
                          },
                          body: JSON.stringify({
                            sourceDevice,
                            targetDevice,
                            adapters,
                          }),
                        })
                          .then((response) => {
                            if (!response.ok) {
                              throw new Error(`Error: ${response.status}`);
                            }
                            return response.json();
                          })
                          .then((data) => {
                            setResults(data);
                          })
                          .catch((err) => {
                            setError(err.message);
                          });
                      }}
                    >
                      <div>
                        <label
                          htmlFor="sourceDevice"
                          className="block text-sm font-medium text-[#5D646C]"
                        >
                          Source Device
                        </label>
                        <input
                          type="text"
                          name="sourceDevice"
                          id="sourceDevice"
                          className="mt-1 block w-full border border-[#E4E7EA] rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-[#6567EF] focus:border-[#6567EF] sm:text-sm"
                          placeholder="MacBook Pro, iPhone, etc."
                          required
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="targetDevice"
                          className="block text-sm font-medium text-[#5D646C]"
                        >
                          Target Device
                        </label>
                        <input
                          type="text"
                          name="targetDevice"
                          id="targetDevice"
                          className="mt-1 block w-full border border-[#E4E7EA] rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-[#6567EF] focus:border-[#6567EF] sm:text-sm"
                          placeholder="Dell Monitor, TV, etc."
                          required
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="adapters"
                          className="block text-sm font-medium text-[#5D646C]"
                        >
                          Adapters (comma separated)
                        </label>
                        <input
                          type="text"
                          name="adapters"
                          id="adapters"
                          className="mt-1 block w-full border border-[#E4E7EA] rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-[#6567EF] focus:border-[#6567EF] sm:text-sm"
                          placeholder="USB-C to HDMI, HDMI to VGA"
                          required
                        />
                        <p className="mt-1 text-xs text-[#8C8C8C]">
                          Example: USB-C to HDMI, HDMI to VGA
                        </p>
                      </div>

                      <div>
                        <button
                          type="submit"
                          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#6567EF] hover:bg-[#5D646C] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#6567EF]"
                        >
                          Test Compatibility
                        </button>
                      </div>
                    </form>

                    {results && !results.error && !results.stripe && (
                      <div className="mt-6 border-t pt-6">
                        <h3 className="text-lg font-medium mb-4">
                          Test Results
                        </h3>

                        <div
                          className={`p-4 rounded-md ${
                            results.willWork ? "bg-green-50" : "bg-red-50"
                          }`}
                        >
                          <div className="flex">
                            <div
                              className={`flex-shrink-0 ${
                                results.willWork
                                  ? "text-green-400"
                                  : "text-red-400"
                              }`}
                            >
                              <i
                                className={`fas fa-${
                                  results.willWork
                                    ? "check-circle"
                                    : "times-circle"
                                } text-xl`}
                              ></i>
                            </div>
                            <div className="ml-3">
                              <h3
                                className={`text-sm font-medium ${
                                  results.willWork
                                    ? "text-green-800"
                                    : "text-red-800"
                                }`}
                              >
                                {results.willWork
                                  ? "Connection will work"
                                  : "Connection will not work"}
                              </h3>
                              <div
                                className={`mt-2 text-sm ${
                                  results.willWork
                                    ? "text-green-700"
                                    : "text-red-700"
                                }`}
                              >
                                <p>Quality: {results.quality}%</p>

                                {results.issues &&
                                  results.issues.length > 0 && (
                                    <div className="mt-2">
                                      <p className="font-medium">Issues:</p>
                                      <ul className="list-disc pl-5 mt-1 space-y-1">
                                        {results.issues.map((issue, index) => (
                                          <li key={index}>{issue}</li>
                                        ))}
                                      </ul>
                                    </div>
                                  )}

                                {results.recommendations &&
                                  results.recommendations.length > 0 && (
                                    <div className="mt-2">
                                      <p className="font-medium">
                                        Recommendations:
                                      </p>
                                      <ul className="list-disc pl-5 mt-1 space-y-1">
                                        {results.recommendations.map(
                                          (rec, index) => (
                                            <li key={index}>{rec}</li>
                                          )
                                        )}
                                      </ul>
                                    </div>
                                  )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {error && (
                      <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-md">
                        {error}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;