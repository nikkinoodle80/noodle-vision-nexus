"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [devices, setDevices] = React.useState([]);
  const [selectedDevice, setSelectedDevice] = React.useState(null);
  const [models, setModels] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState(null);
  const [arActive, setArActive] = React.useState(false);
  const [placedDevices, setPlacedDevices] = React.useState([]);
  const [history, setHistory] = React.useState([[]]);
  const [historyIndex, setHistoryIndex] = React.useState(0);

  const [isARSupported, setIsARSupported] = React.useState(false);
  const [viewMode, setViewMode] = React.useState("3d");
  const [showTutorial, setShowTutorial] = React.useState(false);
  const [saveModalOpen, setSaveModalOpen] = React.useState(false);
  const [loadModalOpen, setLoadModalOpen] = React.useState(false);
  const [configName, setConfigName] = React.useState("");
  const [savedConfigs, setSavedConfigs] = React.useState([]);
  const [connections, setConnections] = React.useState([]);

  const arViewerRef = React.useRef(null);
  const devicePlacementRef = React.useRef(null);

  React.useEffect(() => {
    const checkARSupport = async () => {
      if (typeof navigator !== "undefined" && "xr" in navigator) {
        try {
          const supported = await navigator.xr.isSessionSupported(
            "immersive-ar"
          );
          setIsARSupported(supported);
          if (!supported) {
            setViewMode("3d");
          }
        } catch (err) {
          console.error("Error checking AR support:", err);
          setIsARSupported(false);
          setViewMode("3d");
        }
      } else {
        setIsARSupported(false);
        setViewMode("3d");
      }
    };

    checkARSupport();
  }, []);

  React.useEffect(() => {
    if (typeof localStorage !== "undefined") {
      const hasSeenTutorial = localStorage.getItem("ar-tutorial-seen");
      if (!hasSeenTutorial && !userLoading && user) {
        setShowTutorial(true);
      }
    }
  }, [userLoading, user]);

  React.useEffect(() => {
    const loadDeviceModels = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/load-3d-models", {
          method: "POST",
        });

        if (!response.ok) {
          throw new Error(`Failed to load device models: ${response.status}`);
        }

        const data = await response.json();

        if (data.success) {
          setDevices(data.models);
        } else {
          throw new Error(data.error || "Failed to load device models");
        }
      } catch (err) {
        console.error("Error loading device models:", err);
        setError("Failed to load device models. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    loadDeviceModels();
  }, []);

  const loadSavedConfigurations = async () => {
    if (!user) return;

    try {
      const response = await fetch("/api/get-ar-configurations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ userId: user.id }),
      });

      if (!response.ok) {
        throw new Error(`Failed to load configurations: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        setSavedConfigs(data.configurations);
      } else {
        throw new Error(data.error || "Failed to load configurations");
      }
    } catch (err) {
      console.error("Error loading configurations:", err);
      setError("Failed to load your saved configurations.");
    }
  };

  React.useEffect(() => {
    if (user) {
      loadSavedConfigurations();
    }
  }, [user]);

  const handleDeviceSelect = (device) => {
    setSelectedDevice(device);
  };

  const handleStartAR = () => {
    setArActive(true);
  };

  const handlePlaceDevice = (position) => {
    if (!selectedDevice || !arActive) return;

    const newDeviceToAdd = {
      ...selectedDevice,
      position,
      id: Date.now(),
    };

    const newPlacedDevices = [...placedDevices, newDeviceToAdd];

    const nextHistory = history.slice(0, historyIndex + 1);
    nextHistory.push(newPlacedDevices);
    setHistory(nextHistory);
    setHistoryIndex(nextHistory.length - 1);

    setPlacedDevices(newPlacedDevices);
    setSelectedDevice(null);
  };

  const handleExitAR = () => {
    setArActive(false);
  };

  const handleRemoveDevice = (deviceId) => {
    const newPlacedDevices = placedDevices.filter(
      (device) => device.id !== deviceId
    );

    const nextHistory = history.slice(0, historyIndex + 1);
    nextHistory.push(newPlacedDevices);
    setHistory(nextHistory);
    setHistoryIndex(nextHistory.length - 1);

    setPlacedDevices(newPlacedDevices);
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      setPlacedDevices(history[newIndex]);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      setHistoryIndex(newIndex);
      setPlacedDevices(history[newIndex]);
    }
  };

  const handleSaveConfiguration = async () => {
    if (!user) {
      setError("You must be signed in to save configurations");
      return;
    }

    if (!configName.trim()) {
      setError("Please enter a name for your configuration");
      return;
    }

    try {
      const response = await fetch("/api/save-ar-configuration", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: user.id,
          name: configName,
          devices: placedDevices.reduce((acc, device) => {
            acc[device.id] = {
              modelId: device.modelId,
              name: device.name,
              position: device.position,
              rotation: device.rotation,
              scale: device.scale,
            };
            return acc;
          }, {}),
          connections: connections.reduce((acc, conn) => {
            acc[conn.id] = {
              sourceId: conn.sourceId,
              targetId: conn.targetId,
              type: conn.type,
              compatible: conn.compatible,
            };
            return acc;
          }, {}),
          arPosition: arViewerRef.current?.getCameraPosition
            ? arViewerRef.current.getCameraPosition()
            : null,
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to save configuration: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        setSaveModalOpen(false);
        setConfigName("");
        loadSavedConfigurations();
      } else {
        throw new Error(data.error || "Failed to save configuration");
      }
    } catch (err) {
      console.error("Error saving configuration:", err);
      setError("Failed to save your configuration. Please try again.");
    }
  };

  const handleCreateConnection = (sourceId, targetId, connectionType) => {
    // Placeholder for connection creation logic
    console.log("Creating connection:", sourceId, targetId, connectionType);
    const newConnection = {
      id: Date.now(),
      sourceId,
      targetId,
      type: connectionType,
      compatible: Math.random() > 0.2, // Simulate compatibility check
    };
    setConnections([...connections, newConnection]);
    setError(null); // Clear previous errors
  };

  const handleRemoveConnection = (connectionId) => {
    // Placeholder for connection removal logic
    console.log("Removing connection:", connectionId);
    setConnections(connections.filter((conn) => conn.id !== connectionId));
  };

  const renderTutorial = () => {
    if (!showTutorial) return null;
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-xl max-w-lg w-full">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Welcome to the AR Simulator!
          </h2>
          <p className="text-gray-700 dark:text-gray-300 mb-2">
            This quick tutorial will guide you through the basics.
          </p>
          <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 mb-4 space-y-1">
            <li>Select devices from the "Available Devices" panel.</li>
            <li>
              If AR is supported and active, tap on your real-world surface to
              place them. In 3D mode, click on the viewer.
            </li>
            <li>Manage placed devices and create connections between them.</li>
            <li>Save your configurations to revisit them later.</li>
          </ul>
          <button
            onClick={() => {
              setShowTutorial(false);
              if (typeof localStorage !== "undefined") {
                localStorage.setItem("ar-tutorial-seen", "true");
              }
            }}
            className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Got it!
          </button>
        </div>
      </div>
    );
  };

  const renderSaveModal = () => {
    if (!saveModalOpen) return null;
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-xl max-w-md w-full">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
            Save Configuration
          </h2>
          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}
          <input
            type="text"
            name="configName"
            value={configName}
            onChange={(e) => setConfigName(e.target.value)}
            placeholder="Configuration Name"
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white mb-4"
          />
          <div className="flex justify-end space-x-2">
            <button
              onClick={() => {
                setSaveModalOpen(false);
                setError(null);
              }}
              className="px-4 py-2 bg-gray-300 dark:bg-gray-600 text-gray-800 dark:text-gray-200 rounded-md hover:bg-gray-400 dark:hover:bg-gray-500"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveConfiguration}
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              Save
            </button>
          </div>
        </div>
      </div>
    );
  };

  const renderLoadModal = () => {
    if (!loadModalOpen) return null;

    const handleLoadConfig = (config) => {
      // Assuming config.devices is an object like { deviceId: { modelId, name, position, rotation, scale }}
      // And config.connections is an object like { connId: { sourceId, targetId, type, compatible }}

      const loadedPlacedDevices = Object.entries(config.devices || {}).map(
        ([id, deviceData]) => ({
          id: id, // Keep original ID if possible, or generate new if complex
          modelId: deviceData.modelId,
          name: deviceData.name,
          type:
            devices.find((d) => d.modelId === deviceData.modelId)?.type ||
            "Unknown Type", // Try to find original type
          icon:
            devices.find((d) => d.modelId === deviceData.modelId)?.icon ||
            "desktop", // Try to find original icon
          position: deviceData.position,
          rotation: deviceData.rotation,
          scale: deviceData.scale,
        })
      );
      setPlacedDevices(loadedPlacedDevices);

      const loadedConnections = Object.entries(config.connections || {}).map(
        ([id, connData]) => ({
          id: id, // Keep original ID
          ...connData,
        })
      );
      setConnections(loadedConnections);

      // Reset history with the loaded state as the new base
      const newHistoryBase = [loadedPlacedDevices]; // Or a more complex state if connections are part of history
      setHistory([newHistoryBase]);
      setHistoryIndex(0);

      setLoadModalOpen(false);
      setError(null);
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-xl max-w-lg w-full max-h-[80vh] flex flex-col">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
            Load Configuration
          </h2>
          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}
          {savedConfigs.length === 0 ? (
            <p className="text-gray-700 dark:text-gray-300">
              No saved configurations found.
            </p>
          ) : (
            <ul className="space-y-2 overflow-y-auto flex-grow">
              {savedConfigs.map((config) => (
                <li
                  key={config.id}
                  className="p-3 border dark:border-gray-700 rounded-md flex justify-between items-center"
                >
                  <div>
                    <span className="font-medium text-gray-900 dark:text-white">
                      {config.name}
                    </span>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Last updated:{" "}
                      {new Date(config.updatedAt).toLocaleDateString()}
                    </p>
                  </div>
                  <button
                    onClick={() => handleLoadConfig(config)}
                    className="px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    Load
                  </button>
                </li>
              ))}
            </ul>
          )}
          <div className="mt-4 flex justify-end">
            <button
              onClick={() => {
                setLoadModalOpen(false);
                setError(null);
              }}
              className="px-4 py-2 bg-gray-300 dark:bg-gray-600 text-gray-800 dark:text-gray-200 rounded-md hover:bg-gray-400 dark:hover:bg-gray-500"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    );
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col font-roboto">
      <header
        id="header"
        className="bg-white dark:bg-gray-800 shadow-sm py-4 px-6"
      >
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4 md:mb-0">
            AR Hardware Simulator
          </h1>

          <div className="flex items-center space-x-2 md:space-x-3">
            <button
              title="Undo"
              onClick={handleUndo}
              disabled={historyIndex === 0}
              className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <i className="fas fa-undo text-gray-700 dark:text-gray-300"></i>
            </button>
            <button
              title="Redo"
              onClick={handleRedo}
              disabled={historyIndex === history.length - 1}
              className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <i className="fas fa-redo text-gray-700 dark:text-gray-300"></i>
            </button>

            <div id="view-toggle" className="mr-2 md:mr-4">
              <button
                onClick={() => setViewMode(viewMode === "ar" ? "3d" : "ar")}
                disabled={!isARSupported && viewMode === "3d"}
                className={`px-3 py-1.5 rounded-md text-sm md:text-base ${
                  !isARSupported && viewMode === "3d"
                    ? "bg-gray-300 dark:bg-gray-700 cursor-not-allowed"
                    : "bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 hover:bg-blue-200 dark:hover:bg-blue-800"
                }`}
              >
                {viewMode === "ar" ? "3D View" : "AR View"}
              </button>
            </div>

            <div id="save-button">
              <button
                onClick={() => {
                  if (!user) {
                    setError("You must be signed in to save configurations");
                    // Optionally redirect to sign-in or show a more prominent message
                    return;
                  }
                  setError(null); // Clear previous errors
                  setSaveModalOpen(true);
                }}
                className="px-3 py-1.5 bg-green-600 text-white rounded-md hover:bg-green-700 text-sm md:text-base"
              >
                Save
              </button>
            </div>

            <div>
              <button
                onClick={() => {
                  if (!user) {
                    setError("You must be signed in to load configurations");
                    // Optionally redirect to sign-in
                    return;
                  }
                  setError(null); // Clear previous errors
                  loadSavedConfigurations(); // Refresh list before opening
                  setLoadModalOpen(true);
                }}
                className="px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm md:text-base"
              >
                Load
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-grow flex flex-col md:flex-row overflow-hidden">
        <div
          id="device-list"
          className="w-full md:w-80 bg-white dark:bg-gray-800 shadow-md p-4 overflow-y-auto flex-shrink-0"
        >
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Available Devices
          </h2>

          {loading && !devices.length ? (
            <div className="flex justify-center items-center h-40">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : error && !devices.length ? (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
              {error}
            </div>
          ) : (
            <div className="space-y-3">
              {devices.map((device) => (
                <div
                  key={device.id || device.modelId} // Prefer device.id, fallback to modelId if id is not stable from API
                  onClick={() => handleDeviceSelect(device)}
                  className={`p-3 border rounded-md cursor-pointer transition-colors ${
                    selectedDevice?.id === (device.id || device.modelId) ||
                    selectedDevice?.modelId === (device.id || device.modelId)
                      ? "border-blue-500 bg-blue-50 dark:bg-blue-900 dark:border-blue-400"
                      : "border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700"
                  }`}
                >
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gray-200 dark:bg-gray-700 rounded-md flex items-center justify-center mr-3">
                      <i
                        className={`fas fa-${
                          device.icon || "desktop"
                        } text-gray-500 dark:text-gray-400 text-xl`}
                      ></i>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900 dark:text-white">
                        {device.name}
                      </h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {device.type}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {placedDevices.length > 0 && (
            <div className="mt-8">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Placed Devices
              </h2>
              <div className="space-y-2">
                {placedDevices.map((device) => (
                  <div
                    key={device.id}
                    className="p-2 border border-gray-200 dark:border-gray-700 rounded-md"
                  >
                    <div className="flex justify-between items-center">
                      <span
                        className="text-sm text-gray-900 dark:text-white truncate"
                        title={device.name}
                      >
                        {device.name}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default MainComponent;