"use client";
import React from "react";

function MainComponent() {
  const [devices, setDevices] = useState([]);
  const [placedDevices, setPlacedDevices] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState(null);
  const [isPlacingDevice, setIsPlacingDevice] = useState(false);
  const [connections, setConnections] = useState([]);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectingSource, setConnectingSource] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [arInitialized, setArInitialized] = useState(false);
  const [arSupported, setArSupported] = useState(true);
  const [savedConfigs, setSavedConfigs] = useState([]);
  const [configName, setConfigName] = useState("");
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [showLoadModal, setShowLoadModal] = useState(false);
  const { data: user } = useUser();
  const arViewerRef = React.useRef(null);

  useEffect(() => {
    const fetchDevices = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/get-devices", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) {
          throw new Error(`Error: ${response.status} ${response.statusText}`);
        }

        const data = await response.json();
        if (data.error) {
          throw new Error(data.error);
        }

        setDevices(data.devices || []);
      } catch (err) {
        console.error("Failed to load devices:", err);
        setError("Failed to load devices. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    fetchDevices();
  }, []);

  useEffect(() => {
    if (user) {
      const fetchSavedConfigs = async () => {
        try {
          const response = await fetch("/api/get-a-r-configurations", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ userId: user.id }),
          });

          if (!response.ok) {
            throw new Error(`Error: ${response.status} ${response.statusText}`);
          }

          const data = await response.json();
          if (data.error) {
            throw new Error(data.error);
          }

          setSavedConfigs(data.configurations || []);
        } catch (err) {
          console.error("Failed to load saved configurations:", err);
        }
      };

      fetchSavedConfigs();
    }
  }, [user]);

  useEffect(() => {
    const initializeAR = () => {
      if (typeof window !== "undefined") {
        if (!window.navigator.xr) {
          setArSupported(false);
          setArInitialized(true);
          return;
        }

        try {
          setTimeout(() => {
            setArInitialized(true);
          }, 1500);
        } catch (err) {
          console.error("Failed to initialize AR:", err);
          setArSupported(false);
          setArInitialized(true);
        }
      }
    };

    initializeAR();
  }, []);

  const handleDeviceSelect = (deviceId) => {
    setSelectedDeviceId(deviceId);
    setIsPlacingDevice(true);
  };

  const handlePlaceDevice = (position, rotation) => {
    if (!selectedDeviceId) return;

    const deviceToPlace = devices.find((d) => d.id === selectedDeviceId);
    if (!deviceToPlace) return;

    const newPlacedDevice = {
      id: `placed-${Date.now()}`,
      deviceId: selectedDeviceId,
      name: deviceToPlace.name,
      model: deviceToPlace.model,
      position,
      rotation,
      scale: { x: 1, y: 1, z: 1 },
      ports: deviceToPlace.ports || [],
    };

    setPlacedDevices([...placedDevices, newPlacedDevice]);
    setIsPlacingDevice(false);
    setSelectedDeviceId(null);
  };

  const handleCancelPlacement = () => {
    setIsPlacingDevice(false);
    setSelectedDeviceId(null);
  };

  const handleStartConnecting = (deviceId) => {
    setIsConnecting(true);
    setConnectingSource(deviceId);
  };

  const handleCompleteConnection = (targetDeviceId) => {
    if (!connectingSource || connectingSource === targetDeviceId) {
      setIsConnecting(false);
      setConnectingSource(null);
      return;
    }

    const newConnection = {
      id: `conn-${Date.now()}`,
      sourceId: connectingSource,
      targetId: targetDeviceId,
      status: "connected",
      type: "ethernet",
    };

    setConnections([...connections, newConnection]);
    setIsConnecting(false);
    setConnectingSource(null);
  };

  const handleCancelConnection = () => {
    setIsConnecting(false);
    setConnectingSource(null);
  };

  const handleRemoveDevice = (deviceId) => {
    setPlacedDevices(placedDevices.filter((d) => d.id !== deviceId));
    setConnections(
      connections.filter(
        (c) => c.sourceId !== deviceId && c.targetId !== deviceId
      )
    );
  };

  const handleSaveConfiguration = async () => {
    if (!user) {
      setError("Please sign in to save configurations");
      return;
    }

    if (!configName.trim()) {
      setError("Please enter a name for your configuration");
      return;
    }

    try {
      const configData = {
        name: configName,
        userId: user.id,
        devices: placedDevices,
        connections: connections,
      };

      const response = await fetch("/api/save-a-r-configuration", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(configData),
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setSavedConfigs([...savedConfigs, { id: data.id, name: configName }]);
      setShowSaveModal(false);
      setConfigName("");
    } catch (err) {
      console.error("Failed to save configuration:", err);
      setError("Failed to save configuration. Please try again.");
    }
  };

  const handleLoadConfiguration = async (configId) => {
    try {
      const response = await fetch("/api/get-a-r-configurations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ configId }),
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      if (data.configuration) {
        setPlacedDevices(data.configuration.devices || []);
        setConnections(data.configuration.connections || []);
        setShowLoadModal(false);
      }
    } catch (err) {
      console.error("Failed to load configuration:", err);
      setError("Failed to load configuration. Please try again.");
    }
  };

  if (loading && !arInitialized) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-white dark:bg-gray-900 p-4">
        <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-lg text-gray-700 dark:text-gray-300 font-inter">
          Initializing AR environment...
        </p>
      </div>
    );
  }

  if (error && !arInitialized) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-white dark:bg-gray-900 p-4">
        <div className="bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 p-4 rounded-md max-w-md">
          <p className="font-inter">{error}</p>
          <button
            onClick={() => setError(null)}
            className="mt-4 bg-red-600 text-white font-inter py-2 px-4 rounded-md hover:bg-red-700"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  if (!arSupported && arInitialized) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-white dark:bg-gray-900 p-4">
        <div className="bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-200 p-6 rounded-md max-w-md">
          <h2 className="text-xl font-bold mb-4 font-inter">
            AR Not Supported
          </h2>
          <p className="font-inter mb-4">
            Your device or browser doesn't support Augmented Reality. You can
            still use our 3D simulator mode.
          </p>
          <button
            onClick={() => setArSupported(true)}
            className="bg-blue-600 text-white font-inter py-2 px-4 rounded-md hover:bg-blue-700"
          >
            Continue in 3D Mode
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-gray-900">
      <header className="bg-white dark:bg-gray-800 shadow-md p-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4 md:mb-0">
            AR Hardware Simulator
          </h1>
          <div className="flex space-x-4">
            {user ? (
              <div className="flex items-center">
                <span className="text-gray-700 dark:text-gray-300 font-inter mr-4">
                  Hello, {user.name || user.email}
                </span>
                <button
                  onClick={() => setShowSaveModal(true)}
                  className="bg-blue-600 text-white font-inter py-2 px-4 rounded-md hover:bg-blue-700"
                  disabled={placedDevices.length === 0}
                >
                  Save Configuration
                </button>
                <button
                  onClick={() => setShowLoadModal(true)}
                  className="bg-gray-600 text-white font-inter py-2 px-4 rounded-md hover:bg-gray-700 ml-2"
                  disabled={savedConfigs.length === 0}
                >
                  Load Configuration
                </button>
              </div>
            ) : (
              <a
                href="/account/signin?callbackUrl=/ar-simulator"
                className="bg-blue-600 text-white font-inter py-2 px-4 rounded-md hover:bg-blue-700"
              >
                Sign In to Save
              </a>
            )}
          </div>
        </div>
      </header>

      <div className="flex flex-col md:flex-row flex-1 overflow-hidden">
        <div className="w-full md:w-64 bg-gray-100 dark:bg-gray-800 p-4 overflow-y-auto">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Available Devices
          </h2>

          {loading ? (
            <div className="flex justify-center items-center py-8">
              <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : devices.length > 0 ? (
            <div className="space-y-3">
              {devices.map((device) => (
                <div
                  key={device.id}
                  className={`p-3 rounded-md cursor-pointer transition-colors ${
                    selectedDeviceId === device.id
                      ? "bg-blue-100 dark:bg-blue-900 border border-blue-500"
                      : "bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"
                  }`}
                  onClick={() => handleDeviceSelect(device.id)}
                >
                  <div className="flex items-center">
                    {device.imageUrl && (
                      <img
                        src={device.imageUrl}
                        alt={`${device.name} thumbnail`}
                        className="w-12 h-12 object-contain mr-3"
                      />
                    )}
                    <div>
                      <h3 className="font-medium text-gray-900 dark:text-white">
                        {device.name}
                      </h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {device.category}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 dark:text-gray-400 text-center py-8">
              No devices available
            </p>
          )}

          {error && (
            <div className="mt-4 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 p-3 rounded-md text-sm">
              {error}
            </div>
          )}
        </div>

        <div className="flex-1 relative">
          <div
            ref={arViewerRef}
            className="w-full h-[calc(100vh-64px)] bg-gray-200 dark:bg-gray-700"
          >
            <ARViewer
              placedDevices={placedDevices}
              connections={connections}
              isPlacingDevice={isPlacingDevice}
              selectedDeviceId={selectedDeviceId}
              isConnecting={isConnecting}
              connectingSource={connectingSource}
              onPlaceDevice={handlePlaceDevice}
              onCompleteConnection={handleCompleteConnection}
              devices={devices}
            />
          </div>

          <div className="absolute bottom-4 left-0 right-0 flex justify-center">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-3 flex space-x-3">
              {isPlacingDevice ? (
                <>
                  <button
                    onClick={handleCancelPlacement}
                    className="bg-red-600 text-white font-inter py-2 px-4 rounded-md hover:bg-red-700"
                  >
                    Cancel Placement
                  </button>
                  <div className="text-gray-700 dark:text-gray-300 font-inter flex items-center">
                    <span>Tap on a surface to place the device</span>
                  </div>
                </>
              ) : isConnecting ? (
                <>
                  <button
                    onClick={handleCancelConnection}
                    className="bg-red-600 text-white font-inter py-2 px-4 rounded-md hover:bg-red-700"
                  >
                    Cancel Connection
                  </button>
                  <div className="text-gray-700 dark:text-gray-300 font-inter flex items-center">
                    <span>Select a device to connect to</span>
                  </div>
                </>
              ) : (
                <>
                  <button
                    onClick={() => setSelectedDeviceId(null)}
                    className="bg-blue-600 text-white font-inter py-2 px-4 rounded-md hover:bg-blue-700"
                    disabled={placedDevices.length === 0}
                  >
                    <i className="fas fa-hand-pointer mr-2"></i>
                    Select
                  </button>
                  <button
                    onClick={() => {
                      if (placedDevices.length > 0) {
                        setIsConnecting(true);
                        setConnectingSource(placedDevices[0].id);
                      }
                    }}
                    className="bg-green-600 text-white font-inter py-2 px-4 rounded-md hover:bg-green-700"
                    disabled={placedDevices.length < 2}
                  >
                    <i className="fas fa-plug mr-2"></i>
                    Connect
                  </button>
                  <button
                    onClick={() => {
                      if (placedDevices.length > 0) {
                        handleRemoveDevice(
                          placedDevices[placedDevices.length - 1].id
                        );
                      }
                    }}
                    className="bg-red-600 text-white font-inter py-2 px-4 rounded-md hover:bg-red-700"
                    disabled={placedDevices.length === 0}
                  >
                    <i className="fas fa-trash mr-2"></i>
                    Remove
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {showSaveModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
              Save Configuration
            </h2>
            <input
              type="text"
              name="configName"
              placeholder="Configuration Name"
              value={configName}
              onChange={(e) => setConfigName(e.target.value)}
              className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white mb-4"
            />
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowSaveModal(false)}
                className="bg-gray-300 dark:bg-gray-600 text-gray-800 dark:text-white font-inter py-2 px-4 rounded-md hover:bg-gray-400 dark:hover:bg-gray-500"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveConfiguration}
                className="bg-blue-600 text-white font-inter py-2 px-4 rounded-md hover:bg-blue-700"
                disabled={!configName.trim()}
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {showLoadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
              Load Configuration
            </h2>
            {savedConfigs.length > 0 ? (
              <div className="max-h-64 overflow-y-auto">
                {savedConfigs.map((config) => (
                  <div
                    key={config.id}
                    className="p-3 mb-2 rounded-md cursor-pointer bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600"
                    onClick={() => handleLoadConfiguration(config.id)}
                  >
                    <p className="font-medium text-gray-900 dark:text-white">
                      {config.name}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                No saved configurations
              </p>
            )}
            <div className="flex justify-end mt-4">
              <button
                onClick={() => setShowLoadModal(false)}
                className="bg-gray-300 dark:bg-gray-600 text-gray-800 dark:text-white font-inter py-2 px-4 rounded-md hover:bg-gray-400 dark:hover:bg-gray-500"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ARViewer({
  placedDevices,
  connections,
  isPlacingDevice,
  selectedDeviceId,
  isConnecting,
  connectingSource,
  onPlaceDevice,
  onCompleteConnection,
  devices,
}) {
  return (
    <div className="relative w-full h-full bg-gradient-to-b from-blue-100 to-gray-100 dark:from-gray-800 dark:to-gray-900 overflow-hidden">
      <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-gray-300 to-transparent dark:from-gray-700 dark:to-transparent"></div>

      <div className="absolute inset-0 bg-[url('/grid.png')] opacity-30"></div>

      {placedDevices.map((device) => {
        const deviceData = devices.find((d) => d.id === device.deviceId);
        const isConnecting = connectingSource === device.id;
        const isConnectionTarget =
          connectingSource && connectingSource !== device.id;

        return (
          <div
            key={device.id}
            className={`absolute p-2 rounded-md transform translate-x-[-50%] translate-y-[-50%] transition-all duration-200 ${
              isConnecting
                ? "bg-green-100 border-2 border-green-500 shadow-lg"
                : isConnectionTarget
                ? "bg-blue-100 border-2 border-blue-500 shadow-lg cursor-pointer"
                : "bg-white dark:bg-gray-800 shadow-md"
            }`}
            style={{
              left: `${(device.position?.x || 50) * 100}%`,
              top: `${(device.position?.y || 50) * 100}%`,
              transform: `translate(-50%, -50%) rotate(${
                device.rotation?.y || 0
              }deg)`,
              width: "120px",
              height: "80px",
            }}
            onClick={() => {
              if (isConnectionTarget) {
                onCompleteConnection(device.id);
              }
            }}
          >
            <div className="flex flex-col items-center justify-center h-full">
              {deviceData?.imageUrl ? (
                <img
                  src={deviceData.imageUrl}
                  alt={device.name}
                  className="w-12 h-12 object-contain"
                />
              ) : (
                <div className="w-12 h-12 bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center">
                  <i className="fas fa-server text-gray-500"></i>
                </div>
              )}
              <p className="text-xs text-center mt-1 text-gray-900 dark:text-white font-medium truncate w-full">
                {device.name}
              </p>
            </div>
          </div>
        );
      })}

      {connections.map((connection) => {
        const sourceDevice = placedDevices.find(
          (d) => d.id === connection.sourceId
        );
        const targetDevice = placedDevices.find(
          (d) => d.id === connection.targetId
        );

        if (!sourceDevice || !targetDevice) return null;

        const sourceX = (sourceDevice.position?.x || 0.5) * 100;
        const sourceY = (sourceDevice.position?.y || 0.5) * 100;
        const targetX = (targetDevice.position?.x || 0.5) * 100;
        const targetY = (targetDevice.position?.y || 0.5) * 100;

        const length = Math.sqrt(
          Math.pow(targetX - sourceX, 2) + Math.pow(targetY - sourceY, 2)
        );
        const angle =
          (Math.atan2(targetY - sourceY, targetX - sourceX) * 180) / Math.PI;

        return (
          <div
            key={connection.id}
            className={`absolute h-1 rounded-full ${
              connection.status === "connected" ? "bg-green-500" : "bg-red-500"
            }`}
            style={{
              left: `${sourceX}%`,
              top: `${sourceY}%`,
              width: `${length}%`,
              transformOrigin: "left center",
              transform: `rotate(${angle}deg)`,
            }}
          ></div>
        );
      })}

      {isPlacingDevice && (
        <div
          className="absolute left-1/2 top-1/2 w-16 h-16 bg-blue-500 bg-opacity-50 rounded-full transform -translate-x-1/2 -translate-y-1/2 flex items-center justify-center"
          onClick={() => {
            const randomX = 0.3 + Math.random() * 0.4;
            const randomY = 0.3 + Math.random() * 0.4;
            onPlaceDevice({ x: randomX, y: randomY }, { x: 0, y: 0, z: 0 });
          }}
        >
          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
            <i className="fas fa-plus text-white"></i>
          </div>
        </div>
      )}

      <div className="absolute top-4 left-4 right-4 bg-white dark:bg-gray-800 bg-opacity-90 dark:bg-opacity-90 p-3 rounded-md shadow-md">
        <p className="text-sm text-gray-700 dark:text-gray-300 font-inter">
          {isPlacingDevice
            ? "Tap on a surface to place the selected device"
            : isConnecting
            ? "Select a device to connect to"
            : "Select devices from the panel and place them in the AR space"}
        </p>
      </div>
    </div>
  );
}

export default MainComponent;