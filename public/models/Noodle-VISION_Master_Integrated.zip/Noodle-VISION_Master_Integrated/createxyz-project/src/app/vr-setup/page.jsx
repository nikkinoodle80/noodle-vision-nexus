"use client";
import React from "react";

function MainComponent() {
  const [activeTab, setActiveTab] = React.useState("headsets");
  const [selectedHeadset, setSelectedHeadset] = React.useState(null);
  const [roomDimensions, setRoomDimensions] = React.useState({
    width: 2,
    length: 2,
    height: 2.5,
  });
  const [systemSpecs, setSystemSpecs] = React.useState({
    gpu: "",
    cpu: "",
    ram: "",
    platform: "pc",
  });
  const [showCompatibilityResults, setShowCompatibilityResults] =
    React.useState(false);
  const [compatibilityResults, setCompatibilityResults] = React.useState(null);
  const [setupSteps, setSetupSteps] = React.useState([]);
  const [imageUpload, setImageUpload] = React.useState(null);

  const headsets = [
    {
      id: "quest3",
      name: "Meta Quest 3",
      image: "/images/quest3.jpg",
      type: "Standalone/PCVR",
      resolution: "2064 × 2208 per eye",
      refreshRate: "90Hz/120Hz",
      tracking: "Inside-out",
      controllers: "Touch Plus",
      minSpace: "2m × 2m",
      connections: ["USB-C", "Wi-Fi 6E"],
      adaptersNeeded: ["USB-C to USB-A (optional)", "Link Cable (for PC VR)"],
      setupInstructions: [
        "Charge your Quest 3 headset fully before first use",
        "Download the Meta Quest app on your smartphone",
        "Follow the in-app setup instructions to pair your headset",
        "Set up your Guardian boundary in a clear play area",
        "For PC VR: Install the Oculus PC app and connect via Link cable or Air Link",
      ],
    },
    {
      id: "index",
      name: "Valve Index",
      image: "/images/index.jpg",
      type: "PCVR",
      resolution: "1440 × 1600 per eye",
      refreshRate: "80Hz/90Hz/120Hz/144Hz",
      tracking: "Outside-in (Base Stations)",
      controllers: "Knuckles",
      minSpace: "2m × 1.5m",
      connections: ["DisplayPort 1.2", "USB 3.0"],
      adaptersNeeded: ["DisplayPort to Mini DisplayPort (if needed)"],
      setupInstructions: [
        "Install SteamVR on your PC",
        "Mount base stations in opposite corners of your play area, 2m+ high",
        "Connect headset to DisplayPort and USB 3.0 ports on your PC",
        "Connect controllers to USB for first-time pairing",
        "Run room setup in SteamVR to define your play area",
      ],
    },
    {
      id: "psvr2",
      name: "PlayStation VR2",
      image: "/images/psvr2.jpg",
      type: "Console VR",
      resolution: "2000 × 2040 per eye",
      refreshRate: "90Hz/120Hz",
      tracking: "Inside-out",
      controllers: "Sense",
      minSpace: "2m × 2m",
      connections: ["USB-C"],
      adaptersNeeded: ["None (connects directly to PS5)"],
      setupInstructions: [
        "Ensure your PS5 is updated to the latest system software",
        "Connect the PSVR2 headset directly to the front USB-C port on your PS5",
        "Follow the on-screen setup instructions",
        "Set up your play area using the headset cameras",
        "Pair your Sense controllers following the on-screen instructions",
      ],
    },
    {
      id: "vive",
      name: "HTC Vive Pro 2",
      image: "/images/vivepro2.jpg",
      type: "PCVR",
      resolution: "2448 × 2448 per eye",
      refreshRate: "90Hz/120Hz",
      tracking: "Outside-in (Base Stations)",
      controllers: "Vive Controllers",
      minSpace: "2m × 1.5m",
      connections: ["DisplayPort 1.4", "USB 3.0"],
      adaptersNeeded: ["DisplayPort to Mini DisplayPort (if needed)"],
      setupInstructions: [
        "Install SteamVR and Vive software on your PC",
        "Mount base stations diagonally in your play area, above head height",
        "Connect the Link Box to power, then to your PC via DisplayPort and USB",
        "Connect the headset to the Link Box",
        "Run room setup in SteamVR to calibrate your play space",
      ],
    },
  ];

  const cableManagementSolutions = [
    {
      id: "ceiling",
      name: "Ceiling Pulley System",
      description:
        "Suspend cables from the ceiling to keep them out of the way during play",
      image: "/images/pulley.jpg",
      pros: [
        "Keeps cables off the floor",
        "Reduces tripping hazard",
        "Minimal cable drag",
      ],
      cons: [
        "Requires ceiling installation",
        "May limit movement range slightly",
      ],
      setupTips: [
        "Install pulleys along a path from your PC to the center of your play area",
        "Leave enough slack for comfortable movement",
        "Use cable clips to manage excess cable length",
        "Test range of motion before finalizing installation",
      ],
    },
    {
      id: "wireless",
      name: "Wireless Adapter",
      description: "Eliminate cables entirely with a wireless solution",
      image: "/images/wireless.jpg",
      pros: [
        "Complete freedom of movement",
        "No cable management needed",
        "Clean setup",
      ],
      cons: ["Added latency", "Battery life limitations", "Higher cost"],
      setupTips: [
        "Install wireless adapter software on your PC",
        "Position the wireless receiver with clear line-of-sight to play area",
        "Keep battery charged between sessions",
        "Consider a backup battery for extended play sessions",
      ],
    },
    {
      id: "floor",
      name: "Floor Cable Management",
      description: "Secure cables along the floor perimeter with cable covers",
      image: "/images/floor-cables.jpg",
      pros: ["Easy to set up", "Low cost", "No installation required"],
      cons: [
        "Cables still on floor",
        "Potential tripping hazard",
        "Limited movement range",
      ],
      setupTips: [
        "Route cables along walls whenever possible",
        "Use cable covers or tape to secure cables to the floor",
        "Create a cable path that minimizes crossing your play area",
        "Consider using a VR extension cable for more flexibility",
      ],
    },
  ];

  const roomSetupTips = [
    {
      title: "Clear Play Space",
      description:
        "Remove furniture, obstacles, and trip hazards from your VR area",
      icon: "fa-broom",
    },
    {
      title: "Lighting Considerations",
      description:
        "Ensure consistent, moderate lighting - avoid direct sunlight and very dark rooms",
      icon: "fa-lightbulb",
    },
    {
      title: "Ceiling Clearance",
      description:
        "Check for overhead obstacles like fans, lights, or low ceilings",
      icon: "fa-arrows-alt-v",
    },
    {
      title: "Floor Surface",
      description:
        "A carpet or mat can help you stay oriented in your play space",
      icon: "fa-rug",
    },
    {
      title: "Nearby PC Position",
      description:
        "For PCVR, position your computer close enough for cable reach but away from play area",
      icon: "fa-desktop",
    },
  ];

  const checkCompatibility = () => {
    let result = {
      compatible: false,
      headsetSupport: {},
      recommendations: [],
      issues: [],
    };

    if (systemSpecs.platform === "ps5") {
      result.compatible = true;
      result.headsetSupport = {
        psvr2: "Fully Compatible",
        quest3: "Not Compatible",
        index: "Not Compatible",
        vive: "Not Compatible",
      };
      result.recommendations.push(
        "PlayStation VR2 is the only supported headset for PS5"
      );
    } else if (systemSpecs.platform === "pc") {
      result.compatible = true;

      if (!systemSpecs.gpu) {
        result.issues.push(
          "Please specify your GPU for accurate compatibility"
        );
      } else if (
        systemSpecs.gpu.toLowerCase().includes("rtx") ||
        systemSpecs.gpu.toLowerCase().includes("gtx 1080") ||
        systemSpecs.gpu.toLowerCase().includes("rx 6")
      ) {
        result.recommendations.push(
          "Your GPU should handle most VR headsets well"
        );
      } else {
        result.issues.push(
          "Your GPU may struggle with high-resolution VR headsets"
        );
        result.recommendations.push(
          "Consider a GPU upgrade for optimal VR performance"
        );
      }

      if (!systemSpecs.ram) {
        result.issues.push(
          "Please specify your RAM amount for accurate compatibility"
        );
      } else if (parseInt(systemSpecs.ram) >= 16) {
        result.recommendations.push("Your RAM is sufficient for VR");
      } else {
        result.issues.push("16GB+ RAM recommended for smooth VR experience");
      }

      result.headsetSupport = {
        quest3: "Compatible (via Link Cable or Air Link)",
        index: "Compatible (requires DisplayPort)",
        psvr2: "Not Compatible with PC",
        vive: "Compatible (requires DisplayPort)",
      };
    } else {
      result.compatible = false;
      result.issues.push("Please select a platform");
    }

    setCompatibilityResults(result);
    setShowCompatibilityResults(true);
  };

  const selectHeadset = (headset) => {
    setSelectedHeadset(headset);
    setSetupSteps(headset.setupInstructions);
  };

  const renderHeadsetSelection = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">VR Headset Selection</h2>
      <p className="text-gray-600">
        Select a VR headset to view detailed specifications and setup
        instructions.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {headsets.map((headset) => (
          <div
            key={headset.id}
            className={`border rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-pointer ${
              selectedHeadset?.id === headset.id ? "ring-2 ring-blue-500" : ""
            }`}
            onClick={() => selectHeadset(headset)}
          >
            <div className="h-48 overflow-hidden">
              <img
                src={headset.image}
                alt={`${headset.name} VR headset`}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-4">
              <h3 className="font-bold text-lg">{headset.name}</h3>
              <p className="text-sm text-gray-600">{headset.type}</p>
            </div>
          </div>
        ))}
      </div>

      {selectedHeadset && (
        <div className="mt-8 bg-gray-50 p-6 rounded-lg">
          <div className="flex flex-col md:flex-row gap-6">
            <div className="md:w-1/3">
              <img
                src={selectedHeadset.image}
                alt={`${selectedHeadset.name} VR headset details`}
                className="w-full rounded-lg"
              />
            </div>
            <div className="md:w-2/3 space-y-4">
              <h3 className="text-2xl font-bold">{selectedHeadset.name}</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-gray-700">
                    Specifications
                  </h4>
                  <ul className="mt-2 space-y-2">
                    <li>
                      <span className="font-medium">Type:</span>{" "}
                      {selectedHeadset.type}
                    </li>
                    <li>
                      <span className="font-medium">Resolution:</span>{" "}
                      {selectedHeadset.resolution}
                    </li>
                    <li>
                      <span className="font-medium">Refresh Rate:</span>{" "}
                      {selectedHeadset.refreshRate}
                    </li>
                    <li>
                      <span className="font-medium">Tracking:</span>{" "}
                      {selectedHeadset.tracking}
                    </li>
                    <li>
                      <span className="font-medium">Controllers:</span>{" "}
                      {selectedHeadset.controllers}
                    </li>
                    <li>
                      <span className="font-medium">Minimum Space:</span>{" "}
                      {selectedHeadset.minSpace}
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-700">Connections</h4>
                  <ul className="mt-2 space-y-1">
                    {selectedHeadset.connections.map((connection, index) => (
                      <li key={index}>{connection}</li>
                    ))}
                  </ul>

                  <h4 className="font-semibold text-gray-700 mt-4">
                    Adapters Needed
                  </h4>
                  <ul className="mt-2 space-y-1">
                    {selectedHeadset.adaptersNeeded.map((adapter, index) => (
                      <li key={index}>{adapter}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="mt-6">
                <h4 className="font-semibold text-gray-700">
                  Setup Instructions
                </h4>
                <ol className="mt-2 space-y-2 list-decimal list-inside">
                  {selectedHeadset.setupInstructions.map((step, index) => (
                    <li key={index}>{step}</li>
                  ))}
                </ol>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderRoomSetup = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Room Setup Guide</h2>
      <p className="text-gray-600">
        Prepare your physical space for the best VR experience.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
        {roomSetupTips.map((tip, index) => (
          <div key={index} className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center mb-4">
              <i className={`fas ${tip.icon} text-blue-500 text-2xl mr-3`}></i>
              <h3 className="font-bold text-lg">{tip.title}</h3>
            </div>
            <p className="text-gray-600">{tip.description}</p>
          </div>
        ))}
      </div>

      <div className="bg-gray-50 p-6 rounded-lg mt-8">
        <h3 className="text-xl font-bold mb-4">Room Dimensions Calculator</h3>
        <p className="mb-4">
          Set your available space dimensions to check compatibility with VR
          headsets.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Width (meters)
            </label>
            <input
              type="number"
              min="1"
              max="10"
              step="0.1"
              value={roomDimensions.width}
              name="roomWidth"
              onChange={(e) =>
                setRoomDimensions({
                  ...roomDimensions,
                  width: parseFloat(e.target.value),
                })
              }
              className="w-full p-2 border rounded-md"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Length (meters)
            </label>
            <input
              type="number"
              min="1"
              max="10"
              step="0.1"
              value={roomDimensions.length}
              name="roomLength"
              onChange={(e) =>
                setRoomDimensions({
                  ...roomDimensions,
                  length: parseFloat(e.target.value),
                })
              }
              className="w-full p-2 border rounded-md"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Height (meters)
            </label>
            <input
              type="number"
              min="1.5"
              max="5"
              step="0.1"
              value={roomDimensions.height}
              name="roomHeight"
              onChange={(e) =>
                setRoomDimensions({
                  ...roomDimensions,
                  height: parseFloat(e.target.value),
                })
              }
              className="w-full p-2 border rounded-md"
            />
          </div>
        </div>

        <div className="mt-6">
          <h4 className="font-medium text-gray-700 mb-2">
            Room Compatibility:
          </h4>
          <div className="space-y-2">
            {headsets.map((headset) => {
              const [minWidth, minLength] = headset.minSpace
                .split("×")
                .map((dim) => parseFloat(dim));
              const isCompatible =
                roomDimensions.width >= minWidth &&
                roomDimensions.length >= minLength;

              return (
                <div key={headset.id} className="flex items-center">
                  <div
                    className={`w-4 h-4 rounded-full mr-2 ${
                      isCompatible ? "bg-green-500" : "bg-red-500"
                    }`}
                  ></div>
                  <span>
                    {headset.name}:{" "}
                    {isCompatible ? "Compatible" : "Needs more space"}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-6 p-4 bg-blue-50 rounded-md">
          <h4 className="font-medium text-blue-700 mb-2">Room Setup Tips:</h4>
          <ul className="list-disc list-inside space-y-1 text-blue-800">
            <li>
              Clear at least 0.5m beyond your play area as a safety buffer
            </li>
            <li>For room-scale VR, a minimum of 2m × 2m is recommended</li>
            <li>
              Consider using a VR mat to help you stay centered in your play
              space
            </li>
            <li>
              Ensure your ceiling is high enough for overhead movements (2.5m+
              recommended)
            </li>
          </ul>
        </div>
      </div>
    </div>
  );

  const renderCompatibilityChecker = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">
        VR Compatibility Checker
      </h2>
      <p className="text-gray-600">
        Check if your system meets the requirements for different VR headsets.
      </p>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-xl font-bold mb-4">System Specifications</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Platform
            </label>
            <select
              value={systemSpecs.platform}
              name="platform"
              onChange={(e) =>
                setSystemSpecs({ ...systemSpecs, platform: e.target.value })
              }
              className="w-full p-2 border rounded-md"
            >
              <option value="pc">PC</option>
              <option value="ps5">PlayStation 5</option>
            </select>
          </div>

          {systemSpecs.platform === "pc" && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  GPU Model
                </label>
                <input
                  type="text"
                  placeholder="e.g. RTX 3070, GTX 1080"
                  value={systemSpecs.gpu}
                  name="gpuModel"
                  onChange={(e) =>
                    setSystemSpecs({ ...systemSpecs, gpu: e.target.value })
                  }
                  className="w-full p-2 border rounded-md"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  CPU Model
                </label>
                <input
                  type="text"
                  placeholder="e.g. i7-10700K, Ryzen 5 5600X"
                  value={systemSpecs.cpu}
                  name="cpuModel"
                  onChange={(e) =>
                    setSystemSpecs({ ...systemSpecs, cpu: e.target.value })
                  }
                  className="w-full p-2 border rounded-md"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  RAM (GB)
                </label>
                <input
                  type="number"
                  min="4"
                  max="128"
                  placeholder="e.g. 16"
                  value={systemSpecs.ram}
                  name="ramAmount"
                  onChange={(e) =>
                    setSystemSpecs({ ...systemSpecs, ram: e.target.value })
                  }
                  className="w-full p-2 border rounded-md"
                />
              </div>
            </>
          )}
        </div>

        <button
          onClick={checkCompatibility}
          className="mt-6 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          Check Compatibility
        </button>
      </div>

      {showCompatibilityResults && compatibilityResults && (
        <div className="bg-gray-50 p-6 rounded-lg mt-4">
          <h3 className="text-xl font-bold mb-4">Compatibility Results</h3>

          <div className="mb-6">
            <h4 className="font-medium text-gray-700 mb-2">
              Headset Compatibility:
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(compatibilityResults.headsetSupport).map(
                ([headsetId, status]) => {
                  const headset = headsets.find((h) => h.id === headsetId);
                  return (
                    <div key={headsetId} className="flex items-center">
                      <div
                        className={`w-4 h-4 rounded-full mr-2 ${
                          status.includes("Not") ? "bg-red-500" : "bg-green-500"
                        }`}
                      ></div>
                      <span>
                        <strong>{headset?.name}:</strong> {status}
                      </span>
                    </div>
                  );
                }
              )}
            </div>
          </div>

          {compatibilityResults.recommendations.length > 0 && (
            <div className="mb-6">
              <h4 className="font-medium text-gray-700 mb-2">
                Recommendations:
              </h4>
              <ul className="list-disc list-inside space-y-1 text-green-800">
                {compatibilityResults.recommendations.map((rec, index) => (
                  <li key={index}>{rec}</li>
                ))}
              </ul>
            </div>
          )}

          {compatibilityResults.issues.length > 0 && (
            <div>
              <h4 className="font-medium text-gray-700 mb-2">
                Potential Issues:
              </h4>
              <ul className="list-disc list-inside space-y-1 text-red-800">
                {compatibilityResults.issues.map((issue, index) => (
                  <li key={index}>{issue}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      <div className="bg-blue-50 p-6 rounded-lg mt-4">
        <h3 className="text-xl font-bold text-blue-800 mb-4">
          VR System Requirements Guide
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium text-blue-700 mb-2">
              Minimum Requirements (Basic VR)
            </h4>
            <ul className="list-disc list-inside space-y-1 text-blue-800">
              <li>GPU: NVIDIA GTX 1060 / AMD RX 480 or better</li>
              <li>CPU: Intel i5-4590 / AMD Ryzen 5 1500X or better</li>
              <li>RAM: 8GB+</li>
              <li>Video Output: HDMI 1.4 or DisplayPort 1.2</li>
              <li>USB: 1x USB 3.0 port</li>
              <li>OS: Windows 10</li>
            </ul>
          </div>

          <div>
            <h4 className="font-medium text-blue-700 mb-2">
              Recommended Requirements (High-quality VR)
            </h4>
            <ul className="list-disc list-inside space-y-1 text-blue-800">
              <li>GPU: NVIDIA RTX 2070 / AMD RX 5700 XT or better</li>
              <li>CPU: Intel i7-9700K / AMD Ryzen 7 3700X or better</li>
              <li>RAM: 16GB+</li>
              <li>Video Output: DisplayPort 1.4</li>
              <li>USB: Multiple USB 3.0 ports</li>
              <li>OS: Windows 10/11</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCableManagement = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">
        Cable Management Solutions
      </h2>
      <p className="text-gray-600">
        Optimize your VR experience with these cable management options.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
        {cableManagementSolutions.map((solution) => (
          <div
            key={solution.id}
            className="bg-white rounded-lg shadow-md overflow-hidden"
          >
            <div className="h-48 overflow-hidden">
              <img
                src={solution.image}
                alt={`${solution.name} cable management solution`}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-4">
              <h3 className="font-bold text-lg mb-2">{solution.name}</h3>
              <p className="text-gray-600 mb-4">{solution.description}</p>

              <div className="mb-4">
                <h4 className="font-medium text-green-700 mb-1">Pros:</h4>
                <ul className="list-disc list-inside space-y-1 text-green-800">
                  {solution.pros.map((pro, index) => (
                    <li key={index}>{pro}</li>
                  ))}
                </ul>
              </div>

              <div className="mb-4">
                <h4 className="font-medium text-red-700 mb-1">Cons:</h4>
                <ul className="list-disc list-inside space-y-1 text-red-800">
                  {solution.cons.map((con, index) => (
                    <li key={index}>{con}</li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="font-medium text-blue-700 mb-1">Setup Tips:</h4>
                <ul className="list-disc list-inside space-y-1 text-blue-800">
                  {solution.setupTips.map((tip, index) => (
                    <li key={index}>{tip}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-gray-50 p-6 rounded-lg mt-8">
        <h3 className="text-xl font-bold mb-4">
          Additional Cable Management Tips
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium text-gray-700 mb-2">
              For PCVR Headsets:
            </h4>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>
                Use cable extensions if needed, but be aware that very long
                extensions may cause signal degradation
              </li>
              <li>Consider cable sleeves to bundle multiple cables together</li>
              <li>
                Label your cables to easily identify them during setup and
                troubleshooting
              </li>
              <li>
                Route cables away from high-traffic areas even within your play
                space
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-medium text-gray-700 mb-2">
              For Standalone Headsets:
            </h4>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>Keep charging cables organized and easily accessible</li>
              <li>
                Consider a dedicated storage solution that allows charging while
                stored
              </li>
              <li>
                For optional PC connectivity, follow the PCVR cable management
                tips
              </li>
              <li>
                Use right-angle adapters to reduce cable strain when connected
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );

  const tabContent = {
    headsets: renderHeadsetSelection(),
    roomsetup: renderRoomSetup(),
    compatibility: renderCompatibilityChecker(),
    cable: renderCableManagement(),
  };

  const tabs = [
    { id: "headsets", label: "Headsets", icon: "fa-headset" },
    { id: "roomsetup", label: "Room Setup", icon: "fa-person-booth" },
    { id: "compatibility", label: "Compatibility", icon: "fa-check-circle" },
    { id: "cable", label: "Cable Management", icon: "fa-plug" },
  ];

  const handleImageUpload = (event) => {
    if (event.target.files && event.target.files[0]) {
      setImageUpload(event.target.files[0]);
    }
  };

  const uploadedImageUrl = imageUpload
    ? URL.createObjectURL(imageUpload)
    : null;

  return <div className="font-inter bg-white text-[#191919] min-h" />;
}

export default MainComponent;