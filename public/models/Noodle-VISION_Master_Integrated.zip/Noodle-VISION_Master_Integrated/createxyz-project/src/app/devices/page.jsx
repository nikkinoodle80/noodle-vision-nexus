"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [deviceType, setDeviceType] = React.useState("");
  const [manufacturer, setManufacturer] = React.useState("");
  const [modelName, setModelName] = React.useState("");
  const [modelNumber, setModelNumber] = React.useState("");
  const [customNickname, setCustomNickname] = React.useState("");
  const [imageUrl, setImageUrl] = React.useState("");
  const [specifications, setSpecifications] = React.useState("");
  const [notes, setNotes] = React.useState("");

  const [error, setError] = React.useState(null);
  const [successMessage, setSuccessMessage] = React.useState(null);
  const [isLoading, setIsLoading] = React.useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setSuccessMessage(null);

    if (!user) {
      setError("You must be signed in to add a device.");
      setIsLoading(false);
      return;
    }

    if (!deviceType || !modelName) {
      setError("Device Type and Model Name are required.");
      setIsLoading(false);
      return;
    }

    const deviceData = {
      name: modelName,
      type: deviceType,
      manufacturer: manufacturer || null,
      model_number: modelNumber || null,
      image_url: imageUrl || null,
      specifications: specifications || null,
    };

    const userDeviceData = {
      custom_name: customNickname || null,
      notes: notes || null,
    };

    try {
      const response = await fetch("/api/manage-gear", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "add",
          deviceData,
          userDeviceData,
        }),
      });

      const result = await response.json();

      if (!response.ok || result.error) {
        throw new Error(
          result.error || `Server responded with status ${response.status}`
        );
      }

      if (result.success) {
        setSuccessMessage("Device added successfully!");
        setDeviceType("");
        setManufacturer("");
        setModelName("");
        setModelNumber("");
        setCustomNickname("");
        setImageUrl("");
        setSpecifications("");
        setNotes("");
      }
    } catch (err) {
      console.error("Failed to add device:", err);
      setError(
        err.message || "An unexpected error occurred. Please try again."
      );
    } finally {
      setIsLoading(false);
    }
  };

  const commonInputClass =
    "w-full p-3 bg-gray-700 border border-gray-600 rounded-md focus:ring-2 focus:ring-[#00B2FF] focus:border-[#00B2FF] outline-none transition-colors text-white";
  const commonLabelClass = "block text-sm font-medium text-gray-300 mb-1";

  return (
    <div className="flex flex-col min-h-screen bg-gray-800 text-white font-roboto">
      <nav className="w-full bg-black bg-opacity-50 p-4 shadow-lg">
        <div className="container mx-auto flex justify-between items-center">
          <a
            href="/"
            className="text-2xl font-bold text-[#00B2FF] hover:text-white transition-colors"
          >
            A/V Connect
          </a>
          <div className="space-x-4">
            <a
              href="/devices"
              className="hover:text-[#00B2FF] transition-colors"
            >
              Browse Devices
            </a>
            <a href="/blog" className="hover:text-[#00B2FF] transition-colors">
              Blog
            </a>
            <a
              href="/community"
              className="hover:text-[#00B2FF] transition-colors"
            >
              Community
            </a>
            {user ? (
              <>
                <a
                  href="/my-gear"
                  className="hover:text-[#00B2FF] transition-colors"
                >
                  My Gear
                </a>
                <a
                  href="/subscription"
                  className="hover:text-[#00B2FF] transition-colors"
                >
                  Subscription
                </a>
                <a
                  href="/account/logout"
                  className="hover:text-[#00B2FF] transition-colors"
                >
                  Sign Out
                </a>
              </>
            ) : (
              <>
                <a
                  href="/account/signin"
                  className="hover:text-[#00B2FF] transition-colors"
                >
                  Sign In
                </a>
                <a
                  href="/account/signup"
                  className="bg-[#0072C6] text-white px-4 py-2 rounded-md hover:bg-[#0052A6] transition-colors"
                >
                  Sign Up
                </a>
              </>
            )}
          </div>
        </div>
      </nav>

      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto bg-gray-900 p-6 md:p-8 rounded-xl shadow-2xl">
          <h1 className="text-3xl font-bold text-center text-[#00B2FF] mb-8">
            Add New A/V Device
          </h1>

          {userLoading && (
            <p className="text-center text-gray-400">
              Loading user information...
            </p>
          )}

          {!user && !userLoading && (
            <div className="text-center p-4 bg-yellow-800 bg-opacity-30 rounded-md">
              <p className="text-yellow-300">
                Please{" "}
                <a
                  href="/account/signin?callbackUrl=/devices"
                  className="font-bold underline hover:text-yellow-200"
                >
                  sign in
                </a>{" "}
                to add devices to your collection.
              </p>
            </div>
          )}

          {user && (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="deviceType" className={commonLabelClass}>
                  Device Type <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  id="deviceType"
                  name="deviceType"
                  value={deviceType}
                  onChange={(e) => setDeviceType(e.target.value)}
                  className={commonInputClass}
                  placeholder="e.g., Receiver, TV, Speaker"
                  required
                />
              </div>

              <div>
                <label htmlFor="modelName" className={commonLabelClass}>
                  Model Name <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  id="modelName"
                  name="modelName"
                  value={modelName}
                  onChange={(e) => setModelName(e.target.value)}
                  className={commonInputClass}
                  placeholder="e.g., STR-DH590, OLED65C1PUA"
                  required
                />
              </div>

              <div>
                <label htmlFor="manufacturer" className={commonLabelClass}>
                  Manufacturer
                </label>
                <input
                  type="text"
                  id="manufacturer"
                  name="manufacturer"
                  value={manufacturer}
                  onChange={(e) => setManufacturer(e.target.value)}
                  className={commonInputClass}
                  placeholder="e.g., Sony, LG, Klipsch"
                />
              </div>

              <div>
                <label htmlFor="modelNumber" className={commonLabelClass}>
                  Model Number
                </label>
                <input
                  type="text"
                  id="modelNumber"
                  name="modelNumber"
                  value={modelNumber}
                  onChange={(e) => setModelNumber(e.target.value)}
                  className={commonInputClass}
                  placeholder="e.g., STRDH590, 65C1"
                />
              </div>

              <div>
                <label htmlFor="customNickname" className={commonLabelClass}>
                  Custom Nickname
                </label>
                <input
                  type="text"
                  id="customNickname"
                  name="customNickname"
                  value={customNickname}
                  onChange={(e) => setCustomNickname(e.target.value)}
                  className={commonInputClass}
                  placeholder="e.g., Living Room Amp, Main TV"
                />
              </div>

              <div>
                <label htmlFor="imageUrl" className={commonLabelClass}>
                  Image URL
                </label>
                <input
                  type="url"
                  id="imageUrl"
                  name="imageUrl"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  className={commonInputClass}
                  placeholder="https://example.com/image.jpg"
                />
              </div>

              <div>
                <label htmlFor="specifications" className={commonLabelClass}>
                  Specifications
                </label>
                <textarea
                  id="specifications"
                  name="specifications"
                  value={specifications}
                  onChange={(e) => setSpecifications(e.target.value)}
                  className={`${commonInputClass} min-h-[100px]`}
                  placeholder="e.g., HDMI Ports: 4, Power: 100W per channel"
                />
              </div>

              <div>
                <label htmlFor="notes" className={commonLabelClass}>
                  Notes
                </label>
                <textarea
                  id="notes"
                  name="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className={`${commonInputClass} min-h-[100px]`}
                  placeholder="e.g., Purchased on Jan 2025, Input 1 is for Blu-ray"
                />
              </div>

              {error && (
                <div className="p-3 bg-red-500 bg-opacity-20 text-red-300 border border-red-500 rounded-md text-sm">
                  {error}
                </div>
              )}
              {successMessage && (
                <div className="p-3 bg-green-500 bg-opacity-20 text-green-300 border border-green-500 rounded-md text-sm">
                  {successMessage}
                </div>
              )}

              <div>
                <button
                  type="submit"
                  disabled={isLoading || !user}
                  className="w-full bg-[#0072C6] text-white font-bold py-3 px-6 rounded-lg text-lg hover:bg-[#0052A6] transition-colors duration-300 shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? "Adding Device..." : "Add Device"}
                </button>
              </div>
            </form>
          )}
        </div>
      </main>

      <footer className="w-full bg-black bg-opacity-70 p-4 text-center mt-12">
        <p className="text-sm text-gray-400">
          &copy; 2025 A/V Connect. All rights reserved.
        </p>
        <p className="text-xs text-gray-500">
          High-tech connections, simplified.
        </p>
      </footer>
    </div>
  );
}

export default MainComponent;