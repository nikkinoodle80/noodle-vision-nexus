"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading } = useUser();
  const [activeTab, setActiveTab] = useState("devices");
  const [userSetups, setUserSetups] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedSourceDevice, setSelectedSourceDevice] = useState(null);
  const [selectedTargetDevice, setSelectedTargetDevice] = useState(null);
  const [devices, setDevices] = useState([]);
  const [loadingDevices, setLoadingDevices] = useState(false);

  useEffect(() => {
    if (user) {
      fetchUserSetups();
      fetchDevices();
    } else if (!loading) {
      setIsLoading(false);
    }
  }, [user, loading]);

  async function fetchUserSetups() {
    try {
      setIsLoading(true);
      const response = await fetch("/api/setups/user");
      if (!response.ok) throw new Error("Failed to fetch setups");
      const data = await response.json();
      setUserSetups(data || []);
    } catch (error) {
      console.error("Error fetching setups:", error);
      setUserSetups([]);
    } finally {
      setIsLoading(false);
    }
  }

  async function fetchDevices() {
    try {
      setLoadingDevices(true);
      const response = await fetch("/api/get-devices-consolidated", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({}),
      });
      if (!response.ok) throw new Error("Failed to fetch devices");
      const data = await response.json();
      setDevices(data || []);
    } catch (error) {
      console.error("Error fetching devices:", error);
      setDevices([]);
    } finally {
      setLoadingDevices(false);
    }
  }

  if (loading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin h-12 w-12 border-4 border-[#6567EF] rounded-full border-t-transparent"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F6F6F6]">
        <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-medium text-[#191919] sm:text-5xl sm:tracking-tight lg:text-6xl">
              Welcome to Adapter Finder
            </h1>
            <p className="mt-5 max-w-xl mx-auto text-xl text-[#5D646C]">
              Find the right adapters for all your devices. Sign in to manage
              your setups.
            </p>
            <div className="mt-8 flex justify-center">
              <div className="inline-flex rounded-md shadow">
                <a
                  href="/account/signin"
                  className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-[#6567EF] hover:bg-[#5D646C]"
                >
                  Sign in
                </a>
              </div>
              <div className="ml-3 inline-flex">
                <a
                  href="/account/signup"
                  className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-[#6567EF] bg-white hover:bg-[#E4E7EA]"
                >
                  Sign up
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <header className="mb-8">
        <h1 className="text-3xl font-medium">Simplified Dashboard</h1>
        <p className="text-[#5D646C] mt-2">
          Quick access to your most important tools
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow">
          <h2 className="text-xl font-medium mb-2">Quick Links</h2>
          <p className="text-[#5D646C]">Access your favorite tools quickly</p>
          <button className="mt-4 px-4 py-2 bg-[#6567EF] text-white rounded-md hover:bg-[#5D646C]">
            View Links
          </button>
        </div>
        <div className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow">
          <h2 className="text-xl font-medium mb-2">Recent Activity</h2>
          <p className="text-[#5D646C]">See what you've been working on</p>
          <button className="mt-4 px-4 py-2 bg-[#6567EF] text-white rounded-md hover:bg-[#5D646C]">
            View Activity
          </button>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;