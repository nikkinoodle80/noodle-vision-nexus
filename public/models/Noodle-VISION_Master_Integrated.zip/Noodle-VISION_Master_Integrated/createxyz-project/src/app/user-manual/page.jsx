"use client";
import React from "react";

function MainComponent() {
  const [activeSection, setActiveSection] = React.useState("getting-started");
  const [searchQuery, setSearchQuery] = React.useState("");
  const [searchResults, setSearchResults] = React.useState([]);
  const [tutorials, setTutorials] = React.useState([]);
  const [domains, setDomains] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState(null);

  React.useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);

        // Fetch domains and tutorials in parallel
        const [domainsResponse, tutorialsResponse] = await Promise.all([
          fetch("/api/get-domains", { method: "POST" }),
          fetch("/api/get-tutorials", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ domainId: null }),
          }),
        ]);

        if (!domainsResponse.ok || !tutorialsResponse.ok) {
          throw new Error("Failed to fetch data");
        }

        const domainsData = await domainsResponse.json();
        const tutorialsData = await tutorialsResponse.json();

        setDomains(domainsData.domains || []);
        setTutorials(tutorialsData.tutorials || []);
        setLoading(false);
      } catch (err) {
        console.error(err);
        setError("Failed to load manual data. Please try again later.");
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleSearch = (e) => {
    const query = e.target.value.toLowerCase();
    setSearchQuery(query);

    if (query.trim() === "") {
      setSearchResults([]);
      return;
    }

    const results = [];

    // Search in manual content
    Object.entries(manualContent).forEach(([sectionId, section]) => {
      if (section.title.toLowerCase().includes(query)) {
        results.push({
          type: "section",
          id: sectionId,
          title: section.title,
          match: "title",
        });
      }

      section.content.forEach((item, index) => {
        if (typeof item === "string" && item.toLowerCase().includes(query)) {
          results.push({
            type: "content",
            sectionId,
            index,
            title: section.title,
            snippet: item.substring(0, 100) + "...",
            match: "content",
          });
        }
      });
    });

    // Search in tutorials
    tutorials.forEach((tutorial) => {
      if (tutorial.title.toLowerCase().includes(query)) {
        results.push({
          type: "tutorial",
          id: tutorial.id,
          title: tutorial.title,
          match: "title",
        });
      }

      if (
        tutorial.description &&
        tutorial.description.toLowerCase().includes(query)
      ) {
        results.push({
          type: "tutorial",
          id: tutorial.id,
          title: tutorial.title,
          snippet: tutorial.description.substring(0, 100) + "...",
          match: "description",
        });
      }
    });

    setSearchResults(results);
  };

  const scrollToSection = (sectionId) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleInteractiveTutorial = (tutorialId) => {
    console.log(`Starting tutorial with ID: ${tutorialId}`);
  };

  const manualContent = {
    "getting-started": {
      title: "Getting Started",
      content: [
        "Welcome to ConnectEase! This user manual will guide you through all the features of our platform.",
        "ConnectEase is designed to help you find the right adapters and connections for all your devices without requiring technical knowledge.",
        <div key="features" className="bg-[#1D1D1F] p-4 rounded-lg mt-4 mb-4">
          <h4 className="text-white font-semibold mb-2">Key Features:</h4>
          <ul className="list-disc pl-5 text-[#86868B]">
            <li>Interactive device connection builder</li>
            <li>Pre-made solutions for common setups</li>
            <li>Comprehensive device compatibility database</li>
            <li>Step-by-step tutorials for complex connections</li>
            <li>Save and share your custom setups</li>
          </ul>
        </div>,
        "To get started, navigate to the Device Builder from the main menu or use the Solutions page to find pre-configured setups for your needs.",
      ],
    },
    "device-builder": {
      title: "Device Connection Builder",
      content: [
        "The Device Connection Builder is our interactive tool that helps you connect your devices together.",
        <div
          key="builder-instructions"
          className="bg-[#1D1D1F] p-4 rounded-lg mt-4 mb-4"
        >
          <h4 className="text-white font-semibold mb-2">
            How to Use the Builder:
          </h4>
          <ol className="list-decimal pl-5 text-[#86868B]">
            <li>Select your source device (what you want to connect from)</li>
            <li>
              Select your destination device (what you want to connect to)
            </li>
            <li>The system will automatically show compatible connections</li>
            <li>
              If direct connection isn't possible, adapters will be suggested
            </li>
            <li>Add the connection to your workspace</li>
            <li>Repeat for additional connections</li>
            <li>Save your setup when complete</li>
          </ol>
        </div>,
        "The builder uses color-coded connections to represent different signal types:",
        <div
          key="connection-types"
          className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 mb-4"
        >
          <div className="flex items-center">
            <div className="w-6 h-3 rounded-full bg-[#FF5555] mr-2"></div>
            <span className="text-[#86868B]">Audio signals</span>
          </div>
          <div className="flex items-center">
            <div className="w-6 h-3 rounded-full bg-[#55FF55] mr-2"></div>
            <span className="text-[#86868B]">Video signals</span>
          </div>
          <div className="flex items-center">
            <div className="w-6 h-3 rounded-full bg-[#5555FF] mr-2"></div>
            <span className="text-[#86868B]">Data connections</span>
          </div>
          <div className="flex items-center">
            <div className="w-6 h-3 rounded-full bg-[#FFAA00] mr-2"></div>
            <span className="text-[#86868B]">Power connections</span>
          </div>
        </div>,
      ],
    },
    "special-features": {
      title: "Special Device Features",
      content: [
        "Some devices have special features that can be unlocked with the right adapters and connections. Our system helps you discover these hidden capabilities.",
        <div
          key="samsung-dex"
          className="bg-[#2A2A2A] p-5 rounded-lg mt-6 mb-6"
        >
          <h3 className="text-white font-semibold text-xl mb-3">Samsung DeX</h3>
          <div className="flex flex-col md:flex-row gap-6">
            <div className="md:w-2/3">
              <p className="text-[#86868B] mb-4">
                Samsung DeX transforms your Galaxy smartphone into a
                desktop-like experience. By connecting your phone to a monitor,
                you can use your apps on a larger screen with a PC-like
                interface.
              </p>
              <h4 className="text-white font-medium mb-2">What You Need:</h4>
              <ul className="list-disc pl-5 text-[#86868B] mb-4">
                <li>Compatible Samsung Galaxy device (S8 or newer)</li>
                <li>USB-C to HDMI adapter or DeX cable/dock</li>
                <li>External display (HDMI or VGA with additional adapter)</li>
                <li>Optional: Bluetooth keyboard and mouse</li>
              </ul>
              <h4 className="text-white font-medium mb-2">Did You Know?</h4>
              <p className="text-[#86868B]">
                Even if you have an older VGA monitor, you can still use Samsung
                DeX! Our system will show you the exact adapter chain needed:
                USB-C to HDMI adapter + HDMI to VGA converter.
              </p>
            </div>
            <div className="md:w-1/3 bg-[#1D1D1F] p-3 rounded-lg">
              <div className="text-center mb-3">
                <i className="fas fa-mobile-alt text-[#0066FF] text-4xl"></i>
                <i className="fas fa-arrow-right text-[#86868B] mx-2"></i>
                <i className="fas fa-plug text-[#0066FF] text-2xl"></i>
                <i className="fas fa-arrow-right text-[#86868B] mx-2"></i>
                <i className="fas fa-desktop text-[#0066FF] text-4xl"></i>
              </div>
              <p className="text-[#86868B] text-sm text-center">
                ConnectEase identifies special features like Samsung DeX and
                shows you exactly how to enable them with the right adapters.
              </p>
            </div>
          </div>
        </div>,
        "Our database includes many other special device features and the exact adapter combinations needed to enable them. The Device Connection Builder will automatically suggest these possibilities when you select compatible devices.",
        <div
          key="other-features"
          className="bg-[#1D1D1F] p-4 rounded-lg mt-4 mb-4"
        >
          <h4 className="text-white font-semibold mb-2">
            Other Special Features You Can Discover:
          </h4>
          <ul className="list-disc pl-5 text-[#86868B]">
            <li>Nintendo Switch TV mode on non-standard displays</li>
            <li>iPad Pro as a secondary monitor</li>
            <li>Laptop video output to projectors with legacy connections</li>
            <li>Gaming consoles on portable displays</li>
            <li>DSLR cameras as high-quality webcams</li>
          </ul>
        </div>,
      ],
    },
    solutions: {
      title: "Pre-made Solutions",
      content: [
        "Our Solutions page offers pre-configured setups for common scenarios.",
        "Each solution includes:",
        <ul
          key="solution-features"
          className="list-disc pl-5 text-[#86868B] mt-2 mb-4"
        >
          <li>Required devices and adapters</li>
          <li>Step-by-step connection instructions</li>
          <li>Troubleshooting tips</li>
          <li>Alternative configurations</li>
        </ul>,
        "Popular solutions include:",
        <div
          key="popular-solutions"
          className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 mb-4"
        >
          <div className="bg-[#2A2A2A] p-4 rounded-lg">
            <h4 className="text-white font-semibold mb-2">
              Home Theater Setup
            </h4>
            <p className="text-[#86868B] text-sm">
              Connect your TV, sound system, streaming devices, and game
              consoles.
            </p>
          </div>
          <div className="bg-[#2A2A2A] p-4 rounded-lg">
            <h4 className="text-white font-semibold mb-2">Work From Home</h4>
            <p className="text-[#86868B] text-sm">
              Optimal setup for laptop, external monitor, webcam, and
              peripherals.
            </p>
          </div>
          <div className="bg-[#2A2A2A] p-4 rounded-lg">
            <h4 className="text-white font-semibold mb-2">Content Creator</h4>
            <p className="text-[#86868B] text-sm">
              Camera, microphone, lighting, and computer connections for
              streamers.
            </p>
          </div>
          <div className="bg-[#2A2A2A] p-4 rounded-lg">
            <h4 className="text-white font-semibold mb-2">Gaming Setup</h4>
            <p className="text-[#86868B] text-sm">
              Console/PC connections with optimal audio/video quality.
            </p>
          </div>
        </div>,
      ],
    },
    compatibility: {
      title: "Device Compatibility",
      content: [
        "Our database includes thousands of devices and their compatible connections.",
        "For each device, we provide:",
        <ul
          key="device-info"
          className="list-disc pl-5 text-[#86868B] mt-2 mb-4"
        >
          <li>Available input/output ports</li>
          <li>Supported resolutions and formats</li>
          <li>Power requirements</li>
          <li>Known compatibility issues</li>
        </ul>,
        "If your specific device isn't in our database, you can:",
        <ol
          key="missing-device"
          className="list-decimal pl-5 text-[#86868B] mt-2 mb-4"
        >
          <li>Search for a similar model from the same manufacturer</li>
          <li>Use the generic device type with the same ports</li>
          <li>Submit a device addition request</li>
        </ol>,
      ],
    },
    account: {
      title: "Account Management",
      content: [
        "Creating an account allows you to:",
        <ul
          key="account-benefits"
          className="list-disc pl-5 text-[#86868B] mt-2 mb-4"
        >
          <li>Save your device setups</li>
          <li>Access your setups from any device</li>
          <li>Share configurations with others</li>
          <li>Track your device inventory</li>
          <li>Receive updates on new compatibility information</li>
        </ul>,
        "To create an account:",
        <ol
          key="account-creation"
          className="list-decimal pl-5 text-[#86868B] mt-2 mb-4"
        >
          <li>Click "Sign Up" in the top navigation</li>
          <li>Enter your email and create a password</li>
          <li>Verify your email address</li>
          <li>Complete your profile with your devices</li>
        </ol>,
      ],
    },
    troubleshooting: {
      title: "Troubleshooting",
      content: [
        "If you encounter issues with your connections, try these steps:",
        <div
          key="troubleshooting-steps"
          className="bg-[#1D1D1F] p-4 rounded-lg mt-4 mb-4"
        >
          <h4 className="text-white font-semibold mb-2">Common Issues:</h4>
          <div className="space-y-4">
            <div>
              <h5 className="text-white font-medium">No Signal</h5>
              <ul className="list-disc pl-5 text-[#86868B]">
                <li>Check if all devices are powered on</li>
                <li>Verify cables are securely connected</li>
                <li>Try a different cable if available</li>
                <li>Ensure correct input source is selected</li>
              </ul>
            </div>
            <div>
              <h5 className="text-white font-medium">Poor Quality</h5>
              <ul className="list-disc pl-5 text-[#86868B]">
                <li>Check cable quality and condition</li>
                <li>Verify resolution settings match capabilities</li>
                <li>Reduce cable length if possible</li>
                <li>Remove unnecessary adapters</li>
              </ul>
            </div>
            <div>
              <h5 className="text-white font-medium">Incompatible Formats</h5>
              <ul className="list-disc pl-5 text-[#86868B]">
                <li>Check if devices support the same formats</li>
                <li>Look for format conversion options</li>
                <li>Update device firmware if available</li>
              </ul>
            </div>
          </div>
        </div>,
        "If problems persist, use our community forums or contact support for assistance.",
      ],
    },
    faq: {
      title: "Frequently Asked Questions",
      content: [
        <div key="faq-list" className="space-y-6 mt-2">
          <div>
            <h4 className="text-white font-semibold">
              Can I connect an older device to a newer one?
            </h4>
            <p className="text-[#86868B] mt-1">
              Yes, in most cases. You'll likely need an adapter to bridge the
              different connection types. Our system will suggest the
              appropriate adapters.
            </p>
          </div>
          <div>
            <h4 className="text-white font-semibold">
              How do I know if a connection will support 4K?
            </h4>
            <p className="text-[#86868B] mt-1">
              The Device Builder will indicate the maximum supported resolution
              for each connection. For 4K, you typically need HDMI 2.0 or newer,
              or DisplayPort 1.2+.
            </p>
          </div>
          <div>
            <h4 className="text-white font-semibold">
              Can I connect multiple devices to one display?
            </h4>
            <p className="text-[#86868B] mt-1">
              Yes, you can use an HDMI switch, AV receiver, or a display with
              multiple inputs. Add each connection separately in the Device
              Builder.
            </p>
          </div>
          <div>
            <h4 className="text-white font-semibold">
              Will using adapters reduce quality?
            </h4>
            <p className="text-[#86868B] mt-1">
              Some adapters may limit resolution or refresh rates. Our system
              will warn you about any limitations when suggesting adapters.
            </p>
          </div>
          <div>
            <h4 className="text-white font-semibold">
              How do I connect devices without visible ports?
            </h4>
            <p className="text-[#86868B] mt-1">
              Check the device manual for hidden ports. Some devices use
              proprietary connections or require special adapters, which our
              database includes.
            </p>
          </div>
        </div>,
      ],
    },
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white text-xl">Loading user manual...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-red-500 text-xl">{error}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <nav className="fixed w-full bg-[#1D1D1F] border-b border-[#424245] z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <a href="/" className="text-xl font-inter font-bold text-white">
              ConnectEase
            </a>
            <div className="flex items-center space-x-6">
              <a
                href="/integrations"
                className="font-inter text-[#86868B] hover:text-[#0066FF]"
              >
                Solutions
              </a>
              <a
                href="/modular-system"
                className="font-inter text-[#86868B] hover:text-[#0066FF]"
              >
                Device Builder
              </a>
              <a href="/user-manual" className="font-inter text-white">
                User Manual
              </a>
              <a
                href="/account/signin"
                className="font-inter text-[#86868B] hover:text-[#0066FF]"
              >
                Sign In
              </a>
            </div>
          </div>
        </div>
      </nav>

      <div className="pt-16 pb-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row gap-8">
          <div className="md:w-1/4">
            <div className="sticky top-20">
              <div className="mb-6">
                <h2 className="text-2xl font-inter font-semibold mb-4">
                  User Manual
                </h2>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search manual..."
                    className="w-full bg-[#2A2A2A] border border-[#424245] rounded-lg py-2 px-4 text-white placeholder-[#86868B] focus:outline-none focus:ring-2 focus:ring-[#0066FF]"
                    value={searchQuery}
                    onChange={handleSearch}
                  />
                  <i className="fas fa-search absolute right-3 top-3 text-[#86868B]"></i>
                </div>

                {searchResults.length > 0 && (
                  <div className="mt-4 bg-[#2A2A2A] border border-[#424245] rounded-lg p-4 max-h-80 overflow-y-auto">
                    <h3 className="text-sm font-semibold text-[#86868B] mb-2">
                      Search Results ({searchResults.length})
                    </h3>
                    <div className="space-y-3">
                      {searchResults.map((result, index) => (
                        <div
                          key={index}
                          className="border-b border-[#424245] pb-2 last:border-0 last:pb-0"
                        >
                          {result.type === "section" ||
                          result.type === "content" ? (
                            <button
                              onClick={() => {
                                scrollToSection(result.sectionId);
                                setSearchQuery("");
                                setSearchResults([]);
                              }}
                              className="text-left w-full"
                            >
                              <div className="text-[#0066FF] font-medium hover:underline">
                                {result.title}
                              </div>
                              {result.snippet && (
                                <div className="text-sm text-[#86868B] mt-1">
                                  {result.snippet}
                                </div>
                              )}
                              <div className="text-xs text-[#86868B] mt-1">
                                Found in:{" "}
                                {result.match === "title"
                                  ? "Section title"
                                  : "Section content"}
                              </div>
                            </button>
                          ) : (
                            <div>
                              <div className="text-[#0066FF] font-medium">
                                {result.title}
                              </div>
                              {result.snippet && (
                                <div className="text-sm text-[#86868B] mt-1">
                                  {result.snippet}
                                </div>
                              )}
                              <div className="text-xs text-[#86868B] mt-1">
                                Found in: Tutorial{" "}
                                {result.match === "title"
                                  ? "title"
                                  : "description"}
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-[#1D1D1F] border border-[#424245] rounded-lg p-4">
                <h3 className="font-semibold mb-3">Table of Contents</h3>
                <ul className="space-y-2">
                  {Object.entries(manualContent).map(([id, section]) => (
                    <li key={id}>
                      <button
                        onClick={() => scrollToSection(id)}
                        className={`text-left w-full py-1 px-2 rounded ${
                          activeSection === id
                            ? "bg-[#0066FF] text-white"
                            : "text-[#86868B] hover:text-white"
                        }`}
                      >
                        {section.title}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>

              {tutorials.length > 0 && (
                <div className="mt-6 bg-[#1D1D1F] border border-[#424245] rounded-lg p-4">
                  <h3 className="font-semibold mb-3">Related Tutorials</h3>
                  <ul className="space-y-2">
                    {tutorials.slice(0, 5).map((tutorial) => (
                      <li
                        key={tutorial.id}
                        className="text-[#86868B] hover:text-white cursor-pointer"
                        onClick={() => handleInteractiveTutorial(tutorial.id)}
                      >
                        <i className="fas fa-play-circle mr-2 text-[#0066FF]"></i>
                        {tutorial.title}
                      </li>
                    ))}
                    <li className="text-[#0066FF] hover:underline text-sm pt-2">
                      <i className="fas fa-external-link-alt mr-1"></i>
                      View all tutorials
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>

          <div className="md:w-3/4">
            <FramerMotion
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-[#1D1D1F] border border-[#424245] rounded-lg p-6 mb-8"
            >
              <h1 className="text-3xl font-inter font-bold mb-4">
                ConnectEase User Manual
              </h1>
              <p className="text-[#86868B]">
                Welcome to the comprehensive guide for ConnectEase. This manual
                will help you understand all the features and capabilities of
                our platform, designed to simplify device connections for
                everyone.
              </p>
            </FramerMotion>

            <div className="space-y-12">
              {Object.entries(manualContent).map(([id, section]) => (
                <FramerMotion
                  key={id}
                  id={id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.5 }}
                  className="scroll-mt-20"
                >
                  <div className="bg-[#1D1D1F] border border-[#424245] rounded-lg p-6">
                    <h2 className="text-2xl font-inter font-semibold mb-4">
                      {section.title}
                    </h2>
                    <div className="space-y-4">
                      {section.content.map((content, index) => (
                        <div key={index}>
                          {typeof content === "string" ? (
                            <p className="text-[#86868B]">{content}</p>
                          ) : (
                            content
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </FramerMotion>
              ))}
            </div>

            <div className="mt-12 bg-[#1D1D1F] border border-[#424245] rounded-lg p-6">
              <h2 className="text-2xl font-inter font-semibold mb-4">
                Visual Guides
              </h2>
              <p className="text-[#86868B] mb-4">
                Explore our visual guides to better understand device
                connections.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-[#2A2A2A] p-4 rounded-lg">
                  <h4 className="text-white font-semibold mb-2">Guide 1</h4>
                  <p className="text-[#86868B] text-sm">
                    Step-by-step visual guide for setting up a home theater
                    system.
                  </p>
                </div>
                <div className="bg-[#2A2A2A] p-4 rounded-lg">
                  <h4 className="text-white font-semibold mb-2">Guide 2</h4>
                  <p className="text-[#86868B] text-sm">
                    Visual guide for connecting multiple devices to a single
                    display.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-12 bg-[#1D1D1F] border border-[#424245] rounded-lg p-6">
              <h2 className="text-2xl font-inter font-semibold mb-4">
                Test Your Knowledge
              </h2>
              <p className="text-[#86868B] mb-4">
                Take a quick quiz to test your understanding of device
                connections.
              </p>
              <button className="bg-[#2A2A2A] text-white border border-[#424245] rounded py-1 px-4 hover:bg-[#3A3A3A] transition-colors">
                Start Quiz
              </button>
            </div>
          </div>
        </div>
      </div>

      <footer className="bg-[#1D1D1F] border-t border-[#424245] py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <div className="text-xl font-inter font-bold text-white mb-2">
                ConnectEase
              </div>
              <div className="text-[#86868B]">
                © 2025 ConnectEase. All rights reserved.
              </div>
            </div>
            <div className="flex space-x-6">
              <a href="#" className="text-[#86868B] hover:text-white">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-[#86868B] hover:text-white">
                <i className="fab fa-facebook"></i>
              </a>
              <a href="#" className="text-[#86868B] hover:text-white">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-[#86868B] hover:text-white">
                <i className="fab fa-youtube"></i>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;