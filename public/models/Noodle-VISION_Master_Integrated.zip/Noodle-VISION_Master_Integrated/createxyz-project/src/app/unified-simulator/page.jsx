"use client";
import React from "react";

import { useHandleStreamResponse } from "../utilities/runtime-helpers";

function MainComponent() {
  const [activeTab, setActiveTab] = useState("interactive");
  const [devices, setDevices] = useState([]);
  const [availableDevices, setAvailableDevices] = useState([]);
  const [connections, setConnections] = useState([]);
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [streamingMessage, setStreamingMessage] = useState("");
  const [messages, setMessages] = useState([]);
  const [configName, setConfigName] = useState("");
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [savedConfigs, setSavedConfigs] = useState([]);
  const [showHelpTips, setShowHelpTips] = useState(false);
  const [arSurfaces, setArSurfaces] = useState([]);
  const [arDevices, setArDevices] = useState([]);
  const [arMode, setArMode] = useState("scanning"); // scanning, placing, connecting
  const [analysisResult, setAnalysisResult] = useState(null);

  useEffect(() => {
    const fetchDevices = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/load-3-d-models", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ deviceIds: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] }),
        });

        if (!response.ok) {
          throw new Error(`Error: ${response.status} ${response.statusText}`);
        }

        const data = await response.json();
        if (data.error) {
          throw new Error(data.error);
        }

        const categorizedDevices = (data.devices || []).map((device) => ({
          ...device,
          category: device.category || "Other",
          ports:
            device.inputPorts?.map((port) => ({
              name: `Port ${port}`,
              type: "Ethernet",
              speed: "1 Gbps",
              status: "active",
            })) || [],
        }));

        setAvailableDevices(categorizedDevices);
      } catch (err) {
        console.error("Failed to load devices:", err);
        setError("Failed to load devices. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    const fetchSavedConfigs = async () => {
      try {
        const response = await fetch("/api/get-user-configurations", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (response.ok) {
          const data = await response.json();
          if (data.success && data.configurations) {
            setSavedConfigs(data.configurations);
          }
        }
      } catch (err) {
        console.error("Failed to load saved configurations:", err);
      }
    };

    fetchDevices();
    fetchSavedConfigs();
  }, []);

  const filteredDevices = useMemo(() => {
    if (selectedCategory === "all") {
      return availableDevices;
    }
    return availableDevices.filter(
      (device) => device.category === selectedCategory
    );
  }, [availableDevices, selectedCategory]);

  const categories = useMemo(() => {
    const cats = [
      "all",
      ...new Set(availableDevices.map((device) => device.category)),
    ];
    return cats.filter((cat) => cat);
  }, [availableDevices]);

  const handleDrop = (item, position) => {
    const newDevice = {
      ...item,
      position,
      id: `device-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };
    setDevices((prev) => [...prev, newDevice]);
  };

  const handleArPlacement = (device, position) => {
    const newArDevice = {
      ...device,
      position,
      id: `ar-device-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };
    setArDevices((prev) => [...prev, newArDevice]);
  };

  const simulateConnections = async () => {
    if (devices.length < 2) {
      setError("Please add at least two devices to simulate connections");
      return;
    }

    try {
      setLoading(true);
      const userMessage = {
        role: "user",
        content: `Analyze the following device connections and provide compatibility assessment: ${JSON.stringify(
          devices.map((d) => ({
            name: d.name,
            model: d.model,
            category: d.category,
            ports: d.ports,
          }))
        )}`,
      };

      const response = await fetch("/integrations/google-gemini-1-5/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMessage],
          stream: true,
        }),
      });

      const handleStreamResponse = useHandleStreamResponse({
        onChunk: setStreamingMessage,
        onFinish: (message) => {
          setMessages((prev) => [
            ...prev,
            { role: "assistant", content: message },
          ]);
          setStreamingMessage("");

          try {
            const analysis = JSON.parse(message);
            setAnalysisResult(analysis);

            const simulatedConnections = [];
            devices.forEach((sourceDevice, i) => {
              devices.forEach((targetDevice, j) => {
                if (i !== j) {
                  const connectionStatus =
                    analysis[i]?.connections?.[j]?.status || "unknown";
                  simulatedConnections.push({
                    source: sourceDevice.id,
                    target: targetDevice.id,
                    status: connectionStatus,
                  });
                }
              });
            });

            setConnections(simulatedConnections);
          } catch (e) {
            console.error("Failed to parse analysis:", e);
            setError("Failed to parse compatibility analysis");
          }
        },
      });

      handleStreamResponse(response);
    } catch (e) {
      console.error(e);
      setError("Failed to simulate connections");
    } finally {
      setLoading(false);
    }
  };

  const saveConfiguration = async () => {
    if (!configName.trim()) {
      setError("Please enter a name for your configuration");
      return;
    }

    try {
      setLoading(true);
      const configData = {
        name: configName,
        mode: activeTab,
        devices: activeTab === "interactive" ? devices : arDevices,
        connections: connections,
        timestamp: new Date().toISOString(),
      };

      const response = await fetch("/api/save-user-configuration", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ configuration: configData }),
      });

      if (!response.ok) {
        throw new Error("Failed to save configuration");
      }

      const data = await response.json();
      if (data.success) {
        setSavedConfigs((prev) => [...prev, configData]);
        setShowSaveModal(false);
        setConfigName("");
      } else {
        throw new Error(data.error || "Failed to save configuration");
      }
    } catch (err) {
      console.error("Error saving configuration:", err);
      setError(err.message || "Failed to save configuration");
    } finally {
      setLoading(false);
    }
  };

  const loadConfiguration = (config) => {
    if (config.mode === "interactive") {
      setDevices(config.devices || []);
      setConnections(config.connections || []);
      setActiveTab("interactive");
    } else {
      setArDevices(config.devices || []);
      setConnections(config.connections || []);
      setActiveTab("ar");
    }
  };

  const clearConfiguration = () => {
    if (activeTab === "interactive") {
      setDevices([]);
    } else {
      setArDevices([]);
    }
    setConnections([]);
    setAnalysisResult(null);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 py-4 px-4 md:px-8">
      <div className="max-w-7xl mx-auto">
        <header className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Unified Hardware Simulator
          </h1>
          <p className="text-gray-700 dark:text-gray-300 font-inter mt-2">
            Test and visualize hardware compatibility in both virtual and
            augmented reality environments
          </p>
        </header>

        <div className="flex border-b border-gray-300 dark:border-gray-700 mb-6">
          <button
            className={`py-2 px-4 font-inter ${
              activeTab === "interactive"
                ? "border-b-2 border-blue-500 text-blue-600 dark:text-blue-400"
                : "text-gray-700 dark:text-gray-300"
            }`}
            onClick={() => setActiveTab("interactive")}
          >
            Interactive Simulator
          </button>
          <button
            className={`py-2 px-4 font-inter ${
              activeTab === "ar"
                ? "border-b-2 border-blue-500 text-blue-600 dark:text-blue-400"
                : "text-gray-700 dark:text-gray-300"
            }`}
            onClick={() => setActiveTab("ar")}
          >
            AR Simulator
          </button>
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          <div className="w-full md:w-1/4 bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
              Device Library
            </h2>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Filter by Category
              </label>
              <select
                className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
              >
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category === "all" ? "All Categories" : category}
                  </option>
                ))}
              </select>
            </div>

            <div className="overflow-y-auto max-h-[500px]">
              {loading ? (
                <div className="flex justify-center items-center py-8">
                  <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                </div>
              ) : error ? (
                <div className="bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 p-3 rounded-md">
                  {error}
                </div>
              ) : filteredDevices.length === 0 ? (
                <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                  No devices found
                </p>
              ) : (
                <div className="grid grid-cols-1 gap-3">
                  {filteredDevices.map((device) => (
                    <div
                      key={device.id}
                      className="bg-gray-100 dark:bg-gray-700 p-3 rounded-md cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-600"
                      onClick={() => setSelectedDevice(device)}
                      draggable={activeTab === "interactive"}
                      onDragStart={(e) => {
                        e.dataTransfer.setData(
                          "device",
                          JSON.stringify(device)
                        );
                      }}
                    >
                      <div className="flex items-center">
                        {device.thumbnailUrl && (
                          <img
                            src={device.thumbnailUrl}
                            alt={device.name}
                            className="w-12 h-12 object-contain mr-3"
                          />
                        )}
                        <div>
                          <h3 className="font-medium text-gray-900 dark:text-white">
                            {device.name}
                          </h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {device.category}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="mt-4 space-y-2">
              <button
                onClick={() => setShowSaveModal(true)}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-inter py-2 px-4 rounded-md"
              >
                Save Configuration
              </button>
              <button
                onClick={clearConfiguration}
                className="w-full bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200 font-inter py-2 px-4 rounded-md"
              >
                Clear Workspace
              </button>
              <button
                onClick={() => setShowHelpTips(!showHelpTips)}
                className="w-full bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200 font-inter py-2 px-4 rounded-md"
              >
                {showHelpTips ? "Hide Help" : "Show Help"}
              </button>
            </div>
          </div>

          <div className="w-full md:w-3/4">
            {activeTab === "interactive" ? (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 h-[600px] relative">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  Interactive Simulator
                </h2>

                <div
                  className="bg-gray-100 dark:bg-gray-700 rounded-md h-[450px] overflow-auto p-4"
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const deviceData = e.dataTransfer.getData("device");
                    if (deviceData) {
                      const device = JSON.parse(deviceData);
                      const position = {
                        x: e.nativeEvent.offsetX,
                        y: e.nativeEvent.offsetY,
                      };
                      handleDrop(device, position);
                    }
                  }}
                >
                  {devices.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-gray-500 dark:text-gray-400">
                      <i className="fas fa-arrow-down text-3xl mb-2"></i>
                      <p>Drag and drop devices here</p>
                    </div>
                  ) : (
                    <div className="relative h-full">
                      {devices.map((device) => (
                        <div
                          key={device.id}
                          className="absolute bg-white dark:bg-gray-800 p-3 rounded-md shadow-md"
                          style={{
                            left: `${device.position.x}px`,
                            top: `${device.position.y}px`,
                            zIndex: 10,
                          }}
                        >
                          <div className="flex items-center">
                            {device.thumbnailUrl && (
                              <img
                                src={device.thumbnailUrl}
                                alt={device.name}
                                className="w-10 h-10 object-contain mr-2"
                              />
                            )}
                            <div>
                              <h3 className="font-medium text-sm text-gray-900 dark:text-white">
                                {device.name}
                              </h3>
                              <p className="text-xs text-gray-600 dark:text-gray-400">
                                {device.category}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}

                      <svg className="absolute top-0 left-0 w-full h-full pointer-events-none">
                        {connections.map((connection, index) => {
                          const sourceDevice = devices.find(
                            (d) => d.id === connection.source
                          );
                          const targetDevice = devices.find(
                            (d) => d.id === connection.target
                          );

                          if (!sourceDevice || !targetDevice) return null;

                          const sourceX = sourceDevice.position.x + 50;
                          const sourceY = sourceDevice.position.y + 25;
                          const targetX = targetDevice.position.x + 50;
                          const targetY = targetDevice.position.y + 25;

                          return (
                            <line
                              key={index}
                              x1={sourceX}
                              y1={sourceY}
                              x2={targetX}
                              y2={targetY}
                              stroke={
                                connection.status === "compatible"
                                  ? "#10B981"
                                  : connection.status === "incompatible"
                                  ? "#EF4444"
                                  : "#9CA3AF"
                              }
                              strokeWidth="2"
                            />
                          );
                        })}
                      </svg>
                    </div>
                  )}
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    onClick={simulateConnections}
                    disabled={devices.length < 2 || loading}
                    className={`bg-blue-600 hover:bg-blue-700 text-white font-inter py-2 px-4 rounded-md ${
                      devices.length < 2 || loading
                        ? "opacity-50 cursor-not-allowed"
                        : ""
                    }`}
                  >
                    {loading ? "Analyzing..." : "Simulate Connections"}
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 h-[600px]">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  AR Simulator
                </h2>

                <div className="bg-gray-100 dark:bg-gray-700 rounded-md h-[450px] overflow-hidden relative">
                  {arMode === "scanning" ? (
                    <div className="flex flex-col items-center justify-center h-full">
                      <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                      <p className="text-gray-700 dark:text-gray-300 font-inter">
                        Scanning environment...
                      </p>
                      <button
                        onClick={() => setArMode("placing")}
                        className="mt-4 bg-blue-600 hover:bg-blue-700 text-white font-inter py-2 px-4 rounded-md"
                      >
                        Skip to Placement Mode
                      </button>
                    </div>
                  ) : (
                    <div className="h-full">
                      <div className="h-full flex items-center justify-center">
                        {selectedDevice ? (
                          <div className="text-center">
                            <p className="text-gray-700 dark:text-gray-300 font-inter mb-2">
                              Tap on the surface to place {selectedDevice.name}
                            </p>
                            <div className="bg-white dark:bg-gray-800 p-4 rounded-md shadow-md inline-block">
                              {selectedDevice.thumbnailUrl && (
                                <img
                                  src={selectedDevice.thumbnailUrl}
                                  alt={selectedDevice.name}
                                  className="w-24 h-24 object-contain mx-auto"
                                />
                              )}
                              <h3 className="font-medium text-gray-900 dark:text-white mt-2">
                                {selectedDevice.name}
                              </h3>
                            </div>
                            <div className="mt-4">
                              <button
                                onClick={() => {
                                  const position = {
                                    x: Math.floor(Math.random() * 300) + 50,
                                    y: Math.floor(Math.random() * 300) + 50,
                                    z: 0,
                                  };
                                  handleArPlacement(selectedDevice, position);
                                  setSelectedDevice(null);
                                }}
                                className="bg-green-600 hover:bg-green-700 text-white font-inter py-2 px-4 rounded-md mr-2"
                              >
                                Place Device
                              </button>
                              <button
                                onClick={() => setSelectedDevice(null)}
                                className="bg-gray-500 hover:bg-gray-600 text-white font-inter py-2 px-4 rounded-md"
                              >
                                Cancel
                              </button>
                            </div>
                          </div>
                        ) : arDevices.length === 0 ? (
                          <div className="text-center">
                            <p className="text-gray-700 dark:text-gray-300 font-inter mb-4">
                              Select a device from the library to place in AR
                            </p>
                            <i className="fas fa-arrow-left text-3xl text-gray-500 dark:text-gray-400"></i>
                          </div>
                        ) : (
                          <div className="relative h-full w-full">
                            {arDevices.map((device) => (
                              <div
                                key={device.id}
                                className="absolute bg-white dark:bg-gray-800 p-3 rounded-md shadow-md"
                                style={{
                                  left: `${device.position.x}px`,
                                  top: `${device.position.y}px`,
                                  zIndex: 10,
                                }}
                              >
                                <div className="flex items-center">
                                  {device.thumbnailUrl && (
                                    <img
                                      src={device.thumbnailUrl}
                                      alt={device.name}
                                      className="w-10 h-10 object-contain mr-2"
                                    />
                                  )}
                                  <div>
                                    <h3 className="font-medium text-sm text-gray-900 dark:text-white">
                                      {device.name}
                                    </h3>
                                    <p className="text-xs text-gray-600 dark:text-gray-400">
                                      {device.category}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    onClick={() =>
                      setArMode(arMode === "scanning" ? "placing" : "scanning")
                    }
                    className="bg-blue-600 hover:bg-blue-700 text-white font-inter py-2 px-4 rounded-md"
                  >
                    {arMode === "scanning"
                      ? "Start Placement"
                      : "Restart Scanning"}
                  </button>
                  {arDevices.length >= 2 && (
                    <button
                      onClick={simulateConnections}
                      className="bg-green-600 hover:bg-green-700 text-white font-inter py-2 px-4 rounded-md"
                    >
                      Analyze AR Setup
                    </button>
                  )}
                </div>
              </div>
            )}

            {analysisResult && (
              <div className="mt-6 bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  Compatibility Analysis
                </h2>
                <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-md">
                  <pre className="text-sm text-gray-800 dark:text-gray-200 whitespace-pre-wrap font-inter">
                    {JSON.stringify(analysisResult, null, 2)}
                  </pre>
                </div>
              </div>
            )}
          </div>
        </div>

        {showHelpTips && (
          <div className="mt-6 bg-blue-50 dark:bg-blue-900 rounded-lg p-4">
            <h2 className="text-xl font-semibold text-blue-800 dark:text-blue-200 mb-3">
              Quick Tips
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h3 className="font-medium text-blue-700 dark:text-blue-300 mb-2">
                  Interactive Simulator
                </h3>
                <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 font-inter space-y-1 ml-2">
                  <li>Drag devices from the library to the simulator area</li>
                  <li>Add at least two devices to simulate connections</li>
                  <li>Green lines indicate compatible connections</li>
                  <li>Red lines indicate incompatible connections</li>
                  <li>Save your configuration to access it later</li>
                </ul>
              </div>
              <div>
                <h3 className="font-medium text-blue-700 dark:text-blue-300 mb-2">
                  AR Simulator
                </h3>
                <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 font-inter space-y-1 ml-2">
                  <li>Select a device from the library to place in AR</li>
                  <li>Wait for surface detection or skip to placement mode</li>
                  <li>Tap on surfaces to place selected devices</li>
                  <li>Use the analyze button to check compatibility</li>
                  <li>For best results, use in well-lit environments</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {savedConfigs.length > 0 && (
          <div className="mt-6 bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
              Saved Configurations
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {savedConfigs.map((config, index) => (
                <div
                  key={index}
                  className="bg-gray-100 dark:bg-gray-700 p-3 rounded-md cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-600"
                  onClick={() => loadConfiguration(config)}
                >
                  <h3 className="font-medium text-gray-900 dark:text-white">
                    {config.name}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Mode: {config.mode === "interactive" ? "Interactive" : "AR"}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Devices: {config.devices?.length || 0}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    {new Date(config.timestamp).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {showSaveModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                Save Configuration
              </h2>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Configuration Name
                </label>
                <input
                  type="text"
                  name="configName"
                  value={configName}
                  onChange={(e) => setConfigName(e.target.value)}
                  className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300"
                  placeholder="My Hardware Setup"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setShowSaveModal(false)}
                  className="bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200 font-inter py-2 px-4 rounded-md"
                >
                  Cancel
                </button>
                <button
                  onClick={saveConfiguration}
                  disabled={!configName.trim() || loading}
                  className={`bg-blue-600 hover:bg-blue-700 text-white font-inter py-2 px-4 rounded-md ${
                    !configName.trim() || loading
                      ? "opacity-50 cursor-not-allowed"
                      : ""
                  }`}
                >
                  {loading ? "Saving..." : "Save"}
                </button>
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className="fixed bottom-4 right-4 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 px-4 py-2 rounded-md shadow-lg">
            {error}
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;