"use client";
import React from "react";

function MainComponent() {
  const [testResults, setTestResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [testHistory, setTestHistory] = useState([]);
  const [selectedTest, setSelectedTest] = useState(null);

  const runTests = async (testType) => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/test-runner", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ testType }),
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }

      const data = await response.json();
      setTestResults(data);

      const timestamp = new Date().toISOString();
      setTestHistory((prev) => [
        {
          id: timestamp,
          timestamp,
          testType,
          success: data.success,
          stats: data.stats,
        },
        ...prev.slice(0, 9),
      ]);
    } catch (err) {
      setError(err.message);
      console.error("Failed to run tests:", err);
    } finally {
      setLoading(false);
    }
  };

  const getFilteredResults = () => {
    if (!testResults) return [];

    let results = [];

    if (activeTab === "all" && testResults.results) {
      if (Array.isArray(testResults.results)) {
        results = testResults.results;
      } else if (
        testResults.results.unit &&
        testResults.results.component &&
        testResults.results.e2e
      ) {
        results = [
          ...(testResults.results.unit.results || []),
          ...(testResults.results.component.results || []),
          ...(testResults.results.e2e.results || []),
        ];
      }
    } else if (activeTab === "unit" && testResults.results) {
      results = Array.isArray(testResults.results)
        ? testResults.results
        : testResults.results.unit?.results || [];
    } else if (activeTab === "component" && testResults.results) {
      results = Array.isArray(testResults.results)
        ? testResults.results
        : testResults.results.component?.results || [];
    } else if (activeTab === "e2e" && testResults.results) {
      results = Array.isArray(testResults.results)
        ? testResults.results
        : testResults.results.e2e?.results || [];
    }

    if (filterStatus === "passed") {
      return results.filter((test) => test.status === "passed");
    } else if (filterStatus === "failed") {
      return results.filter((test) => test.status === "failed");
    }

    return results;
  };

  const viewTestDetails = (test) => {
    setSelectedTest(test);
  };

  const closeTestDetails = () => {
    setSelectedTest(null);
  };

  return (
    <div className="min-h-screen bg-[#1B1B1B] font-inter">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-medium text-[#F6F6F6] mb-2">
            Test Dashboard
          </h1>
          <p className="text-[#B1B1B1]">
            Run and monitor automated tests for the application
          </p>
        </div>

        <div className="bg-white rounded-lg p-6 mb-8">
          <h2 className="text-xl font-medium text-[#191919] mb-4">Run Tests</h2>
          <div className="flex flex-wrap gap-4">
            <button
              onClick={() => runTests("unit")}
              disabled={loading}
              className="px-4 py-2 bg-[#6567EF] text-white rounded hover:bg-[#2C2C2C] hover:text-[#F6F6F6] transition-colors disabled:bg-[#B1B1B1]"
            >
              Run Unit Tests
            </button>
            <button
              onClick={() => runTests("component")}
              disabled={loading}
              className="px-4 py-2 bg-[#6567EF] text-white rounded hover:bg-[#2C2C2C] hover:text-[#F6F6F6] transition-colors disabled:bg-[#B1B1B1]"
            >
              Run Component Tests
            </button>
            <button
              onClick={() => runTests("e2e")}
              disabled={loading}
              className="px-4 py-2 bg-[#6567EF] text-white rounded hover:bg-[#2C2C2C] hover:text-[#F6F6F6] transition-colors disabled:bg-[#B1B1B1]"
            >
              Run E2E Tests
            </button>
            <button
              onClick={() => runTests("all")}
              disabled={loading}
              className="px-4 py-2 bg-[#6567EF] text-white rounded hover:bg-[#2C2C2C] hover:text-[#F6F6F6] transition-colors disabled:bg-[#B1B1B1]"
            >
              Run All Tests
            </button>
          </div>

          {loading && (
            <div className="mt-4 flex items-center text-[#6567EF]">
              <i className="fas fa-circle-notch fa-spin mr-2"></i>
              Running tests...
            </div>
          )}

          {error && (
            <div className="mt-4 p-3 bg-red-100 text-red-700 rounded">
              <i className="fas fa-exclamation-circle mr-2"></i>
              {error}
            </div>
          )}
        </div>

        {testResults && (
          <div className="bg-white rounded-lg p-6 mb-8">
            <h2 className="text-xl font-medium text-[#191919] mb-4">
              Test Results
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-[#F6F6F6] p-4 rounded">
                <div className="text-[#5D646C] text-sm">Total Tests</div>
                <div className="text-2xl font-medium text-[#191919]">
                  {testResults.stats.tests}
                </div>
              </div>
              <div className="bg-[#F6F6F6] p-4 rounded">
                <div className="text-[#5D646C] text-sm">Passed</div>
                <div className="text-2xl font-medium text-[#191919]">
                  {testResults.stats.passed}
                </div>
              </div>
              <div className="bg-[#F6F6F6] p-4 rounded">
                <div className="text-[#5D646C] text-sm">Failed</div>
                <div className="text-2xl font-medium text-[#191919]">
                  {testResults.stats.failed}
                </div>
              </div>
              <div className="bg-[#F6F6F6] p-4 rounded">
                <div className="text-[#5D646C] text-sm">Skipped</div>
                <div className="text-2xl font-medium text-[#191919]">
                  {testResults.stats.skipped || 0}
                </div>
              </div>
            </div>

            <div className="flex flex-col md:flex-row justify-between mb-4">
              <div className="flex mb-4 md:mb-0">
                <button
                  onClick={() => setActiveTab("all")}
                  className={`px-4 py-2 rounded-l ${
                    activeTab === "all"
                      ? "bg-[#6567EF] text-white"
                      : "bg-[#F6F6F6] text-[#191919]"
                  }`}
                >
                  All Tests
                </button>
                <button
                  onClick={() => setActiveTab("unit")}
                  className={`px-4 py-2 ${
                    activeTab === "unit"
                      ? "bg-[#6567EF] text-white"
                      : "bg-[#F6F6F6] text-[#191919]"
                  }`}
                >
                  Unit
                </button>
                <button
                  onClick={() => setActiveTab("component")}
                  className={`px-4 py-2 ${
                    activeTab === "component"
                      ? "bg-[#6567EF] text-white"
                      : "bg-[#F6F6F6] text-[#191919]"
                  }`}
                >
                  Component
                </button>
                <button
                  onClick={() => setActiveTab("e2e")}
                  className={`px-4 py-2 rounded-r ${
                    activeTab === "e2e"
                      ? "bg-[#6567EF] text-white"
                      : "bg-[#F6F6F6] text-[#191919]"
                  }`}
                >
                  E2E
                </button>
              </div>

              <div className="flex">
                <button
                  onClick={() => setFilterStatus("all")}
                  className={`px-4 py-2 rounded-l ${
                    filterStatus === "all"
                      ? "bg-[#6567EF] text-white"
                      : "bg-[#F6F6F6] text-[#191919]"
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setFilterStatus("passed")}
                  className={`px-4 py-2 ${
                    filterStatus === "passed"
                      ? "bg-[#6567EF] text-white"
                      : "bg-[#F6F6F6] text-[#191919]"
                  }`}
                >
                  Passed
                </button>
                <button
                  onClick={() => setFilterStatus("failed")}
                  className={`px-4 py-2 rounded-r ${
                    filterStatus === "failed"
                      ? "bg-[#6567EF] text-white"
                      : "bg-[#F6F6F6] text-[#191919]"
                  }`}
                >
                  Failed
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-[#F6F6F6]">
                    <th className="text-left p-3 border-b text-[#191919]">
                      Test Name
                    </th>
                    <th className="text-left p-3 border-b text-[#191919]">
                      Status
                    </th>
                    <th className="text-left p-3 border-b text-[#191919]">
                      Duration
                    </th>
                    <th className="text-left p-3 border-b text-[#191919]">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {getFilteredResults().length > 0 ? (
                    getFilteredResults().map((test, index) => (
                      <tr key={index} className="hover:bg-[#E4E7EA]">
                        <td className="p-3 border-b text-[#191919]">
                          {test.name}
                        </td>
                        <td className="p-3 border-b">
                          {test.status === "passed" ? (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              <i className="fas fa-check-circle mr-1"></i>{" "}
                              Passed
                            </span>
                          ) : (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                              <i className="fas fa-times-circle mr-1"></i>{" "}
                              Failed
                            </span>
                          )}
                        </td>
                        <td className="p-3 border-b text-[#191919]">
                          {test.duration || "N/A"}
                        </td>
                        <td className="p-3 border-b">
                          <button
                            onClick={() => viewTestDetails(test)}
                            className="text-[#6567EF] hover:text-[#191919]"
                          >
                            <i className="fas fa-info-circle mr-1"></i> Details
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td
                        colSpan="4"
                        className="p-3 text-center text-[#5D646C]"
                      >
                        No test results match the current filters
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        <div className="bg-white rounded-lg p-6">
          <h2 className="text-xl font-medium text-[#191919] mb-4">
            Test History
          </h2>

          {testHistory.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-[#F6F6F6]">
                    <th className="text-left p-3 border-b text-[#191919]">
                      Timestamp
                    </th>
                    <th className="text-left p-3 border-b text-[#191919]">
                      Test Type
                    </th>
                    <th className="text-left p-3 border-b text-[#191919]">
                      Status
                    </th>
                    <th className="text-left p-3 border-b text-[#191919]">
                      Results
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {testHistory.map((history) => (
                    <tr key={history.id} className="hover:bg-[#E4E7EA]">
                      <td className="p-3 border-b text-[#191919]">
                        {new Date(history.timestamp).toLocaleString()}
                      </td>
                      <td className="p-3 border-b text-[#191919] capitalize">
                        {history.testType}
                      </td>
                      <td className="p-3 border-b">
                        {history.success ? (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            <i className="fas fa-check-circle mr-1"></i> Passed
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                            <i className="fas fa-times-circle mr-1"></i> Failed
                          </span>
                        )}
                      </td>
                      <td className="p-3 border-b text-[#191919]">
                        {history.stats.passed}/{history.stats.tests} passed
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center text-[#5D646C] py-4">
              No test history available. Run some tests to see results here.
            </div>
          )}
        </div>
      </div>

      {selectedTest && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg w-full max-w-3xl max-h-[80vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-medium text-[#191919]">
                  {selectedTest.name}
                </h3>
                <button
                  onClick={closeTestDetails}
                  className="text-[#5D646C] hover:text-[#191919]"
                >
                  <i className="fas fa-times"></i>
                </button>
              </div>

              <div className="mb-4">
                <div className="flex items-center mb-2">
                  <span className="font-medium text-[#191919] mr-2">
                    Status:
                  </span>
                  {selectedTest.status === "passed" ? (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      <i className="fas fa-check-circle mr-1"></i> Passed
                    </span>
                  ) : (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                      <i className="fas fa-times-circle mr-1"></i> Failed
                    </span>
                  )}
                </div>

                {selectedTest.duration && (
                  <div className="mb-2">
                    <span className="font-medium text-[#191919]">
                      Duration:
                    </span>{" "}
                    {selectedTest.duration}
                  </div>
                )}
              </div>

              {selectedTest.error && (
                <div className="mb-4">
                  <h4 className="font-medium text-[#191919] mb-2">
                    Error Details:
                  </h4>
                  <div className="bg-red-50 p-4 rounded border border-red-200 text-red-800 font-mono text-sm whitespace-pre-wrap">
                    {selectedTest.error}
                  </div>
                </div>
              )}

              {selectedTest.assertions && (
                <div>
                  <h4 className="font-medium text-[#191919] mb-2">
                    Assertions:
                  </h4>
                  <ul className="list-disc pl-5">
                    {selectedTest.assertions.map((assertion, index) => (
                      <li
                        key={index}
                        className="mb-1 font-mono text-sm text-[#191919]"
                      >
                        {assertion}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="bg-[#F6F6F6] px-6 py-3 flex justify-end">
              <button
                onClick={closeTestDetails}
                className="px-4 py-2 bg-[#6567EF] text-white rounded hover:bg-[#2C2C2C] hover:text-[#F6F6F6] transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default MainComponent;