"use client";
import React from "react";

function MainComponent() {
  const [selectedBillingCycle, setSelectedBillingCycle] = useState("monthly");
  const { data: user, loading: userLoading } = useUser();
  const [userSubscription, setUserSubscription] = useState(null);
  const [loadingSubscription, setLoadingSubscription] = useState(false);
  const [error, setError] = useState(null);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [processingSubscription, setProcessingSubscription] = useState(false);
  const [cancellingSubscription, setCancellingSubscription] = useState(false);

  useEffect(() => {
    if (user) {
      fetchUserSubscription();
    }
  }, [user]);

  const fetchUserSubscription = async () => {
    setLoadingSubscription(true);
    setError(null);
    try {
      const response = await fetch("/api/get-user-subscription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }

      const data = await response.json();
      setUserSubscription(data.subscription);
    } catch (err) {
      console.error("Failed to fetch subscription:", err);
      setError("Failed to load your subscription information.");
    } finally {
      setLoadingSubscription(false);
    }
  };

  const handleSubscribe = async (planId) => {
    if (!user) {
      window.location.href = "/account/signin?callbackUrl=/pricing";
      return;
    }

    setProcessingSubscription(true);
    setError(null);
    try {
      const response = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          planId,
          billingCycle: selectedBillingCycle,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }

      const data = await response.json();
      window.location.href = data.url;
    } catch (err) {
      console.error("Failed to create checkout session:", err);
      setError("Failed to process subscription. Please try again.");
    } finally {
      setProcessingSubscription(false);
    }
  };

  const handleCancelSubscription = async () => {
    if (!user || !userSubscription) return;

    setCancellingSubscription(true);
    setError(null);
    try {
      const response = await fetch("/api/cancel-subscription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }

      setShowSuccessMessage(true);
      setTimeout(() => {
        setShowSuccessMessage(false);
      }, 5000);

      fetchUserSubscription();
    } catch (err) {
      console.error("Failed to cancel subscription:", err);
      setError("Failed to cancel subscription. Please try again.");
    } finally {
      setCancellingSubscription(false);
    }
  };

  const plans = [
    {
      id: "free",
      name: "Free",
      description: "Basic access to hardware compatibility tools",
      price: {
        monthly: 0,
        yearly: 0,
      },
      features: [
        "Basic device compatibility checks",
        "Limited AR simulations (5/month)",
        "Standard support",
        "Single user access",
        "Basic device library",
      ],
      recommended: false,
      buttonText: "Get Started",
      buttonColor: "bg-gray-600 hover:bg-gray-700",
    },
    {
      id: "standard",
      name: "Standard",
      description: "Enhanced tools for professionals",
      price: {
        monthly: 19.99,
        yearly: 199.99,
      },
      features: [
        "Advanced compatibility analysis",
        "Unlimited AR simulations",
        "Priority support",
        "Up to 5 team members",
        "Extended device library",
        "Save up to 10 configurations",
      ],
      recommended: true,
      buttonText: "Subscribe Now",
      buttonColor: "bg-blue-600 hover:bg-blue-700",
    },
    {
      id: "premium",
      name: "Premium",
      description: "Complete solution for enterprises",
      price: {
        monthly: 49.99,
        yearly: 499.99,
      },
      features: [
        "Enterprise-grade compatibility analysis",
        "Unlimited AR simulations",
        "24/7 dedicated support",
        "Unlimited team members",
        "Full device library with custom additions",
        "Unlimited saved configurations",
        "API access for integration",
      ],
      recommended: false,
      buttonText: "Contact Sales",
      buttonColor: "bg-purple-600 hover:bg-purple-700",
    },
  ];

  const faqs = [
    {
      question: "How do I change my subscription plan?",
      answer:
        "You can upgrade your plan at any time from your account dashboard. When upgrading, you'll only be charged the prorated difference for the remainder of your billing cycle.",
    },
    {
      question: "Can I cancel my subscription?",
      answer:
        "Yes, you can cancel your subscription at any time from your account settings. Your subscription will remain active until the end of your current billing period.",
    },
    {
      question: "Do you offer discounts for educational institutions?",
      answer:
        "Yes, we offer special pricing for educational institutions. Please contact our sales team for more information.",
    },
    {
      question: "What payment methods do you accept?",
      answer:
        "We accept all major credit cards, PayPal, and bank transfers for annual plans.",
    },
    {
      question: "Is there a free trial available?",
      answer:
        "Yes, all paid plans come with a 14-day free trial. No credit card required to start.",
    },
    {
      question: "How does the billing cycle work?",
      answer:
        "You can choose between monthly or annual billing. Annual billing comes with a discount equivalent to 2 months free compared to monthly billing.",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 py-16 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 font-inter">
            Choose Your Plan
          </h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto font-inter">
            Get access to our powerful hardware compatibility tools with a plan
            that fits your needs
          </p>

          {user && userSubscription && !loadingSubscription && (
            <div className="mt-6 bg-white/10 backdrop-blur-sm rounded-lg p-4 max-w-xl mx-auto">
              <p className="text-white font-inter">
                You are currently on the{" "}
                <span className="font-bold">{userSubscription.planName}</span>{" "}
                plan.
                {userSubscription.renewalDate && (
                  <span>
                    {" "}
                    Next billing date:{" "}
                    {new Date(
                      userSubscription.renewalDate
                    ).toLocaleDateString()}
                  </span>
                )}
              </p>
            </div>
          )}

          {showSuccessMessage && (
            <div className="mt-6 bg-green-500/90 backdrop-blur-sm rounded-lg p-4 max-w-xl mx-auto">
              <p className="text-white font-inter">
                Your subscription has been successfully cancelled. You'll have
                access until the end of your billing period.
              </p>
            </div>
          )}

          {error && (
            <div className="mt-6 bg-red-500/90 backdrop-blur-sm rounded-lg p-4 max-w-xl mx-auto">
              <p className="text-white font-inter">{error}</p>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-12 px-4">
        <div className="flex justify-center items-center space-x-4">
          <span
            className={`text-lg font-inter ${
              selectedBillingCycle === "monthly"
                ? "text-gray-900 dark:text-white font-medium"
                : "text-gray-500 dark:text-gray-400"
            }`}
          >
            Monthly
          </span>
          <button
            onClick={() =>
              setSelectedBillingCycle(
                selectedBillingCycle === "monthly" ? "yearly" : "monthly"
              )
            }
            className="relative inline-flex h-6 w-12 items-center rounded-full bg-gray-300 dark:bg-gray-700"
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                selectedBillingCycle === "yearly"
                  ? "translate-x-7"
                  : "translate-x-1"
              }`}
            />
          </button>
          <span
            className={`text-lg font-inter ${
              selectedBillingCycle === "yearly"
                ? "text-gray-900 dark:text-white font-medium"
                : "text-gray-500 dark:text-gray-400"
            }`}
          >
            Yearly{" "}
            <span className="text-green-500 text-sm font-medium">Save 16%</span>
          </span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto py-12 px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`rounded-xl overflow-hidden shadow-lg transition-all duration-300 hover:shadow-xl bg-white dark:bg-gray-800 border ${
                plan.recommended
                  ? "border-blue-500 dark:border-blue-400 transform scale-105 md:scale-110"
                  : "border-transparent"
              }`}
            >
              {plan.recommended && (
                <div className="bg-blue-500 text-white text-center py-2 font-inter font-medium">
                  Recommended
                </div>
              )}
              <div className="p-6">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2 font-inter">
                  {plan.name}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-6 font-inter">
                  {plan.description}
                </p>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-gray-900 dark:text-white font-inter">
                    ${plan.price[selectedBillingCycle].toFixed(2)}
                  </span>
                  <span className="text-gray-600 dark:text-gray-300 font-inter">
                    {plan.price[selectedBillingCycle] > 0
                      ? `/${selectedBillingCycle === "monthly" ? "mo" : "yr"}`
                      : ""}
                  </span>
                </div>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <i className="fas fa-check text-green-500 mt-1 mr-2"></i>
                      <span className="text-gray-700 dark:text-gray-300 font-inter">
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => handleSubscribe(plan.id)}
                  disabled={
                    processingSubscription ||
                    (userSubscription && userSubscription.planId === plan.id)
                  }
                  className={`w-full py-3 px-4 rounded-lg text-white font-medium transition-colors font-inter ${
                    userSubscription && userSubscription.planId === plan.id
                      ? "bg-gray-400 cursor-not-allowed"
                      : plan.buttonColor
                  }`}
                >
                  {processingSubscription ? (
                    <span className="flex items-center justify-center">
                      <i className="fas fa-spinner fa-spin mr-2"></i>{" "}
                      Processing...
                    </span>
                  ) : userSubscription &&
                    userSubscription.planId === plan.id ? (
                    "Current Plan"
                  ) : (
                    plan.buttonText
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {user && userSubscription && userSubscription.planId !== "free" && (
        <div className="max-w-7xl mx-auto pb-12 px-4 text-center">
          <button
            onClick={handleCancelSubscription}
            disabled={cancellingSubscription}
            className="py-2 px-4 rounded-lg text-red-600 border border-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors font-inter"
          >
            {cancellingSubscription ? (
              <span className="flex items-center justify-center">
                <i className="fas fa-spinner fa-spin mr-2"></i> Processing...
              </span>
            ) : (
              "Cancel Subscription"
            )}
          </button>
        </div>
      )}

      <div className="max-w-7xl mx-auto py-12 px-4 bg-gray-100 dark:bg-gray-800 rounded-xl">
        <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12 font-inter">
          Compare Features
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-300 dark:border-gray-700">
                <th className="text-left py-4 px-4 font-inter text-gray-900 dark:text-white">
                  Feature
                </th>
                {plans.map((plan) => (
                  <th
                    key={plan.id}
                    className="text-center py-4 px-4 font-inter text-gray-900 dark:text-white"
                  >
                    {plan.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-300 dark:border-gray-700">
                <td className="py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  AR Simulations
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  5/month
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  Unlimited
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  Unlimited
                </td>
              </tr>
              <tr className="border-b border-gray-300 dark:border-gray-700">
                <td className="py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  Team Members
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  1
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  Up to 5
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  Unlimited
                </td>
              </tr>
              <tr className="border-b border-gray-300 dark:border-gray-700">
                <td className="py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  Saved Configurations
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  3
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  10
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  Unlimited
                </td>
              </tr>
              <tr className="border-b border-gray-300 dark:border-gray-700">
                <td className="py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  Support
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  Standard
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  Priority
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  24/7 Dedicated
                </td>
              </tr>
              <tr className="border-b border-gray-300 dark:border-gray-700">
                <td className="py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  API Access
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  <i className="fas fa-times text-red-500"></i>
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  <i className="fas fa-times text-red-500"></i>
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  <i className="fas fa-check text-green-500"></i>
                </td>
              </tr>
              <tr>
                <td className="py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  Custom Device Library
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  <i className="fas fa-times text-red-500"></i>
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  <i className="fas fa-times text-red-500"></i>
                </td>
                <td className="text-center py-4 px-4 font-inter text-gray-700 dark:text-gray-300">
                  <i className="fas fa-check text-green-500"></i>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="max-w-4xl mx-auto py-16 px-4">
        <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12 font-inter">
          Frequently Asked Questions
        </h2>
        <div className="space-y-6">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6"
            >
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3 font-inter">
                {faq.question}
              </h3>
              <p className="text-gray-700 dark:text-gray-300 font-inter">
                {faq.answer}
              </p>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-600 to-purple-600 py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-6 font-inter">
            Ready to get started?
          </h2>
          <p className="text-xl text-white/90 mb-8 font-inter">
            Join thousands of professionals who trust our platform for their
            hardware compatibility needs.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a
              href={user ? "#pricing" : "/account/signup"}
              className="bg-white text-blue-600 hover:bg-gray-100 py-3 px-8 rounded-lg font-medium transition-colors font-inter"
            >
              {user ? "Choose a Plan" : "Sign Up Free"}
            </a>
            <a
              href="/simulator"
              className="bg-transparent border border-white text-white hover:bg-white/10 py-3 px-8 rounded-lg font-medium transition-colors font-inter"
            >
              Try Demo
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;