"use client";
import React from "react";
import Button from "../../components/button";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [patches, setPatches] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState(null);

  React.useEffect(() => {
    async function fetchPatches() {
      if (!user) {
        setLoading(false);
        return;
      }
      setLoading(true);
      setError(null);
      try {
        const response = await fetch("/api/user-patches", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ userId: user.id }),
        });
        if (!response.ok) {
          throw new Error(
            `Failed to fetch patches: [${response.status}] ${response.statusText}`
          );
        }
        const data = await response.json();
        setPatches(Array.isArray(data.patches) ? data.patches : []);
      } catch (err) {
        console.error(err);
        setError("Could not load your simulators. Please try again.");
      } finally {
        setLoading(false);
      }
    }
    if (user && !userLoading) {
      fetchPatches();
    }
  }, [user, userLoading]);

  if (userLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F6F6F6] font-inter">
        <div className="flex flex-col items-center">
          <i className="fas fa-spinner fa-spin text-3xl text-[#6567EF] mb-4"></i>
          <div className="text-[#5D646C] text-lg">
            Loading your simulators...
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#F6F6F6] font-inter">
        <div className="bg-white rounded-xl shadow p-8 max-w-md w-full flex flex-col items-center">
          <i className="fas fa-user-lock text-3xl text-[#6567EF] mb-4"></i>
          <div className="text-[#191919] text-xl mb-2">Sign in required</div>
          <div className="text-[#5D646C] mb-6 text-center">
            Please{" "}
            <a href="/account/signin" className="text-[#6567EF] underline">
              sign in
            </a>{" "}
            to view your modular simulators.
          </div>
          <a href="/dashboard" className="w-full">
            <Button text="Back to Dashboard" highlighted={true} />
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F6F6F6] font-inter flex flex-col items-center py-10 px-2">
      <div className="w-full max-w-3xl bg-white rounded-2xl shadow border border-[#E4E7EA] p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-medium text-[#191919]">
            My Modular Simulators
          </h1>
          <a href="/dashboard">
            <Button text="Back to Dashboard" />
          </a>
        </div>
        {error && <div className="mb-4 text-red-600 text-sm">{error}</div>}
        {patches.length === 0 ? (
          <div className="flex flex-col items-center py-16">
            <i className="fas fa-cube text-3xl text-[#6567EF] mb-4"></i>
            <div className="text-[#191919] text-lg mb-2">
              No simulators found
            </div>
            <div className="text-[#5D646C] mb-4 text-center">
              You haven't created any modular simulators yet.
              <br />
              Start by building a new patch!
            </div>
            <a href="/interactive-setup-simulator">
              <Button text="Create New Simulator" highlighted={true} />
            </a>
          </div>
        ) : (
          <div className="divide-y divide-[#E4E7EA]">
            {patches.map((patch) => (
              <div
                key={patch.id}
                className="flex flex-col md:flex-row items-start md:items-center py-4"
              >
                <div className="flex-1">
                  <div className="text-[#191919] font-medium text-base mb-1">
                    {patch.name || "Untitled Patch"}
                  </div>
                  <div className="text-[#8C8C8C] text-sm">
                    {patch.description || "No description provided."}
                  </div>
                </div>
                <div className="mt-3 md:mt-0 md:ml-4">
                  <a
                    href={`/setup-simulator?patchId=${encodeURIComponent(
                      patch.id
                    )}`}
                  >
                    <Button text="Open Simulator" highlighted={true} />
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;