"use client";
import React from "react";

function MainComponent() {
  return null;
}

export default MainComponent;