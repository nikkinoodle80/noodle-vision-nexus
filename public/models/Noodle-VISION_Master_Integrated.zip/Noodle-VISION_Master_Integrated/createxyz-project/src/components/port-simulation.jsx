"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ ports, onPortConnect }) {
  const [highlightedPort, setHighlightedPort] = useState(null);

  const handleDragOver = (portId) => {
    setHighlightedPort(portId);
  };

  const handleDragLeave = () => {
    setHighlightedPort(null);
  };

  const handleDrop = (portId) => {
    onPortConnect(portId);
    setHighlightedPort(null);
  };

  return (
    <div className="grid grid-cols-4 gap-4 p-4">
      {ports.map((port) => (
        <div
          key={port.id}
          className={`w-10 h-10 rounded-full ${
            highlightedPort === port.id ? "bg-green-500" : "bg-gray-300"
          } flex items-center justify-center cursor-pointer`}
          onDragOver={() => handleDragOver(port.id)}
          onDragLeave={handleDragLeave}
          onDrop={() => handleDrop(port.id)}
        >
          {port.name}
        </div>
      ))}
    </div>
  );
}

function StoryComponent() {
  const ports = [
    { id: 1, name: "Port 1" },
    { id: 2, name: "Port 2" },
    { id: 3, name: "Port 3" },
    { id: 4, name: "Port 4" },
  ];

  const handlePortConnect = (portId) => {
    console.log(`Connected to port ${portId}`);
  };

  return (
    <div>
      <MainComponent ports={ports} onPortConnect={handlePortConnect} />
    </div>
  );
});
}