"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ settings }) {
  const [activeTab, setActiveTab] = useState(settings[0]?.name || "");

  return (
    <div className="w-full">
      <div className="flex flex-col md:flex-row border-b border-gray-200 dark:border-gray-700">
        {settings.map((setting) => (
          <button
            key={setting.name}
            className={`flex-1 text-center py-2 px-4 font-medium text-gray-600 dark:text-gray-300 ${
              activeTab === setting.name
                ? "border-b-2 border-blue-500 text-blue-600 dark:text-blue-400"
                : "hover:text-blue-600 dark:hover:text-blue-400"
            }`}
            onClick={() => setActiveTab(setting.name)}
          >
            {setting.name}
          </button>
        ))}
      </div>
      <div className="p-4">
        {settings.map(
          (setting) =>
            activeTab === setting.name && (
              <div key={setting.name} className="text-gray-700 dark:text-gray-300">
                {setting.action}
              </div>
            )
        )}
      </div>
    </div>
  );
}

function StoryComponent() {
  const settingsData = [
    { name: "Profile", action: "Edit your profile information here." },
    { name: "Security", action: "Update your password and security settings." },
    { name: "Notifications", action: "Manage your notification preferences." },
  ];

  return (
    <div className="max-w-md mx-auto">
      <MainComponent settings={settingsData} />
    </div>
  );
});
}