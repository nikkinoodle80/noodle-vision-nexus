"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({
  devices = [],
  onSearch = () => {},
  onDevicePlace = () => {},
  onDeviceRemove = () => {},
  onDeviceSelect = () => {},
  onDeviceAdjust = () => {},
  onSnapToSurface = () => {},
  placedDevices = [],
  selectedDeviceId = null,
  categories = ["Routers", "Switches", "Access Points", "Modems", "Adapters"],
  isLoading = false
}) {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const [arViewerKey, setArViewerKey] = useState(Date.now());
  const [showDeviceList, setShowDeviceList] = useState(true);
  
  const deviceListRef = useRef(null);
  
  const handleSearch = (e) => {
    const term = e.target.value;
    setSearchTerm(term);
    onSearch(term);
  };
  
  const handleDeviceDragStart = (e, device) => {
    e.dataTransfer.setData("device", JSON.stringify(device));
    e.dataTransfer.effectAllowed = "copy";
  };
  
  const handleDrop = (e) => {
    e.preventDefault();
    const deviceData = JSON.parse(e.dataTransfer.getData("device"));
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    
    onDevicePlace({
      ...deviceData,
      position: { x, y, z: -1 },
      rotation: { x: 0, y: 0, z: 0 }, 
      scale: 1.0
    });
  };
  
  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "copy";
  };
  
  const handleDeviceSelect = (deviceId) => {
    onDeviceSelect(deviceId);
  };
  
  const handleDeviceRemove = (deviceId) => {
    onDeviceRemove(deviceId);
    if (selectedDeviceId === deviceId) {
      onDeviceSelect(null);
    }
  };
  
  const handlePositionChange = (deviceId, axis, value) => {
    const device = placedDevices.find(d => d.id === deviceId);
    if (device) {
      const newPosition = { ...device.position, [axis]: value };
      onDeviceAdjust(deviceId, { position: newPosition });
    }
  };
  
  const handleRotationChange = (deviceId, axis, value) => {
    const device = placedDevices.find(d => d.id === deviceId);
    if (device) {
      const newRotation = { ...device.rotation, [axis]: value };
      onDeviceAdjust(deviceId, { rotation: newRotation });
    }
  };
  
  const handleScaleChange = (deviceId, value) => {
    onDeviceAdjust(deviceId, { scale: value });
  };
  
  const handleSnapToSurface = (deviceId) => {
    onSnapToSurface(deviceId);
  };
  
  const filteredDevices = devices.filter(device => {
    const matchesSearch = device.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          device.model.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === "All" || device.category === activeCategory;
    return matchesSearch && matchesCategory;
  });
  
  const getDeviceConnections = () => {
    if (!selectedDeviceId || placedDevices.length < 2) return [];
    
    const selectedDevice = placedDevices.find(d => d.id === selectedDeviceId);
    if (!selectedDevice) return [];
    
    return placedDevices
      .filter(d => d.id !== selectedDeviceId)
      .map(device => {
        const startX = selectedDevice.position.x * 100 + 100;
        const startY = selectedDevice.position.y * 100 + 100;
        const endX = device.position.x * 100 + 100;
        const endY = device.position.y * 100 + 100;
        
        const dx = endX - startX;
        const dy = endY - startY;
        const angle = Math.atan2(dy, dx) * (180 / Math.PI);
        
        const compatible = selectedDevice.ports?.some(port => 
          device.ports?.some(otherPort => port.type === otherPort.type)
        ) || false;
        
        return {
          startX,
          startY,
          angle,
          compatible 
        };
      });
  };

  const selectedDevice = placedDevices.find(d => d.id === selectedDeviceId);

  return (
    <div className="flex flex-col h-screen bg-gray-100 dark:bg-gray-900">
      <div className="flex items-center justify-between p-4 bg-white dark:bg-gray-800 shadow">
        <h1 className="text-xl font-bold text-gray-800 dark:text-white">AR Device Placement</h1>
        <div className="relative">
          <input
            type="text"
            placeholder="Search devices..."
            className="pl-10 pr-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 text-gray-800 dark:text-white"
            value={searchTerm}
            onChange={handleSearch}
          />
          <i className="fas fa-search absolute left-3 top-3 text-gray-400"></i>
        </div>
        <button 
          className="p-2 rounded-md bg-blue-500 text-white"
          onClick={() => setShowDeviceList(!showDeviceList)}
        >
          <i className={`fas ${showDeviceList ? 'fa-chevron-left' : 'fa-chevron-right'}`}></i>
        </button>
      </div>
      
      <div className="flex flex-1 overflow-hidden">
        {showDeviceList && (
          <div className="w-80 bg-white dark:bg-gray-800 shadow-md flex flex-col">
            <div className="p-3 border-b border-gray-200 dark:border-gray-700">
              <div className="flex overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-gray-300 dark:scrollbar-thumb-gray-600">
                <button
                  className={`px-3 py-1 mr-2 rounded-full text-sm whitespace-nowrap ${
                    activeCategory === "All" 
                      ? "bg-blue-500 text-white" 
                      : "bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300"
                  }`}
                  onClick={() => setActiveCategory("All")}
                >
                  All
                </button>
                {categories.map(category => (
                  <button
                    key={category}
                    className={`px-3 py-1 mr-2 rounded-full text-sm whitespace-nowrap ${
                      activeCategory === category 
                        ? "bg-blue-500 text-white" 
                        : "bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300"
                    }`}
                    onClick={() => setActiveCategory(category)}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
            
            <div 
              ref={deviceListRef}
              className="flex-1 overflow-y-auto p-3 space-y-3 scrollbar-thin scrollbar-thumb-gray-300 dark:scrollbar-thumb-gray-600"
            >
              {isLoading ? (
                <div className="flex justify-center items-center h-full">
                  <div className="w-10 h-10 border-4 border-t-blue-500 border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin"></div>
                </div>
              ) : filteredDevices.length === 0 ? (
                <div className="text-center py-10 text-gray-500 dark:text-gray-400">
                  <i className="fas fa-search text-4xl mb-3"></i>
                  <p>No devices found</p>
                </div>
              ) : (
                filteredDevices.map(device => (
                  <div
                    key={device.id}
                    className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3 shadow-sm cursor-move"
                    draggable
                    onDragStart={(e) => handleDeviceDragStart(e, device)}
                  >
                    <div className="flex items-center">
                      <div className="w-16 h-16 bg-gray-200 dark:bg-gray-600 rounded-md overflow-hidden flex-shrink-0">
                        <img 
                          src={device.imageUrl || "/images/device-placeholder.png"} 
                          alt={device.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="ml-3 flex-1">
                        <h3 className="font-medium text-gray-800 dark:text-white">{device.name}</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{device.model}</p>
                        <div className="flex items-center mt-1">
                          <span className="text-xs bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-0.5 rounded">
                            {device.category}
                          </span>
                          <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">
                            {device.ports?.length || 0} ports
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
        
        <div 
          className="flex-1 relative"
          onDrop={handleDrop}
          onDragOver={handleDragOver}
        >
          <ArViewer
            key={arViewerKey}
            modelUrl="/models/default-device.glb"
            arEnabled={true}
            connections={getDeviceConnections()}
            onPermissionDenied={() => console.error("Camera permission denied")}
            onARError={(error) => console.error("AR error:", error)}
            onModelLoad={() => console.log("Model loaded")}
          />
          
          <div className="absolute top-4 right-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-3 max-w-xs">
            <h3 className="font-medium text-gray-800 dark:text-white mb-2">Placed Devices ({placedDevices.length})</h3>
            {placedDevices.length === 0 ? (
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Drag and drop devices from the list to place them in AR space
              </p>
            ) : (
              <div className="max-h-40 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 dark:scrollbar-thumb-gray-600">
                {placedDevices.map(device => (
                  <div 
                    key={device.id}
                    className={`flex items-center justify-between p-2 mb-1 rounded ${
                      selectedDeviceId === device.id 
                        ? "bg-blue-100 dark:bg-blue-900" 
                        : "bg-gray-50 dark:bg-gray-700"
                    }`}
                  >
                    <div 
                      className="flex items-center cursor-pointer flex-1"
                      onClick={() => handleDeviceSelect(device.id)}
                    >
                      <div className="w-8 h-8 bg-gray-200 dark:bg-gray-600 rounded overflow-hidden">
                        <img 
                          src={device.imageUrl || "/images/device-placeholder.png"} 
                          alt={device.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <span className="ml-2 text-sm text-gray-800 dark:text-white truncate">
                        {device.name}
                      </span>
                    </div>
                    <button 
                      className="ml-2 text-red-500 hover:text-red-700"
                      onClick={() => handleDeviceRemove(device.id)}
                    >
                      <i className="fas fa-trash-alt"></i>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {selectedDevice && (
            <div className="absolute bottom-4 left-4 right-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-medium text-gray-800 dark:text-white">{selectedDevice.name}</h3>
                <button 
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                  onClick={() => onDeviceSelect(null)}
                >
                  <i className="fas fa-times"></i>
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Position</h4>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <span className="w-6 text-center text-gray-500 dark:text-gray-400">X</span>
                      <input 
                        type="range" 
                        min="-2" 
                        max="2" 
                        step="0.1" 
                        value={selectedDevice.position.x}
                        onChange={(e) => handlePositionChange(selectedDevice.id, 'x', parseFloat(e.target.value))}
                        className="flex-1 mx-2"
                      />
                      <span className="w-10 text-xs text-gray-500 dark:text-gray-400">
                        {selectedDevice.position.x.toFixed(1)}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <span className="w-6 text-center text-gray-500 dark:text-gray-400">Y</span>
                      <input 
                        type="range" 
                        min="-2" 
                        max="2" 
                        step="0.1" 
                        value={selectedDevice.position.y}
                        onChange={(e) => handlePositionChange(selectedDevice.id, 'y', parseFloat(e.target.value))}
                        className="flex-1 mx-2"
                      />
                      <span className="w-10 text-xs text-gray-500 dark:text-gray-400">
                        {selectedDevice.position.y.toFixed(1)}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <span className="w-6 text-center text-gray-500 dark:text-gray-400">Z</span>
                      <input 
                        type="range" 
                        min="-3" 
                        max="0" 
                        step="0.1" 
                        value={selectedDevice.position.z}
                        onChange={(e) => handlePositionChange(selectedDevice.id, 'z', parseFloat(e.target.value))}
                        className="flex-1 mx-2"
                      />
                      <span className="w-10 text-xs text-gray-500 dark:text-gray-400">
                        {selectedDevice.position.z.toFixed(1)}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Rotation</h4>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <span className="w-6 text-center text-gray-500 dark:text-gray-400">X</span>
                      <input 
                        type="range" 
                        min="0" 
                        max="360" 
                        step="15" 
                        value={selectedDevice.rotation.x}
                        onChange={(e) => handleRotationChange(selectedDevice.id, 'x', parseInt(e.target.value))}
                        className="flex-1 mx-2"
                      />
                      <span className="w-10 text-xs text-gray-500 dark:text-gray-400">
                        {selectedDevice.rotation.x}°
                      </span>
                    </div>
                    <div className="flex items-center">
                      <span className="w-6 text-center text-gray-500 dark:text-gray-400">Y</span>
                      <input 
                        type="range" 
                        min="0" 
                        max="360" 
                        step="15" 
                        value={selectedDevice.rotation.y}
                        onChange={(e) => handleRotationChange(selectedDevice.id, 'y', parseInt(e.target.value))}
                        className="flex-1 mx-2"
                      />
                      <span className="w-10 text-xs text-gray-500 dark:text-gray-400">
                        {selectedDevice.rotation.y}°
                      </span>
                    </div>
                    <div className="flex items-center">
                      <span className="w-6 text-center text-gray-500 dark:text-gray-400">Z</span>
                      <input 
                        type="range" 
                        min="0" 
                        max="360" 
                        step="15" 
                        value={selectedDevice.rotation.z}
                        onChange={(e) => handleRotationChange(selectedDevice.id, 'z', parseInt(e.target.value))}
                        className="flex-1 mx-2"
                      />
                      <span className="w-10 text-xs text-gray-500 dark:text-gray-400">
                        {selectedDevice.rotation.z}°
                      </span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Scale & Actions</h4>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <span className="w-6 text-center text-gray-500 dark:text-gray-400">
                        <i className="fas fa-expand-alt"></i>
                      </span>
                      <input 
                        type="range" 
                        min="0.5" 
                        max="2" 
                        step="0.1" 
                        value={selectedDevice.scale}
                        onChange={(e) => handleScaleChange(selectedDevice.id, parseFloat(e.target.value))}
                        className="flex-1 mx-2"
                      />
                      <span className="w-10 text-xs text-gray-500 dark:text-gray-400">
                        {selectedDevice.scale.toFixed(1)}x
                      </span>
                    </div>
                    <button
                      className="w-full mt-2 px-3 py-1.5 bg-blue-500 text-white rounded-md text-sm flex items-center justify-center"
                      onClick={() => handleSnapToSurface(selectedDevice.id)}
                    >
                      <i className="fas fa-magnet mr-2"></i>
                      Snap to Surface
                    </button>
                  </div>
                </div>
              </div>
              
              {selectedDevice.ports && selectedDevice.ports.length > 0 && (
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Ports</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                    {selectedDevice.ports.map((port, index) => (
                      <div 
                        key={index}
                        className="bg-gray-50 dark:bg-gray-700 p-2 rounded text-xs"
                      >
                        <div className="flex items-center">
                          <div className={`w-3 h-3 rounded-full mr-2 ${
                            port.status === 'active' ? 'bg-green-500' : 
                            port.status === 'inactive' ? 'bg-gray-400' : 'bg-red-500'
                          }`}></div>
                          <span className="font-medium text-gray-800 dark:text-white">{port.name}</span>
                        </div>
                        <div className="mt-1 text-gray-500 dark:text-gray-400">
                          {port.type} - {port.speed || 'N/A'}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StoryComponent() {
  const [devices, setDevices] = useState([
    {
      id: "1",
      name: "Cisco Router",
      model: "ISR 4331", 
      category: "Routers",
      imageUrl: "/images/router.jpg",
      ports: [
        { name: "GE 0/0", type: "Ethernet", speed: "1 Gbps", status: "active" },
        { name: "GE 0/1", type: "Ethernet", speed: "1 Gbps", status: "inactive" },
        { name: "Console", type: "Serial", speed: "115200", status: "inactive" },
        { name: "AUX", type: "Serial", speed: "9600", status: "inactive" }
      ]
    },
    {
      id: "2", 
      name: "Cisco Switch",
      model: "Catalyst 9300",
      category: "Switches", 
      imageUrl: "/images/switch.jpg",
      ports: [
        { name: "GE 1/0/1", type: "Ethernet", speed: "1 Gbps", status: "active" },
        { name: "GE 1/0/2", type: "Ethernet", speed: "1 Gbps", status: "active" },
        { name: "GE 1/0/3", type: "Ethernet", speed: "1 Gbps", status: "inactive" },
        { name: "GE 1/0/4", type: "Ethernet", speed: "1 Gbps", status: "inactive" }
      ]
    },
    {
      id: "3",
      name: "Cisco Access Point",
      model: "Aironet 3800",
      category: "Access Points",
      imageUrl: "/images/ap.jpg", 
      ports: [
        { name: "GE 0", type: "Ethernet", speed: "1 Gbps", status: "active" },
        { name: "Console", type: "Serial", speed: "9600", status: "inactive" }
      ]
    },
    {
      id: "4",
      name: "Cable Modem",
      model: "DOCSIS 3.1",
      category: "Modems",
      imageUrl: "/images/modem.jpg",
      ports: [
        { name: "WAN", type: "Coaxial", speed: "10 Gbps", status: "active" },
        { name: "LAN 1", type: "Ethernet", speed: "1 Gbps", status: "active" },
        { name: "LAN 2", type: "Ethernet", speed: "1 Gbps", status: "inactive" }
      ]
    },
    {
      id: "5",
      name: "Fiber Converter",
      model: "SFP+ to RJ45",
      category: "Adapters",
      imageUrl: "/images/converter.jpg",
      ports: [
        { name: "SFP+", type: "Fiber", speed: "10 Gbps", status: "active" },
        { name: "RJ45", type: "Ethernet", speed: "10 Gbps", status: "active" }
      ]
    },
    {
      id: "6",
      name: "Wireless Router",
      model: "AX6000",
      category: "Routers",
      imageUrl: "/images/wireless-router.jpg",
      ports: [
        { name: "WAN", type: "Ethernet", speed: "1 Gbps", status: "active" },
        { name: "LAN 1", type: "Ethernet", speed: "1 Gbps", status: "active" },
        { name: "LAN 2", type: "Ethernet", speed: "1 Gbps", status: "inactive" },
        { name: "LAN 3", type: "Ethernet", speed: "1 Gbps", status: "inactive" },
        { name: "LAN 4", type: "Ethernet", speed: "1 Gbps", status: "inactive" }
      ]
    }
  ]);
  
  const [placedDevices, setPlacedDevices] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  
  const handleSearch = (term) => {
    setSearchTerm(term);
  };
  
  const handleDevicePlace = (device) => {
    setPlacedDevices(prev => [...prev, device]);
    setSelectedDeviceId(device.id);
  };
  
  const handleDeviceRemove = (deviceId) => {
    setPlacedDevices(prev => prev.filter(d => d.id !== deviceId));
    if (selectedDeviceId === deviceId) {
      setSelectedDeviceId(null);
    }
  };
  
  const handleDeviceSelect = (deviceId) => {
    setSelectedDeviceId(deviceId);
  };
  
  const handleDeviceAdjust = (deviceId, changes) => {
    setPlacedDevices(prev => 
      prev.map(device => 
        device.id === deviceId 
          ? { ...device, ...changes } 
          : device
      )
    );
  };
  
  const handleSnapToSurface = (deviceId) => {
    setPlacedDevices(prev => 
      prev.map(device => 
        device.id === deviceId 
          ? { 
              ...device, 
              position: { ...device.position, y: -0.5 },
              rotation: { ...device.rotation, x: 0 }
            }
          : device
      )
    );
  };
  
  return (
    <div className="h-screen bg-gray-100 dark:bg-gray-900">
      <h1 className="text-2xl font-bold p-4 text-gray-800 dark:text-white">Device AR Placement Component</h1>
      
      <div className="p-4">
        <h2 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">Default State</h2>
        <div className="border border-gray-300 dark:border-gray-700 rounded-lg h-[600px] overflow-hidden">
          <MainComponent 
            devices={devices}
            onSearch={handleSearch}
            onDevicePlace={handleDevicePlace}
            onDeviceRemove={handleDeviceRemove}
            onDeviceSelect={handleDeviceSelect}
            onDeviceAdjust={handleDeviceAdjust}
            onSnapToSurface={handleSnapToSurface}
            placedDevices={placedDevices}
            selectedDeviceId={selectedDeviceId}
          />
        </div>
      </div>
      
      <div className="p-4">
        <h2 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">Loading State</h2>
        <div className="border border-gray-300 dark:border-gray-700 rounded-lg h-[600px] overflow-hidden">
          <MainComponent 
            devices={[]}
            isLoading={true}
            placedDevices={[]}
          />
        </div>
      </div>
      
      <div className="p-4">
        <h2 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">With Placed Devices</h2>
        <div className="border border-gray-300 dark:border-gray-700 rounded-lg h-[600px] overflow-hidden">
          <MainComponent 
            devices={devices}
            placedDevices={[
              {
                id: "1",
                name: "Cisco Router",
                model: "ISR 4331",
                category: "Routers",
                imageUrl: "/images/router.jpg",
                position: { x: -0.5, y: 0, z: -1 },
                rotation: { x: 0, y: 45, z: 0 },
                scale: 1.0,
                ports: [
                  { name: "GE 0/0", type: "Ethernet", speed: "1 Gbps", status: "active" },
                  { name: "GE 0/1", type: "Ethernet", speed: "1 Gbps", status: "inactive" },
                  { name: "Console", type: "Serial", speed: "115200", status: "inactive" },
                  { name: "AUX", type: "Serial", speed: "9600", status: "inactive" }
                ]
              },
              {
                id: "2",
                name: "Cisco Switch", 
                model: "Catalyst 9300",
                category: "Switches",
                imageUrl: "/images/switch.jpg",
                position: { x: 0.5, y: 0, z: -1 },
                rotation: { x: 0, y: -45, z: 0 },
                scale: 1.0,
                ports: [
                  { name: "GE 1/0/1", type: "Ethernet", speed: "1 Gbps", status: "active" },
                  { name: "GE 1/0/2", type: "Ethernet", speed: "1 Gbps", status: "active" },
                  { name: "GE 1/0/3", type: "Ethernet", speed: "1 Gbps", status: "inactive" },
                  { name: "GE 1/0/4", type: "Ethernet", speed: "1 Gbps", status: "inactive" }
                ]
              }
            ]}
            selectedDeviceId="1"
          />
        </div>
      </div>
    </div>
  );
});
}