"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ 
  onSearch, 
  placeholder, 
  categories = ["devices", "cables", "adapters"],
  connectionTypes = ["HDMI", "USB-C", "USB-A", "DisplayPort", "VGA", "Ethernet", "Thunderbolt", "Lightning", "Audio"],
  categoryTabs = ["All", "Home Theater", "Networking", "Automotive", "Security"],
  suggestedTerms = [],
  popularSearches = []
}) {
  const [query, setQuery] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedCategories, setSelectedCategories] = useState(categories);
  const [selectedConnectionTypes, setSelectedConnectionTypes] = useState([]);
  const [activeTab, setActiveTab] = useState("All");
  const [recentSearches, setRecentSearches] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('recentSearches');
      return saved ? JSON.parse(saved) : [];
    }
    return [];
  });
  const [filteredSuggestions, setFilteredSuggestions] = useState([]);
  const searchInputRef = React.useRef(null);
  const suggestionsRef = React.useRef(null);

  React.useEffect(() => {
    const handleClickOutside = (event) => {
      if (suggestionsRef.current && !suggestionsRef.current.contains(event.target) &&
          searchInputRef.current && !searchInputRef.current.contains(event.target)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  React.useEffect(() => {
    if (query.trim() === '') {
      setFilteredSuggestions([]);
      return;
    }

    const filtered = suggestedTerms.filter(term => 
      term.toLowerCase().includes(query.toLowerCase())
    );
    setFilteredSuggestions(filtered);
  }, [query, suggestedTerms]);

  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('recentSearches', JSON.stringify(recentSearches));
    }
  }, [recentSearches]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (query.trim()) {
      if (!recentSearches.includes(query)) {
        const updatedSearches = [query, ...recentSearches.slice(0, 4)];
        setRecentSearches(updatedSearches);
      }
      
      onSearch({
        query,
        categories: selectedCategories,
        connectionTypes: selectedConnectionTypes,
        categoryTab: activeTab
      });
      
      setShowSuggestions(false);
    }
  };

  const handleCategoryChange = (category) => {
    setSelectedCategories(prev => 
      prev.includes(category) 
        ? prev.filter(c => c !== category) 
        : [...prev, category]
    );
  };

  const handleConnectionTypeChange = (type) => {
    setSelectedConnectionTypes(prev => 
      prev.includes(type) 
        ? prev.filter(t => t !== type) 
        : [...prev, type]
    );
  };

  const handleSuggestionClick = (suggestion) => {
    setQuery(suggestion);
    setShowSuggestions(false);
    
    if (!recentSearches.includes(suggestion)) {
      const updatedSearches = [suggestion, ...recentSearches.slice(0, 4)];
      setRecentSearches(updatedSearches);
    }
    
    onSearch({
      query: suggestion,
      categories: selectedCategories,
      connectionTypes: selectedConnectionTypes,
      categoryTab: activeTab
    });
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  const handleClearRecentSearches = () => {
    setRecentSearches([]);
  };

  return (
    <div className="w-full">
      <div className="mb-4 border-b border-gray-200 dark:border-gray-700">
        <ul className="flex flex-wrap -mb-px text-sm font-medium text-center">
          {categoryTabs.map(tab => (
            <li key={tab} className="mr-2">
              <button
                onClick={() => handleTabChange(tab)}
                className={`inline-block p-4 border-b-2 rounded-t-lg ${
                  activeTab === tab
                    ? 'text-blue-600 border-blue-600 dark:text-blue-500 dark:border-blue-500'
                    : 'border-transparent hover:text-gray-600 hover:border-gray-300 dark:hover:text-gray-300'
                }`}
              >
                {tab}
              </button>
            </li>
          ))}
        </ul>
      </div>

      <form onSubmit={handleSubmit} className="w-full">
        <div className="relative">
          <input
            ref={searchInputRef}
            type="text"
            className="w-full px-4 py-2 pl-10 pr-12 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder={placeholder || "Search for devices, adapters, cables..."}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setShowSuggestions(true)}
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
            </svg>
          </div>
          <button
            type="submit"
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
          >
            Search
          </button>
        </div>

        {showSuggestions && (
          <div 
            ref={suggestionsRef}
            className="absolute z-10 mt-1 w-full bg-white dark:bg-gray-800 shadow-lg rounded-lg border border-gray-200 dark:border-gray-700 max-h-96 overflow-y-auto"
          >
            <div className="p-3 border-b border-gray-200 dark:border-gray-700">
              <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2">CATEGORIES</p>
              <div className="flex flex-wrap gap-2">
                {categories.map(category => (
                  <button
                    key={category}
                    type="button"
                    onClick={() => handleCategoryChange(category)}
                    className={`px-3 py-1 text-xs rounded-full ${
                      selectedCategories.includes(category)
                        ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300'
                        : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                    }`}
                  >
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-3 border-b border-gray-200 dark:border-gray-700">
              <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2">CONNECTION TYPES</p>
              <div className="flex flex-wrap gap-2">
                {connectionTypes.map(type => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => handleConnectionTypeChange(type)}
                    className={`px-3 py-1 text-xs rounded-full ${
                      selectedConnectionTypes.includes(type)
                        ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
                        : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            {filteredSuggestions.length > 0 && (
              <div className="p-3 border-b border-gray-200 dark:border-gray-700">
                <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2">SUGGESTIONS</p>
                <ul>
                  {filteredSuggestions.map((suggestion, index) => (
                    <li key={index}>
                      <button
                        type="button"
                        onClick={() => handleSuggestionClick(suggestion)}
                        className="w-full text-left px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
                      >
                        <div className="flex items-center">
                          <svg className="h-4 w-4 text-gray-400 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                          </svg>
                          {suggestion}
                        </div>
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {recentSearches.length > 0 && (
              <div className="p-3 border-b border-gray-200 dark:border-gray-700">
                <div className="flex justify-between items-center mb-2">
                  <p className="text-xs font-semibold text-gray-500 dark:text-gray-400">RECENT SEARCHES</p>
                  <button 
                    type="button" 
                    onClick={handleClearRecentSearches}
                    className="text-xs text-red-500 hover:text-red-700 dark:hover:text-red-400"
                  >
                    Clear
                  </button>
                </div>
                <ul>
                  {recentSearches.map((search, index) => (
                    <li key={index}>
                      <button
                        type="button"
                        onClick={() => handleSuggestionClick(search)}
                        className="w-full text-left px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
                      >
                        <div className="flex items-center">
                          <svg className="h-4 w-4 text-gray-400 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                          </svg>
                          {search}
                        </div>
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {popularSearches.length > 0 && (
              <div className="p-3">
                <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2">POPULAR SEARCHES</p>
                <div className="flex flex-wrap gap-2">
                  {popularSearches.map((search, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => handleSuggestionClick(search)}
                      className="px-3 py-1 text-xs bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600"
                    >
                      {search}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </form>
    </div>
  );
}

function StoryComponent() {
  const [searchResults, setSearchResults] = React.useState(null);
  const [searchParams, setSearchParams] = React.useState(null);
  
  const handleSearch = (params) => {
    setSearchParams(params);
    setSearchResults(`Search results for: ${params.query}`);
  };
  
  const suggestedTerms = [
    "HDMI cable 4K",
    "USB-C to DisplayPort",
    "Ethernet switch",
    "Wireless HDMI transmitter",
    "Thunderbolt dock",
    "VGA to HDMI adapter",
    "Car audio interface",
    "Security camera cables",
    "Network patch panel"
  ];
  
  const popularSearches = [
    "USB-C hub",
    "HDMI 2.1",
    "Ethernet Cat 6",
    "Wireless display",
    "Audio interface",
    "KVM switch",
    "Security camera system"
  ];
  
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      <div className="space-y-4">
        <h2 className="text-xl font-bold">Enhanced Search Bar</h2>
        <MainComponent 
          onSearch={handleSearch}
          suggestedTerms={suggestedTerms}
          popularSearches={popularSearches}
        />
        {searchParams && (
          <div className="mt-4 p-4 bg-gray-100 dark:bg-gray-800 rounded">
            <h3 className="font-medium mb-2">Search Parameters:</h3>
            <pre className="text-sm overflow-x-auto">
              {JSON.stringify(searchParams, null, 2)}
            </pre>
          </div>
        )}
        {searchResults && (
          <div className="mt-4 p-4 bg-gray-100 dark:bg-gray-800 rounded">
            <h3 className="font-medium mb-2">Results:</h3>
            {searchResults}
          </div>
        )}
      </div>
      
      <div className="space-y-4">
        <h2 className="text-xl font-bold">Search Bar with Custom Categories</h2>
        <MainComponent 
          onSearch={handleSearch} 
          placeholder="Search for audio equipment..."
          categories={["speakers", "amplifiers", "headphones", "microphones"]}
          connectionTypes={["XLR", "TRS", "RCA", "Optical", "Bluetooth"]}
          categoryTabs={["All", "Studio", "Home Audio", "Live Sound", "DJ"]}
          suggestedTerms={[
            "Studio monitors",
            "XLR microphone",
            "Bluetooth headphones",
            "Phono preamp",
            "Digital mixer"
          ]}
          popularSearches={[
            "Condenser mic",
            "Wireless headphones",
            "Turntable setup",
            "Powered speakers"
          ]}
        />
      </div>
      
      <div className="space-y-4">
        <h2 className="text-xl font-bold">Minimal Search Bar</h2>
        <MainComponent 
          onSearch={handleSearch} 
          placeholder="Quick search..."
          categories={["all"]}
          connectionTypes={[]}
          categoryTabs={["All"]}
        />
      </div>
    </div>
  );
});
}