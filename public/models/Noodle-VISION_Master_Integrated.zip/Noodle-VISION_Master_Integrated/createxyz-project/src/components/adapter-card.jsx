"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ adapter, onSelect, isSelected }) {
  return (
    <div 
      className={`border rounded-lg p-4 cursor-pointer transition-all ${
        isSelected ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'border-gray-200 dark:border-gray-700'
      }`}
      onClick={() => onSelect(adapter)}
    >
      <div className="flex items-center mb-2">
        {adapter.image_url ? (
          <img 
            src={adapter.image_url} 
            alt={adapter.name} 
            className="w-16 h-16 object-contain mr-3"
          />
        ) : (
          <div className="w-16 h-16 bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center mr-3">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </div>
        )}
        <div>
          <h3 className="font-medium text-gray-900 dark:text-white">{adapter.name}</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">{adapter.input_type} → {adapter.output_type}</p>
        </div>
      </div>
      
      {adapter.description && (
        <p className="text-sm text-gray-600 dark:text-gray-300">{adapter.description}</p>
      )}
    </div>
  );
}

function StoryComponent() {
  const [selectedAdapter, setSelectedAdapter] = React.useState(null);
  
  const sampleAdapters = [
    {
      id: 1,
      name: "USB-C to HDMI",
      input_type: "USB-C",
      output_type: "HDMI",
      description: "Connect your USB-C device to an HDMI display"
    },
    {
      id: 2,
      name: "DisplayPort to DVI",
      input_type: "DisplayPort",
      output_type: "DVI",
      description: "Convert DisplayPort signal to DVI for older monitors",
      image_url: "/images/dp-to-dvi.jpg"
    },
    {
      id: 3,
      name: "Lightning to 3.5mm",
      input_type: "Lightning",
      output_type: "3.5mm Audio",
      description: "Connect headphones to your iPhone"
    }
  ];
  
  const handleSelect = (adapter) => {
    setSelectedAdapter(adapter.id === selectedAdapter?.id ? null : adapter);
  };
  
  return (
    <div className="p-4 space-y-4">
      <h2 className="text-xl font-bold mb-4">Adapter Card Examples</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sampleAdapters.map(adapter => (
          <MainComponent 
            key={adapter.id}
            adapter={adapter}
            onSelect={handleSelect}
            isSelected={selectedAdapter?.id === adapter.id}
          />
        ))}
      </div>
    </div>
  );
});
}