"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ 
  modelUrl = "/models/default-device.glb", 
  isLoading = false, 
  arEnabled = true,
  connections = [],
  onPermissionDenied = () => {},
  onARError = () => {},
  onModelLoad = () => {},
  initialScale = 1.0,
  initialRotation = { x: 0, y: 0, z: 0 },
  initialPosition = { x: 0, y: 0, z: -1 }
}) {
  const [cameraPermission, setCameraPermission] = useState(null);
  const [arSupported, setARSupported] = useState(null);
  const [viewMode, setViewMode] = useState(arEnabled ? 'ar' : '3d');
  const [modelLoaded, setModelLoaded] = useState(false);
  const [scale, setScale] = useState(initialScale);
  const [rotation, setRotation] = useState(initialRotation);
  const [position, setPosition] = useState(initialPosition);
  const [error, setError] = useState(null);
  
  const sceneRef = useRef(null);
  const cameraRef = useRef(null);
  const modelRef = useRef(null);
  
  useEffect(() => {
    const checkARSupport = async () => {
      try {
        const isARSupported = 
          'xr' in navigator && 
          await navigator.xr?.isSessionSupported('immersive-ar');
        
        setARSupported(isARSupported);
        
        if (!isARSupported && viewMode === 'ar') {
          setViewMode('3d');
          onARError('AR not supported on this device. Falling back to 3D view.');
        }
      } catch (err) {
        console.error('Error checking AR support:', err);
        setARSupported(false);
        setViewMode('3d');
        onARError('Error initializing AR. Falling back to 3D view.');
      }
    };
    
    checkARSupport();
  }, [onARError, viewMode]);
  
  useEffect(() => {
    const requestCameraPermission = async () => {
      if (viewMode !== 'ar') return;
      
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        setCameraPermission('granted');
        
        return () => {
          stream.getTracks().forEach(track => track.stop());
        };
      } catch (err) {
        console.error('Camera permission denied:', err);
        setCameraPermission('denied');
        setViewMode('3d');
        onPermissionDenied('Camera permission denied. Falling back to 3D view.');
      }
    };
    
    requestCameraPermission();
  }, [viewMode, onPermissionDenied]);
  
  useEffect(() => {
    if (!sceneRef.current) return;
    
    const initScene = () => {
      try {
        setModelLoaded(false);
        
        const timer = setTimeout(() => {
          setModelLoaded(true);
          onModelLoad();
        }, 2000);
        
        return () => clearTimeout(timer);
      } catch (err) {
        console.error('Error initializing 3D scene:', err);
        setError('Failed to initialize 3D scene');
      }
    };
    
    initScene();
  }, [modelUrl, onModelLoad]);
  
  const handleScaleChange = (newScale) => {
    setScale(newScale);
  };
  
  const handleRotationChange = (axis, value) => {
    setRotation(prev => ({
      ...prev,
      [axis]: value
    }));
  };
  
  const handlePositionChange = (axis, value) => {
    setPosition(prev => ({
      ...prev,
      [axis]: value
    }));
  };
  
  const toggleViewMode = () => {
    if (viewMode === '3d' && arSupported) {
      setViewMode('ar');
    } else {
      setViewMode('3d');
    }
  };
  
  const renderConnections = () => {
    return connections.map((connection, index) => (
      <div 
        key={index}
        className={`absolute h-1 bg-gradient-to-r ${
          connection.compatible 
            ? 'from-green-500 to-green-300' 
            : 'from-red-500 to-red-300'
        } rounded-full transform`}
        style={{
          width: '100px',
          left: `${connection.startX}px`,
          top: `${connection.startY}px`,
          transform: `rotate(${connection.angle}deg)`,
          transformOrigin: 'left center'
        }}
      />
    ));
  };
  
  return (
    <div className="relative w-full h-full min-h-[400px] bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
      <div 
        ref={sceneRef}
        className="absolute inset-0 bg-transparent"
        style={{ 
          backgroundImage: viewMode === 'ar' ? 'none' : 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)' 
        }}
      >
        {viewMode === 'ar' && cameraPermission === 'granted' && (
          <video 
            ref={cameraRef}
            className="absolute inset-0 w-full h-full object-cover"
            autoPlay 
            playsInline 
            muted
          />
        )}
        
        <div 
          ref={modelRef}
          className={`absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 
            ${modelLoaded ? 'opacity-100' : 'opacity-0'} transition-opacity duration-500`}
          style={{
            width: `${200 * scale}px`,
            height: `${200 * scale}px`,
            transform: `translate(-50%, -50%) 
                       translate3d(${position.x * 100}px, ${position.y * 100}px, ${position.z * 100}px) 
                       rotateX(${rotation.x}deg) rotateY(${rotation.y}deg) rotateZ(${rotation.z}deg)`
          }}
        >
          <div className="w-full h-full bg-blue-500 bg-opacity-50 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold">3D Model</span>
          </div>
        </div>
        
        {modelLoaded && renderConnections()}
      </div>
      
      {(isLoading || !modelLoaded) && (
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center z-10">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-t-blue-500 border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin mx-auto"></div>
            <p className="mt-4 text-white font-medium">Loading 3D Model...</p>
          </div>
        </div>
      )}
      
      {error && (
        <div className="absolute inset-0 bg-red-500 bg-opacity-20 flex items-center justify-center z-10">
          <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-lg max-w-xs">
            <p className="text-red-500 font-medium">{error}</p>
            <button 
              className="mt-2 px-4 py-2 bg-blue-500 text-white rounded-md w-full"
              onClick={() => setError(null)}
            >
              Dismiss
            </button>
          </div>
        </div>
      )}
      
      <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-2 z-20">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-2 flex items-center space-x-2">
          {arSupported && (
            <button 
              className={`p-2 rounded-md ${viewMode === 'ar' ? 'bg-blue-500 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
              onClick={toggleViewMode}
              title={viewMode === 'ar' ? 'Switch to 3D View' : 'Switch to AR View'}
            >
              <i className={`fas ${viewMode === 'ar' ? 'fa-cube' : 'fa-camera'} text-lg`}></i>
            </button>
          )}
          
          <button 
            className="p-2 bg-gray-200 dark:bg-gray-700 rounded-md text-gray-700 dark:text-gray-300"
            onClick={() => handleScaleChange(scale + 0.1)}
            title="Scale Up"
          >
            <i className="fas fa-search-plus text-lg"></i>
          </button>
          
          <button 
            className="p-2 bg-gray-200 dark:bg-gray-700 rounded-md text-gray-700 dark:text-gray-300"
            onClick={() => handleScaleChange(Math.max(0.1, scale - 0.1))}
            title="Scale Down"
          >
            <i className="fas fa-search-minus text-lg"></i>
          </button>
          
          <button 
            className="p-2 bg-gray-200 dark:bg-gray-700 rounded-md text-gray-700 dark:text-gray-300"
            onClick={() => handleRotationChange('y', rotation.y + 45)}
            title="Rotate"
          >
            <i className="fas fa-sync text-lg"></i>
          </button>
          
          <button 
            className="p-2 bg-gray-200 dark:bg-gray-700 rounded-md text-gray-700 dark:text-gray-300"
            onClick={() => {
              setScale(initialScale);
              setRotation(initialRotation);
              setPosition(initialPosition);
            }}
            title="Reset View"
          >
            <i className="fas fa-undo text-lg"></i>
          </button>
        </div>
      </div>
    </div>
  );
}

function StoryComponent() {
  const compatibleConnections = [
    { startX: 150, startY: 150, angle: 45, compatible: true },
    { startX: 200, startY: 200, angle: 135, compatible: true }
  ];
  
  const mixedConnections = [
    { startX: 150, startY: 150, angle: 45, compatible: true },
    { startX: 200, startY: 200, angle: 135, compatible: false }
  ];
  
  return (
    <div className="p-4 space-y-8">
      <h1 className="text-2xl font-bold mb-4">AR Viewer Component</h1>
      
      <div>
        <h2 className="text-xl font-semibold mb-2">Default State</h2>
        <div className="h-[400px] border border-gray-300 rounded-lg">
          <MainComponent />
        </div>
      </div>
      
      <div>
        <h2 className="text-xl font-semibold mb-2">Loading State</h2>
        <div className="h-[400px] border border-gray-300 rounded-lg">
          <MainComponent isLoading={true} />
        </div>
      </div>
      
      <div>
        <h2 className="text-xl font-semibold mb-2">3D View Mode (AR Disabled)</h2>
        <div className="h-[400px] border border-gray-300 rounded-lg">
          <MainComponent 
            arEnabled={false} 
            modelUrl="/models/router.glb"
            initialScale={1.2}
          />
        </div>
      </div>
      
      <div>
        <h2 className="text-xl font-semibold mb-2">With Compatible Connections</h2>
        <div className="h-[400px] border border-gray-300 rounded-lg">
          <MainComponent 
            arEnabled={false}
            connections={compatibleConnections}
            initialRotation={{ x: 0, y: 45, z: 0 }}
          />
        </div>
      </div>
      
      <div>
        <h2 className="text-xl font-semibold mb-2">With Mixed Connections</h2>
        <div className="h-[400px] border border-gray-300 rounded-lg">
          <MainComponent 
            arEnabled={false}
            connections={mixedConnections}
            initialPosition={{ x: 0.5, y: 0, z: -1 }}
          />
        </div>
      </div>
    </div>
  );
});
}