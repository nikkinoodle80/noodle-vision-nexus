"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ 
  activePage = "home", 
  isAuthenticated = false, 
  userName = "", 
  userEmail = "",
  onSignIn = () => {},
  onSignUp = () => {},
  onSignOut = () => {},
  isDarkMode = false
}) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [isConfigDropdownOpen, setIsConfigDropdownOpen] = useState(false);
  
  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const toggleProfileDropdown = () => {
    setIsProfileDropdownOpen(!isProfileDropdownOpen);
    setIsConfigDropdownOpen(false);
  };
  const toggleConfigDropdown = () => {
    setIsConfigDropdownOpen(!isConfigDropdownOpen);
    setIsProfileDropdownOpen(false);
  };
  
  const closeAllDropdowns = () => {
    setIsMenuOpen(false);
    setIsProfileDropdownOpen(false);
    setIsConfigDropdownOpen(false);
  };
  
  const navLinks = [
    { name: "Home", path: "/", id: "home" },
    { name: "AR Simulator", path: "/ar-simulator", id: "ar-simulator" },
    { name: "Device Library", path: "/device-library", id: "device-library" },
    { 
      name: "Configurations", 
      path: "#", 
      id: "configurations",
      isDropdown: true,
      dropdownItems: [
        { name: "My Configurations", path: "/configurations", id: "my-configurations" },
        { name: "Create New", path: "/configurations/new", id: "create-configuration" },
        { name: "Shared With Me", path: "/configurations/shared", id: "shared-configurations" }
      ]
    },
    { name: "Pricing", path: "/pricing", id: "pricing" }
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 ${isDarkMode ? 'bg-gray-900 text-white' : 'bg-white text-gray-800'} shadow-md`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo and primary navigation */}
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <a href="/" className="flex items-center" onClick={closeAllDropdowns}>
                <i className="fas fa-vr-cardboard text-blue-600 text-2xl mr-2"></i>
                <span className="font-bold text-xl">AR Hardware</span>
              </a>
            </div>
            
            {/* Desktop navigation links */}
            <div className="hidden md:ml-6 md:flex md:items-center md:space-x-4">
              {navLinks.map(link => 
                !link.isDropdown ? (
                  <a 
                    key={link.id}
                    href={link.path}
                    className={`px-3 py-2 rounded-md text-sm font-medium ${
                      activePage === link.id 
                        ? 'bg-blue-600 text-white' 
                        : `${isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'} hover:text-gray-900`
                    } transition duration-150 ease-in-out`}
                  >
                    {link.name}
                  </a>
                ) : (
                  <div key={link.id} className="relative">
                    <button
                      onClick={toggleConfigDropdown}
                      className={`px-3 py-2 rounded-md text-sm font-medium flex items-center ${
                        activePage.startsWith(link.id) 
                          ? 'bg-blue-600 text-white' 
                          : `${isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'} hover:text-gray-900`
                      } transition duration-150 ease-in-out`}
                    >
                      {link.name}
                      <i className={`fas fa-chevron-down ml-1 text-xs transition-transform duration-200 ${isConfigDropdownOpen ? 'transform rotate-180' : ''}`}></i>
                    </button>
                    
                    {isConfigDropdownOpen && (
                      <div className={`absolute left-0 mt-2 w-48 rounded-md shadow-lg ${isDarkMode ? 'bg-gray-800' : 'bg-white'} ring-1 ring-black ring-opacity-5 z-10`}>
                        <div className="py-1" role="menu" aria-orientation="vertical">
                          {link.dropdownItems.map(item => (
                            <a
                              key={item.id}
                              href={item.path}
                              className={`block px-4 py-2 text-sm ${
                                activePage === item.id
                                  ? 'bg-blue-100 text-blue-900 dark:bg-blue-900 dark:text-blue-100'
                                  : `${isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'}`
                              }`}
                              role="menuitem"
                              onClick={closeAllDropdowns}
                            >
                              {item.name}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )
              )}
            </div>
          </div>
          
          {/* User profile and authentication */}
          <div className="hidden md:flex md:items-center">
            {isAuthenticated ? (
              <div className="relative ml-3">
                <div>
                  <button
                    onClick={toggleProfileDropdown}
                    className={`flex items-center max-w-xs rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${isDarkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'} px-3 py-2`}
                    id="user-menu"
                    aria-expanded="false"
                    aria-haspopup="true"
                  >
                    <span className="sr-only">Open user menu</span>
                    <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center text-white">
                      {userName.charAt(0).toUpperCase()}
                    </div>
                    <span className="ml-2 font-medium">{userName}</span>
                    <i className={`fas fa-chevron-down ml-1 text-xs transition-transform duration-200 ${isProfileDropdownOpen ? 'transform rotate-180' : ''}`}></i>
                  </button>
                </div>
                
                {isProfileDropdownOpen && (
                  <div 
                    className={`origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg ${isDarkMode ? 'bg-gray-800' : 'bg-white'} ring-1 ring-black ring-opacity-5 z-10`}
                    role="menu"
                    aria-orientation="vertical"
                    aria-labelledby="user-menu"
                  >
                    <div className="py-1" role="none">
                      <div className={`px-4 py-2 text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'} border-b ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
                        {userEmail}
                      </div>
                      <a
                        href="/account"
                        className={`block px-4 py-2 text-sm ${isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'}`}
                        role="menuitem"
                        onClick={closeAllDropdowns}
                      >
                        Your Account
                      </a>
                      <a
                        href="/account/settings"
                        className={`block px-4 py-2 text-sm ${isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'}`}
                        role="menuitem"
                        onClick={closeAllDropdowns}
                      >
                        Settings
                      </a>
                      <button
                        className={`block w-full text-left px-4 py-2 text-sm ${isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'}`}
                        role="menuitem"
                        onClick={() => {
                          onSignOut();
                          closeAllDropdowns();
                        }}
                      >
                        Sign out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex space-x-2">
                <button
                  onClick={() => {
                    onSignIn();
                    closeAllDropdowns();
                  }}
                  className={`px-4 py-2 text-sm font-medium rounded-md ${isDarkMode ? 'bg-gray-800 text-white hover:bg-gray-700' : 'bg-gray-100 text-gray-800 hover:bg-gray-200'} transition duration-150 ease-in-out`}
                >
                  Sign in
                </button>
                <button
                  onClick={() => {
                    onSignUp();
                    closeAllDropdowns();
                  }}
                  className="px-4 py-2 text-sm font-medium rounded-md bg-blue-600 text-white hover:bg-blue-700 transition duration-150 ease-in-out"
                >
                  Sign up
                </button>
              </div>
            )}
          </div>
          
          {/* Mobile menu button */}
          <div className="flex items-center md:hidden">
            <button
              onClick={toggleMenu}
              className={`inline-flex items-center justify-center p-2 rounded-md ${isDarkMode ? 'text-gray-400 hover:text-white hover:bg-gray-700' : 'text-gray-500 hover:text-gray-900 hover:bg-gray-100'} focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500`}
              aria-expanded="false"
            >
              <span className="sr-only">Open main menu</span>
              {isMenuOpen ? (
                <i className="fas fa-times block h-6 w-6"></i>
              ) : (
                <i className="fas fa-bars block h-6 w-6"></i>
              )}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className={`md:hidden ${isDarkMode ? 'bg-gray-900' : 'bg-white'}`}>
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navLinks.map(link => 
              !link.isDropdown ? (
                <a
                  key={link.id}
                  href={link.path}
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    activePage === link.id 
                      ? 'bg-blue-600 text-white' 
                      : `${isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'} hover:text-gray-900`
                  }`}
                  onClick={closeAllDropdowns}
                >
                  {link.name}
                </a>
              ) : (
                <div key={link.id}>
                  <button
                    onClick={toggleConfigDropdown}
                    className={`w-full text-left px-3 py-2 rounded-md text-base font-medium flex items-center justify-between ${
                      activePage.startsWith(link.id) 
                        ? 'bg-blue-600 text-white' 
                        : `${isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'} hover:text-gray-900`
                    }`}
                  >
                    {link.name}
                    <i className={`fas fa-chevron-down text-xs transition-transform duration-200 ${isConfigDropdownOpen ? 'transform rotate-180' : ''}`}></i>
                  </button>
                  
                  {isConfigDropdownOpen && (
                    <div className={`pl-4 ${isDarkMode ? 'bg-gray-800' : 'bg-gray-50'}`}>
                      {link.dropdownItems.map(item => (
                        <a
                          key={item.id}
                          href={item.path}
                          className={`block px-3 py-2 rounded-md text-base font-medium ${
                            activePage === item.id
                              ? 'bg-blue-100 text-blue-900 dark:bg-blue-900 dark:text-blue-100'
                              : `${isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'}`
                          }`}
                          onClick={closeAllDropdowns}
                        >
                          {item.name}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              )
            )}
          </div>
          
          {/* Mobile authentication */}
          <div className={`pt-4 pb-3 border-t ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
            {isAuthenticated ? (
              <div>
                <div className="flex items-center px-5">
                  <div className="flex-shrink-0">
                    <div className="h-10 w-10 rounded-full bg-blue-600 flex items-center justify-center text-white">
                      {userName.charAt(0).toUpperCase()}
                    </div>
                  </div>
                  <div className="ml-3">
                    <div className={`text-base font-medium ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>{userName}</div>
                    <div className={`text-sm font-medium ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{userEmail}</div>
                  </div>
                </div>
                <div className="mt-3 px-2 space-y-1">
                  <a
                    href="/account"
                    className={`block px-3 py-2 rounded-md text-base font-medium ${isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'} hover:text-gray-900`}
                    onClick={closeAllDropdowns}
                  >
                    Your Account
                  </a>
                  <a
                    href="/account/settings"
                    className={`block px-3 py-2 rounded-md text-base font-medium ${isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'} hover:text-gray-900`}
                    onClick={closeAllDropdowns}
                  >
                    Settings
                  </a>
                  <button
                    className={`block w-full text-left px-3 py-2 rounded-md text-base font-medium ${isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'} hover:text-gray-900`}
                    onClick={() => {
                      onSignOut();
                      closeAllDropdowns();
                    }}
                  >
                    Sign out
                  </button>
                </div>
              </div>
            ) : (
              <div className="px-2 space-y-1">
                <button
                  onClick={() => {
                    onSignIn();
                    closeAllDropdowns();
                  }}
                  className={`block w-full text-left px-3 py-2 rounded-md text-base font-medium ${isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'} hover:text-gray-900`}
                >
                  Sign in
                </button>
                <button
                  onClick={() => {
                    onSignUp();
                    closeAllDropdowns();
                  }}
                  className="block w-full text-left px-3 py-2 rounded-md text-base font-medium bg-blue-600 text-white hover:bg-blue-700"
                >
                  Sign up
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}

function StoryComponent() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };
  
  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-900'}`}>
      {/* Dark mode toggle */}
      <div className="fixed bottom-4 right-4 z-50">
        <button 
          onClick={toggleDarkMode}
          className={`p-3 rounded-full shadow-lg ${isDarkMode ? 'bg-gray-800 text-yellow-400' : 'bg-white text-gray-800'}`}
        >
          <i className={`fas ${isDarkMode ? 'fa-sun' : 'fa-moon'}`}></i>
        </button>
      </div>
      
      {/* Navigation examples */}
      <div className="pt-20 px-4">
        <h1 className={`text-2xl font-bold mb-8 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Navigation Component Examples</h1>
        
        <div className="space-y-16">
          {/* Example 1: Not authenticated */}
          <div>
            <h2 className={`text-xl font-semibold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Not Authenticated</h2>
            <div className="relative h-16">
              <MainComponent 
                activePage="home" 
                isAuthenticated={false}
                isDarkMode={isDarkMode}
                onSignIn={() => alert('Sign in clicked')}
                onSignUp={() => alert('Sign up clicked')}
              />
            </div>
          </div>
          
          {/* Example 2: Authenticated */}
          <div>
            <h2 className={`text-xl font-semibold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Authenticated User</h2>
            <div className="relative h-16">
              <MainComponent 
                activePage="ar-simulator" 
                isAuthenticated={true}
                userName="John Doe"
                userEmail="john.doe@example.com"
                isDarkMode={isDarkMode}
                onSignOut={() => alert('Sign out clicked')}
              />
            </div>
          </div>
          
          {/* Example 3: Active Dropdown */}
          <div>
            <h2 className={`text-xl font-semibold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>With Active Dropdown Item</h2>
            <div className="relative h-16">
              <MainComponent 
                activePage="my-configurations" 
                isAuthenticated={true}
                userName="Jane Smith"
                userEmail="jane.smith@example.com"
                isDarkMode={isDarkMode}
                onSignOut={() => alert('Sign out clicked')}
              />
            </div>
          </div>
          
          {/* Example 4: Pricing Page */}
          <div>
            <h2 className={`text-xl font-semibold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Pricing Page</h2>
            <div className="relative h-16">
              <MainComponent 
                activePage="pricing" 
                isAuthenticated={true}
                userName="Alex Johnson"
                userEmail="alex@example.com"
                isDarkMode={isDarkMode}
                onSignOut={() => alert('Sign out clicked')}
              />
            </div>
          </div>
        </div>
        
        <div className="h-32"></div> {/* Spacer at bottom */}
      </div>
    </div>
  );
});
}