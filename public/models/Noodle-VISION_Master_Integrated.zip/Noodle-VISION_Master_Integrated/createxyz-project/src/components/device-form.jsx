"use client";
import React from "react";

import { useUpload } from '../utilities/runtime-helpers'

export default function Index() {
  return (function MainComponent({ onSubmit }) {
  const [name, setName] = React.useState("");
  const [category, setCategory] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [imageUrl, setImageUrl] = React.useState("");
  const [imageMethod, setImageMethod] = React.useState("url");
  const [ports, setPorts] = React.useState([{ type: "", count: 1 }]);
  const [error, setError] = React.useState(null);
  
  const useUpload = () => {
    const [loading, setLoading] = React.useState(false);
    const uploadFile = async ({ file: fileToUpload }) => {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 1000)); 
      setLoading(false);
      if (typeof window !== 'undefined' && fileToUpload.name.startsWith("error")) {
        return { url: null, error: "Simulated upload error" };
      }
      if (typeof window !== 'undefined' && typeof URL !== 'undefined') {
        return { url: URL.createObjectURL(fileToUpload), error: null };
      }
      return { url: "simulated_url_for_ssr", error: null};
    };
    return [uploadFile, { loading }];
  };
  const [upload, { loading: uploading }] = useUpload();


  const [uploadedImageUrl, setUploadedImageUrl] = React.useState(null);
  const [file, setFile] = React.useState(null);
  const [previewUrl, setPreviewUrl] = React.useState(null);
  const [analyzing, setAnalyzing] = React.useState(false);
  const [analysisResult, setAnalysisResult] = React.useState(null);

  const handleAddPort = () => {
    setPorts([...ports, { type: "", count: 1 }]);
  };

  const handleRemovePort = (index) => {
    const newPorts = [...ports];
    newPorts.splice(index, 1);
    setPorts(newPorts);
  };

  const handlePortChange = (index, field, value) => {
    const newPorts = [...ports];
    if (field === "count") {
      newPorts[index][field] = parseInt(value, 10) >= 1 ? parseInt(value, 10) : 1;
    } else {
      newPorts[index][field] = value;
    }
    setPorts(newPorts);
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      setUploadedImageUrl(null); 
      setError(null);

      if (typeof window !== 'undefined' && typeof FileReader !== 'undefined') {
        const fileReader = new FileReader();
        fileReader.onload = (event) => {
          setPreviewUrl(event.target.result);
        };
        fileReader.readAsDataURL(selectedFile);
      }


      setAnalysisResult(null);
    }
  };

  const handleUploadImage = async () => {
    if (!file) return null;

    try {
      setError(null);
      const { url, error: uploadError } = await upload({ file });

      if (uploadError) {
        setError(uploadError);
        return null;
      }

      setUploadedImageUrl(url);
      return url;
    } catch (err) {
      setError("Failed to upload image: " + err.message);
      console.error(err);
      return null;
    }
  };

  const analyzeImage = async () => {
    try {
      setAnalyzing(true);
      setError(null);

      let imageToAnalyzeUrl = imageMethod === "url" ? imageUrl : uploadedImageUrl;

      if (imageMethod === "upload" && !uploadedImageUrl && file) {
        imageToAnalyzeUrl = await handleUploadImage();
        if (!imageToAnalyzeUrl) {
          setError("Failed to upload image for analysis. Please try uploading again.");
          setAnalyzing(false);
          return;
        }
      }
      
      if (!imageToAnalyzeUrl && !(imageMethod === "upload" && previewUrl)) {
         setError("Please provide an image URL or upload an image to analyze.");
         setAnalyzing(false);
         return;
      }

      let imageContentForApi;
      if (imageMethod === "upload") {
        imageContentForApi = uploadedImageUrl || previewUrl;
      } else {
        imageContentForApi = imageUrl;
      }

      if (!imageContentForApi) {
        setError("No image content available for analysis.");
        setAnalyzing(false);
        return;
      }


      const messages = [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this device image and provide the following information in JSON format: deviceName, category (one of: Display, Audio, Computer, Gaming, Automotive, Security, Other), description, ports (array of objects with type and count), and any additional notes. Focus on identifying all visible ports and connectors.",
            },
            {
              type: "image_url",
              image_url: {
                url: imageContentForApi,
              },
            },
          ],
        },
      ];

      const response = await fetch("/integrations/gpt-vision/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ messages }),
      });

      if (!response.ok) {
        throw new Error(`GPT Vision API returned ${response.status}`);
      }

      const data = await response.json();

      if (
        !data.choices ||
        !data.choices[0] ||
        !data.choices[0].message ||
        !data.choices[0].message.content
      ) {
        throw new Error("Invalid response from GPT Vision API");
      }

      const content = data.choices[0].message.content;
      let analysisData;

      try {
        const jsonMatch =
          content.match(/json\n([\s\S]*?)\n/) || content.match(/{[\s\S]*?}/);
        const jsonString = jsonMatch ? jsonMatch[1] || jsonMatch[0] : content;
        analysisData = JSON.parse(jsonString.trim());
      } catch (e) {
        console.error("Failed to parse JSON from response:", e);
        console.log("Raw content:", content);
        analysisData = {
          deviceName: (content.match(/deviceName["'\s:]+([^"'\n,]+)/i) || [])[1]?.replace(/["']/g, '').trim() || "",
          category: (content.match(/category["'\s:]+([^"'\n,]+)/i) || [])[1]?.replace(/["']/g, '').trim() || "",
          description: (content.match(/description["'\s:]+([^"'\n,]+)/i) || [])[1]?.replace(/["']/g, '').trim() || "",
          notes: (content.match(/notes["'\s:]+([^"'\n,]+)/i) || [])[1]?.replace(/["']/g, '').trim() || "",
          ports: [],
        };
        const portsMatch = content.match(/ports["'\s:]+\[([\s\S]*?)\]/i);
        if (portsMatch && portsMatch[1]) {
          const portsText = portsMatch[1];
          const portMatches = [...portsText.matchAll(/{\s*["']?type["']?\s*:\s*["']?([^"'\n,}]+)["']?,\s*["']?count["']?\s*:\s*(\d+)\s*}/gi)];
          if (portMatches) {
            analysisData.ports = portMatches.map(match => ({
              type: match[1]?.replace(/["']/g, '').trim(),
              count: parseInt(match[2], 10) || 1,
            }));
          }
        }
      }

      setAnalysisResult(analysisData);

      if (analysisData) {
        if (analysisData.deviceName && !name) {
          setName(analysisData.deviceName);
        }
        if (analysisData.category && !category) {
          const categories = ["Display", "Audio", "Computer", "Gaming", "Automotive", "Security", "Other"];
          const detectedCategory = categories.find(cat => analysisData.category.toLowerCase().includes(cat.toLowerCase())) || "Other";
          setCategory(detectedCategory);
        }
        if (analysisData.description && !description) {
          setDescription(analysisData.description);
        }
        if (analysisData.ports && Array.isArray(analysisData.ports) && analysisData.ports.length > 0) {
          const detectedPorts = analysisData.ports.map(port => ({
            type: port.type || "",
            count: port.count || 1,
          }));
          setPorts(detectedPorts);
        }
      }
    } catch (err) {
      setError("Image analysis failed: " + err.message);
      console.error("Analysis error:", err);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let finalImageUrl = imageUrl;

    if (imageMethod === "upload") {
      if (file && !uploadedImageUrl) {
        const uploadedUrl = await handleUploadImage();
        if (!uploadedUrl) {
             setError("Image upload is required for submission. Please upload the image or try again.");
             return;
        }
        finalImageUrl = uploadedUrl;
      } else {
        finalImageUrl = uploadedImageUrl;
      }
    }
    

    const portsObject = {};
    ports.forEach((port) => {
      if (port.type) {
        portsObject[port.type] = (portsObject[port.type] || 0) + port.count;
      }
    });

    onSubmit({
      name,
      category,
      description,
      image_url: finalImageUrl,
      ports: portsObject,
      analysis: analysisResult,
    });

    setName("");
    setCategory("");
    setDescription("");
    setImageUrl("");
    setImageMethod("url");
    setPorts([{ type: "", count: 1 }]);
    setFile(null);
    setPreviewUrl(null);
    setUploadedImageUrl(null);
    setAnalysisResult(null);
  };

  const portTypeOptions = ["HDMI", "USB-C", "USB-A", "DisplayPort", "VGA", "Ethernet", "Thunderbolt", "Lightning", "Audio (3.5mm)", "RCA", "Optical", "Other"];
  const categoryOptions = ["Display", "Audio", "Computer", "Gaming", "Automotive", "Security", "Networking", "Accessory", "Other"];

  return (
    <form onSubmit={handleSubmit} className="space-y-6 p-4 md:p-6 bg-white dark:bg-gray-800 rounded-lg shadow font-sans">
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
          <strong className="font-bold">Error: </strong>
          <span className="block sm:inline">{error}</span>
        </div>
      )}

      <div>
        <label htmlFor="deviceName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Device Name</label>
        <input
          type="text"
          id="deviceName"
          name="deviceName"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          required
        />
      </div>

      <div>
        <label htmlFor="deviceCategory" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Category</label>
        <select
          id="deviceCategory"
          name="deviceCategory"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          required
        >
          <option value="">Select a category</option>
          {categoryOptions.map(cat => <option key={cat} value={cat}>{cat}</option>)}
        </select>
      </div>

      <div>
        <label htmlFor="deviceDescription" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Description</label>
        <textarea
          id="deviceDescription"
          name="deviceDescription"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows="3"
          className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
        ></textarea>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Image</label>
        <div className="mt-1 flex space-x-4">
          <label className="inline-flex items-center">
            <input type="radio" name="imageMethod" value="url" checked={imageMethod === "url"} onChange={() => { setImageMethod("url"); setFile(null); setPreviewUrl(null); setUploadedImageUrl(null); }} className="form-radio h-4 w-4 text-indigo-600 dark:text-indigo-400 border-gray-300 dark:border-gray-600 focus:ring-indigo-500 dark:focus:ring-indigo-400 bg-white dark:bg-gray-700" />
            <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">URL</span>
          </label>
          <label className="inline-flex items-center">
            <input type="radio" name="imageMethod" value="upload" checked={imageMethod === "upload"} onChange={() => { setImageMethod("upload"); setImageUrl(""); }} className="form-radio h-4 w-4 text-indigo-600 dark:text-indigo-400 border-gray-300 dark:border-gray-600 focus:ring-indigo-500 dark:focus:ring-indigo-400 bg-white dark:bg-gray-700" />
            <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Upload</span>
          </label>
        </div>
      </div>

      {imageMethod === "url" && (
        <div>
          <label htmlFor="imageUrl" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Image URL</label>
          <input
            type="url"
            id="imageUrl"
            name="imageUrl"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          />
        </div>
      )}

      {imageMethod === "upload" && (
        <div>
          <label htmlFor="imageFile" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Upload Image</label>
          <input
            type="file"
            id="imageFile"
            name="imageFile"
            accept="image/*"
            onChange={handleFileChange}
            className="mt-1 block w-full text-sm text-gray-500 dark:text-gray-400
              file:mr-4 file:py-2 file:px-4
              file:rounded-md file:border-0
              file:text-sm file:font-semibold
              file:bg-indigo-50 dark:file:bg-indigo-900 file:text-indigo-700 dark:file:text-indigo-300
              hover:file:bg-indigo-100 dark:hover:file:bg-indigo-800"
          />
          {previewUrl && (
            <div className="mt-2">
              <img src={previewUrl} alt="Preview" className="h-32 w-auto rounded-md object-contain" />
            </div>
          )}
        </div>
      )}
      
      {(imageUrl || previewUrl) && (
        <button
          type="button"
          onClick={analyzeImage}
          disabled={analyzing || uploading}
          className="mt-2 w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
        >
          {analyzing ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Analyzing...
            </>
          ) : 'Analyze Image & Auto-fill'}
        </button>
      )}

      {analysisResult && (
        <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-700 rounded-md">
          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-200">Analysis Result:</h4>
          <p className="text-xs text-gray-600 dark:text-gray-300 mt-1">
            <strong>Device Name:</strong> {analysisResult.deviceName || 'N/A'} <br />
            <strong>Category:</strong> {analysisResult.category || 'N/A'} <br />
            <strong>Description:</strong> {analysisResult.description || 'N/A'} <br />
            <strong>Notes:</strong> {analysisResult.notes || 'N/A'}
          </p>
        </div>
      )}


      <div>
        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Ports</h4>
        {ports.map((port, index) => (
          <div key={index} className="mt-2 flex items-center space-x-2">
            <select
              name={`portType-${index}`}
              value={port.type}
              onChange={(e) => handlePortChange(index, "type", e.target.value)}
              className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="">Select port type</option>
              {portTypeOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
            <input
              type="number"
              name={`portCount-${index}`}
              value={port.count}
              onChange={(e) => handlePortChange(index, "count", e.target.value)}
              min="1"
              className="block w-20 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
            <button
              type="button"
              onClick={() => handleRemovePort(index)}
              className="p-2 text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300"
            >
              <i className="fas fa-trash"></i>
            </button>
          </div>
        ))}
        <button
          type="button"
          onClick={handleAddPort}
          className="mt-2 text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 dark:hover:text-indigo-300"
        >
          + Add Port
        </button>
      </div>
      
      <div className="flex justify-end pt-4 border-t border-gray-200 dark:border-gray-700">
        <button
          type="submit"
          disabled={uploading || analyzing}
          className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
        >
          {uploading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Saving...
            </>
          ) : 'Save Device'}
        </button>
      </div>
    </form>
  );
}

function StoryComponent() {
  const [submittedData, setSubmittedData] = React.useState(null);

  const handleSubmit = (data) => {
    console.log("Device Data Submitted:", data);
    setSubmittedData(data);
  };

  return (
    <div className="p-6 bg-gray-100 dark:bg-gray-900 min-h-screen font-sans">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-100 mb-6">Add New Device</h1>
        <MainComponent onSubmit={handleSubmit} />

        {submittedData && (
          <div className="mt-8 p-6 bg-white dark:bg-gray-800 rounded-lg shadow">
            <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4">Submitted Data:</h2>
            <pre className="text-sm text-gray-700 dark:text-gray-200 bg-gray-50 dark:bg-gray-700 p-4 rounded-md overflow-x-auto">
              {JSON.stringify(submittedData, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
});
}