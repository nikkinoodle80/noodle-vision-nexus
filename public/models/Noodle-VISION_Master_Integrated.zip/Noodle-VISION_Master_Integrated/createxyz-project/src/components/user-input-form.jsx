"use client";
import React from "react";



export default function Index() {
  return (function MainComponent() {
  const [device, setDevice] = useState("");
  const [adapter, setAdapter] = useState("");
  const [wire, setWire] = useState("");
  const [feedback, setFeedback] = useState("");
  const [error, setError] = useState(null);
  const [showDetails, setShowDetails] = useState(false);
  const [status, setStatus] = useState(null); // 'success', 'warning', 'error', or null
  const [ports, setPorts] = useState([]);
  const [fetchingSpecs, setFetchingSpecs] = useState(false);

  const analyzeConfiguration = async () => {
    try {
      const response = await fetch("/integrations/google-gemini-1-5/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [
            {
              role: "user",
              content: `Analyze the following configuration: Device: ${device}, Adapter: ${adapter}, Wire: ${wire}`,
            },
          ],
        }),
      });

      if (!response.ok) {
        setStatus("error");
        throw new Error(`Error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      const feedbackMessage = data.choices[0].message.content;
      setFeedback(feedbackMessage);
      setStatus("success");
    } catch (error) {
      console.error(error);
      setError("Failed to analyze configuration");
      setStatus("error");
    }
  };

  const fetchDeviceSpecs = async () => {
    setFetchingSpecs(true);
    setError(null);
    setPorts([]);
    try {
      const response = await fetch("/integrations/web-scraping/post", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: `https://www.google.com/search?q=${encodeURIComponent(device + " specs")}`,
          getText: true,
        }),
      });
      if (!response.ok) {
        throw new Error(
          `Failed to fetch specs: ${response.status} ${response.statusText}`,
        );
      }
      const text = await response.text();
      // Try to extract port info from the text (very basic, can be improved with AI)
      const portMatches =
        text.match(
          /(USB|HDMI|AUX|Ethernet|Thunderbolt|MIDI|CV|Gate|Input|Output|In|Out)[^\n]{0,40}/gi,
        ) || [];
      setPorts([...new Set(portMatches)]);
    } catch (e) {
      console.error(e);
      setError("Could not fetch device specs.");
    } finally {
      setFetchingSpecs(false);
    }
  };

  const handleDownload = () => {
    const blob = new Blob(
      [
        `Device: ${device}\nAdapter: ${adapter}\nWire: ${wire}\n\nFeedback:\n${feedback}`,
      ],
      { type: "text/plain" },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "simulator-feedback.txt";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-4 bg-gradient-to-br from-gray-900 via-gray-800 to-blue-900 rounded-xl shadow-lg max-w-xl mx-auto mt-8 font-mono">
      <div className="mb-4 flex items-center justify-between">
        <span className="text-lg text-blue-300 font-bold tracking-widest">
          FUTURE MODULATOR SIMULATOR
        </span>
        {status === "success" && (
          <i
            className="fas fa-check-circle text-green-400 text-xl"
            title="Success"
          ></i>
        )}
        {status === "error" && (
          <i
            className="fas fa-exclamation-triangle text-red-400 text-xl"
            title="Error"
          ></i>
        )}
        {!status && (
          <i className="fas fa-robot text-blue-400 text-xl" title="Idle"></i>
        )}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-blue-200 font-semibold mb-1">
            Device
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              name="device"
              value={device}
              onChange={(e) => setDevice(e.target.value)}
              className="w-full p-2 bg-gray-800 border border-blue-700 rounded-md text-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-400"
              placeholder="Enter device name"
            />
            <button
              type="button"
              onClick={fetchDeviceSpecs}
              className="bg-blue-700 text-white px-2 py-1 rounded hover:bg-blue-600 text-xs"
              disabled={!device || fetchingSpecs}
            >
              {fetchingSpecs ? "Fetching..." : "Fetch Specs"}
            </button>
          </div>
          {ports.length > 0 && (
            <div className="mt-2 bg-gray-900 border border-blue-700 rounded p-3">
              <div className="text-blue-300 font-semibold text-sm mb-2 flex items-center">
                <i className="fas fa-microchip mr-2 text-blue-400"></i>
                Detected System Interfaces:
              </div>
              <div className="text-blue-100 text-xs max-h-28 overflow-y-auto space-y-1 pr-1">
                {ports.map((port, idx) => (
                  <div
                    key={idx}
                    className="flex items-center bg-gray-800 p-1.5 rounded-sm border-l-2 border-blue-500"
                  >
                    <i className="fas fa-caret-right text-blue-400 mr-2 text-[10px]"></i>
                    <span className="truncate">{port}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        <div>
          <label className="block text-blue-200 font-semibold mb-1">
            Adapter
          </label>
          <input
            type="text"
            name="adapter"
            value={adapter}
            onChange={(e) => setAdapter(e.target.value)}
            className="w-full p-2 bg-gray-800 border border-blue-700 rounded-md text-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-400"
            placeholder="Enter adapter type"
          />
        </div>
        <div>
          <label className="block text-blue-200 font-semibold mb-1">Wire</label>
          <input
            type="text"
            name="wire"
            value={wire}
            onChange={(e) => setWire(e.target.value)}
            className="w-full p-2 bg-gray-800 border border-blue-700 rounded-md text-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-400"
            placeholder="Enter wire type"
          />
        </div>
        <div className="flex items-end">
          <button
            onClick={analyzeConfiguration}
            className="w-full bg-blue-700 text-white font-bold py-2 px-4 rounded-md hover:bg-blue-600 shadow-md transition"
          >
            Simulate
          </button>
        </div>
      </div>
      {error && <div className="text-red-400 mt-4">{error}</div>}
      {feedback && (
        <div className="mt-8 bg-gray-950 border-2 border-blue-700 rounded-lg p-4 relative shadow-inner">
          <div className="flex items-center mb-2">
            <i className="fas fa-terminal text-blue-400 mr-2"></i>
            <span className="text-blue-200 font-semibold">
              Simulator Output
            </span>
            <button
              className="ml-auto text-blue-400 hover:text-blue-200 text-xs underline"
              onClick={() => setShowDetails((v) => !v)}
            >
              {showDetails ? "Hide Details" : "Show Details"}
            </button>
          </div>
          <div className="text-blue-100 whitespace-pre-line text-sm max-h-40 overflow-y-auto">
            {showDetails
              ? feedback
              : feedback.slice(0, 200) + (feedback.length > 200 ? "..." : "")}
          </div>
          <div className="flex gap-2 mt-4">
            <button
              onClick={analyzeConfiguration}
              className="bg-blue-800 text-white px-3 py-1 rounded hover:bg-blue-700 text-xs"
            >
              Simulate Again
            </button>
            <button
              onClick={handleDownload}
              className="bg-gray-700 text-blue-200 px-3 py-1 rounded hover:bg-gray-600 text-xs"
            >
              Download Report
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function StoryComponent() {
  return (
    <div>
      <MainComponent />
    </div>
  );
});
}