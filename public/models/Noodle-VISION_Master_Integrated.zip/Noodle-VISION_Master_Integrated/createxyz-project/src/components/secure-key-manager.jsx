"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ onSave, onTest, initialKeyType, initialKeyValue, keyTypes = [] }) {
  const [keyType, setKeyType] = useState(initialKeyType || '');
  const [keyValue, setKeyValue] = useState(initialKeyValue || '');
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [action, setAction] = useState(null);

  const defaultKeyTypes = [
    { value: 'ANTHROPIC_API_KEY', label: 'Anthropic API Key' },
    { value: 'STRIPE_SECRET_KEY', label: 'Stripe Secret Key' },
    { value: 'GOOGLE_API_KEY', label: 'Google API Key' },
    { value: 'OPENAI_API_KEY', label: 'OpenAI API Key' }
  ];

  const availableKeyTypes = keyTypes.length > 0 ? keyTypes : defaultKeyTypes;

  const maskKey = (key) => {
    if (!key) return '';
    if (key.length <= 4) return '••••';
    return '••••••••' + key.slice(-4);
  };

  const handleTest = async () => {
    if (!keyType || !keyValue) {
      setError('Please select a key type and enter a key value');
      return;
    }

    setAction('test');
    setShowConfirmation(true);
  };

  const handleSave = async () => {
    if (!keyType || !keyValue) {
      setError('Please select a key type and enter a key value');
      return;
    }

    setAction('set');
    setShowConfirmation(true);
  };

  const confirmAction = async () => {
    setShowConfirmation(false);
    setIsLoading(true);
    setError(null);
    setMessage(null);

    try {
      const response = await fetch('/api/configure-secrets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: action,
          key: keyType,
          value: keyValue
        }),
      });

      const data = await response.json();

      if (data.success) {
        setMessage(data.message || `Successfully ${action === 'test' ? 'tested' : 'saved'} ${keyType}`);
        if (action === 'set' && typeof onSave === 'function') {
          onSave(keyType, keyValue);
        } else if (action === 'test' && typeof onTest === 'function') {
          onTest(keyType, keyValue);
        }
      } else {
        setError(data.error || `Failed to ${action} key`);
      }
    } catch (err) {
      console.error(`Error ${action === 'test' ? 'testing' : 'saving'} API key:`, err);
      setError(`An error occurred while ${action === 'test' ? 'testing' : 'saving'} the API key`);
    } finally {
      setIsLoading(false);
    }
  };

  const cancelAction = () => {
    setShowConfirmation(false);
    setAction(null);
  };

  return (
    <div className="bg-white dark:bg-gray-800 border-2 border-red-500 rounded-lg p-6 max-w-md mx-auto shadow-lg">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Secure API Key Management</h2>
        <div className="bg-yellow-50 dark:bg-yellow-900/30 border-l-4 border-yellow-400 p-4 mb-4">
          <p className="text-yellow-800 dark:text-yellow-200 text-sm">
            <i className="fas fa-exclamation-triangle mr-2"></i>
            <strong>Warning:</strong> API keys provide access to sensitive services. Never share these keys or expose them in client-side code.
          </p>
        </div>
      </div>

      <form className="space-y-4">
        <div>
          <label htmlFor="keyType" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Key Type <span className="text-red-500">*</span>
          </label>
          <select
            id="keyType"
            name="keyType"
            value={keyType}
            onChange={(e) => setKeyType(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            required
          >
            <option value="">Select a key type</option>
            {availableKeyTypes.map((type) => (
              <option key={type.value} value={type.value}>
                {type.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="keyValue" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            API Key Value <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <input
              id="keyValue"
              name="keyValue"
              type="password"
              value={keyValue}
              onChange={(e) => setKeyValue(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              placeholder="Enter your API key"
              required
            />
          </div>
          <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
            {keyValue ? `Stored as: ${maskKey(keyValue)}` : 'Your key will be securely stored'}
          </p>
        </div>

        <div className="flex space-x-4 pt-2">
          <button
            type="button"
            onClick={handleTest}
            disabled={isLoading}
            className="flex-1 bg-blue-100 hover:bg-blue-200 text-blue-800 font-medium py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
          >
            {isLoading && action === 'test' ? (
              <span className="flex items-center justify-center">
                <i className="fas fa-spinner fa-spin mr-2"></i> Testing...
              </span>
            ) : (
              'Test Key'
            )}
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isLoading}
            className="flex-1 bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-colors"
          >
            {isLoading && action === 'set' ? (
              <span className="flex items-center justify-center">
                <i className="fas fa-spinner fa-spin mr-2"></i> Saving...
              </span>
            ) : (
              'Save Key'
            )}
          </button>
        </div>
      </form>

      {message && (
        <div className="mt-4 bg-green-50 dark:bg-green-900/30 border-l-4 border-green-400 p-4">
          <p className="text-green-800 dark:text-green-200 text-sm">{message}</p>
        </div>
      )}

      {error && (
        <div className="mt-4 bg-red-50 dark:bg-red-900/30 border-l-4 border-red-400 p-4">
          <p className="text-red-800 dark:text-red-200 text-sm">{error}</p>
        </div>
      )}

      {showConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-md mx-auto shadow-xl">
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
              Confirm {action === 'test' ? 'Test' : 'Save'}
            </h3>
            <p className="text-gray-700 dark:text-gray-300 mb-4">
              Are you sure you want to {action === 'test' ? 'test' : 'save'} the {keyType} key?
              {action === 'set' && ' This will overwrite any existing key of this type.'}
            </p>
            <div className="flex space-x-4">
              <button
                onClick={cancelAction}
                className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-md"
              >
                Cancel
              </button>
              <button
                onClick={confirmAction}
                className={`flex-1 font-medium py-2 px-4 rounded-md ${
                  action === 'test'
                    ? 'bg-blue-600 hover:bg-blue-700 text-white'
                    : 'bg-red-600 hover:bg-red-700 text-white'
                }`}
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StoryComponent() {
  const [savedKeys, setSavedKeys] = useState({});
  const [testResults, setTestResults] = useState({});

  const handleSave = (keyType, keyValue) => {
    setSavedKeys(prev => ({
      ...prev,
      [keyType]: keyValue
    }));
  };

  const handleTest = (keyType, keyValue) => {
    setTestResults(prev => ({
      ...prev,
      [keyType]: "Test successful"
    }));
  };

  return (
    <div className="p-8 bg-gray-100 dark:bg-gray-900 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">API Key Management</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-8">
            Securely manage your API keys for various services.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Add New API Key</h2>
            <MainComponent 
              onSave={handleSave} 
              onTest={handleTest}
            />
          </div>

          <div>
            <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">With Initial Values</h2>
            <MainComponent 
              initialKeyType="ANTHROPIC_API_KEY"
              initialKeyValue="sk_ant_1234567890abcdef"
              onSave={handleSave}
              onTest={handleTest}
            />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Saved Keys</h2>
          {Object.keys(savedKeys).length > 0 ? (
            <ul className="space-y-2">
              {Object.entries(savedKeys).map(([type, value]) => (
                <li key={type} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700 rounded">
                  <span className="font-medium text-gray-800 dark:text-white">{type}</span>
                  <span className="text-gray-500 dark:text-gray-400">
                    {'••••••••' + value.slice(-4)}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500 dark:text-gray-400 italic">No keys saved yet</p>
          )}
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Test Results</h2>
          {Object.keys(testResults).length > 0 ? (
            <ul className="space-y-2">
              {Object.entries(testResults).map(([type, result]) => (
                <li key={type} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700 rounded">
                  <span className="font-medium text-gray-800 dark:text-white">{type}</span>
                  <span className="text-green-500">{result}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500 dark:text-gray-400 italic">No keys tested yet</p>
          )}
        </div>
      </div>
    </div>
  );
});
}