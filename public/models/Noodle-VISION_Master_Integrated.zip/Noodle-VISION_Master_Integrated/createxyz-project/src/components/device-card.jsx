"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ device, onSelect, isSelected }) {
  return (
    <div 
      className={`border rounded-lg p-4 cursor-pointer transition-all ${
        isSelected ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'border-gray-200 dark:border-gray-700'
      }`}
      onClick={() => onSelect(device)}
    >
      <div className="flex items-center mb-2">
        {device.image_url ? (
          <img 
            src={device.image_url} 
            alt={device.name} 
            className="w-16 h-16 object-contain mr-3"
          />
        ) : (
          <div className="w-16 h-16 bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center mr-3">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
          </div>
        )}
        <div>
          <h3 className="font-medium text-gray-900 dark:text-white">{device.name}</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">{device.category}</p>
        </div>
      </div>
      
      {device.description && (
        <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">{device.description}</p>
      )}
      
      {device.ports && (
        <div className="mt-2">
          <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">Available Ports:</p>
          <div className="flex flex-wrap gap-1">
            {Object.entries(device.ports).map(([port, count]) => (
              <span key={port} className="text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                {port}: {count}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StoryComponent() {
  const [selectedDevice, setSelectedDevice] = useState(null);
  
  const sampleDevices = [
    {
      id: 1,
      name: "MacBook Pro 16\"",
      category: "Laptop",
      description: "Apple MacBook Pro with M1 Pro chip",
      ports: {
        "USB-C": 3,
        "HDMI": 1,
        "Headphone": 1
      }
    },
    {
      id: 2,
      name: "Dell XPS 15",
      category: "Laptop",
      description: "Dell XPS 15 with 11th Gen Intel Core i7",
      image_url: "/images/dell-xps.jpg",
      ports: {
        "USB-C": 2,
        "USB-A": 1,
        "HDMI": 1,
        "SD Card": 1
      }
    },
    {
      id: 3,
      name: "LG UltraFine 5K",
      category: "Monitor",
      description: "27-inch 5K display with Thunderbolt 3",
      ports: {
        "Thunderbolt 3": 3,
        "USB-C": 1
      }
    }
  ];
  
  const handleSelect = (device) => {
    setSelectedDevice(device.id === selectedDevice?.id ? null : device);
  };
  
  return (
    <div className="p-4 space-y-4">
      <h2 className="text-xl font-bold mb-4">Device Card Examples</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sampleDevices.map(device => (
          <MainComponent 
            key={device.id}
            device={device}
            onSelect={handleSelect}
            isSelected={selectedDevice?.id === device.id}
          />
        ))}
      </div>
    </div>
  );
});
}