"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ 
  current = 0, 
  limit = 100, 
  label = "API Usage", 
  description = "Monthly API calls", 
  unit = "calls",
  showPercentage = true,
  size = "default" // "small", "default", "large"
}) {
  const percentage = Math.min(Math.round((current / limit) * 100), 100);
  
  const getColorClass = () => {
    if (percentage < 50) return "bg-green-500";
    if (percentage < 80) return "bg-yellow-500";
    return "bg-red-500";
  };
  
  const getHeightClass = () => {
    switch(size) {
      case "small": return "h-2";
      case "large": return "h-6";
      default: return "h-4";
    }
  };
  
  const getTextSizeClass = () => {
    switch(size) {
      case "small": return "text-xs";
      case "large": return "text-base";
      default: return "text-sm";
    }
  };

  return (
    <div className="w-full font-inter">
      <div className="flex justify-between items-center mb-1">
        <div className="font-medium text-gray-800 dark:text-gray-200">{label}</div>
        <div className="text-gray-700 dark:text-gray-300 font-medium">
          {current.toLocaleString()} / {limit.toLocaleString()} {unit}
          {showPercentage && <span className="ml-2">({percentage}%)</span>}
        </div>
      </div>
      
      <div className={`w-full bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden ${getHeightClass()}`}>
        <div 
          className={`${getColorClass()} rounded-full transition-all duration-300 ease-in-out`} 
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
      
      {description && (
        <div className={`mt-1 text-gray-500 dark:text-gray-400 ${getTextSizeClass()}`}>
          {description}
        </div>
      )}
    </div>
  );
}

function StoryComponent() {
  return (
    <div className="p-8 bg-white dark:bg-gray-900 space-y-12">
      <div className="max-w-3xl mx-auto space-y-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Subscription Usage Bar Examples</h1>
        
        <div className="space-y-6">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200">Usage Levels</h2>
          
          <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-3">Low Usage (Green)</h3>
            <MainComponent 
              current={25} 
              limit={100} 
              label="API Usage" 
              description="25% of your monthly API calls used"
            />
          </div>
          
          <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-3">Medium Usage (Yellow)</h3>
            <MainComponent 
              current={65} 
              limit={100} 
              label="Storage" 
              description="65% of your storage allocation used"
              unit="GB"
            />
          </div>
          
          <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-3">High Usage (Red)</h3>
            <MainComponent 
              current={90} 
              limit={100} 
              label="Bandwidth" 
              description="90% of your monthly bandwidth used"
              unit="GB"
            />
          </div>
          
          <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-3">Exceeded Limit</h3>
            <MainComponent 
              current={120} 
              limit={100} 
              label="API Requests" 
              description="You have exceeded your monthly limit"
              unit="requests"
            />
          </div>
        </div>
        
        <div className="space-y-6">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200">Sizes</h2>
          
          <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-3">Small</h3>
            <MainComponent 
              current={45} 
              limit={100} 
              label="API Usage" 
              description="Small size variant"
              size="small"
            />
          </div>
          
          <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-3">Default</h3>
            <MainComponent 
              current={45} 
              limit={100} 
              label="API Usage" 
              description="Default size variant"
            />
          </div>
          
          <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-3">Large</h3>
            <MainComponent 
              current={45} 
              limit={100} 
              label="API Usage" 
              description="Large size variant"
              size="large"
            />
          </div>
        </div>
        
        <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-3">Without Percentage</h3>
          <MainComponent 
            current={72} 
            limit={100} 
            label="Database Connections" 
            description="Current active connections"
            showPercentage={false}
            unit="connections"
          />
        </div>
        
        <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-3">Without Description</h3>
          <MainComponent 
            current={50} 
            limit={100} 
            label="Memory Usage" 
            description=""
            unit="MB"
          />
        </div>
        
        <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-3">Enterprise Plan Example</h3>
          <MainComponent 
            current={1250} 
            limit={5000} 
            label="API Requests" 
            description="Resets on June 30, 2025"
            unit="requests"
          />
        </div>
      </div>
    </div>
  );
});
}