"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ 
  cable = {}, 
  onAddToConfig = () => {}, 
  onViewDetails = () => {} 
}) {
  const { 
    name = "", 
    type = "", 
    imageUrl = "/images/cable-default.jpg", 
    connectorA = "", 
    connectorB = "", 
    description = "", 
    specs = {} 
  } = cable;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg border border-gray-200 dark:border-gray-700 flex flex-col h-full">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={imageUrl} 
          alt={`${name} cable`} 
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
        <div className="absolute top-0 right-0 bg-blue-500 text-white px-2 py-1 text-xs font-bold rounded-bl-lg">
          {type}
        </div>
      </div>
      
      <div className="p-4 flex-grow">
        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{name}</h3>
        
        <div className="flex justify-between mb-3">
          <div className="bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded text-sm text-gray-700 dark:text-gray-300">
            <i className="fas fa-plug mr-1"></i> {connectorA}
          </div>
          <div className="text-gray-500 dark:text-gray-400 px-2">
            <i className="fas fa-arrows-alt-h"></i>
          </div>
          <div className="bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded text-sm text-gray-700 dark:text-gray-300">
            <i className="fas fa-plug mr-1"></i> {connectorB}
          </div>
        </div>
        
        <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">{description}</p>
        
        {specs && Object.keys(specs).length > 0 && (
          <div className="mb-4">
            <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1">Specifications:</h4>
            <ul className="text-xs text-gray-600 dark:text-gray-400">
              {Object.entries(specs).map(([key, value]) => (
                <li key={key} className="flex justify-between">
                  <span>{key}:</span>
                  <span className="font-medium">{value}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
      
      <div className="p-4 pt-0 mt-auto">
        <div className="flex space-x-2">
          <button 
            onClick={() => onAddToConfig(cable)}
            className="flex-1 bg-blue-500 hover:bg-blue-600 text-white py-2 px-3 rounded-md text-sm font-medium transition-colors duration-200 flex items-center justify-center"
          >
            <i className="fas fa-plus mr-1"></i> Add
          </button>
          <button 
            onClick={() => onViewDetails(cable)}
            className="flex-1 bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200 py-2 px-3 rounded-md text-sm font-medium transition-colors duration-200 flex items-center justify-center"
          >
            <i className="fas fa-info-circle mr-1"></i> Details
          </button>
        </div>
      </div>
    </div>
  );
}

function StoryComponent() {
  const sampleCables = [
    {
      id: 1,
      name: "HDMI 2.1 Cable",
      type: "Digital",
      imageUrl: "/images/hdmi-cable.jpg",
      connectorA: "HDMI",
      connectorB: "HDMI",
      description: "High-speed HDMI cable supporting 8K video, HDR, and enhanced audio return channel (eARC).",
      specs: {
        "Length": "2m",
        "Max Resolution": "8K@60Hz",
        "Bandwidth": "48 Gbps"
      }
    },
    {
      id: 2,
      name: "USB-C to DisplayPort",
      type: "Adapter",
      imageUrl: "/images/usbc-dp-cable.jpg",
      connectorA: "USB-C",
      connectorB: "DisplayPort",
      description: "Connect USB-C devices to DisplayPort monitors with this high-quality adapter cable.",
      specs: {
        "Length": "1.8m",
        "Max Resolution": "4K@60Hz",
        "Version": "DP 1.4"
      }
    },
    {
      id: 3,
      name: "Optical Audio Cable",
      type: "Audio",
      imageUrl: "/images/optical-cable.jpg",
      connectorA: "TOSLINK",
      connectorB: "TOSLINK",
      description: "Digital optical audio cable for high-quality sound transmission between audio devices.",
      specs: {
        "Length": "1.5m",
        "Type": "Fiber Optic",
        "Connector": "TOSLINK"
      }
    }
  ];

  const handleAddToConfig = (cable) => {
    console.log("Adding to configuration:", cable.name);
  };

  const handleViewDetails = (cable) => {
    console.log("Viewing details for:", cable.name);
  };

  return (
    <div className="p-6 bg-gray-100 dark:bg-gray-900 min-h-screen">
      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Cable Card Component</h2>
      
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">Standard View</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {sampleCables.map(cable => (
            <MainComponent 
              key={cable.id}
              cable={cable}
              onAddToConfig={handleAddToConfig}
              onViewDetails={handleViewDetails}
            />
          ))}
        </div>
      </div>
      
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">Minimal Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <MainComponent 
            cable={{
              name: "Basic HDMI Cable",
              type: "Digital",
              connectorA: "HDMI",
              connectorB: "HDMI",
              description: "Standard HDMI cable for connecting devices."
            }}
            onAddToConfig={handleAddToConfig}
            onViewDetails={handleViewDetails}
          />
          <MainComponent 
            cable={{
              name: "RCA Audio Cable",
              type: "Analog",
              imageUrl: "/images/rca-cable.jpg",
              connectorA: "RCA",
              connectorB: "RCA"
            }}
            onAddToConfig={handleAddToConfig}
            onViewDetails={handleViewDetails}
          />
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">Empty State</h3>
        <div className="max-w-sm">
          <MainComponent 
            onAddToConfig={handleAddToConfig}
            onViewDetails={handleViewDetails}
          />
        </div>
      </div>
    </div>
  );
});
}