"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ plan, currentPlan, onSelectPlan }) {
  const isCurrentPlan = currentPlan && currentPlan.id === plan.id;
  const features = plan.features ? JSON.parse(plan.features) : {};

  return (
    <div
      className={`border rounded-lg p-6 shadow-sm transition-all ${isCurrentPlan ? "border-blue-500 bg-blue-50" : "hover:shadow-md"}`}
    >
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-xl font-bold">{plan.name}</h3>
          <p className="text-gray-600 mt-1">{plan.description}</p>
        </div>
        {isCurrentPlan && (
          <span className="bg-blue-500 text-white text-xs px-2 py-1 rounded-full">
            Current Plan
          </span>
        )}
      </div>

      <div className="mt-4">
        <span className="text-3xl font-bold">
          ${parseFloat(plan.price).toFixed(2)}
        </span>
        <span className="text-gray-500">/{plan.interval}</span>
      </div>

      <div className="mt-6">
        <h4 className="font-semibold mb-2">Features:</h4>
        <ul className="space-y-2">
          {features.basic_compatibility && (
            <li className="flex items-center">
              <svg
                className="w-5 h-5 text-green-500 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M5 13l4 4L19 7"
                ></path>
              </svg>
              Basic compatibility checking
            </li>
          )}
          {features.ai_analysis && (
            <li className="flex items-center">
              <svg
                className="w-5 h-5 text-green-500 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M5 13l4 4L19 7"
                ></path>
              </svg>
              AI-powered analysis
            </li>
          )}
          <li className="flex items-center">
            <svg
              className="w-5 h-5 text-green-500 mr-2"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M5 13l4 4L19 7"
                ></path>
            </svg>
            {plan.api_calls_limit === null ? "Unlimited" : plan.api_calls_limit}{" "}
            AI analyses per month
          </li>
          <li className="flex items-center">
            <svg
              className="w-5 h-5 text-green-500 mr-2"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M5 13l4 4L19 7"
                ></path>
            </svg>
            {features.saved_configurations === null
              ? "Unlimited"
              : features.saved_configurations}{" "}
            saved configurations
          </li>
          {features.priority_support && (
            <li className="flex items-center">
              <svg
                className="w-5 h-5 text-green-500 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M5 13l4 4L19 7"
                ></path>
              </svg>
              Priority support
            </li>
          )}
          {features.team_access && (
            <li className="flex items-center">
              <svg
                className="w-5 h-5 text-green-500 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M5 13l4 4L19 7"
                ></path>
              </svg>
              Team collaboration
            </li>
          )}
          {features.custom_devices && (
            <li className="flex items-center">
              <svg
                className="w-5 h-5 text-green-500 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M5 13l4 4L19 7"
                ></path>
              </svg>
              Custom device definitions
            </li>
          )}
          {plan.name === "Enterprise" && (
            <li className="flex items-center">
              <svg
                className="w-5 h-5 text-green-500 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M5 13l4 4L19 7"
                ></path>
              </svg>
              API access for integrations
            </li>
          )}
        </ul>
      </div>

      <div className="mt-8">
        {isCurrentPlan ? (
          <button
            className="w-full py-2 px-4 bg-gray-200 text-gray-800 rounded-md font-medium"
            disabled
          >
            Current Plan
          </button>
        ) : (
          <button
            onClick={() => onSelectPlan(plan)}
            className="w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-md font-medium transition-colors"
          >
            {plan.price > 0 ? "Subscribe" : "Select Free Plan"}
          </button>
        )}
      </div>
    </div>
  );
}

function StoryComponent() {
  const freePlan = {
    id: 1,
    name: "Free",
    description: "Basic compatibility checking",
    price: 0,
    interval: "month",
    api_calls_limit: 10,
    features: JSON.stringify({
      basic_compatibility: true,
      saved_configurations: 3,
    }),
  };

  const proPlan = {
    id: 2,
    name: "Pro",
    description: "Advanced features for power users",
    price: 9.99,
    interval: "month",
    api_calls_limit: 100,
    features: JSON.stringify({
      basic_compatibility: true,
      ai_analysis: true,
      saved_configurations: 20,
      priority_support: true,
    }),
  };

  const enterprisePlan = {
    id: 3,
    name: "Enterprise",
    description: "Complete solution for teams",
    price: 29.99,
    interval: "month",
    api_calls_limit: null,
    features: JSON.stringify({
      basic_compatibility: true,
      ai_analysis: true,
      saved_configurations: null,
      priority_support: true,
      team_access: true,
      custom_devices: true,
    }),
  };

  const currentPlan = proPlan;

  const handleSelectPlan = (plan) => {
    console.log("Selected plan:", plan.name);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6">
      <MainComponent
        plan={freePlan}
        currentPlan={currentPlan}
        onSelectPlan={handleSelectPlan}
      />
      <MainComponent
        plan={proPlan}
        currentPlan={currentPlan}
        onSelectPlan={handleSelectPlan}
      />
      <MainComponent
        plan={enterprisePlan}
        currentPlan={currentPlan}
        onSelectPlan={handleSelectPlan}
      />
    </div>
  );
});
}