"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ initialPosition }) {
  const [position, setPosition] = useState(initialPosition);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState(null);
  const gridSize = 20; // Snap to grid size
  const boundary = { x: 400, y: 400 }; // Boundary constraints

  useEffect(() => {
    const fetchPosition = async () => {
      try {
        const response = await fetch("/api/get-cable-position", {
          method: "POST",
        });
        const data = await response.json();
        if (data) {
          setPosition({ x: data.x, y: data.y });
        }
      } catch (error) {
        console.error("Failed to fetch cable position", error);
        setError("Could not load cable position");
      }
    };
    fetchPosition();
  }, []);

  const handleMouseDown = (e) => {
    setDragging(true);
  };

  const handleMouseUp = async () => {
    setDragging(false);
    try {
      const response = await fetch("/api/update-cable-position", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ x: position.x, y: position.y }),
      });
      const data = await response.json();
      if (data.error) {
        setError(data.error);
      }
    } catch (error) {
      console.error("Failed to update cable position", error);
      setError("Could not update cable position");
    }
  };

  const handleMouseMove = (e) => {
    if (dragging) {
      setPosition((prevPosition) => {
        let newX = prevPosition.x + e.movementX;
        let newY = prevPosition.y + e.movementY;

        // Snap to grid
        newX = Math.round(newX / gridSize) * gridSize;
        newY = Math.round(newY / gridSize) * gridSize;

        // Boundary constraints
        newX = Math.max(0, Math.min(boundary.x, newX));
        newY = Math.max(0, Math.min(boundary.y, newY));

        return { x: newX, y: newY };
      });
    }
  };

  const handleKeyDown = (e) => {
    if (!dragging) return;
    let deltaX = 0;
    let deltaY = 0;
    switch (e.key) {
      case "ArrowUp":
        deltaY = -gridSize;
        break;
      case "ArrowDown":
        deltaY = gridSize;
        break;
      case "ArrowLeft":
        deltaX = -gridSize;
        break;
      case "ArrowRight":
        deltaX = gridSize;
        break;
      default:
        return;
    }
    setPosition((prevPosition) => {
      let newX = prevPosition.x + deltaX;
      let newY = prevPosition.y + deltaY;

      // Boundary constraints
      newX = Math.max(0, Math.min(boundary.x, newX));
      newY = Math.max(0, Math.min(boundary.y, newY));

      return { x: newX, y: newY };
    });
  };

  return (
    <div
      style={{
        position: "absolute",
        left: position.x,
        top: position.y,
        cursor: dragging ? "grabbing" : "grab",
        transition: "transform 0.1s ease, box-shadow 0.2s ease-in-out",
        boxShadow: dragging
          ? "0 0 15px rgba(0,0,0,0.7)"
          : "0 0 5px rgba(0,0,0,0.3)",
        border: "2px dashed #4A90E2",
        borderRadius: "8px",
        backgroundColor: dragging ? "rgba(74, 144, 226, 0.1)" : "transparent",
      }}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseDown={handleMouseDown}
      onKeyDown={handleKeyDown}
      tabIndex={0} // Make div focusable for keyboard events
    >
      {error && <div style={{ color: "red" }}>{error}</div>}
      <></>
    </div>
  );
}

function StoryComponent() {
  return (
    <div className="w-full h-[400px] bg-gray-100 relative">
      <MainComponent initialPosition={{ x: 50, y: 50 }} />
    </div>
  );
}

<style jsx>{`
  .draggable {
    transition: box-shadow 0.2s ease-in-out;
  }
  .draggable:active {
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.7);
  }
`}</style>;);
}